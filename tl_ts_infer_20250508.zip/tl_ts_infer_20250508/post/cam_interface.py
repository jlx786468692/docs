import math
import numpy as np
from utils  import _cam_matrix_mult

MET_TL_TRACK_WIDTH=0.6
MET_TS_TRACK_WIDTH2=0.9
def met_cam_ProjectIWGW2G(K,pwidth, gwidth, px):#K--array
    x = -(K[11]+K[1] * gwidth / pwidth) / K[8]
    y = (K[0] * x+K[3]-(K[8] * px * x+px * K[11])) / (px * K[9]-K[1])
    wX = x
    WY = y
    return wX,WY

def TL_2Dto3D(K,comInfo,detItem):#detItem[0-3]--[xmin ymin xmax ymax] [4-6]--cam_x,cam_y,cam_z
    global MET_TL_TRACK_WIDTH
    xmin, ymin, xmax, ymax = detItem[0],detItem[1],detItem[2],detItem[3]
    vanishx,vanishy = comInfo[0],comInfo[1]
    px = (xmax + xmin) / 2
    py = (ymax + ymin) / 2
    uwidth = xmax - xmin
    uheight = ymax - ymin
    if uwidth > uheight:
        uwidth = uheight
    detItem[4],detItem[5] = met_cam_ProjectIWGW2G(K, uwidth, MET_TL_TRACK_WIDTH,px)
    detItem[4],detItem[6] = met_cam_ProjectIWGW2G(K, uwidth, MET_TL_TRACK_WIDTH,py+vanishx-vanishy)
    return detItem

def TS_2Dto3D(K,comInfo,obj):
    global MET_TS_TRACK_WIDTH2
    xmin, ymin, xmax, ymax = obj[0], obj[1], obj[2], obj[3]
    vanishx, vanishy = comInfo[0], comInfo[1]
    uheight = ymax - ymin
    px = (xmax + xmin) / 2
    py = (ymax + ymin) / 2
    width = MET_TS_TRACK_WIDTH2
    obj[4], obj[5] = met_cam_ProjectIWGW2G(K, uheight, width, px)
    obj[4], obj[6] = met_cam_ProjectIWGW2G(K, uheight, width, py+vanishx-vanishy)
    return obj

def Init(rxyz,camExt_position_xyz,focal_length,pixel_pitch_xy,principal_point_xy):
######################setting#################
    rx=rxyz[0]
    ry=rxyz[1]
    rz=rxyz[2]
    pixel_pitch_x = pixel_pitch_xy[0]
    principal_point_x =principal_point_xy[0]
    pixel_pitch_y =pixel_pitch_xy[1]
    principal_point_y =principal_point_xy[1]
    camExt_position_x = camExt_position_xyz[0]
    camExt_position_y = camExt_position_xyz[1]
    camExt_position_z = camExt_position_xyz[2]
######################setting#################
    Rx = np.zeros(16)
    Ry = np.zeros(16)
    Rz = np.zeros(16)
    Rr = np.zeros(16)
    Rrot = np.zeros(16)
    Ttrs  = np.zeros(16)
    tempRMatrix1 = np.zeros(16)
    tempRMatrix2 = np.zeros(16)
    Cint =np.zeros(16)
    K = np.zeros(16)

    Rr[0] = 0.0
    Rr[1] = -1.0
    Rr[2] = 0.0
    Rr[3] = 0.0

    Rr[4] = 0.0
    Rr[5] = 0.0
    Rr[6] = -1.0
    Rr[7] = 0.0

    Rr[8] = 1.0
    Rr[9] = 0.0
    Rr[10] = 0.0
    Rr[11] = 0.0

    Rr[12] = 0.0
    Rr[13] = 0.0
    Rr[14] = 0.0
    Rr[15] = 1.0


    Rx[0] = 1.0
    Rx[1] = 0.0
    Rx[2] = 0.0
    Rx[3] = 0.0

    Rx[4] = 0.0
    Rx[5] = np.cos(rx)
    Rx[6] = np.sin(rx)
    Rx[7] = 0.0

    Rx[8] = 0.0
    Rx[9] = -np.sin(rx)
    Rx[10] = np.cos(rx)
    Rx[11] = 0.0

    Rx[12] = 0.0
    Rx[13] = 0.0
    Rx[14] = 0.0
    Rx[15] = 1.0

    
    Ry[0] = np.cos(ry)
    Ry[1] = 0.0
    Ry[2] = -np.sin(ry)
    Ry[3] = 0.0

    Ry[4] = 0.0
    Ry[5] = 1.0
    Ry[6] = 0.0
    Ry[7] = 0.0

    Ry[8] = np.sin(ry)
    Ry[9] = 0.0
    Ry[10] = np.cos(ry)
    Ry[11] = 0.0

    Ry[12] = 0.0
    Ry[13] = 0.0
    Ry[14] = 0.0
    Ry[15] = 1.0


    Rz[0] = np.cos(rz)
    Rz[1] = np.sin(rz)
    Rz[2] = 0.0
    Rz[3] = 0.0

    Rz[4] = -np.sin(rz)
    Rz[5] = np.cos(rz)
    Rz[6] = 0.0
    Rz[7] = 0.0

    Rz[8] = 0.0
    Rz[9] = 0.0
    Rz[10] = 1.0
    Rz[11] = 0.0

    Rz[12] = 0.0
    Rz[13] = 0.0
    Rz[14] = 0.0
    Rz[15] = 1.0
    
    Cint[0] = focal_length / pixel_pitch_x
    Cint[1] = 0.0
    Cint[2] = principal_point_x
    Cint[3] = 0.0
    Cint[4] = 0.0
    Cint[5] = focal_length / pixel_pitch_y
    Cint[6] = principal_point_y
    Cint[7] = 0.0
    Cint[8] = 0.0
    Cint[9] = 0.0
    Cint[10] = 1.0
    Cint[11] = 0.0
    Cint[12] = 0.0
    Cint[13] = 0.0
    Cint[14] = 0.0
    Cint[15] = 1.0

    Rr_1 = Rr.reshape(4, 4)
    Rx_1 = Rx.reshape(4, 4)
    Ry_1 = Ry.reshape(4, 4)
    Rz_1 = Rz.reshape(4, 4)
    Cint_1 = Cint.reshape(4, 4)

    tempRMatrix1 = np.matmul(Rx_1, Ry_1)
    tempRMatrix2 = np.matmul(tempRMatrix1, Rz_1)
    Rrot = np.matmul(Rr_1, tempRMatrix2)


    Ttrs[0] = 1.0
    Ttrs[1] = 0.0
    Ttrs[2] = 0.0
    Ttrs[3] = -camExt_position_x
    Ttrs[4] = 0.0
    Ttrs[5] = 1.0
    Ttrs[6] = 0.0
    Ttrs[7] = -camExt_position_y
    Ttrs[8] = 0.0
    Ttrs[9] = 0.0
    Ttrs[10] = 1.0
    Ttrs[11] = -camExt_position_z
    Ttrs[12] = 0.0
    Ttrs[13] = 0.0
    Ttrs[14] = 0.0
    Ttrs[15] = 1.0
    Ttrs_1 = Ttrs.reshape(4, 4)

    tempRMatrix1 = np.matmul(Cint_1, Rrot)
    K = np.matmul(tempRMatrix1, Ttrs_1)
    return K


# rxyz=np.zeros(3)
# rxyz[0] = 1.6080659423017158 * math.pi / 180
# rxyz[1] = 1.5684645973510274 * math.pi / 180
# rxyz[2] = 3.1402112835371545 * math.pi / 180
# camExt_position_xyz = np.zeros(3)
# camExt_position_xyz[0] = 2.0773722782444124
# camExt_position_xyz[1] = -0.007406776651538639
# camExt_position_xyz[2] = 1.3577889458447912
# focal_length = 0.0038193
# pixel_pitch_xy = np.zeros(2)
# pixel_pitch_xy[0] = 0.0000029
# pixel_pitch_xy[1] = 0.0000029
# principal_point_xy = np.zeros(2)
# principal_point_xy[0] = 1456.000000
# principal_point_xy[1] = 592.000000
# print(rxyz)

rxyz=np.zeros(3)
# roll: 1.6080659423017158
# pitch: 3.1402112835371545
# yaw: 1.5684645973510274
rxyz[0] = 1.6080659423017158 * math.pi / 180
rxyz[1] = 3.1402112835371545 * math.pi / 180
rxyz[2] = 1.5684645973510274 * math.pi / 180
camExt_position_xyz = np.zeros(3)
camExt_position_xyz[0] = 2.0773722782444124
camExt_position_xyz[1] = -0.007406776651538639
camExt_position_xyz[2] = 1.3577889458447912
pixel_pitch_xy = np.zeros(2)
pixel_pitch_xy[0] = 0.0000021
pixel_pitch_xy[1] = 0.0000021
focal_length =0.0051024
principal_point_xy = np.zeros(2)
principal_point_xy[0]=3599.500000
principal_point_xy[1]=1199.500000


K_val = Init(rxyz,camExt_position_xyz,focal_length,pixel_pitch_xy,principal_point_xy)
# print(K_val)
K_val = K_val.flatten()

comInfo = np.zeros(2)
comInfo[0] = 3600
comInfo[1] = 1200

# 3763 1063 3788 1137
# 3846 1058 3873 1126
# 4610 1189 4623 1219
# 5046 1128 5083 1193
# 6531 606 6637 763

detItem = np.zeros(7)

detItem[0] = 3763
detItem[1] = 1063
detItem[2] = 3788
detItem[3] = 1137

detout = TL_2Dto3D(K_val, comInfo, detItem)
print("tl1-x,y,z:", detout[4], detout[5], detout[6])


detItem[0] = 3846
detItem[1] = 1058
detItem[2] = 3873
detItem[3] = 1126

detout = TL_2Dto3D(K_val, comInfo, detItem)
print("tl2-x,y,z:", detout[4], detout[5], detout[6])

detItem[0] = 4610
detItem[1] = 1189
detItem[2] = 4623
detItem[3] = 1219

detout = TL_2Dto3D(K_val, comInfo, detItem)
print("tl3-x,y,z:", detout[4], detout[5], detout[6])

detItem[0] = 5046
detItem[1] = 1128
detItem[2] = 5083
detItem[3] = 1193

detout = TL_2Dto3D(K_val, comInfo, detItem)
print("tl4-x,y,z:", detout[4], detout[5], detout[6])

detItem[0] = 6531
detItem[1] = 606
detItem[2] = 6637
detItem[3] = 763

detout = TL_2Dto3D(K_val, comInfo, detItem)
print("tl5-x,y,z:", detout[4], detout[5], detout[6])


# 3497 1056 3543 1111
# 3890 1132 3915 1158

detItem[0] = 3497
detItem[1] = 1056
detItem[2] = 3543
detItem[3] = 1111

detout = TS_2Dto3D(K_val, comInfo, detItem)
print("ts1-x,y,z:", detout[4], detout[5], detout[6])

detItem[0] = 3890
detItem[1] = 1132
detItem[2] = 3915
detItem[3] = 1158

detout = TS_2Dto3D(K_val, comInfo, detItem)
print("ts1-x,y,z:", detout[4], detout[5], detout[6])

