import numpy as np
def _cam_matrix_mult_new(AB, A, rowNumA, colNumA, B, rowNumB, colNumB):
    if colNumA != rowNumB:
        print("Error: Matrix Multiplication! colNumA != rowNumB")
        return
    tmpA=0
    for k in range(rowNumA):
        tmpA = A[k * colNumA]
        tmpB = B
        for j in range(colNumB):
            AB[k * colNumB + j] = tmpA * tmpB[j]

    for i in range(1, colNumA):
        for k in range(rowNumA):
            tmpA = A[k * colNumA + i]
            tmpB = B[i * colNumB:]
            for j in range(colNumB):
                AB[k * colNumB + j] += tmpA * tmpB[j]
    return AB

def _cam_matrix_mult(A, num_row_A, num_col_A, X, num_row_X, num_col_X, B):
    B = _cam_matrix_mult_new(B, A, num_row_A, num_col_A, X, num_row_X, num_col_X)
    return B