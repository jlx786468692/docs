
import os
import sys
import numpy as np
import onnx
from onnx import helper
import onnxruntime
import onnxruntime as rt
import time
import cv2 
import math
from tqdm import tqdm
import cam_interface

class TrafficSignDetOut:
    def __init__(self):
        self.roiId = 0
        self.label = 0
        self.signclass = 0
        self.score = 0
        self.color = 0
        self.shape = 0
        self.ts_cls = 0
        self.depth = 0
        self.center_x = 0
        self.center_y = 0
        self.pbbox =[0,0,0,0,0,0,0,0,0,0]
        self.ori_bbox = [0,0,0,0]
        self.bbox = [0,0,0,0]
        self.bbox_ori = [0,0,0,0]
        self.bbox_pooling = [0,0,0,0]
        self.label2 = 0
        self.label2_score = 0
        self.value = 0
        self.value_score = 0


def met_resize(from_image, sub_shape):
    roiH, roiW, _ = from_image.shape
    resizeW, resizeH = sub_shape[0], sub_shape[1]
    to_image = from_image.copy()
    rx_rate = float(roiW) / resizeW
    ry_rate = float(roiH) / resizeH

    down_x_scale_times = int(np.log2(rx_rate))
    down_y_scale_times = int(np.log2(ry_rate))

    target_rz_w = roiW
    target_rz_h = roiH

    max_down_scale_times = down_x_scale_times if down_x_scale_times > down_y_scale_times else down_y_scale_times

    if max_down_scale_times >= 1:
        for i in range(max_down_scale_times):
            if i < down_x_scale_times and max_down_scale_times >= 1:
                target_rz_w = int((target_rz_w + 1) / 2.0)

            if i <= down_y_scale_times and max_down_scale_times >= 1:
                target_rz_h = int((target_rz_h + 1) / 2.0)

            to_image = cv2.resize(to_image, (target_rz_w, target_rz_h), interpolation=cv2.INTER_LINEAR)

    if to_image.shape[1] != resizeW or to_image.shape[0] != resizeH:
        to_image = cv2.resize(to_image, (resizeW, resizeH), interpolation=cv2.INTER_LINEAR)

    else:
        if to_image.shape[1] != resizeW or to_image.shape[0] != resizeH:
            to_image = cv2.resize(to_image, (resizeW, resizeH), interpolation=cv2.INTER_LINEAR)
    return to_image


def swap_float_buf(p_f, p_i, index_a, index_b):

    temp_f = p_f[index_a]
    p_f[index_a] = p_f[index_b]
    p_f[index_b] = temp_f
    #print(index_a, index_b)
    tmp_buf = p_i[index_a]
    p_i[index_a] = p_i[index_b]
    p_i[index_b] = tmp_buf


def quick_sort_buf(arr, inde, start, end):
    tempStart = start
    tempEnd = end

    if (tempStart >= tempEnd):
        return
    #print(arr[start])
    arrBase = arr[start]
    while (start < end):
        #print(start, end)
        while (start < end and arr[end] < arrBase):
            end -= 1

        if (start < end):
            swap_float_buf(arr, inde, start, end)
            start += 1

        while (start < end and arr[start] > arrBase):
            start+=1

        if (start < end):
            swap_float_buf(arr, inde, start, end)
            end -= 1

    arr[start] = arrBase
    arrMiddle = start

    quick_sort_buf(arr, inde, tempStart, arrMiddle - 1)
    quick_sort_buf(arr, inde, arrMiddle + 1, tempEnd)
    return


def IntersectBBox(bbox1, bbox2, intersect_bbox):
    if (bbox2[0] > bbox1[2] or bbox2[2] < bbox1[0] or
        bbox2[1] > bbox1[3] or bbox2[3] < bbox1[1]):

        intersect_bbox[0] = 0.
        intersect_bbox[1] = 0.
        intersect_bbox[2] = 0.
        intersect_bbox[3] = 0.
    else:
        intersect_bbox[0] = max(bbox1[0], bbox2[0])
        intersect_bbox[1] = max(bbox1[1], bbox2[1])
        intersect_bbox[2] = min(bbox1[2], bbox2[2])
        intersect_bbox[3] = min(bbox1[3], bbox2[3])
    return intersect_bbox


def get_bboxSize(bbox):
    bbox_width = bbox[2] - bbox[0]
    bbox_height = bbox[3] - bbox[1]
    return bbox_width * bbox_height


def JaccardOverlap(bbox1, bbox2):
    intersect_bbox = [0,0,0,0]
    intersect_bbox = IntersectBBox(bbox1, bbox2, intersect_bbox)

    intersect_size = get_bboxSize(intersect_bbox)
    bbox1_size = get_bboxSize(bbox1)
    bbox2_size = get_bboxSize(bbox2)
    
    if (intersect_size > 0):

        overlap = intersect_size / (bbox1_size + bbox2_size - intersect_size + 0.000001)
    else:
        overlap = 0.0

    return overlap


def METCenterNetFastNMS_TrafficSign(detOutList,num,nms_threshold, MAX_NUM_PER_CLS):
    bboxIdx = np.zeros(MAX_NUM_PER_CLS)
    overlap = 0.0
    
    
    num_tmp = num

    for first_idx in range(num_tmp):
        if(bboxIdx[first_idx] == -1):
            continue
        tmpDetOut = detOutList[first_idx]

        for i in range(first_idx+ 1,num_tmp):
            if(bboxIdx[i] == -1):
                continue
            overlap = JaccardOverlap(tmpDetOut.bbox, detOutList[i].bbox)
            if(overlap > nms_threshold):
                if(get_bboxSize(tmpDetOut.bbox) < get_bboxSize(detOutList[i].bbox)):
                    tmpDetOut.bbox = detOutList[i].bbox

                bboxIdx[i]  = -1


    idx = 0
    for i in range(num_tmp):
        if(bboxIdx[i] == 0):
            if(bboxIdx[i] != idx):
                detOutList[idx] = detOutList[i]
            idx +=1
    return idx


def MetNetPost2ORI(detout,num,roi):
    image_width = 768
    image_height = 208
    rst = []
    big_rst = []
    count = 0
    #print(roi)
    for i in range(num):

        roiId = detout[i].roiId


        scale_w = float(roi[2])/768.
        scale_h = float(roi[3])/208.
        #print(detout[i].ori_bbox)
        
        detout[i].ori_bbox[0] = ((detout[i].bbox[0] * image_width) * scale_w + roi[0])
        detout[i].ori_bbox[1] = ((detout[i].bbox[1] * image_height) * scale_h + roi[1])
        detout[i].ori_bbox[2] = ((detout[i].bbox[2] * image_width) * scale_w + roi[0])
        detout[i].ori_bbox[3] = ((detout[i].bbox[3] * image_height) * scale_h + roi[1])
        # print(detout[i].bbox)
        # print(detout[i].ori_bbox)
        # print(detout[i].label)
        if(detout[i].score != -1):
            detout[count].roiId = detout[i].roiId
            detout[count].label = detout[i].label
            detout[count].signclass = detout[i].signclass
            detout[count].score = detout[i].score
            detout[count].color = detout[i].color
            detout[count].shape = detout[i].shape
            detout[count].ts_cls = detout[i].ts_cls
            detout[count].depth = detout[i].depth
            detout[count].center_x = detout[i].center_x
            detout[count].center_y = detout[i].center_y
            detout[count].pbbox = detout[i].pbbox
            detout[count].ori_bbox = detout[i].ori_bbox
            detout[count].bbox = detout[i].bbox
            detout[count].bbox_ori = detout[i].bbox_ori
            detout[count].bbox_pooling = detout[i].bbox_pooling
            
            rst.append([detout[count].ori_bbox[0], detout[count].ori_bbox[1], detout[count].ori_bbox[2], detout[count].ori_bbox[3], 
                        detout[count].score, detout[count].label])
            big_rst.append([detout[count].ori_bbox[0], detout[count].ori_bbox[1], detout[count].ori_bbox[2], detout[count].ori_bbox[3], 
                            detout[count].score, detout[count].label,
                            
                    detout[count].shape,detout[count].color,detout[count].ts_cls, detout[count].bbox_pooling, roiId])
            count += 1
    detect_num = count
    if(detect_num > 16):
        detect_num = 16
        rst = rst[0:16]
        big_rst = big_rst[0:16]
    # print(big_rst)
    return detout, detect_num, rst, big_rst


def MetNetPost2ORISTAGE2(detout,num,roi):
    image_width = 768
    image_height = 208
    tl_big_rst = []
    ts_big_rst = []
    count_tl = 0
    count_ts = 0
    print(roi)
    for i in range(num):

        roiId = detout[i].roiId


        scale_w = float(roi[roiId][2])/image_width
        scale_h = float(roi[roiId][3])/image_height
        #print(detout[i].ori_bbox)
        
        detout[i].ori_bbox[0] = ((detout[i].bbox[0] * image_width) * scale_w + roi[roiId][0])
        detout[i].ori_bbox[1] = ((detout[i].bbox[1] * image_height) * scale_h + roi[roiId][1])
        detout[i].ori_bbox[2] = ((detout[i].bbox[2] * image_width) * scale_w + roi[roiId][0])
        detout[i].ori_bbox[3] = ((detout[i].bbox[3] * image_height) * scale_h + roi[roiId][1])
        # print(detout[i].bbox)
        # print(detout[i].ori_bbox)
        # print(detout[i].label)
        if(detout[i].score != -1):
            detout[count_tl].roiId = detout[i].roiId
            detout[count_tl].label = detout[i].label
            detout[count_tl].signclass = detout[i].signclass
            detout[count_tl].score = detout[i].score
            detout[count_tl].color = detout[i].color
            detout[count_tl].shape = detout[i].shape
            detout[count_tl].ts_cls = detout[i].ts_cls
            detout[count_tl].depth = detout[i].depth
            detout[count_tl].center_x = detout[i].center_x
            detout[count_tl].center_y = detout[i].center_y
            detout[count_tl].pbbox = detout[i].pbbox
            detout[count_tl].ori_bbox = detout[i].ori_bbox
            detout[count_tl].bbox = detout[i].bbox
            detout[count_tl].bbox_ori = detout[i].bbox_ori
            detout[count_tl].bbox_pooling = detout[i].bbox_pooling

            # rst.append([detout[count_tl].ori_bbox[0], detout[count_tl].ori_bbox[1], detout[count_tl].ori_bbox[2], detout[count_tl].ori_bbox[3], 
            #             detout[count_tl].score, detout[count_tl].label])

            if(detout[count_tl].signclass == 0):
                tl_big_rst.append([detout[count_tl].ori_bbox[0], detout[count_tl].ori_bbox[1], detout[count_tl].ori_bbox[2], detout[count_tl].ori_bbox[3], 
                                detout[count_tl].score, detout[count_tl].label,
                        detout[count_tl].shape,detout[count_tl].color,detout[count_tl].ts_cls, detout[count_tl].bbox_pooling, roiId])
                count_tl += 1
            elif(detout[count_tl].signclass == 1):
                ts_big_rst.append([detout[count_tl].ori_bbox[0], detout[count_tl].ori_bbox[1], detout[count_tl].ori_bbox[2], detout[count_tl].ori_bbox[3], 
                                detout[count_tl].score, detout[count_tl].label,
                        detout[count_tl].shape,detout[count_tl].color,detout[count_tl].ts_cls, detout[count_tl].bbox_pooling, roiId, 
                        detout[count_tl].label2, detout[count_tl].label2_score, detout[count_tl].value, detout[count_tl].value_score])
            
                count_ts += 1

    tl_detect_num = count_tl
    ts_detect_num = count_ts

    if(tl_detect_num > 16):
        tl_detect_num = 16
        tl_big_rst = big_rst[0:16]
    if(ts_detect_num > 16):
        ts_detect_num = 16
        ts_big_rst = big_rst[0:16]
    # print(big_rst)
    return detout, tl_detect_num, tl_big_rst, ts_detect_num, ts_big_rst


def MetTLMultiROIPoolingWithPad(conv_feat, detOut, detout_num):
    TLS_ROI_POOLING_CHANNEL = int(128)
    TLS_ROI_POOLING_WIDTH = int(7)
    TLS_ROI_POOLING_PAD = int(5)
    TLS_ROI_POOLING_ROW_NUM = int(4)
    TLS_ROI_POOLING_START = int(3)
    TLS_ROI_POOLING_MUL_WIDTH = int(49)
    TLS_ROI_POOLING_DATA_SIZE = int(TLS_ROI_POOLING_MUL_WIDTH * TLS_ROI_POOLING_MUL_WIDTH * TLS_ROI_POOLING_CHANNEL)
 
    pool_buf = np.zeros(TLS_ROI_POOLING_DATA_SIZE, np.float32)
    net_width = int(192)
    net_height = int(52)
    idx = int(0)
    usedCnt = int(0)
    row_outIdx = int(0)

    pool_index = int(0)
    temp_feature_data = float(0)

    obj_top_line_top = int(0)
    obj_top_line_bottom = int(0)
    obj_left = int(0)
    obj_top_line_yratio = 0.

    obj_bottom_line_top = int(0)
    obj_bottom_line_bottom = int(0)
    obj_bottom_line_yratio = 0.

    center_x=np.zeros(TLS_ROI_POOLING_WIDTH, np.float32)
    center_y=np.zeros(TLS_ROI_POOLING_WIDTH, np.float32)
    y_ratio=np.zeros(TLS_ROI_POOLING_WIDTH, np.float32)
    x_ratio=np.zeros(TLS_ROI_POOLING_WIDTH, np.float32)

    cy_top =np.zeros(TLS_ROI_POOLING_WIDTH, np.int32)
    cy_bottom=np.zeros(TLS_ROI_POOLING_WIDTH, np.int32)
    cx_left=np.zeros(TLS_ROI_POOLING_WIDTH, np.int32)
    cx_right=np.zeros(TLS_ROI_POOLING_WIDTH, np.int32)

    topleft = int(0)
    topright = int(0)
    bottomleft = int(0)
    bottomright = int(0)
    
    _top_data = pool_buf

    pooled_width = int(TLS_ROI_POOLING_WIDTH)
    pooled_height = int(TLS_ROI_POOLING_WIDTH)
    multi_pooled_width = int(TLS_ROI_POOLING_MUL_WIDTH)
    multi_pooled_height = int(TLS_ROI_POOLING_MUL_WIDTH)
    
    MAX_TLS_NUM_FOR_STAGE2 = int(16)

    temp_detout_num = 0
    for i in range(detout_num):
        if (idx >= MAX_TLS_NUM_FOR_STAGE2):
            break

        pad = int(0)

        h_stride = multi_pooled_width + 2 * pad
        c_stride = (multi_pooled_height + 2 * pad) * (multi_pooled_width + 2 * pad)

        h_offset = int(idx / TLS_ROI_POOLING_ROW_NUM) * (7 + 5) + 3 + pad
        w_offset = int(idx % TLS_ROI_POOLING_ROW_NUM) * (7 + 5) + 3 + pad

        _roi_based_data = conv_feat[detOut[i].roiId]


        det_obj_start_w = detOut[i].bbox_pooling[0] * float(net_width)
        det_obj_end_w = detOut[i].bbox_pooling[2] * float(net_width)
        det_obj_start_h = detOut[i].bbox_pooling[1] * float(net_height)
        det_obj_end_h = detOut[i].bbox_pooling[3] * float(net_height)
        print(detOut[i].roiId, detOut[i].bbox_pooling[0],detOut[i].bbox_pooling[1],detOut[i].bbox_pooling[2],detOut[i].bbox_pooling[3])   

        roi_height = det_obj_end_h - det_obj_start_h + 1
        roi_width = det_obj_end_w - det_obj_start_w + 1
        bin_size_h = (roi_height) / float(TLS_ROI_POOLING_WIDTH)
        bin_size_w = (roi_width) / float(TLS_ROI_POOLING_WIDTH)
        half_bin_size_h = bin_size_h / 2
        half_bin_size_w = bin_size_w / 2


        obj_top_line_top = int(math.floor(det_obj_start_h))
        obj_left =  int(math.floor(det_obj_start_w))
        if( (obj_left >= (net_width -1)) or (obj_top_line_top >= (net_height -1)) ):
            continue


        
        obj_top_line_bottom = int(math.ceil(det_obj_start_h))
        obj_top_line_yratio = det_obj_start_h - float(obj_top_line_top)

        obj_bottom_line_top = int(math.floor(det_obj_end_h))
        obj_bottom_line_bottom = int(math.ceil(det_obj_end_h))
        obj_bottom_line_yratio = det_obj_end_h - float(obj_bottom_line_top)


        for pw in range(TLS_ROI_POOLING_WIDTH):
            center_x[pw] = half_bin_size_w + float(pw) * bin_size_w + det_obj_start_w
            center_y[pw] = half_bin_size_h + float(pw) * bin_size_h + det_obj_start_h
            
            cy_top[pw] = min(max(int((math.floor(center_y[pw]))),0),net_height - 1)
            cx_left[pw] = min(max(int((math.floor(center_x[pw]))),0),net_width - 1)

            y_ratio[pw] = center_y[pw] - (float)(cy_top[pw])
            x_ratio[pw] = center_x[pw] - (float)(cx_left[pw])

        line_step = 0
        for ph in range(TLS_ROI_POOLING_WIDTH):
            for pw in range(TLS_ROI_POOLING_WIDTH):
                pool_index = int((ph + h_offset) * h_stride + (pw + w_offset))

                ratio_a = float(1 - y_ratio[ph]) * (1 - x_ratio[pw])
                ratio_b = float(1 - y_ratio[ph]) * (x_ratio[pw])
                ratio_c = float(y_ratio[ph]) * (1 - x_ratio[pw])
                ratio_d = float(y_ratio[ph]) * (x_ratio[pw])

                cy_bottom = min((cy_top[ph] + 1), net_height - 1)
                cx_right = min((cx_left[pw] + 1), net_width - 1)


                topleft = cy_top[ph] * net_width + cx_left[pw]
                topright = cy_top[ph] * net_width + cx_right
                bottomleft = cy_bottom * net_width + cx_left[pw]
                bottomright = cy_bottom * net_width + cx_right


                for c in range(TLS_ROI_POOLING_CHANNEL):
                    #print(64 * topleft + c, 64 * topright + c, 64 * bottomleft + c, 64 * bottomright + c)
                    temp_feature_data = float(_roi_based_data[TLS_ROI_POOLING_CHANNEL * topleft + c]) * ratio_a + float(_roi_based_data[TLS_ROI_POOLING_CHANNEL * topright + c]) * ratio_b + float(_roi_based_data[TLS_ROI_POOLING_CHANNEL * bottomleft + c]) * ratio_c + float(_roi_based_data[TLS_ROI_POOLING_CHANNEL * bottomright + c]) * ratio_d
                    _top_data[TLS_ROI_POOLING_CHANNEL * pool_index + c] = temp_feature_data
                line_step +=1
        idx +=1
    _top_data = _top_data.reshape(1, TLS_ROI_POOLING_MUL_WIDTH, TLS_ROI_POOLING_MUL_WIDTH, TLS_ROI_POOLING_CHANNEL)#.transpose(0,3,1,2)
    print(_top_data.shape)

    return _top_data


def detect_tlsdstage1_8M(p3_conv_loc_1x1, p3_conv_ploy_1x1, conf_heatmap_1x1_sigmoid ,conf_heatmap_1x1_sigmoid_pool, conv_feat, roi,roiId):
    MAX_NUM_PER_CLS = int(32)
    nms_threshold = 0.35

    net_width = int(192)
    net_height = int(52)
    
    width = net_width
    height = net_height
    
    loc = p3_conv_loc_1x1
    conf_pool = conf_heatmap_1x1_sigmoid_pool.flatten()
    conf = conf_heatmap_1x1_sigmoid
    conf_flat = conf_heatmap_1x1_sigmoid.flatten()
    conv_ploy = p3_conv_ploy_1x1
    
    tl_conf = conf[:,:,:,0].flatten()
    tsr_conf = conf[:,:,:,1].flatten()


    x_dim = loc[:,:,:,0].flatten()
    y_dim = loc[:,:,:,1].flatten()
    x0_dim = conv_ploy[:,:,:,0].flatten()
    y0_dim = conv_ploy[:,:,:,1].flatten()
    x1_dim = conv_ploy[:,:,:,2].flatten()
    y1_dim = conv_ploy[:,:,:,3].flatten()
    x2_dim = conv_ploy[:,:,:,4].flatten()
    y2_dim = conv_ploy[:,:,:,5].flatten()
    x3_dim = conv_ploy[:,:,:,6].flatten()
    y3_dim = conv_ploy[:,:,:,7].flatten()
    
    
    detout = []
    num = 0
    detect_num = 0
    score = np.zeros((2,MAX_NUM_PER_CLS), np.float32)
    score_buf = []
    num_oneLabel = [0,0]
    #print(score.shape)
    for i in range(2 *MAX_NUM_PER_CLS):
        detout.append(TrafficSignDetOut())
    for c in range(int(2)):
        cls_num = int(0)
        s32Cnt = int(0)
        for h in range(height):
            for w in range(width):
                color = 0
                label = 0
                max_conf_offset = np.fabs(conf_pool[2*s32Cnt + c] - conf_flat[2*s32Cnt + c])
                # print(conf_flat[2*s32Cnt + c], max_conf_offset)
                if((conf_flat[2*s32Cnt + c] > 0.35) and (max_conf_offset< 0.001)):
                #if((conf_flat[2*s32Cnt + c] > 0.35)):
                    # print(conf_flat[2*s32Cnt + c], max_conf_offset)
                    if(num >= 2 * MAX_NUM_PER_CLS):
                        break
                    score = 0.
                    if(c == 0):
                        score = tl_conf[s32Cnt]
                        # color = get_arg_max(tl_color[s32Cnt:s32Cnt + 3], 3)
                        # shape = get_arg_max(tl_shape[s32Cnt:s32Cnt + 8], 8)

                    else:
                        score = tsr_conf[s32Cnt]
                        # ts_cls_temp = get_arg_max(ts_cls[2*s32Cnt:2*s32Cnt + 2], 2)

                        label = 1

                    center_x_temp = w + x_dim[s32Cnt]
                    center_y_temp = h + y_dim[s32Cnt]
                    center_x = min(1,max(0,(center_x_temp )/width))
                    center_y = min(1,max(0,(center_y_temp) /height))

                    x0 = min(1,max(0,(center_x_temp - x0_dim[s32Cnt]) / width))
                    y0 = min(1,max(0,(center_y_temp - y0_dim[s32Cnt]) / height))
                    x1 = min(1,max(0,(center_x_temp - x1_dim[s32Cnt]) / width))
                    y1 = min(1,max(0,(center_y_temp - y1_dim[s32Cnt]) / height))
                    x2 = min(1,max(0,(center_x_temp - x2_dim[s32Cnt]) / width))
                    y2 = min(1,max(0,(center_y_temp - y2_dim[s32Cnt]) / height))
                    x3 = min(1,max(0,(center_x_temp - x3_dim[s32Cnt]) / width))
                    y3 = min(1,max(0,(center_y_temp - y3_dim[s32Cnt]) / height))
                    
                    xmin=min(min(x0,x1),min(x2,x3))
                    ymin=min(min(y0,y1),min(y2,y3))
                    xmax=max(max(x0,x1),max(x2,x3))
                    ymax=max(max(y0,y1),max(y2,y3))
                    
                    if(c==0):
                        # detout[num].color = color
                        # detout[num].shape = shape
                        detout[num].label = label
                        # detout[num].ts_cls = 0
                    else:
                        # detout[num].color = 0
                        # detout[num].shape = 0
                        detout[num].label = 1
                        # detout[num].ts_cls = ts_cls_temp
                    # print(conf_flat[2*s32Cnt + c])
                    # score[c][num] = conf_flat[2*s32Cnt + c]
                    score_buf.append(conf_flat[2*s32Cnt + c])
                    detout[num].score = conf_flat[2*s32Cnt + c]
                    #print(detout[num].score)
                    detout[num].signclass = c
                    detout[num].center_x = center_x
                    detout[num].center_y = center_y
  
                    detout[num].roiId = roiId
                    #print(detout[num].roiId)

                    detout[num].pbbox[0] = x0
                    detout[num].pbbox[1] = y0
                    detout[num].pbbox[2] = x1
                    detout[num].pbbox[3] = y1
                    detout[num].pbbox[4] = x2
                    detout[num].pbbox[5] = y2
                    detout[num].pbbox[6] = x3
                    detout[num].pbbox[7] = y3
                    
                    detout[num].bbox[0] = min(min(detout[num].pbbox[0],detout[num].pbbox[2]),min(detout[num].pbbox[4],detout[num].pbbox[6]))
                    detout[num].bbox[1] = min(min(detout[num].pbbox[1],detout[num].pbbox[3]),min(detout[num].pbbox[5],detout[num].pbbox[7]))
                    detout[num].bbox[2] = max(max(detout[num].pbbox[0],detout[num].pbbox[2]),max(detout[num].pbbox[4],detout[num].pbbox[6]))
                    detout[num].bbox[3] = max(max(detout[num].pbbox[1],detout[num].pbbox[3]),max(detout[num].pbbox[5],detout[num].pbbox[7]))
                    # print(detout[num].bbox)
                    detout[num].bbox_pooling = detout[num].bbox
                    #print(detout[num].bbox_pooling)
                    detout[num].depth = 0   
                    num += 1
                    cls_num += 1
                s32Cnt += 1 
        num_oneLabel[c] = cls_num
        # if(c == 0):
        #     num_oneLabel[c] = METCenterNetFastNMS_TrafficSign(detout[0:num_oneLabel[c]],num_oneLabel[c],nms_threshold, MAX_NUM_PER_CLS)
        # else:
        #     num_oneLabel[c] = METCenterNetFastNMS_TrafficSign(detout[num_oneLabel[c-1]:num_oneLabel[c]+num_oneLabel[c-1]],num_oneLabel[c],nms_threshold, MAX_NUM_PER_CLS)
        
        detect_num += num_oneLabel[c]
        

    # quick_sort_buf(score_buf,detout,0,detect_num-1)
    # detect_num = METCenterNetFastNMS_TrafficSign(detout,detect_num,nms_threshold, 2*MAX_NUM_PER_CLS)

    # #print(score_buf)
    # detout, detect_num, rst, big_rst = MetNetPost2ORI(detout,detect_num,roi)


    # stage2_input = MetTLMultiROIPoolingWithPad(conv_feat,detout,detect_num)


    return detout, score_buf, detect_num


def stage2_get_overlap_ploy(box1, box2):
    xmin = max(box1[0], box2[0])
    ymin = max(box1[1], box2[1])
    xmax = min(box1[2], box2[2])
    ymax = min(box1[3], box2[3])
    if (xmax - xmin) <= 0 or (ymax - ymin) <= 0:
        return 0
    over = (xmax - xmin) * (ymax - ymin)
    two_box = (box1[0] - box1[2]) * (box1[1] - box1[3]) + (box2[0] - box2[2]) * (box2[1] - box2[3])
    overlap = over / ((two_box - over) * 1.0)
    return overlap


def load_tlsd_stage1_hwc_data(root_path, img_name, roiId):
    TLSD_STAGE1_HEIGHT = int(52)
    TLSD_STAGE1_WIDTH = int(192)
    
    # p3_conv_loc_1x1_path = f'{root_path}/{img_name}_p3_conv_loc_1x1.raw'
    # p3_conv_ploy_1x1_path = f'{root_path}/{img_name}_p3_conv_ploy_1x1bin'
    # #p3_conv_ploy_1x1_path = f'{bin_root_path}/{img_name}_p4_conv_confp3_conv_ploy_1x1bin'
    # conf_heatmap_1x1_sigmoid_pool_path = f'{root_path}/{img_name}_conf_heatmap_1x1_pool.bin'
    # conf_heatmap_1x1_sigmoid_path = f'{root_path}/{img_name}_conf_heatmap_1x1_sigmoid.bin'
    # # conv_feat_path = f'{bin_root_path}/{img_name}_conv_feat.bin'
    
    
    p3_conv_loc_1x1_path = f'{root_path}/p3_conv_loc_1x1_{roiId}.bin'
    p3_conv_ploy_1x1_path = f'{root_path}/p3_conv_ploy_1x1_{roiId}.bin'
    #p3_conv_ploy_1x1_path = f'{bin_root_path}/{img_name}_p4_conv_confp3_conv_ploy_1x1bin'
    conf_heatmap_1x1_sigmoid_pool_path = f'{root_path}/conf_heatmap_1x1_pool_{roiId}.bin'
    conf_heatmap_1x1_sigmoid_path = f'{root_path}/Concat1_{roiId}.bin'
    conv_feat_path = f'{root_path}/Concat0_{roiId}.bin'

    p3_conv_loc_1x1 = np.fromfile(p3_conv_loc_1x1_path,np.float32).astype(np.float32)
    p3_conv_ploy_1x1 = np.fromfile(p3_conv_ploy_1x1_path,np.float32).astype(np.float32)
    conf_heatmap_1x1_sigmoid = np.fromfile(conf_heatmap_1x1_sigmoid_path,np.float32).astype(np.float32)
    conf_heatmap_1x1_sigmoid_pool = np.fromfile(conf_heatmap_1x1_sigmoid_pool_path,np.float32).astype(np.float32)
    conv_feat = np.fromfile(conv_feat_path,np.float32)
    # conv_feat = np.zeros((1*TLSD_STAGE1_HEIGHT*TLSD_STAGE1_WIDTH*64),np.float32).flatten().astype(np.float32)

    p3_conv_loc_1x1 = p3_conv_loc_1x1.reshape(1,TLSD_STAGE1_HEIGHT,TLSD_STAGE1_WIDTH,2)
    p3_conv_ploy_1x1 = p3_conv_ploy_1x1.reshape(1,TLSD_STAGE1_HEIGHT,TLSD_STAGE1_WIDTH,8)
    conf_heatmap_1x1_sigmoid = conf_heatmap_1x1_sigmoid.reshape(1,TLSD_STAGE1_HEIGHT,TLSD_STAGE1_WIDTH,2)
    conf_heatmap_1x1_sigmoid_pool = conf_heatmap_1x1_sigmoid_pool.reshape(1,TLSD_STAGE1_HEIGHT,TLSD_STAGE1_WIDTH,2)
    conv_feat = conv_feat.reshape(1,TLSD_STAGE1_HEIGHT,TLSD_STAGE1_WIDTH,64).flatten()

    return p3_conv_loc_1x1, p3_conv_ploy_1x1 ,conf_heatmap_1x1_sigmoid, conf_heatmap_1x1_sigmoid_pool, conv_feat


def load_tlsd_stage2_hwc_data(root_path):
    TLSD_STAGE2_HEIGHT = int(25)
    TLSD_STAGE2_WIDTH = int(25)

    
    tl_conf_conv_path = f'{root_path}/tl_conf_conv.bin'
    tl_ploy_conv_path = f'{root_path}/tl_ploy_conv.bin'
    tl_shape_cls_path = f'{root_path}/tl_shape_cls.bin'
    tl_color_cls_path = f'{root_path}/tl_color_cls.bin'
    conv_tsr_cls_path = f'{root_path}/conv_tsr_cls.bin'

    tl_conf_conv = np.fromfile(tl_conf_conv_path,np.float32).astype(np.float32)
    tl_ploy_conv = np.fromfile(tl_ploy_conv_path,np.float32).astype(np.float32)
    tl_shape_cls = np.fromfile(tl_shape_cls_path,np.float32).astype(np.float32)
    tl_color_cls = np.fromfile(tl_color_cls_path,np.float32).astype(np.float32)
    conv_tsr_cls = np.fromfile(conv_tsr_cls_path,np.float32)
    # conv_feat = np.zeros((1*TLSD_STAGE1_HEIGHT*TLSD_STAGE1_WIDTH*64),np.float32).flatten().astype(np.float32)

    tl_conf_conv = tl_conf_conv.reshape(1,TLSD_STAGE2_HEIGHT,TLSD_STAGE2_WIDTH,3).transpose(0,3,1,2).flatten()
    tl_ploy_conv = tl_ploy_conv.reshape(1,TLSD_STAGE2_HEIGHT,TLSD_STAGE2_WIDTH,4).transpose(0,3,1,2).flatten()
    tl_shape_cls = tl_shape_cls.reshape(1,TLSD_STAGE2_HEIGHT,TLSD_STAGE2_WIDTH,9).transpose(0,3,1,2).flatten()
    tl_color_cls = tl_color_cls.reshape(1,TLSD_STAGE2_HEIGHT,TLSD_STAGE2_WIDTH,3).transpose(0,3,1,2).flatten()
    conv_tsr_cls = conv_tsr_cls.reshape(1,TLSD_STAGE2_HEIGHT,TLSD_STAGE2_WIDTH,3).transpose(0,3,1,2).flatten()

    return tl_conf_conv, tl_ploy_conv ,tl_shape_cls, tl_color_cls, conv_tsr_cls


def tlsd_onnx_proc_stage2(transformed_image):
    print("tlsd_onnx_proc_stage2", transformed_image.shape)
    transformed_image = transformed_image.transpose(0,3,1,2)
    path = "../model/0.0.2/tlsd_8M_0.0.2_s2.onnx" 
    model = onnxruntime.InferenceSession(path, providers=['CPUExecutionProvider'])
    ort_inputs = {model.get_inputs()[0].name: transformed_image.astype(np.float32)}
    stage2_outs = model.run(None, ort_inputs)
    
    tl_conf_conv = stage2_outs[0].flatten()
    tl_ploy_conv = stage2_outs[1].flatten()
    tl_shape_cls = stage2_outs[2].flatten()
    tl_color_cls = stage2_outs[3].flatten()
    conv_tsr_cls = stage2_outs[4].flatten()

    return tl_conf_conv, tl_ploy_conv, tl_shape_cls, tl_color_cls, conv_tsr_cls


def ocr_onnx_proc(transformed_image):
    roi_img = transformed_image.transpose(2,0,1)
    transformed_image = roi_img[np.newaxis, :, :, :] 
    # print(transformed_image.shape)
    path = "../model/ocr/ocr_com_0.0.1.onnx" 
    model = onnxruntime.InferenceSession(path, providers=['CPUExecutionProvider'])
    ort_inputs = {model.get_inputs()[0].name: transformed_image.astype(np.float32)}
    ocr_outputs = model.run(None, ort_inputs)
    
    conv_val = ocr_outputs[0]
    conf_cls = ocr_outputs[1].flatten()
    
    # print(conf_cls.shape)
    # print(conf_cls)
    # print(conv_val.shape)

    return conf_cls, conv_val

labelmap = dict(((0, '0'), (1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5'), (6, '6'), (7, '7'), (8, '8'), (9, '9'), (11, 'm'), (12, 't')))

def ocr_detect_process(img, ts_num, ts_rst):
    width = 36
    height = 36

    class_num = 47
    time_step = 9
    blank_label = 10
    alphabet_size = 13
    prev_label = 10

    # print(ts_num)

    for num in range(ts_num):
        xmin = int(ts_rst[num][0])
        ymin = int(ts_rst[num][1])
        xmax = int(ts_rst[num][2])
        ymax = int(ts_rst[num][3])
        img_crop = img[ymin:ymax, xmin:xmax]
        img_roi = met_resize(img_crop, (width, height))
        conf_cls, conv_val = ocr_onnx_proc(img_roi)

        max_cls = 0
        max_conf = conf_cls[0]

        for class_index in range(class_num):
            #print(conf_cls[class_index], class_index)
            if conf_cls[class_index] > max_conf:
                max_conf = conf_cls[class_index]
                max_cls = class_index

        conf = 1.0
        result = ''
        for i in range(time_step):
            predict_label = 0
            max_data = -100000
            for j in range(alphabet_size):
                if conv_val[0, j, 0, i] > max_data:
                    predict_label = j
                    max_data = conv_val[0, j, 0, i]

            if (predict_label != blank_label and predict_label != prev_label):
                # print('predict_label_1:', predict_label)  ## limit speed number, one by one to detected
                result1  = result + labelmap[predict_label]
                result = list(filter(str.isdigit, result1))  # 去除string中字母保留数字
                result = "".join(result)
            prev_label = predict_label
        
        ts_rst[num][11] = max_cls
        ts_rst[num][12] = max_conf
        ts_rst[num][13] = result
        ts_rst[num][14] = conf

        # print(ts_rst[i][11], ts_rst[i][12], ts_rst[i][13], ts_rst[i][14])
        return ts_num, ts_rst


def GetValidNetOutputData_tl_float_softmax(input_data, obj_idx, output_data, channel, chpitch, pitch):
    h_idx = int(obj_idx / 4)
    w_idx = int(obj_idx % 4)

    h_idx = 3 + h_idx * 6
    w_idx = 3 + w_idx * 6
    for c in range(channel):
        index = c * chpitch + h_idx * pitch + w_idx
        output_data[c] = input_data[int(index)]

    return output_data


def GetValidNetOutputData_tl_float(input_data, obj_idx, output_data, channel, chpitch, pitch):
    h_idx = int(obj_idx / 4)
    w_idx = int(obj_idx % 4)

    h_idx = 3 + h_idx * 6
    w_idx = 3 + w_idx * 6
    for c in range(channel):
        index = c * chpitch + h_idx * pitch + w_idx
        output_data[c] = input_data[int(index)]

    return output_data


def simple_get_max_value_index(val, size):
    maxCnt = 0
    maxVal = val[maxCnt]
    for i in range(1,size):
        if(maxVal < val[i]):
            maxVal = val[i]
            maxCnt = i
    return maxVal, maxCnt


def detect_tlsdstage2(tl_conf_conv, tl_shape_cls, tl_color_cls, conv_tsr_cls, tl_ploy_conv, tmp_obj, detect_num, roi):

    conf = np.zeros((detect_num,3),np.float32)
    shape = np.zeros((detect_num,9),np.float32)
    color = np.zeros((detect_num,3),np.float32)
    tsr = np.zeros((detect_num,3),np.float32)
    ploy = np.zeros((detect_num,4),np.float32)

    chpitch = int(25 * 25)
    pitch = int(25)
    print(detect_num)
    for i in range(detect_num):
        conf[i] = GetValidNetOutputData_tl_float_softmax(tl_conf_conv,i, conf[i], 3, chpitch, pitch)
        maxVal, label = simple_get_max_value_index(conf[i],3)
        tmp_obj[i].label = label
        tmp_obj[i].score = maxVal
        print('label',label,'score',maxVal)
        if(tmp_obj[i].label == 0):
            continue
        elif(tmp_obj[i].label == 1):
            tmp_obj[i].label = 0
            tmp_obj[i].signclass = 0
        elif(tmp_obj[i].label == 2):
            tmp_obj[i].label = 1
            tmp_obj[i].signclass = 1

        if(tmp_obj[i].signclass == 0):
            shape[i] = GetValidNetOutputData_tl_float_softmax(tl_shape_cls, i, shape[i], 9, chpitch, pitch)
            maxVal, label = simple_get_max_value_index(shape[i],8)
            tmp_obj[i].shape = label
            color[i] = GetValidNetOutputData_tl_float_softmax(tl_color_cls, i, color[i], 3, chpitch, pitch)
            maxVal, label = simple_get_max_value_index(color[i],3)
            tmp_obj[i].color = label
        elif(tmp_obj[i].signclass == 1):
            tsr[i] = GetValidNetOutputData_tl_float_softmax(conv_tsr_cls, i, tsr[i], 3, chpitch, pitch)
            maxVal, label = simple_get_max_value_index(tsr[i],2)
            tmp_obj[i].ts_cls = label

        ploy[i] = GetValidNetOutputData_tl_float(tl_ploy_conv, i, ploy[i], 4, chpitch, pitch)
        #print(ploy[i])

        tmp_obj[i].bbox[0] = tmp_obj[i].bbox_pooling[0]
        tmp_obj[i].bbox[1] = tmp_obj[i].bbox_pooling[1]
        tmp_obj[i].bbox[2] = tmp_obj[i].bbox_pooling[2] - tmp_obj[i].bbox_pooling[0]
        tmp_obj[i].bbox[3] = tmp_obj[i].bbox_pooling[3] - tmp_obj[i].bbox_pooling[1]
        print(tmp_obj[i].label, tmp_obj[i].score, tmp_obj[i].signclass, tmp_obj[i].shape, tmp_obj[i].color, tmp_obj[i].bbox)
        center_x = tmp_obj[i].bbox[0] + tmp_obj[i].bbox[2]/ 2.
        center_y = tmp_obj[i].bbox[1] + tmp_obj[i].bbox[3]/ 2.
       
        width = tmp_obj[i].bbox[2]
        height = tmp_obj[i].bbox[3]

        variances = [0.1,0.1,0.2,0.2]
        decode_x = ploy[i][0] * variances[0]*width + center_x
        decode_y = ploy[i][1] * variances[1]*height + center_y

        decode_w = math.exp(ploy[i][2] * variances[2])* width
        decode_h = math.exp(ploy[i][3] * variances[3])* height
        #if 1
        tmp_obj[i].bbox[0] = decode_x - decode_w/2.
        tmp_obj[i].bbox[1] = decode_y - decode_h/2.
        tmp_obj[i].bbox[2] = decode_x + decode_w/2
        tmp_obj[i].bbox[3] = decode_y + decode_h/2
        #print(tmp_obj[i].bbox)
    # print(conf)
    # print(ploy)
    detout, tl_detect_num, tl_big_rst, ts_detect_num, ts_big_rst = MetNetPost2ORISTAGE2(tmp_obj, detect_num, roi)
    # return conf, shape, color, tsr, ploy
    return tl_detect_num, tl_big_rst, ts_detect_num, ts_big_rst


def tlsd_8M_onnx_process(path, roi, roi_img, img_name, res_path):
    
    roi_img = roi_img.transpose(2,0,1)
    transformed_image = roi_img[np.newaxis, :, :, :] 
    print(transformed_image.shape)
    model = onnxruntime.InferenceSession(path, providers=['CPUExecutionProvider'])
    ort_inputs = {model.get_inputs()[0].name: transformed_image.astype(np.float32)}
    stage1_outs = model.run(None, ort_inputs)    

    p3_conv_loc_1x1                 = stage1_outs[0].transpose(0,2,3,1)
    p3_conv_ploy_1x1                = stage1_outs[1].transpose(0,2,3,1)
    conv_feat                       = stage1_outs[6].transpose(0,2,3,1).flatten()
    conf_heatmap_1x1_sigmoid        = stage1_outs[7].transpose(0,2,3,1)
    conf_heatmap_1x1_sigmoid_pool   = stage1_outs[5].transpose(0,2,3,1)
    return p3_conv_loc_1x1, p3_conv_ploy_1x1 ,conf_heatmap_1x1_sigmoid, conf_heatmap_1x1_sigmoid_pool, conv_feat


def save_data_bin(save_path, data):
    f = open(save_path,'wb')
    data = np.ascontiguousarray(data)
    f.write(data)
    f.close

def read_map_bin(path):
    map_3840x2160 = np.fromfile(path,np.uint32).reshape(2160,3840,2)
    return map_3840x2160
 
def file_name(file_dir):
    ret = []
    for root, dirs, files in os.walk(file_dir):
        for filespath in files:
            ret.append(os.path.join(root, filespath))
    return ret

if __name__ == '__main__':
    ori_img_path = "./ori_img/"
    root_res_path = "./res/"
    stage1_onnx_path = "../model/0.0.2/tlsd_8M_0.0.2_s1_sim.onnx"
    map_path = "./lcc.bin"
    map_3840_2160 = read_map_bin(map_path)

    rois = [[256, 256, 3328, 936],[1088, 744, 1664, 468]]
    
    width = int(768)
    height = int(208)
    ret = file_name(ori_img_path)
    ListJpgPath = set()
    for i in ret:
        if os.path.splitext(i)[1] == ".jpg":
            ListJpgPath.add(i)
    ListJpgPath = sorted(ListJpgPath)
    
    dump_buf = []
    for idx, img_path in enumerate(tqdm(ListJpgPath)):
        ori_img = cv2.imread(img_path)
        img_name = img_path.split('/')[-1].replace('.jpg','')
        detoutstage1 = []
        for i in range(25):
            detoutstage1.append(TrafficSignDetOut())
        res_count = 0
                    
        pooling_feature = []
        show_img_stage1 = ori_img.copy()
        show_img_stage2 = ori_img.copy()
        roi_res_path = "./roi_img"
        for i_roi, roi in enumerate(rois):
            crop_x, crop_y, crop_w, crop_h = rois[i_roi]
            image_crop = ori_img[crop_y:(crop_y + crop_h), crop_x:(crop_x + crop_w)]
            roi_img = met_resize(image_crop, (width, height))
            
            bin_root_path = "./outputs/"
            p3_conv_loc_1x1, p3_conv_ploy_1x1 ,conf_heatmap_1x1_sigmoid, conf_heatmap_1x1_sigmoid_pool, conv_feat = tlsd_8M_onnx_process(stage1_onnx_path, roi, roi_img, img_name, root_res_path)
            #p3_conv_loc_1x1, p3_conv_ploy_1x1 ,conf_heatmap_1x1_sigmoid, conf_heatmap_1x1_sigmoid_pool, conv_feat = load_tlsd_stage1_hwc_data(bin_root_path,img_name, i_roi)
            pooling_feature.append(conv_feat)


            color = [(0, 0, 255), (0, 255, 255), (0, 255, 0), (255, 255, 0), (255, 0, 0)]
            shape = ['L', 'U', 'R', 'T', 'C', 'P', 'Non_V', 'D', 'fuzz', 'N', 'o', 'Txt']
            
        
            detout, score_buf, detect_num = detect_tlsdstage1_8M(p3_conv_loc_1x1, p3_conv_ploy_1x1, conf_heatmap_1x1_sigmoid ,conf_heatmap_1x1_sigmoid_pool, conv_feat, roi, i_roi)
            MAX_NUM_PER_CLS = int(32)
            nms_threshold = 0.35
            quick_sort_buf(score_buf,detout,0,detect_num-1)
            detect_num = METCenterNetFastNMS_TrafficSign(detout, detect_num, nms_threshold, 2 * MAX_NUM_PER_CLS)

            print(detect_num)
            detout, detect_num, rst, big_rst = MetNetPost2ORI(detout,detect_num,roi)
            for m in range(len(big_rst) - 1):
                if big_rst[m][4] == -1:
                    continue
                for n in range(m + 1, len(big_rst)):
                    if big_rst[n][4] == -1:
                        continue
                    # iou = get_overlap(big_rst[m], big_rst[n])
                    iou = stage2_get_overlap_ploy(big_rst[m], big_rst[n])
                    # print('IOU:', iou)
                    if iou > 0.2:
                        if big_rst[m][-1] == 1:                                 #优先小ROI结果
                        # if big_rst[m][4] > big_rst[n][4]:
                            big_rst[n][4] = -1
                        else:
                            big_rst[m][4] = -1


            cls_label_list = []
            for item in big_rst:
                # print('item :' ,item)
                if item[4] == -1:
                    continue
                label = item[5]
                real_score = item[4]
                r_x0 = int(item[0])
                r_y0 = int(item[1])
                r_x2 = int(item[2])
                r_y2 = int(item[3])

                if res_count < 16:
                    detoutstage1[res_count].roiId = int(item[-1])
                    detoutstage1[res_count].label = item[5]
                    detoutstage1[res_count].score = item[4]

                    detoutstage1[res_count].bbox_pooling = item[-2]
                    # print("label = ",item[5])
                    res_count += 1

           
                shape_label = label
                cls_label = label       
                cls_label_list.append(cls_label)
                print(r_x0,r_y0, r_x2, r_y2)
                cv2.rectangle(show_img_stage1, (int(r_x0), int(r_y0)), (int(r_x2), int(r_y2)), color[label], 1)

                cv2.putText(show_img_stage1, "%s" % (shape[shape_label]), (int(r_x0), int(r_y2) + 10), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                            color[label], 1)
                cv2.putText(show_img_stage1, "%.2f" % real_score, (int(r_x0) - 5, int(r_y2) + 25), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                            color[label], 1)
            print("roi:", crop_y,crop_y + crop_h, int(roi[2]), int(roi[3]))
            cv2.rectangle(show_img_stage1, (crop_x,crop_y), (crop_x + crop_w, crop_y + crop_h), color[0], 1)
        stage2_input = MetTLMultiROIPoolingWithPad(pooling_feature, detoutstage1, res_count)
        # save_path = f'./stage2_res_bin/'
        # f = open(f"{save_path}/{img_name}.bin",'wb')
        res_data = stage2_input.astype(np.float32).transpose(0,3,1,2)
        res_data = np.ascontiguousarray(res_data)
        print(res_data.shape)
        # f.write(res_data)
        # f.close

        # show_img_stage1 = cv2.resize(show_img_stage1,(1920,1080))
        # cv2.imwrite(f"{root_res_path}/{img_name}.jpg", show_img_stage1)
        # cv2.imshow("test", show_img_stage1)
        # cv2.waitKey(0)
        # print(stage2_input.shape)

        tl_conf_conv, tl_ploy_conv, tl_shape_cls, tl_color_cls, conv_tsr_cls = tlsd_onnx_proc_stage2(stage2_input)
        # print(tl_conf_conv.shape)
        # root_path = "./sim_outputs/"
        # tl_conf_conv, tl_ploy_conv, tl_shape_cls, tl_color_cls, conv_tsr_cls = load_tlsd_stage2_hwc_data(root_path)
        
        
        tl_det_num, tl_big_rst, ts_det_num, ts_big_rst = detect_tlsdstage2(tl_conf_conv, tl_shape_cls, tl_color_cls, conv_tsr_cls, tl_ploy_conv, detoutstage1, res_count, rois)

        ts_det_num,ts_big_rst = ocr_detect_process(ori_img, ts_det_num, ts_big_rst)
               
        for m in range(len(tl_big_rst) - 1):
            print(tl_big_rst[m])
            if tl_big_rst[m][4] == -1:
                continue
            for n in range(m + 1, len(tl_big_rst)):
                if tl_big_rst[n][4] == -1:
                    continue
                # iou = get_overlap(big_rst[m], big_rst[n])
                iou = stage2_get_overlap_ploy(tl_big_rst[m], tl_big_rst[n])
                # print('IOU:', iou)
                if iou > 0.2:
                    if tl_big_rst[m][-1] == 1:                                 #优先小ROI结果
                    # if big_rst[m][4] > big_rst[n][4]:
                        tl_big_rst[n][4] = -1
                    else:
                        tl_big_rst[m][4] = -1

        cls_label_list = []
        for item in tl_big_rst:
            # print('item :' ,item)
            if item[4] == -1:
                continue
            label = item[5]
            real_score = item[4]
            r_x0 = int(item[0])
            r_y0 = int(item[1])
            r_x2 = int(item[2])
            r_y2 = int(item[3])

            r_x0_ldc = map_3840_2160[r_y0][r_x0][0]
            r_y0_ldc = map_3840_2160[r_y0][r_x0][1]
            r_x2_ldc = map_3840_2160[r_y2][r_x2][0]
            r_y2_ldc = map_3840_2160[r_y2][r_x2][1]

            print("tl_x0y0x2y2:", r_x0,r_y0, r_x2, r_y2)
            print("tl_x0y0x2y2_ldc:", r_x0_ldc, r_y0_ldc, r_x2_ldc, r_y2_ldc)
            
            
            shape_label = int(item[6])
            color_label = int(item[7])
            cls_label = label       
            cls_label_list.append(cls_label)

            cv2.rectangle(show_img_stage2, (int(r_x0), int(r_y0)), (int(r_x2), int(r_y2)), color[color_label], 2)

            cv2.putText(show_img_stage2, "%s" % (shape[shape_label]), (int(r_x0), int(r_y2) + 10), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                        color[label], 1)
            cv2.putText(show_img_stage2, "%.2f" % real_score, (int(r_x0) - 5, int(r_y2) + 25), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                        color[label], 1)
        

        for m in range(len(ts_big_rst) - 1):
            print(ts_big_rst[m])
            if ts_big_rst[m][4] == -1:
                continue
            for n in range(m + 1, len(ts_big_rst)):
                if ts_big_rst[n][4] == -1:
                    continue
                # iou = get_overlap(big_rst[m], big_rst[n])
                iou = stage2_get_overlap_ploy(ts_big_rst[m], ts_big_rst[n])
                # print('IOU:', iou)
                if iou > 0.2:
                    if ts_big_rst[m][-1] == 1:                                 #优先小ROI结果
                    # if big_rst[m][4] > big_rst[n][4]:
                        ts_big_rst[n][4] = -1
                    else:
                        ts_big_rst[m][4] = -1

        for item in ts_big_rst:
            # print('item :' ,item)
            if item[4] == -1:
                continue
            label = item[5]
            label2 = item[11]
            val = item[13]
            real_score = item[4]
            r_x0 = int(item[0])
            r_y0 = int(item[1])
            r_x2 = int(item[2])
            r_y2 = int(item[3])

            r_x0_ldc = map_3840_2160[r_y0][r_x0][0]
            r_y0_ldc = map_3840_2160[r_y0][r_x0][1]
            r_x2_ldc = map_3840_2160[r_y2][r_x2][0]
            r_y2_ldc = map_3840_2160[r_y2][r_x2][1]

            print("ts_x0y0x2y2:", r_x0,r_y0, r_x2, r_y2)
            print("ts_x0y0x2y2_ldc:", r_x0_ldc, r_y0_ldc, r_x2_ldc, r_y2_ldc)
            
            
            shape_label = int(item[6])
            color_label = int(item[7])
            cls_label = label       
            cls_label_list.append(cls_label)

            cv2.rectangle(show_img_stage2, (int(r_x0), int(r_y0)), (int(r_x2), int(r_y2)), color[4], 2)

            cv2.putText(show_img_stage2, "%s" % (shape[shape_label]), (int(r_x0), int(r_y2) + 10), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                        color[4], 1)
            cv2.putText(show_img_stage2, "%.2f" % real_score, (int(r_x0) - 5, int(r_y2) + 25), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                        color[4], 1)
            cv2.putText(show_img_stage2, "%s" % label2, (int(r_x2) + 5, int(r_y0) + 5), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                        color[4], 1)
            cv2.putText(show_img_stage2, "%s" % val, (int(r_x2) + 5, int(r_y0) + 30), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                        color[4], 1)
        
        
        cv2.rectangle(show_img_stage2, (int(rois[0][0]), int(rois[0][1])), (int(rois[0][2] + rois[0][0]), int(rois[0][3] + rois[0][1])), (0, 0, 255), 1)
        cv2.rectangle(show_img_stage2, (int(rois[1][0]), int(rois[1][1])), (int(rois[1][2] + rois[1][0]), int(rois[1][3] + rois[1][1])), (0, 255, 255), 1)
        
        show_img_stage2 = cv2.resize(show_img_stage2,(1920,1080))
        cv2.imwrite(f"{root_res_path}/{img_name}.jpg", show_img_stage2)
        # show_img_stage2 = cv2.resize(show_img_stage2,(1920,1080))
        # cv2.imshow("test", show_img_stage2)
        # cv2.waitKey(0)