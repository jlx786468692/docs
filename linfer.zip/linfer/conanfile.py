from conans import ConanFile, CMake
from collections import namedtuple
import os


def save_version(version):
    with open("./version.txt", "w", encoding="utf8") as f:
        f.write("LINFER_VERSION=%s" % str(version))


def get_last_commit_time() -> str:
    os.popen('git config --global --add safe.directory "*"')
    return os.popen("date -d@$(git log -1 --format=%ct) +%Y%m%d%H%M%S").read().strip()


class PackageConan(ConanFile):
    name = "linfer"
    # Update this version if want to release conan package.
    # If the version is not changed, the package will not be updated.
    version = "0.4.23"
    save_version(version)

    settings = "os", "compiler", "build_type", "arch"
    description = "Lotus Infer Library"
    url = "https://dev-gitlab.lotuscars.com.cn/ad4-aio/linfer"
    license = "Copyright (c) Lotus Robotics"
    topics = ()
    generators = "cmake"

    requires = (
        "fmt/v8.1.1_b2@ad4-lotus/stable",
        "gflags/v2.2.2_b1@ad4-lotus/stable",
        "spdlog/v1.9.2_b2@ad4-lotus/stable",
        "nlohmann_json/v3.10.0_b2@ad4-lotus/stable",
        "half/1.12.0@ad4-lotus/stable",
        "cutlass/v2.11.0@ad4-lotus/stable",
    )

    build_requires = (
        "googletest/v1.11.0-no-gmock_b1@ad4-lotus/stable",
        "benchmark/v1.6.1_b1@ad4-lotus/stable",
    )

    python_version_map = {
        "3.8": ["38", "python/3.8.13@ad4-lotus/stable", "python3.8"],
        "3.9": ["39", "python/v3.9.19_x86@ad4-lotus/stable", "python3.9"],
        "3.10": ["310", "python/v3.10.6@ad4-lotus/stable", "python3.10"],
        "3.12": ["312", "python/v3.12.6@ad4-lotus/stable", "python3.12"],
    }

    PythonVersion = namedtuple("PythonVersion", ["version", "conan_name", "lib_name"])

    def bind_python(self, python_binding_version):
        if python_binding_version != "OFF":
            python_version_info = self.PythonVersion(
                *self.python_version_map[python_binding_version]
            )
            self.requires(python_version_info.conan_name)
            # Check if building with libtorch.
            # If not, explicitly require pybind11, since libtorch already bundles pybind11.
            if os.environ.get("LMAKE_BUILD_WITH_LIBTORCH", "OFF") == "OFF":
                self.requires("pybind11/v2.13.4@ad4-lotus/stable")

    def requirements(self):
        system_platform = str(self.settings.os.platform).lower()

        if system_platform == "x86":
            trt_ver = os.environ.get("LMAKE_TRT_VERSION", "OFF")
            python_binding_version = os.environ.get("LMAKE_PYTHON_VERSION", "OFF")
            self.bind_python(python_binding_version)

            if trt_ver != "OFF":
                self.requires("TensorRT/{}@ad4-lotus/stable".format(trt_ver))
                # 这里做了简单处理，与thor基本对齐，10.x的TRT必须依赖CUDA12.8和CUDNN9.10
                # 后续可以根据需要，将CUDA、CUDNN的版本指定外放到Makefile
                if int(trt_ver.split(".")[0]) >= 10:
                    self.requires("CUDA/12.8@ad4-lotus/stable")
                    # self.requires("CUDNN/9.10.2@ad4-lotus/stable")

            if os.environ.get("LMAKE_BUILD_WITH_ONNXRUNTIME_OP", "OFF") == "ON":
                self.requires("onnxruntime/v1.18.1_cuda12@ad4-lotus/stable")

            if os.environ.get("LMAKE_BUILD_WITH_LIBTORCH", "OFF") == "ON":
                self.requires("libtorch/v2.7.1+cu128@ad4-lotus/stable")

        elif system_platform == "devcar":
            trt_ver = os.environ.get("LMAKE_TRT_VERSION", "8.5.3.1")
            python_binding_version = os.environ.get("LMAKE_PYTHON_VERSION", "3.8")
            self.bind_python(python_binding_version)

            if trt_ver != "OFF":
                self.requires("TensorRT/{}@ad4-lotus/stable".format(trt_ver))

        elif system_platform == "orin":
            python_binding_version = os.environ.get("LMAKE_PYTHON_VERSION", "OFF")
            self.bind_python(python_binding_version)
        elif system_platform == "thor":
            python_binding_version = os.environ.get("LMAKE_PYTHON_VERSION", "OFF")
            self.bind_python(python_binding_version)
        else:
            raise Exception("error: unknow platform")

    def configure(self):
        pass

    def build(self):
        build_type = os.environ.get("CMAKE_BUILD_TYPE", "Release")

        cmake = CMake(self)
        cmake.definitions["IS_CONAN"] = "TRUE"
        cmake.definitions["VERSION"] = self.version
        cmake.definitions["CMAKE_POSITION_INDEPENDENT_CODE"] = "ON"
        cmake.definitions["CMAKE_BUILD_TYPE"] = build_type
        cmake.definitions["ENABLE_TEST"] = "ON"
        # cmake.verbose = True

        # Debug编译模式下，默认开启lineinfo；如果需要在Release编译模式下打开，请手动开启
        if build_type == "Release":
            # cmake.definitions["LINFER_NVCC_LINEINFO"] = "ON"
            pass

        cmake.definitions["ENABLE_PYBIND"] = "OFF"
        cmake.definitions["ENABLE_CUPTI"] = "OFF"
        enable_cupti = os.environ.get("ENABLE_CUPTI", "OFF")
        if self.settings.os.platform in ["Devcar", "X86"]:
            # For V100(70), RXT4000/RTX2080/T4(75), A100(80), RTX3090/A10/A40(86).
            cmake.definitions["LINFER_GPU_ARCHS"] = "70;75;80;86"
            python_binding_version = os.environ.get("LMAKE_PYTHON_VERSION", "3.8")
            if self.settings.os.platform == "X86":
                cmake.definitions["LINFER_GPU_ARCHS"] += ";89;90"  # for Ada, Hopper and Blackwell

            if python_binding_version != "OFF":
                python_version_info = self.PythonVersion(
                    *self.python_version_map[python_binding_version]
                )
                cmake.definitions["ENABLE_PYBIND"] = "ON"
                cmake.definitions["PYLINFER_SUFFIX"] = ".cpython-{}-x86_64-linux-gnu.so".format(
                    python_version_info.version
                )
                cmake.definitions["PYTHON_LIB_VERSION"] = python_version_info.lib_name

            if self.settings.os.platform == "X86" and enable_cupti == "ON":
                cmake.definitions["ENABLE_CUPTI"] = "ON"

        elif self.settings.os.platform in ["Orin", "Thor"]:
            if self.settings.os.platform == "Orin":
                cmake.definitions["LINFER_GPU_ARCHS"] = "87"  # For orin
            elif self.settings.os.platform == "Thor":
                cmake.definitions["LINFER_GPU_ARCHS"] = "101"  # For thor

            python_binding_version = os.environ.get("LMAKE_PYTHON_VERSION", "OFF")
            if python_binding_version != "OFF":
                python_version_info = self.PythonVersion(
                    *self.python_version_map[python_binding_version]
                )
                cmake.definitions["ENABLE_PYBIND"] = "ON"
                cmake.definitions["PYLINFER_SUFFIX"] = ".cpython-{}-aarch64-linux-gnu.so".format(
                    python_version_info.version
                )
                cmake.definitions["PYTHON_LIB_VERSION"] = python_version_info.lib_name

            if self.settings.os.platform == "Thor" and enable_cupti == "ON":
                cmake.definitions["ENABLE_CUPTI"] = "ON"
        else:
            raise Exception("error: unknow platform")

        cmake.definitions["ENABLE_ONNXRUNTIME_OP"] = os.environ.get(
            "LMAKE_BUILD_WITH_ONNXRUNTIME_OP", "OFF"
        )

        cmake.definitions["ENABLE_LIBTORCH"] = os.environ.get("LMAKE_BUILD_WITH_LIBTORCH", "OFF")

        cmake.configure()
        cmake.build()
        cmake.install()

    def package(self):
        for lib_dir in self.deps_cpp_info.libdirs:
            self.copy("*.so*", dst="lib", src=lib_dir, symlinks=True)

    def package_info(self):
        self.cpp_info.libs = ["liblinfer.so"]
