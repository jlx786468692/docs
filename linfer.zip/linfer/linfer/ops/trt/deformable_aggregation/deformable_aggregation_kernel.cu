#include <cuda_fp16.h>
#include <stdio.h>
#include <stdlib.h>

template <typename T>
__device__ T bilinear_sampling(const T*& bottom_data,
                               const int& height,
                               const int& width,
                               const int& num_embeds,
                               const T& h_im,
                               const T& w_im,
                               const int& base_ptr) {
  const int h_low = floorf(h_im);
  const int w_low = floorf(w_im);
  const int h_high = h_low + 1;
  const int w_high = w_low + 1;

  const T lh = h_im - (T)h_low;
  const T lw = w_im - (T)w_low;
  const T hh = (T)1 - lh, hw = (T)1 - lw;

  const int h_stride = width * num_embeds;
  const int h_low_ptr_offset = h_low * h_stride;
  const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
  const int w_low_ptr_offset = w_low * num_embeds;
  const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;
  const int base_hl = base_ptr + h_low_ptr_offset;
  const int base_hh = base_ptr + h_high_ptr_offset;

  T val = 0;
  if (h_low >= 0 && w_low >= 0) {
    val += bottom_data[base_hl + w_low_ptr_offset] * hh * hw;
  }

  if (h_low >= 0 && w_high <= width - 1) {
    val += bottom_data[base_hl + w_high_ptr_offset] * hh * lw;
  }

  if (h_high <= height - 1 && w_low >= 0) {
    val += bottom_data[base_hh + w_low_ptr_offset] * lh * hw;
  }

  if (h_high <= height - 1 && w_high <= width - 1) {
    val += bottom_data[base_hh + w_high_ptr_offset] * lh * lw;
  }

  return val;
}

template <typename T>
__global__ void deformable_aggregation_kernel(const int num_kernels,
                                              float* output,
                                              const T* mc_ms_feat,
                                              const int* spatial_shape,
                                              const int* scale_start_index,
                                              const T* sample_location,
                                              const T* weights,
                                              int batch_size,
                                              int num_cams,
                                              int num_feat,
                                              int num_embeds,
                                              int num_scale,
                                              int num_anchors,
                                              int num_pts,
                                              int num_groups) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;

  const T weight = *(weights + idx / (num_embeds / num_groups));  // 通过num_groups达到复用机制
  const int channel_index = idx % num_embeds;
  idx /= num_embeds;
  const int scale_index = idx % num_scale;
  idx /= num_scale;

  const int cam_index = idx % num_cams;
  idx /= num_cams;
  const int pts_index = idx % num_pts;
  idx /= num_pts;

  int anchor_index = idx % num_anchors;
  idx /= num_anchors;
  const int batch_index = idx % batch_size;
  idx /= batch_size;

  anchor_index = batch_index * num_anchors + anchor_index;
  // point_2d = sample_location (bs, anchor, pts, cam, 2)
  const int loc_offset = ((anchor_index * num_pts + pts_index) * num_cams + cam_index) << 1;

  const T loc_w = sample_location[loc_offset];
  if (loc_w <= (T)0 || loc_w >= (T)1) return;  // 限定范围不能够超出图片范围
  const T loc_h = sample_location[loc_offset + 1];
  if (loc_h <= (T)0 || loc_h >= (T)1) return;

  int cam_scale_index =
      cam_index * num_scale + scale_index;  // 不同的图像的不同scale，sclae是由fpn来的
  // cam_scale_index是一个提前计算的量，指示了不同图片的不同scale的特征图的起始偏移
  // 下面为获取feature起始坐标
  const int value_offset =
      (batch_index * num_feat + scale_start_index[cam_scale_index]) * num_embeds + channel_index;

  cam_scale_index = cam_scale_index << 1;
  // 下面为获取不同scale特征图的长与宽
  const int h = spatial_shape[cam_scale_index];
  const int w = spatial_shape[cam_scale_index + 1];

  const T h_im = loc_h * (T)h - (T)0.5;
  const T w_im = loc_w * (T)w - (T)0.5;

  // 输出为anchor的特征图
  atomicAdd(
      output + anchor_index * num_embeds + channel_index,
      (float)(bilinear_sampling(mc_ms_feat, h, w, num_embeds, h_im, w_im, value_offset) * weight));
  // *(output + anchor_index * num_embeds + channel_index) += bilinear_sampling(mc_ms_feat, h, w,
  // num_embeds, h_im, w_im, value_offset) * weight;
}

template <typename T>
__global__ void deformable_aggregation_fast_kernel(const int num_kernels,
                                                   T* output,
                                                   const T* mc_ms_feat,
                                                   const int* spatial_shape,
                                                   const int* scale_start_index,
                                                   const T* sample_location,
                                                   const T* weights,
                                                   int batch_size,
                                                   int num_cams,
                                                   int num_feat,
                                                   int num_embeds,
                                                   int num_scale,
                                                   int num_anchors,
                                                   int num_pts,
                                                   int num_groups) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int pts_stride = num_groups * num_scale * num_cams;
  const int anchor_stride = pts_stride * num_pts;
  int anchor_index = idx / num_embeds;

  int spatial_param = num_cams * num_scale * 2;
  int start_param = num_cams * num_scale;
  int weight_param = num_pts * num_groups;
  __shared__ int share_spatial[128];
  __shared__ int share_start[128];
  __shared__ T share_weights[1920];

  int tid = threadIdx.x;
  if (tid < spatial_param) {
    share_spatial[tid] = spatial_shape[tid];
  }

  if (tid < start_param) {
    share_start[tid] = scale_start_index[tid];
  }

  if (tid < weight_param) {
    for (int j = 0; j < num_cams * num_scale; j++) {
      share_weights[tid * num_cams * num_scale + j] =
          weights[anchor_index * anchor_stride + tid * num_cams * num_scale + j];
    }
  }
  __syncthreads();

  const int batch_index = 0;
  T loc[2];
  int hw[2];
  T ret_value = (T)0.0;

  int channel_index = idx - anchor_index * num_embeds;
  const int base_value = batch_index * num_feat * num_embeds + channel_index;
  for (int i = 0; i < num_pts; i++) {
    const int pts_index = i;
    const int base_weight_offset =
        channel_index / (num_embeds / num_groups) + pts_index * pts_stride;
    const int base_loc_offset = (anchor_index * num_pts + pts_index) * num_cams;
    for (int j = 0; j < num_cams; j++) {
      const int cam_index = j;
      const int loc_offset = (base_loc_offset + cam_index) << 1;
      *(int2*)loc = *(int2*)(sample_location + loc_offset);
      // if (anchor_index == 1 && channel_index == 0) {
      //   printf("loc is %f %f %d %d valide %d %d ret is %f\n", (float)loc[0], (float)loc[1],
      //   i, j, !(loc[0] > (T)0 && loc[0] < (T)1), !(loc[1] > (T)0 && loc[1] < (T)1), \
      // (float)output[anchor_index * num_embeds + channel_index]);
      // }
      if (loc[0] <= (T)0 || loc[0] >= (T)1) continue;
      if (loc[1] <= (T)0 || loc[1] >= (T)1) continue;
      const int base_cam_offset = cam_index * num_scale;
      for (int k = 0; k < num_scale; k++) {
        int cam_scale_index = base_cam_offset + k;
        T weight = *(share_weights + base_weight_offset + cam_scale_index * num_groups);
        const int value_offset = (share_start[cam_scale_index]) * num_embeds + base_value;
        cam_scale_index = cam_scale_index << 1;
        *(int2*)hw = *(int2*)(share_spatial + cam_scale_index);
        const T h_im = loc[1] * (T)hw[0] - (T)0.5;
        const T w_im = loc[0] * (T)hw[1] - (T)0.5;
        ret_value +=
            bilinear_sampling(mc_ms_feat, hw[0], hw[1], num_embeds, h_im, w_im, value_offset) *
            weight;
        // if (anchor_index == 1 && channel_index == 0) {
        //   printf("ret_value is %f %f %f h_im is %f w_im is %f %d %d %d %d %d thread %d %d
        //   loc %f %f\n", (float)ret_value, (float)bilinear_sampling(mc_ms_feat, hw[0],
        //   hw[1], num_embeds, h_im, w_im, value_offset), \ (float)weight, (float)h_im,
        //   (float)w_im, anchor_index, pts_index, cam_index, k, channel_index / (num_embeds
        //   / num_groups), blockIdx.x, threadIdx.x, (float)loc[1], (float)loc[0]);
        // }
      }
    }
  }
  output[anchor_index * num_embeds + channel_index] = ret_value;
}

template <typename T>
__global__ void deformable_aggregation_fast_reshape_kernel(const int num_kernels,
                                                           T* output,
                                                           const T* mc_ms_feat,
                                                           const int* spatial_shape,
                                                           const int* scale_start_index,
                                                           const T* sample_location,
                                                           const T* weights,
                                                           int batch_size,
                                                           int num_cams,
                                                           int num_feat,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int num_pixels) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int batch_index = 0;
  T loc[2];
  int hw[2];
  T ret_value = (T)0.0;

  const int pts_stride = num_groups * num_scale * num_cams;
  const int anchor_stride = pts_stride * num_pts;

  int anchor_index = idx / num_embeds;
  int channel_index = idx - anchor_index * num_embeds;
  for (int i = 0; i < num_pts; i++) {
    const int pts_index = i;
    for (int j = 0; j < num_cams; j++) {
      const int cam_index = j;
      const int loc_offset = ((anchor_index * num_pts + pts_index) * num_cams + cam_index) << 1;
      *(int2*)loc = *(int2*)(sample_location + loc_offset);
      // if (blockIdx.x == 0 && threadIdx.x == 0) {
      // printf("%f %f\n", (float)loc[0], (float)loc[1]);
      // }
      if (loc[0] <= (T)0 || loc[0] >= (T)1) continue;
      if (loc[1] <= (T)0 || loc[1] >= (T)1) continue;
      for (int k = 0; k < num_scale; k++) {
        int cam_scale_index = cam_index * num_scale + k;
        T weight =
            *(weights + channel_index / (num_embeds / num_groups) + cam_scale_index * num_groups +
              pts_index * pts_stride + anchor_index * anchor_stride);
        // const int value_offset = (batch_index * num_feat +
        // scale_start_index[cam_scale_index]) * num_embeds + channel_index;
        const int value_offset = (batch_index * num_feat + cam_index * num_pixels) * num_embeds +
                                 channel_index * num_pixels + scale_start_index[k];
        cam_scale_index = cam_scale_index << 1;
        *(int2*)hw = *(int2*)(spatial_shape + cam_scale_index);
        const T h_im = loc[1] * (T)hw[0] - (T)0.5;
        const T w_im = loc[0] * (T)hw[1] - (T)0.5;
        ret_value +=
            bilinear_sampling(mc_ms_feat, hw[0], hw[1], 1, h_im, w_im, value_offset) * weight;
      }
    }
  }
  output[anchor_index * num_embeds + channel_index] = ret_value;
}

void deformable_aggregation(cudaStream_t stream,
                            float* output,
                            const float* mc_ms_feat,
                            const int* spatial_shape,
                            const int* scale_start_index,
                            const float* sample_location,
                            const float* weights,
                            int batch_size,
                            int num_cams,
                            int num_feat,
                            int num_embeds,
                            int num_scale,
                            int num_anchors,
                            int num_pts,
                            int num_groups) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  const int num_kernels = batch_size * num_pts * num_embeds * num_anchors * num_cams * num_scale;
  deformable_aggregation_kernel<<<(int)ceil(((double)num_kernels / 128)), 128, 0, stream>>>(
      num_kernels,
      output,
      mc_ms_feat,
      spatial_shape,
      scale_start_index,
      sample_location,
      weights,
      batch_size,
      num_cams,
      num_feat,
      num_embeds,
      num_scale,
      num_anchors,
      num_pts,
      num_groups);
}

void deformable_aggregation(cudaStream_t stream,
                            float* output,
                            const __half* mc_ms_feat,
                            const int* spatial_shape,
                            const int* scale_start_index,
                            const __half* sample_location,
                            const __half* weights,
                            int batch_size,
                            int num_cams,
                            int num_feat,
                            int num_embeds,
                            int num_scale,
                            int num_anchors,
                            int num_pts,
                            int num_groups) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  const int num_kernels = batch_size * num_pts * num_embeds * num_anchors * num_cams * num_scale;
  deformable_aggregation_kernel<<<(int)ceil(((double)num_kernels / 128)), 128, 0, stream>>>(
      num_kernels,
      output,
      mc_ms_feat,
      spatial_shape,
      scale_start_index,
      sample_location,
      weights,
      batch_size,
      num_cams,
      num_feat,
      num_embeds,
      num_scale,
      num_anchors,
      num_pts,
      num_groups);
}

/*
    L：多相机多尺度2D特征合并在一起之后的长度
    C：图像特征的Channel数
    K：anchor数量
    P：每个anchor的采样点数量
    N：相机数量
    S：每个相机下的尺度（层次）数量
    G：分组数量

    mc_ms_feat: L x C, 包含多相机多尺度的2D特征，将多相机多尺度的特征合并在一起。
    sample_location: KxPxNx2，在2D图像上的采样点坐标
    weights: KxPxNxSxG，权重
    output: KxC，输出

    分组处理的逻辑：对于同一个anchor、同一个采样点，所对应的同一个相机的同一个尺度下，有C维特征，
    将C维特征分为G组，每组长度为C/G，同组共享相同权重，即：w = weights[k, p, n, s, g]
*/
void deformable_aggregation_fast(cudaStream_t stream,
                                 float* output,
                                 const float* mc_ms_feat,
                                 const int* spatial_shape,
                                 const int* scale_start_index,
                                 const float* sample_location,
                                 const float* weights,
                                 int batch_size,
                                 int num_cams,
                                 int num_feat,
                                 int num_embeds,
                                 int num_scale,
                                 int num_anchors,
                                 int num_pts,
                                 int num_groups) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */
  // printf("start to compute float\n");
  const int num_kernels = batch_size * num_embeds * num_anchors;
  deformable_aggregation_fast_kernel<<<(int)ceil(((double)num_kernels / 128)), 128, 0, stream>>>(
      num_kernels,
      output,
      mc_ms_feat,
      spatial_shape,
      scale_start_index,
      sample_location,
      weights,
      batch_size,
      num_cams,
      num_feat,
      num_embeds,
      num_scale,
      num_anchors,
      num_pts,
      num_groups);
}

void deformable_aggregation_fast(cudaStream_t stream,
                                 __half* output,
                                 const __half* mc_ms_feat,
                                 const int* spatial_shape,
                                 const int* scale_start_index,
                                 const __half* sample_location,
                                 const __half* weights,
                                 int batch_size,
                                 int num_cams,
                                 int num_feat,
                                 int num_embeds,
                                 int num_scale,
                                 int num_anchors,
                                 int num_pts,
                                 int num_groups) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */
  // printf("start to compute half\n");
  const int num_kernels = batch_size * num_embeds * num_anchors;
  deformable_aggregation_fast_kernel<<<(int)ceil(((double)num_kernels / 128)), 128, 0, stream>>>(
      num_kernels,
      output,
      mc_ms_feat,
      spatial_shape,
      scale_start_index,
      sample_location,
      weights,
      batch_size,
      num_cams,
      num_feat,
      num_embeds,
      num_scale,
      num_anchors,
      num_pts,
      num_groups);
}

void deformable_aggregation_fast_no_reshape(cudaStream_t stream,
                                            __half* output,
                                            const __half* mc_ms_feat,
                                            const int* spatial_shape,
                                            const int* scale_start_index,
                                            const __half* sample_location,
                                            const __half* weights,
                                            int batch_size,
                                            int num_cams,
                                            int num_feat,
                                            int num_embeds,
                                            int num_scale,
                                            int num_anchors,
                                            int num_pts,
                                            int num_groups,
                                            int num_pixels) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  const int num_kernels = batch_size * num_embeds * num_anchors;
  deformable_aggregation_fast_reshape_kernel<<<(int)ceil(((double)num_kernels / 128)),
                                               128,
                                               0,
                                               stream>>>(num_kernels,
                                                         output,
                                                         mc_ms_feat,
                                                         spatial_shape,
                                                         scale_start_index,
                                                         sample_location,
                                                         weights,
                                                         batch_size,
                                                         num_cams,
                                                         num_feat,
                                                         num_embeds,
                                                         num_scale,
                                                         num_anchors,
                                                         num_pts,
                                                         num_groups,
                                                         num_pixels);
}