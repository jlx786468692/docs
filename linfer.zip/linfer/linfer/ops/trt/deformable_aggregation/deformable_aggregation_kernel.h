
#ifndef DEFORMABLE_AGGREGATION_KERNEL_H
#define DEFORMABLE_AGGREGATION_KERNEL_H

#include <cuda_runtime.h>

void deformable_aggregation(cudaStream_t stream,
                            float* output,
                            const float* mc_ms_feat,
                            const int* spatial_shape,
                            const int* scale_start_index,
                            const float* sample_location,
                            const float* weights,
                            int batch_size,
                            int num_cams,
                            int num_feat,
                            int num_embeds,
                            int num_scale,
                            int num_anchors,
                            int num_pts,
                            int num_groups);

void deformable_aggregation(cudaStream_t stream,
                            float* output,
                            const __half* mc_ms_feat,
                            const int* spatial_shape,
                            const int* scale_start_index,
                            const __half* sample_location,
                            const __half* weights,
                            int batch_size,
                            int num_cams,
                            int num_feat,
                            int num_embeds,
                            int num_scale,
                            int num_anchors,
                            int num_pts,
                            int num_groups);

void deformable_aggregation_fast(cudaStream_t stream,
                                 float* output,
                                 const float* mc_ms_feat,
                                 const int* spatial_shape,
                                 const int* scale_start_index,
                                 const float* sample_location,
                                 const float* weights,
                                 int batch_size,
                                 int num_cams,
                                 int num_feat,
                                 int num_embeds,
                                 int num_scale,
                                 int num_anchors,
                                 int num_pts,
                                 int num_groups);

void deformable_aggregation_fast(cudaStream_t stream,
                                 __half* output,
                                 const __half* mc_ms_feat,
                                 const int* spatial_shape,
                                 const int* scale_start_index,
                                 const __half* sample_location,
                                 const __half* weights,
                                 int batch_size,
                                 int num_cams,
                                 int num_feat,
                                 int num_embeds,
                                 int num_scale,
                                 int num_anchors,
                                 int num_pts,
                                 int num_groups);

void deformable_aggregation_fast_no_reshape(cudaStream_t stream,
                                            __half* output,
                                            const __half* mc_ms_feat,
                                            const int* spatial_shape,
                                            const int* scale_start_index,
                                            const __half* sample_location,
                                            const __half* weights,
                                            int batch_size,
                                            int num_cams,
                                            int num_feat,
                                            int num_embeds,
                                            int num_scale,
                                            int num_anchors,
                                            int num_pts,
                                            int num_groups,
                                            int num_pixels);

#endif  // DEFORMABLE_AGGREGATION_KERNEL_H
