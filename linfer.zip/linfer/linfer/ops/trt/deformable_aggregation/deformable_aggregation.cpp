// Copyright (c) OpenMMLab. All rights reserved.
#include "deformable_aggregation.hpp"

#include <assert.h>

#include <chrono>

#include "deformable_aggregation_kernel.h"
#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"

namespace linfer {
namespace {
static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"LinferDeformableAggregation"};
}  // namespace

DeformableAggregation::DeformableAggregation(const std::string& name) : TRTPluginBase(name) {}

DeformableAggregation::DeformableAggregation(const std::string name,
                                             const void* data,
                                             size_t length)
    : TRTPluginBase(name) {}

nvinfer1::IPluginV2DynamicExt* DeformableAggregation::clone() const TRT_NOEXCEPT {
  DeformableAggregation* plugin = new DeformableAggregation(mLayerName);
  plugin->setPluginNamespace(getPluginNamespace());

  return plugin;
}

nvinfer1::DimsExprs DeformableAggregation::getOutputDimensions(int outputIndex,
                                                               const nvinfer1::DimsExprs* inputs,
                                                               int nbInputs,
                                                               nvinfer1::IExprBuilder& exprBuilder)
    TRT_NOEXCEPT {
  // input[0] == _mc_ms_feat
  // input[1] == _spatial_shape
  // input[2] == _scale_start_index
  // input[3] == _sampling_location
  // input[4] == _weights
  nvinfer1::DimsExprs ret;
  ret.nbDims = 3;
  ret.d[0] = inputs[0].d[0];
  ret.d[1] = inputs[3].d[1];
  // ret.d[2] = inputs[0].d[2];
  ret.d[2] = inputs[0].d[2];

  return ret;
}

bool DeformableAggregation::supportsFormatCombination(int pos,
                                                      const nvinfer1::PluginTensorDesc* ioDesc,
                                                      int nbInputs,
                                                      int nbOutputs) TRT_NOEXCEPT {
  // input[0] == _mc_ms_feat->kFLOAT
  // input[1] == _spatial_shape->kINT32
  // input[2] == _scale_start_index->kINT32
  // input[3] == _sampling_location->kFLOAT
  // input[4] == _weights->kFLOAT
  // output[0] == features->kFLOAT

  if (pos == 1 || pos == 2) {
    return (ioDesc[pos].type == nvinfer1::DataType::kINT32 &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else {
    if (pos == 0) {
      return ((ioDesc[pos].type == nvinfer1::DataType::kFLOAT ||
               ioDesc[pos].type == nvinfer1::DataType::kHALF) &&
              ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
    } else {
      return (ioDesc[pos].type == ioDesc[0].type &&
              ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
    }
  }
}

void DeformableAggregation::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                            int nbInputs,
                                            const nvinfer1::DynamicPluginTensorDesc* outputs,
                                            int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
  ASSERT(nbOutputs == 1);
}

size_t DeformableAggregation::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                               int nbInputs,
                                               const nvinfer1::PluginTensorDesc* outputs,
                                               int nbOutputs) const TRT_NOEXCEPT {
  return 0;
}

int DeformableAggregation::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                   const nvinfer1::PluginTensorDesc* outputDesc,
                                   const void* const* inputs,
                                   void* const* outputs,
                                   void* workSpace,
                                   cudaStream_t stream) TRT_NOEXCEPT {
  /* feat: bs, num_feat(cam x pixel_num), c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  int batch_size = inputDesc[0].dims.d[0];   // 1
  int num_feat = inputDesc[0].dims.d[1];     // 38170
  int num_embeds = inputDesc[0].dims.d[2];   // 256
  int num_cams = inputDesc[1].dims.d[0];     // 5
  int num_scale = inputDesc[1].dims.d[1];    // 3
  int num_anchors = inputDesc[3].dims.d[1];  // 600
  int num_pts = inputDesc[3].dims.d[2];      // 13
  int num_groups = inputDesc[4].dims.d[5];   // 8
  int num_pixels = inputDesc[0].dims.d[3];   // 未使用

  auto data_type = inputDesc[0].type;
  switch (data_type) {
    case nvinfer1::DataType::kFLOAT:
      deformable_aggregation_fast(stream,
                                  (float*)outputs[0],
                                  (float*)inputs[0],
                                  (int*)inputs[1],
                                  (int*)inputs[2],
                                  (float*)inputs[3],
                                  (float*)inputs[4],
                                  batch_size,
                                  num_cams,
                                  num_feat,
                                  num_embeds,
                                  num_scale,
                                  num_anchors,
                                  num_pts,
                                  num_groups);
      break;
    case nvinfer1::DataType::kHALF:
      ASSERT(batch_size == 1);
      deformable_aggregation_fast(stream,
                                  (__half*)outputs[0],
                                  (__half*)inputs[0],
                                  (int*)inputs[1],
                                  (int*)inputs[2],
                                  (__half*)inputs[3],
                                  (__half*)inputs[4],
                                  batch_size,
                                  num_cams,
                                  num_feat,
                                  num_embeds,
                                  num_scale,
                                  num_anchors,
                                  num_pts,
                                  num_groups);
      // deformable_aggregation_fast_no_reshape((__half*)outputs[0], (__half*)inputs[0],
      // (int*)inputs[1], (int*)inputs[2], (__half*)inputs[3], (__half*)inputs[4],
      // batch_size, num_cams, num_feat, num_embeds, num_scale, num_anchors, num_pts,
      // num_groups, num_pixels);
      break;
    default:
      return 1;
      break;
  }

  return 0;
}

nvinfer1::DataType DeformableAggregation::getOutputDataType(int index,
                                                            const nvinfer1::DataType* inputTypes,
                                                            int nbInputs) const TRT_NOEXCEPT {
  return inputTypes[0];
}

// IPluginV2 Methods
const char* DeformableAggregation::getPluginType() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* DeformableAggregation::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

int DeformableAggregation::getNbOutputs() const TRT_NOEXCEPT { return 1; }

size_t DeformableAggregation::getSerializationSize() const TRT_NOEXCEPT { return 0; }

void DeformableAggregation::serialize(void* buffer) const TRT_NOEXCEPT {}

////////////////////// creator /////////////////////////////

DeformableAggregationCreator::DeformableAggregationCreator() {
  mPluginAttributes = std::vector<nvinfer1::PluginField>({});
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* DeformableAggregationCreator::getPluginName() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* DeformableAggregationCreator::getPluginVersion() const TRT_NOEXCEPT {
  return PLUGIN_VERSION;
}

nvinfer1::IPluginV2* DeformableAggregationCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) TRT_NOEXCEPT {
  DeformableAggregation* plugin = new DeformableAggregation(name);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

nvinfer1::IPluginV2* DeformableAggregationCreator::deserializePlugin(const char* name,
                                                                     const void* serialData,
                                                                     size_t serialLength)
    TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call FCPluginDynamic::destroy()
  auto plugin = new DeformableAggregation(name, serialData, serialLength);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(DeformableAggregationCreator);
}  // namespace linfer
