#include <cuda_fp16.h>
#include <stdio.h>
#include <stdlib.h>

#include <cmath>

template <typename T>
__device__ float compute_projection(const float* share_pm,
                                    const int& offset,
                                    const T& point_w,
                                    const T& point_l,
                                    const T& point_h,
                                    const T& point_one) {
  float cam_0 = *(share_pm + offset);
  float cam_1 = *(share_pm + offset + 1);
  float cam_2 = *(share_pm + offset + 2);
  float cam_3 = *(share_pm + offset + 3);
  return cam_0 * (float)point_w + cam_1 * (float)point_l + cam_2 * (float)point_h +
         cam_3 * (float)point_one;
}

template <typename T>
__device__ void project_points(const T* key_points,
                               const float* share_pm,
                               const float& img_w,
                               const float& img_h,
                               const float& resize_resolution,
                               const int& anchor_index,
                               const int& num_pts,
                               const int& num_cams,
                               const int& num_param0,
                               const int& num_param1,
                               const int& num_cor,
                               const int& pts_index,
                               const int& cam_index,
                               T (&loc)[2]) {
  int point_offset = anchor_index * num_pts * num_cor + pts_index * num_cor;
  T point_w = *(key_points + point_offset);
  T point_l = *(key_points + point_offset + 1);
  T point_h = *(key_points + point_offset + 2);
  T point_one = 1.0;
  float shift_size = 1023.0;
  float img_size = 1024.0;
  float scale_size = 256.0;
  float eps = 1e-5;

  int base_offset = cam_index * num_param0 * num_param1;
  float cam_p0 = compute_projection(share_pm, base_offset, point_w, point_l, point_h, point_one);
  float cam_p1 =
      compute_projection(share_pm, base_offset + num_param1, point_w, point_l, point_h, point_one);
  float cam_p2 = compute_projection(share_pm,
                                    base_offset + 2 * num_param1,
                                    point_w,
                                    point_l,
                                    point_h,
                                    point_one);
  float pi = static_cast<float>(M_PI);

  if (cam_index > 2) {
    float fisheye_pow = powf(cam_p0, 2.0) + powf(cam_p2, 2.0);
    float fisheye = sqrtf(fisheye_pow);
    float cylindar_phi = atan2f(fisheye, cam_p1);
    float cylindar_lamda = atan2f(cam_p2, -cam_p0);
    float cylindar_u = (shift_size - cylindar_lamda / pi * img_size) * resize_resolution;
    float cylindar_v = (cylindar_phi / pi * img_size - scale_size) * resize_resolution;
    loc[0] = (T)(cylindar_u / img_w);
    loc[1] = (T)(cylindar_v / img_h);
  } else {
    if (cam_p2 < eps) {
      cam_p2 = eps;
    }
    loc[0] = (T)(cam_p0 / cam_p2 / img_w);
    loc[1] = (T)(cam_p1 / cam_p2 / img_h);
  }
}

template <typename T>
__global__ void project_2d_kernel(T* output,
                                  const T* key_points,
                                  const float* projection_mat,
                                  const float* image_wh,
                                  const int num_threads,
                                  int num_cams,
                                  int num_pts,
                                  int num_param0,
                                  int num_param1,
                                  int num_cor) {
  T loc[2];
  const float img_w = image_wh[0];
  const float img_h = image_wh[1];
  float img_size = 1024.0;
  float resize_resolution = img_w / img_size;

  int tid = threadIdx.x;
  int cam_param = num_cams * num_param0 * num_param1;
  __shared__ float share_pm[128];
  if (tid < cam_param) {
    share_pm[tid] = projection_mat[tid];
  } else {
    share_pm[tid] = 0;
  }
  __syncthreads();
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_threads) return;

  const int anchor_idx = idx / (num_pts * num_cams);
  const int pts_index = idx % (num_pts * num_cams) / num_cams;
  const int cam_index = idx % (num_pts * num_cams) % num_cams;

  project_points(key_points,
                 share_pm,
                 img_w,
                 img_h,
                 resize_resolution,
                 anchor_idx,
                 num_pts,
                 num_cams,
                 num_param0,
                 num_param1,
                 num_cor,
                 pts_index,
                 cam_index,
                 loc);
  output[idx * 2] = loc[0];
  output[idx * 2 + 1] = loc[1];
}

void project_2d(cudaStream_t stream,
                float* output,
                const float* key_points,
                const float* projection_mat,
                const float* image_wh,
                const int num_anchors,
                int num_cams,
                int num_pts,
                int num_param0,
                int num_param1,
                int num_cor) {
  /* key_points: bs, num_anchors, num_pts, num_cor */
  /* projection_mat: bs, num_cams, num_param0, num_param4 */
  /* image_wh: num_cams, 2 */
  int num_threads = num_anchors * num_pts * num_cams;
  project_2d_kernel<<<(int)ceil(((double)num_threads / 128)), 128, 0, stream>>>(output,
                                                                                key_points,
                                                                                projection_mat,
                                                                                image_wh,
                                                                                num_threads,
                                                                                num_cams,
                                                                                num_pts,
                                                                                num_param0,
                                                                                num_param1,
                                                                                num_cor);
}

void project_2d(cudaStream_t stream,
                __half* output,
                const __half* key_points,
                const float* projection_mat,
                const float* image_wh,
                const int num_anchors,
                int num_cams,
                int num_pts,
                int num_param0,
                int num_param1,
                int num_cor) {
  /* key_points: bs, num_anchors, num_pts, num_cor */
  /* projection_mat: bs, num_cams, num_param0, num_param4 */
  /* image_wh: num_cams, 2 */
  int num_threads = num_anchors * num_pts * num_cams;
  project_2d_kernel<<<(int)ceil(((double)num_threads / 128)), 128, 0, stream>>>(output,
                                                                                key_points,
                                                                                projection_mat,
                                                                                image_wh,
                                                                                num_threads,
                                                                                num_cams,
                                                                                num_pts,
                                                                                num_param0,
                                                                                num_param1,
                                                                                num_cor);
}