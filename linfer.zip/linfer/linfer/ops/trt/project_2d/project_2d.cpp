// Copyright (c) OpenMMLab. All rights reserved.
#include "project_2d.hpp"

#include <assert.h>

#include <chrono>

#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "project_2d_kernel.h"

namespace linfer {
namespace {
static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"LinferProject2D"};
}  // namespace

enum INPUT_POS {
  key_points = 0,
  projection_mat,
  image_wh,
  output_points,
};

Project2d::Project2d(const std::string& name) : TRTPluginBase(name) {}

Project2d::Project2d(const std::string name, const void* data, size_t length)
    : TRTPluginBase(name) {}

nvinfer1::IPluginV2DynamicExt* Project2d::clone() const TRT_NOEXCEPT {
  Project2d* plugin = new Project2d(mLayerName);
  plugin->setPluginNamespace(getPluginNamespace());

  return plugin;
}

nvinfer1::DimsExprs Project2d::getOutputDimensions(int outputIndex,
                                                   const nvinfer1::DimsExprs* inputs,
                                                   int nbInputs,
                                                   nvinfer1::IExprBuilder& exprBuilder)
    TRT_NOEXCEPT {
  // input[0] == key_points->kFLOAT
  // input[1] == projection_mat->kFLOAT
  // input[2] == image_wh->kFLOAT
  nvinfer1::DimsExprs ret;
  ret.nbDims = 5;
  ret.d[0] = inputs[0].d[0];
  ret.d[1] = inputs[0].d[1];
  ret.d[2] = inputs[0].d[2];
  ret.d[3] = inputs[1].d[1];
  ret.d[4] = exprBuilder.constant(2);

  return ret;
}

bool Project2d::supportsFormatCombination(int pos,
                                          const nvinfer1::PluginTensorDesc* ioDesc,
                                          int nbInputs,
                                          int nbOutputs) TRT_NOEXCEPT {
  // input[0] == key_points->kFLOAT
  // input[1] == projection_mat->kFLOAT
  // input[2] == image_wh->kFLOAT
  // output[0] == features->kFLOAT

  auto dtype = ioDesc[pos].type;
  auto dformat = ioDesc[pos].format;

  switch (pos) {
    // 为保证dfa精度，project2d需使用float
    case INPUT_POS::key_points:
      return dtype == nvinfer1::DataType::kFLOAT && dformat == nvinfer1::TensorFormat::kLINEAR;
    case INPUT_POS::projection_mat:
      return (dtype == nvinfer1::DataType::kFLOAT &&
              dformat == ioDesc[INPUT_POS::key_points].format);
    case INPUT_POS::image_wh:
      return (dtype == nvinfer1::DataType::kFLOAT &&
              dformat == ioDesc[INPUT_POS::key_points].format);
    case INPUT_POS::output_points:
      return (dtype == ioDesc[INPUT_POS::key_points].type &&
              dformat == ioDesc[INPUT_POS::key_points].format);
    default:
      return false;
  }
}

void Project2d::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                int nbInputs,
                                const nvinfer1::DynamicPluginTensorDesc* outputs,
                                int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
  ASSERT(nbOutputs == 1);
}

size_t Project2d::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                   int nbInputs,
                                   const nvinfer1::PluginTensorDesc* outputs,
                                   int nbOutputs) const TRT_NOEXCEPT {
  return 0;
}

int Project2d::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                       const nvinfer1::PluginTensorDesc* outputDesc,
                       const void* const* inputs,
                       void* const* outputs,
                       void* workSpace,
                       cudaStream_t stream) TRT_NOEXCEPT {
  /* key_points: bs, num_anchors, num_pts, num_cor*/
  /* projection_mat: bs, num_cams, num_param0, num_param1 */
  /* image_wh: bs, num_cams, scale */
  int batch_size = inputDesc[INPUT_POS::key_points].dims.d[0];      // 1
  int num_anchors = inputDesc[INPUT_POS::key_points].dims.d[1];     // 600
  int num_cams = inputDesc[INPUT_POS::projection_mat].dims.d[1];    // 5
  int num_pts = inputDesc[INPUT_POS::key_points].dims.d[2];         // 13
  int num_param0 = inputDesc[INPUT_POS::projection_mat].dims.d[2];  // 4
  int num_param1 = inputDesc[INPUT_POS::projection_mat].dims.d[3];  // 4
  int num_cor = inputDesc[INPUT_POS::key_points].dims.d[3];         // 3

  auto data_type = inputDesc[INPUT_POS::key_points].type;

  switch (data_type) {
    case nvinfer1::DataType::kFLOAT:
      project_2d(stream,
                 (float*)outputs[0],
                 (float*)inputs[INPUT_POS::key_points],
                 (float*)inputs[INPUT_POS::projection_mat],
                 (float*)inputs[INPUT_POS::image_wh],
                 num_anchors,
                 num_cams,
                 num_pts,
                 num_param0,
                 num_param1,
                 num_cor);
      break;
    // case nvinfer1::DataType::kHALF:
    //     ASSERT(batch_size == 1);
    //     project_2d(stream, (__half*)outputs[0], (__half*)inputs[INPUT_POS::key_points],
    //     (float*)inputs[INPUT_POS::projection_mat], (float*)inputs[INPUT_POS::image_wh],
    //     num_anchors, num_cams, num_pts, num_param0, num_param1, num_cor);
    //     break;
    default:
      return 1;
      break;
  }

  return 0;
}

nvinfer1::DataType Project2d::getOutputDataType(int index,
                                                const nvinfer1::DataType* inputTypes,
                                                int nbInputs) const TRT_NOEXCEPT {
  return inputTypes[0];
}

// IPluginV2 Methods
const char* Project2d::getPluginType() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* Project2d::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

int Project2d::getNbOutputs() const TRT_NOEXCEPT { return 1; }

size_t Project2d::getSerializationSize() const TRT_NOEXCEPT { return 0; }

void Project2d::serialize(void* buffer) const TRT_NOEXCEPT {}

////////////////////// creator /////////////////////////////

Project2dCreator::Project2dCreator() {
  mPluginAttributes = std::vector<nvinfer1::PluginField>({});
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* Project2dCreator::getPluginName() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* Project2dCreator::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

nvinfer1::IPluginV2* Project2dCreator::createPlugin(const char* name,
                                                    const nvinfer1::PluginFieldCollection* fc)
    TRT_NOEXCEPT {
  Project2d* plugin = new Project2d(name);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

nvinfer1::IPluginV2* Project2dCreator::deserializePlugin(const char* name,
                                                         const void* serialData,
                                                         size_t serialLength) TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call FCPluginDynamic::destroy()
  auto plugin = new Project2d(name, serialData, serialLength);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(Project2dCreator);
}  // namespace linfer
