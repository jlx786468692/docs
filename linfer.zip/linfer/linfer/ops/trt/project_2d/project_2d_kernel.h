
#ifndef PROJECT_2D_KERNEL_H
#define PROJECT_2D_KERNEL_H

#include <cuda_runtime.h>

void project_2d(cudaStream_t stream,
                float* output,
                const float* key_points,
                const float* projection_mat,
                const float* image_wh,
                const int num_anchors,
                int num_cams,
                int num_pts,
                int num_param0,
                int num_param1,
                int num_cor);

void project_2d(cudaStream_t stream,
                __half* output,
                const __half* key_points,
                const float* projection_mat,
                const float* image_wh,
                const int num_anchors,
                int num_cams,
                int num_pts,
                int num_param0,
                int num_param1,
                int num_cor);

#endif  // PROJECT_2D_KERNEL_H
