#pragma once

#include <NvInfer.h>
#include <NvInferPlugin.h>

#include <string>
#include <vector>

#include "linfer/util/trt/model.h"
#include "linfer/util/util.h"

namespace linfer {
namespace ops {
namespace trt {

// V3 Plugin implementation
class ConcatpdpPluginV3 : public nvinfer1::IPluginV3,
                          public nvinfer1::IPluginV3OneCore,
                          public nvinfer1::IPluginV3OneBuild,
                          public nvinfer1::IPluginV3OneRuntime {
 public:
  // Constructors/destructors
  ConcatpdpPluginV3();
  ~ConcatpdpPluginV3() = default;

  // nvinfer1::IPluginV3 methods
  nvinfer1::IPluginCapability* getCapabilityInterface(
      nvinfer1::PluginCapabilityType type) noexcept override;

  // nvinfer1::IPluginV3OneCore methods
  char const* getPluginName() const noexcept override;
  char const* getPluginVersion() const noexcept override;
  char const* getPluginNamespace() const noexcept override;
  void setPluginNamespace(char const* pluginNamespace) noexcept;
  int32_t getNbOutputs() const noexcept override;
  nvinfer1::IPluginV3* clone() noexcept override;

  // nvinfer1::IPluginV3OneBuild methods
  bool supportsFormatCombination(int32_t pos,
                                 nvinfer1::DynamicPluginTensorDesc const* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;
  int32_t getOutputDataTypes(nvinfer1::DataType* outputTypes,
                             int32_t nbOutputs,
                             nvinfer1::DataType const* inputTypes,
                             int32_t nbInputs) const noexcept override;
  int32_t getOutputShapes(nvinfer1::DimsExprs const* inputs,
                          int32_t nbInputs,
                          nvinfer1::DimsExprs const* shapeInputs,
                          int32_t nbShapeInputs,
                          nvinfer1::DimsExprs* outputs,
                          int32_t nbOutputs,
                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;
  int32_t configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                          int32_t nbInputs,
                          nvinfer1::DynamicPluginTensorDesc const* out,
                          int32_t nbOutputs) noexcept override;
  nvinfer1::PluginFieldCollection const* getFieldsToSerialize() noexcept override;

  // nvinfer1::IPluginV3OneRuntime methods
  size_t getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                          int32_t nbInputs,
                          nvinfer1::DynamicPluginTensorDesc const* outputs,
                          int32_t nbOutputs) const noexcept override;
  int32_t enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                  nvinfer1::PluginTensorDesc const* outputDesc,
                  void const* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;
  nvinfer1::IPluginV3* attachToContext(nvinfer1::IPluginResourceContext* context) noexcept override;
  int32_t onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                        int32_t nbInputs,
                        nvinfer1::PluginTensorDesc const* outputs,
                        int32_t nbOutputs) noexcept override;

 private:
  // Serialization helpers
  std::vector<nvinfer1::PluginField> mDataToSerialize;
  nvinfer1::PluginFieldCollection mFCToSerialize;

  // Plugin namespace
  std::string mNamespace;
};

// Plugin creator class
class ConcatpdpPluginV3Creator : public nvinfer1::IPluginCreatorV3One {
 public:
  // Constructor
  ConcatpdpPluginV3Creator();

  // nvinfer1::IPluginCreatorV3One methods
  char const* getPluginName() const noexcept override;
  char const* getPluginVersion() const noexcept override;
  nvinfer1::PluginFieldCollection const* getFieldNames() noexcept override;
  nvinfer1::IPluginV3* createPlugin(char const* name,
                                    nvinfer1::PluginFieldCollection const* fc,
                                    nvinfer1::TensorRTPhase phase) noexcept override;
  void setPluginNamespace(char const* pluginNamespace) noexcept;
  char const* getPluginNamespace() const noexcept override;

 private:
  // Plugin fields and namespace
  static nvinfer1::PluginFieldCollection mFC;
  static std::vector<nvinfer1::PluginField> mPluginAttributes;
  std::string mNamespace;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer