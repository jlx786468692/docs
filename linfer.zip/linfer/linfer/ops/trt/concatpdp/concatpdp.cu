#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <math.h>

#include <chrono>
#include <ctime>
#include <type_traits>

#include "concatpdp_kernel.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/log.h"

#define DEBUG_LOG_CONCATPDP_LOCAL 0

namespace linfer {
namespace ops {
namespace trt {

__global__ void concat_broadcast_kernel_float4(const float* __restrict__ x1,  // [1, D2, D3]
                                               const float* __restrict__ x2,  // [1, D1, 1, D3]
                                               float* __restrict__ out,       // [1, D1, D2, 2*D3]
                                               int D1,                        // 108
                                               int D2,                        // 128
                                               int D3                         // 128
) {
  int iD1 = blockIdx.x;   // [0, D1)
  int iD2 = blockIdx.y;   // [0, D2)
  int i64 = threadIdx.x;  // [0, D3/2) ==> since each float4 = 4 floats

  int D4 = D3 * 2;  // 输出的最后维度 = 256
  int D4_div4 = D3 / 2;
  int D3_div4 = D3 / 4;

  if (i64 < D4_div4 && iD2 < D2 && iD1 < D1) {
    int out_base_idx = ((iD1 * D2 + iD2) * D4);
    int i256 = i64 * 4;

    float4 result;
    if (i256 < D3) {
      // 来自 x1
      const float4* x1_ptr = reinterpret_cast<const float4*>(x1);
      result = x1_ptr[iD2 * D3_div4 + i64];
    } else {
      // 来自 x2
      const float4* x2_ptr = reinterpret_cast<const float4*>(x2);
      result = x2_ptr[iD1 * D3_div4 + (i64 - D3_div4)];
    }

    float4* out_ptr = reinterpret_cast<float4*>(&out[out_base_idx]);
    out_ptr[i64] = result;
  }
}
__global__ void concat_broadcast_kernel_half_float4(
    const __half* __restrict__ x1,  // [1, N128, N128]
    const __half* __restrict__ x2,  // [1, N108, 1, N128]
    __half* __restrict__ out,       // [1, N108, N128, N256]
    int N108,
    int N128,
    int D128  // 参数传进来
) {
  int i108 = blockIdx.x;
  int i128 = blockIdx.y * blockDim.x + threadIdx.x;
  int i32 = threadIdx.y;  // 每次处理 8 half (=16B)，即 float4

  int D128_div4 = D128 / 4;
  int N128_div8 = N128 / 8;

  if (i32 < D128_div4 && i128 < N128 && i108 < N108) {
    int out_base_idx = ((i108 * N128 + i128) * D128 * 2);
    int i256 = i32 * 8;  // half index

    // reinterpret as float4 (128bit)
    float4 val;
    if (i256 < N128) {
      // x1: [N128, N128]
      const float4* x1_vec = reinterpret_cast<const float4*>(x1);
      val = x1_vec[i128 * N128_div8 + i32];
    } else {
      // x2: [N108, N128]
      const float4* x2_vec = reinterpret_cast<const float4*>(x2);
      val = x2_vec[i108 * N128_div8 + (i32 - N128_div8)];
    }

    float4* out_vec = reinterpret_cast<float4*>(&out[out_base_idx]);
    out_vec[i32] = val;
  }
}

// size3是4的倍数。
void launch_concat_pdp_kernel(const float* input,
                              const float* other,
                              float* result,
                              int size1,
                              int size2,
                              int size3,
                              cudaStream_t stream) {
#if DEBUG_LOG_CONCATPDP_LOCAL
  cudaEvent_t start_event, stop_event;
  cudaEventCreate(&start_event);
  cudaEventCreate(&stop_event);
  cudaEventRecord(start_event);
#endif
  dim3 block(size3 / 2);
  dim3 grid(size1, size2);
  concat_broadcast_kernel_float4<<<grid, block, 0, stream>>>(input,
                                                             other,
                                                             result,
                                                             size1,
                                                             size2,
                                                             size3);  // 0.052ms
  CHECK_CUDA_STATUS("concat_broadcast_kernel_float4");
#if DEBUG_LOG_CONCATPDP_LOCAL
  cudaEventRecord(stop_event);
  cudaEventSynchronize(stop_event);
  float time;
  cudaEventElapsedTime(&time, start_event, stop_event);
  printf("launch_concat_pdp_kernel 程序运行fp32耗时: %f 毫秒\n", time);  // << " 毫秒" << std::endl;
  cudaEventDestroy(start_event);
  cudaEventDestroy(stop_event);
#endif
}

// size3是8的倍数。size2是2的倍数。
void launch_concat_pdp_kernel(const __half* input,
                              const __half* other,
                              __half* result,
                              int size1,
                              int size2,
                              int size3,
                              cudaStream_t stream) {
#if DEBUG_LOG_CONCATPDP_LOCAL
  cudaEvent_t start_event, stop_event;
  cudaEventCreate(&start_event);
  cudaEventCreate(&stop_event);
  cudaEventRecord(start_event);
#endif

  dim3 block(2, size3 / 4);
  dim3 grid(size1, size2 / 2);
  concat_broadcast_kernel_half_float4<<<grid, block, 0, stream>>>(input,
                                                                  other,
                                                                  result,
                                                                  size1,
                                                                  size2,
                                                                  size3);
  CHECK_CUDA_STATUS("concat_broadcast_kernel_half_float4");
#if DEBUG_LOG_CONCATPDP_LOCAL
  cudaEventRecord(stop_event);
  cudaEventSynchronize(stop_event);
  float time;
  cudaEventElapsedTime(&time, start_event, stop_event);
  printf("launch_concat_pdp_kernel 程序运行fp16耗时: %f 毫秒\n", time);  // << " 毫秒" << std::endl;
  cudaEventDestroy(start_event);
  cudaEventDestroy(stop_event);
#endif
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer