#pragma once

#include <cuda_fp16.h>
#include <cuda_runtime.h>

namespace linfer {
namespace ops {
namespace trt {
void launch_concat_pdp_kernel(const float* input,
                              const float* other,
                              float* result,
                              int size1,
                              int size2,
                              int size3,
                              cudaStream_t stream);
void launch_concat_pdp_kernel(const __half* input,
                              const __half* other,
                              __half* result,
                              int size1,
                              int size2,
                              int size3,
                              cudaStream_t stream);
}  // namespace trt
}  // namespace ops
}  // namespace linfer