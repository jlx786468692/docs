#include "concatpdp_v3.h"

#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "../common/trt_serialize.hpp"
#include "concatpdp_kernel.h"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"

using linfer::ops::trt::ConcatpdpPluginV3Creator;
REGISTER_TENSORRT_PLUGIN(ConcatpdpPluginV3Creator);

namespace linfer {
namespace ops {
namespace trt {

constexpr char const* CONCATPDP_PLUGINV3_VERSION{"1"};
constexpr char const* CONCATPDP_PLUGINV3_NAME{"LinferConcatpdpV3"};

nvinfer1::PluginFieldCollection ConcatpdpPluginV3Creator::mFC{};
std::vector<nvinfer1::PluginField> ConcatpdpPluginV3Creator::mPluginAttributes;

ConcatpdpPluginV3::ConcatpdpPluginV3() {}

nvinfer1::IPluginCapability* ConcatpdpPluginV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* ConcatpdpPluginV3::getPluginName() const noexcept { return CONCATPDP_PLUGINV3_NAME; }

char const* ConcatpdpPluginV3::getPluginVersion() const noexcept {
  return CONCATPDP_PLUGINV3_VERSION;
}

int32_t ConcatpdpPluginV3::getNbOutputs() const noexcept { return 1; }

void ConcatpdpPluginV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* ConcatpdpPluginV3::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

nvinfer1::IPluginV3* ConcatpdpPluginV3::clone() noexcept {
  try {
    auto* plugin = new ConcatpdpPluginV3();
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t ConcatpdpPluginV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                              int32_t nbOutputs,
                                              nvinfer1::DataType const* inputTypes,
                                              int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t ConcatpdpPluginV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::DimsExprs const* shapeInputs,
                                           int32_t nbShapeInputs,
                                           nvinfer1::DimsExprs* outputs,
                                           int32_t nbOutputs,
                                           nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    if (inputs == nullptr) {
      std::cerr << "[PLUGIN] getOutputShapes: inputs is nullptr!" << std::endl;
    }
    const auto in_1 = inputs[1];  // 获取主输入
    const auto in_0 = inputs[0];  // 获取主输入
    nvinfer1::DimsExprs out;
    out.nbDims = in_1.nbDims;
    out.d[0] = in_1.d[0];
    out.d[1] = in_1.d[1];
    out.d[2] = in_0.d[1];
    out.d[3] = exprBuilder.operation(nvinfer1::DimensionOperation::kSUM, *in_0.d[2], *in_1.d[3]);

    outputs[0] = out;
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool ConcatpdpPluginV3::supportsFormatCombination(int32_t pos,
                                                  nvinfer1::DynamicPluginTensorDesc const* inOut,
                                                  int32_t nbInputs,
                                                  int32_t nbOutputs) noexcept {
  try {
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;

    auto dtype = desc.type;
    auto dformat = desc.format;

    switch (pos) {
      case 0:  // First input
        return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
               (dformat == nvinfer1::TensorFormat::kLINEAR ||
                dformat == nvinfer1::TensorFormat::kCHW32);
      case 1: {  // Second input
        bool flag = true;
        return (dtype == inOut[0].desc.type && dformat == inOut[0].desc.format && flag);
      }
      case 2: {  // Output
        bool flag = true;
        if ((inOut[pos].desc.dims.d[0] == inOut[1].desc.dims.d[0]) &&
            (inOut[pos].desc.dims.d[1] == inOut[1].desc.dims.d[1]) &&
            (inOut[pos].desc.dims.d[2] == inOut[0].desc.dims.d[1]) &&
            (inOut[pos].desc.dims.d[3] == (inOut[0].desc.dims.d[2] + inOut[1].desc.dims.d[3])))
          flag = true;
        else
          flag = false;
        return (dtype == inOut[0].desc.type && dformat == inOut[0].desc.format && flag);
      }
      default:
        return false;
    }
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t ConcatpdpPluginV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                           int32_t nbInputs,
                                           nvinfer1::DynamicPluginTensorDesc const* out,
                                           int32_t nbOutputs) noexcept {
  try {
    // Validate input arguments
    PLUGIN_ASSERT(nbInputs == 2 && nbOutputs == 1);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const* ConcatpdpPluginV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    // This plugin has no fields to serialize
    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t ConcatpdpPluginV3::getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::DynamicPluginTensorDesc const* outputs,
                                           int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t ConcatpdpPluginV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                         int32_t nbInputs,
                                         nvinfer1::PluginTensorDesc const* outputs,
                                         int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* ConcatpdpPluginV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t ConcatpdpPluginV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                                   nvinfer1::PluginTensorDesc const* outputDesc,
                                   void const* const* inputs,
                                   void* const* outputs,
                                   void* workspace,
                                   cudaStream_t stream) noexcept {
  try {
    const void* input_ptr0 = inputs[0];
    const void* input_ptr1 = inputs[1];
    void* output_ptr0 = outputs[0];

    int size2 = inputDesc[0].dims.d[1];
    int size1 = inputDesc[1].dims.d[1];
    int size3 = inputDesc[0].dims.d[2];

    bool use_float16 = (inputDesc[0].type == nvinfer1::DataType::kHALF);
    if (use_float16) {
      launch_concat_pdp_kernel((const __half*)input_ptr0,
                               (const __half*)input_ptr1,
                               (__half*)output_ptr0,
                               size1,
                               size2,
                               size3,
                               stream);
    } else {  // use float32
      launch_concat_pdp_kernel((const float*)input_ptr0,
                               (const float*)input_ptr1,
                               (float*)output_ptr0,
                               size1,
                               size2,
                               size3,
                               stream);
    }
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

// Plugin Creator Implementation
ConcatpdpPluginV3Creator::ConcatpdpPluginV3Creator() {
  mPluginAttributes.clear();
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* ConcatpdpPluginV3Creator::getPluginName() const noexcept {
  return CONCATPDP_PLUGINV3_NAME;
}

char const* ConcatpdpPluginV3Creator::getPluginVersion() const noexcept {
  return CONCATPDP_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const* ConcatpdpPluginV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* ConcatpdpPluginV3Creator::createPlugin(
    char const* name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  try {
    // This plugin doesn't have any configurable parameters
    auto* plugin = new ConcatpdpPluginV3();
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void ConcatpdpPluginV3Creator::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* ConcatpdpPluginV3Creator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer