#include "concatpdp.h"

#include <assert.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "concatpdp_kernel.h"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"

using linfer::ops::trt::ConcatpdpPluginCreator;
REGISTER_TENSORRT_PLUGIN(ConcatpdpPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

static size_t getElementSize(nvinfer1::DataType dataType) {
  switch (dataType) {
    case nvinfer1::DataType::kFLOAT:
      return sizeof(float);
    case nvinfer1::DataType::kHALF:
      return 2;
    case nvinfer1::DataType::kINT8:
      return sizeof(int8_t);
    case nvinfer1::DataType::kINT32:
      return sizeof(int32_t);
    default:
      std::cerr << "Unsupported data type." << std::endl;
      return 0;
  }
}

const char* Concatpdp_PLUGIN_VERSION{"1"};
static const char* Concatpdp_PLUGIN_NAME{"LinferConcatpdp"};

nvinfer1::PluginFieldCollection ConcatpdpPluginCreator::mFC{};

Concatpdp::Concatpdp() {
  //  std::cout << "[PLUGIN] Concatpdp constructor called" << std::endl;
}

Concatpdp::~Concatpdp() {
  //  std::cout << "[PLUGIN] Concatpdp destructor called" << std::endl;
}

int Concatpdp::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType Concatpdp::getOutputDataType(int index,
                                                const nvinfer1::DataType* inputTypes,
                                                int nbInputs) const noexcept {
  return inputTypes[0];
}

nvinfer1::DimsExprs Concatpdp::getOutputDimensions(int32_t outputIndex,
                                                   const nvinfer1::DimsExprs* inputs,
                                                   int32_t nbInputs,
                                                   nvinfer1::IExprBuilder& exprBuilder) noexcept {
  if (inputs == nullptr) {
    std::cerr << "[PLUGIN] getOutputDimensions: inputs is nullptr!" << std::endl;
  }
  const auto in_1 = inputs[1];  // 获取主输入
  const auto in_0 = inputs[0];  // 获取主输入
  nvinfer1::DimsExprs out;
  out.nbDims = in_1.nbDims;
  out.d[0] = in_1.d[0];
  out.d[1] = in_1.d[1];
  out.d[2] = in_0.d[1];
  out.d[3] = exprBuilder.operation(nvinfer1::DimensionOperation::kSUM, *in_0.d[2], *in_1.d[3]);

  return out;
}

bool Concatpdp::supportsFormatCombination(int32_t pos,
                                          const nvinfer1::PluginTensorDesc* inOut,
                                          int32_t nbInputs,
                                          int32_t nbOutputs) noexcept {
  // //  std::cout << "[PLUGIN] supportsFormatCombination called, pos = " << pos << std::endl;
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];

  auto dtype = desc.type;
  auto dformat = desc.format;
  int32_t dim_num_0 = inOut[0].dims.nbDims;
  auto Dim_0 = inOut[0].dims;

  switch (pos) {
    case 0:
      // return true;
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
             (dformat == nvinfer1::PluginFormat::kLINEAR ||
              dformat == nvinfer1::PluginFormat::kCHW32);
    case 1: {
      bool flag = true;
      // return true;
      return (dtype == inOut[0].type && dformat == inOut[0].format && flag);
    }
    case 2: {
      bool flag = true;
      if ((inOut[pos].dims.d[0] == inOut[1].dims.d[0]) &&
          (inOut[pos].dims.d[1] == inOut[1].dims.d[1]) &&
          (inOut[pos].dims.d[2] == inOut[0].dims.d[1]) &&
          (inOut[pos].dims.d[3] == (inOut[0].dims.d[2] + inOut[1].dims.d[3])))
        flag = true;
      else
        flag = false;
      // return true;
      return (dtype == inOut[0].type && dformat == inOut[0].format && flag);
    }
    default:
      return false;
  }

  return true;
}

void Concatpdp::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                int32_t nbInputs,
                                const nvinfer1::DynamicPluginTensorDesc* out,
                                int32_t nbOutputs) noexcept {
  if (!(nbInputs == 2 && nbOutputs == 1)) {
    std::cerr << "[PLUGIN][ERROR] configurePlugin: invalid input/output count!" << std::endl;
  }
  ASSERT(nbInputs == 2 && nbOutputs == 1);
}

size_t Concatpdp::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                   int32_t nbInputs,
                                   const nvinfer1::PluginTensorDesc* outputs,
                                   int32_t nbOutputs) const noexcept {
  return 0;
}

int Concatpdp::initialize() noexcept { return 0; }

void Concatpdp::terminate() noexcept {}

int32_t Concatpdp::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                           const nvinfer1::PluginTensorDesc* outputDesc,
                           const void* const* inputs,
                           void* const* outputs,
                           void* workspace,
                           cudaStream_t stream) noexcept {
  const void* input_ptr0 = inputs[0];
  const void* input_ptr1 = inputs[1];
  void* output_ptr0 = outputs[0];

  int size2 = inputDesc[0].dims.d[1];
  int size1 = inputDesc[1].dims.d[1];
  int size3 = inputDesc[0].dims.d[2];

  //   printf("size1 is %d, size2 is %d, size3 is %d. \n", size1, size2, size3);

  bool use_float16 = (inputDesc[0].type == nvinfer1::DataType::kHALF);
  if (use_float16) {
    launch_concat_pdp_kernel((const __half*)input_ptr0,
                             (const __half*)input_ptr1,
                             (__half*)output_ptr0,
                             size1,
                             size2,
                             size3,
                             stream);
  } else {  // use float32
    launch_concat_pdp_kernel((const float*)input_ptr0,
                             (const float*)input_ptr1,
                             (float*)output_ptr0,
                             size1,
                             size2,
                             size3,
                             stream);
  }
  return 0;
}

size_t Concatpdp::getSerializationSize() const noexcept { return sizeof(int); }

void Concatpdp::serialize(void* buffer) const noexcept { return; }

const char* Concatpdp::getPluginType() const noexcept { return Concatpdp_PLUGIN_NAME; }

const char* Concatpdp::getPluginVersion() const noexcept { return Concatpdp_PLUGIN_VERSION; }

void Concatpdp::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* Concatpdp::clone() const noexcept {
  auto plugin = new Concatpdp();
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void Concatpdp::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* Concatpdp::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void Concatpdp::attachToContext(cudnnContext* cudnnContext,
                                cublasContext* cublasContext,
                                nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void Concatpdp::detachFromContext() noexcept {}

ConcatpdpPluginCreator::ConcatpdpPluginCreator() {
  pluginName_ = Concatpdp_PLUGIN_NAME;
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* ConcatpdpPluginCreator::getPluginVersion() const noexcept {
  return Concatpdp_PLUGIN_VERSION;
}
const char* ConcatpdpPluginCreator::getPluginName() const noexcept { return pluginName_.c_str(); }
const nvinfer1::PluginFieldCollection* ConcatpdpPluginCreator::getFieldNames() noexcept {
  return &ConcatpdpPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* ConcatpdpPluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  Concatpdp* obj = new Concatpdp();
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* ConcatpdpPluginCreator::deserializePlugin(const char* plugin_name,
                                                                  const void* serialData,
                                                                  size_t serialLength) noexcept {
  auto obj = new Concatpdp();
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void ConcatpdpPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* ConcatpdpPluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
