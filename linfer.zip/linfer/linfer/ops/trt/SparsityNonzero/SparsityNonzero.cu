
#include <string>
#include <vector>

#include "linfer/ops/cuda/index_add/index_add.cuh"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

#define MAX_THREAD_SIZE 1024

template <typename T>
__global__ void sparse_nonzero(T* ret,
                               const T* m1,
                               const T* m2,
                               const T* dist_th,
                               int* len,
                               int* hi,
                               int* wi,
                               size_t n,
                               size_t part,
                               int max_nonzero_len) {
  register int offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register const T* ptr_m1 = m1 + blockIdx.x * part;
  register const T* ptr_m2 = m2 + threadIdx.x * part;
  register T tmp = .0;
  register const T dist_th_val = *dist_th;

  for (; offset < end; offset++) {
    register int relative_offset = part - (end - offset);
    register T base_value = *(ptr_m1 + relative_offset) - *(ptr_m2 + relative_offset);
    // *(ret + blockIdx.x * n + offset) = *(ptr_m1 + relative_offset) - *(ptr_m2 +
    // relative_offset) ;
    tmp += base_value * base_value;
  }
  if ((float)sqrtf(tmp) <= (float)dist_th_val) {
    int32_t ret_offset = atomicAdd(len, part);
    if (ret_offset < max_nonzero_len) {
      for (int i = 0; i < part; i++) {
        ret[ret_offset + i] = m1[blockIdx.x * part + i] - m2[threadIdx.x * part + i];
      }
      hi[ret_offset / 2] = blockIdx.x;
      wi[ret_offset / 2] = threadIdx.x;
    }
  }
}

template <typename T, int MapWidth, int MapWidthx2>
__global__ void sparse_nonzero_1(T* ret,
                                 const T* m1,
                                 const T* m2,
                                 const T* dist_th,
                                 int* len,
                                 int* hi,
                                 int* wi,
                                 size_t n,
                                 size_t part,
                                 int max_nonzero_len) {
  register int mat_1_part_size = 2;
  register int mat_2_part_size = part;
  register int offset = threadIdx.y * mat_2_part_size;
  size_t part_end = offset + mat_2_part_size;
  register size_t end = (n < part_end) ? n : part_end;
  register const T* ptr_m1 = m1 + threadIdx.x * mat_1_part_size;
  register const T* ptr_m2 = m2 + threadIdx.y * mat_2_part_size;
  register const T dist_th_val = *dist_th;
  register T dist_threshold_square = dist_th_val * dist_th_val;
  register T tmp_dist_square[8];
  register T tmp_dist[8][2];
  register int tmp_hi[8];
  register int tmp_wi[8];

  for (int block_num = 0; block_num < MapWidth;
       offset += 2, block_num++) {  // sample_interval = 16; offset += mat_1_part_size
    for (int n = 0; n < 8; n++) {   // one_thread_n_group = part / mat_1_part_size /
                                    // sample_interval; // one_thread_n_group = 8
      // tmp_dist_square[n] = .0;
      register int sub_offset = offset + n * MapWidthx2;  // n * mat_1_part_size * sample_interval
      for (int i = 0; i < 2; i++) {                       // i < mat_1_part_size
        register int mat1_relative_offset = i;
        register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
        tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 + mat2_relative_offset);
      }
      tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
      tmp_hi[n] = threadIdx.x;
      tmp_wi[n] = threadIdx.y * part / 2 + block_num +
                  n * MapWidth;  // threadIdx.y * part / mat_1_part_size +
                                 // block_num + n * sample_interval
    }
    // __syncthreads();
    for (int n = 0; n < 8; n++) {  // one_thread_n_group = 8
      if (tmp_dist_square[n] <= dist_threshold_square) {
        int32_t ret_offset = atomicAdd(len, 2);  //  mat_1_part_size = 2
        if (ret_offset < max_nonzero_len) {
          for (int i = 0; i < 2; i++) {  // i < mat_1_part_size
            ret[ret_offset + i] = tmp_dist[n][i];
          }
          hi[ret_offset / 2] = tmp_hi[n];
          wi[ret_offset / 2] = tmp_wi[n];
        }
      }
    }
    __syncthreads();
  }
}

/*
    输入：
    agt_ctrs: M x 2，agt坐标位置，M代表有多少个agt，2代表每个agt坐标的维度(x,y)
    ctx_ctrs: N x 2，ctx坐标位置，N代表有多少个ctx，2代表每个ctx坐标的维度(x,y)
    dist: scalar，距离阈值
    nonzero_len: scalar，最大非零长度，如果超过，则丢弃超过部分

    输出：
    hi/wi: L，L代表非零长度（最大不超过nonzero_len），值表示非零点的坐标位置
    dist: L x
   2，L代表非零长度（最大不超过nonzero_len），值表示非零点对应的agt_ctrs与ctx_ctrs的距离，即：
        (agt_ctrs[hi[i]].x - ctx_ctrs[wi[i]].x, agt_ctrs[hi[i]].y - ctx_ctrs[wi[i]].y)

    其它说明：
    非零点：指的是agt_ctrs内各点与ctx_ctrs内各点，两两之间的距离小于dist_th的点，即：
        EuclideanDistance(agt_ctrs[i] - ctx_ctrs[j]) <= dist_th

    整个计算过程近似等价为：
    def sparsity_nonzero(
        agt_ctrs : torch.Tensor,  # M x 2
        ctx_ctrs : torch.Tensor,  # N x 2
        dist_th : float,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        dist = agt_ctrs.view(-1, 1, 2) - ctx_ctrs.view(1, -1, 2)
        dist = torch.sqrt(torch.pow(dist, 2).sum(2))
        mask = torch.le(dist, dist_th)
        idcs = torch.nonzero(mask)
        hi = idcs[:, 0]
        wi = idcs[:, 1]
        dist = agt_ctrs[hi] - ctx_ctrs[wi]
        return dist, hi, wi

*/
pluginStatus_t sparsity_nonzero_op(cudaStream_t stream,
                                   int agt_ctrs_size,
                                   int ctx_ctrs_size,
                                   int sizeOfElementInBytes,
                                   const void* agt_ctrs,
                                   const void* ctx_ctrs,
                                   const void* dist_idx,
                                   void* dist,
                                   void* hi,
                                   void* wi,
                                   int nonzero_len,
                                   void* workspace) {
  int* cuda_ret_len = (int*)workspace;
  cudaMemsetAsync(hi, -1, nonzero_len * sizeof(int), stream);  // FIXME
  cudaMemsetAsync(wi, -1, nonzero_len * sizeof(int), stream);  // FIXME
  cudaMemsetAsync(cuda_ret_len, 0, sizeof(int), stream);
  // printf("sizeOfElementInBytes is %d\n", sizeOfElementInBytes);
  if (sizeOfElementInBytes == 2) {
    if (ctx_ctrs_size <= 1024 && agt_ctrs_size * ctx_ctrs_size <= nonzero_len) {
      const size_t thread_size = ctx_ctrs_size;
      size_t part = 2;
      sparse_nonzero<__half><<<agt_ctrs_size, thread_size, 0, stream>>>((__half*)dist,
                                                                        (__half*)agt_ctrs,
                                                                        (__half*)ctx_ctrs,
                                                                        (__half*)dist_idx,
                                                                        cuda_ret_len,
                                                                        (int*)hi,
                                                                        (int*)wi,
                                                                        ctx_ctrs_size * 2,
                                                                        part,
                                                                        nonzero_len * 2);
    } else {
      size_t thread_len = MAX_THREAD_SIZE / agt_ctrs_size;
      dim3 thread_size(agt_ctrs_size, thread_len);
      size_t part = (ctx_ctrs_size + thread_len - 1) / thread_len * 2;
      if (ctx_ctrs_size == 4096 && agt_ctrs_size == 32) {
        sparse_nonzero_1<__half, 16, 32>
            <<<1, thread_size, 0, stream>>>((__half*)dist,
                                            (__half*)agt_ctrs,
                                            (__half*)ctx_ctrs,
                                            (__half*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 16 = 4096 * 32 / 8192
      } else if (ctx_ctrs_size == 3072 && agt_ctrs_size == 64) {
        sparse_nonzero_1<__half, 24, 48>
            <<<1, thread_size, 0, stream>>>((__half*)dist,
                                            (__half*)agt_ctrs,
                                            (__half*)ctx_ctrs,
                                            (__half*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 24 = 3072 * 64 / 8192
      } else if (ctx_ctrs_size == 3072 && agt_ctrs_size == 32) {
        sparse_nonzero_1<__half, 12, 24>
            <<<1, thread_size, 0, stream>>>((__half*)dist,
                                            (__half*)agt_ctrs,
                                            (__half*)ctx_ctrs,
                                            (__half*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 12 = 3072 * 32 / 8192
      } else if (ctx_ctrs_size == 1024 && agt_ctrs_size == 32) {
        sparse_nonzero_1<__half, 4, 8>
            <<<1, thread_size, 0, stream>>>((__half*)dist,
                                            (__half*)agt_ctrs,
                                            (__half*)ctx_ctrs,
                                            (__half*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 4 = 1024 * 32 / 8192
      } else if (ctx_ctrs_size == 1024 && agt_ctrs_size == 64) {
        sparse_nonzero_1<__half, 8, 16>
            <<<1, thread_size, 0, stream>>>((__half*)dist,
                                            (__half*)agt_ctrs,
                                            (__half*)ctx_ctrs,
                                            (__half*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 8 = 1024 * 64 / 8192
      } else if (ctx_ctrs_size == 384 && agt_ctrs_size == 64) {
        sparse_nonzero_1<__half, 3, 6>
            <<<1, thread_size, 0, stream>>>((__half*)dist,
                                            (__half*)agt_ctrs,
                                            (__half*)ctx_ctrs,
                                            (__half*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 3 = 384 * 64 / 8192
      } else {
        printf("no op suit ctx_ctrs_size %d\n", ctx_ctrs_size);
      }
    }
  } else {
    if (ctx_ctrs_size <= 1024 && agt_ctrs_size * ctx_ctrs_size <= nonzero_len) {
      const size_t thread_size = ctx_ctrs_size;
      size_t part = 2;
      sparse_nonzero<float><<<agt_ctrs_size, thread_size, 0, stream>>>((float*)dist,
                                                                       (float*)agt_ctrs,
                                                                       (float*)ctx_ctrs,
                                                                       (float*)dist_idx,
                                                                       cuda_ret_len,
                                                                       (int*)hi,
                                                                       (int*)wi,
                                                                       ctx_ctrs_size * 2,
                                                                       part,
                                                                       nonzero_len * 2);
    } else {
      size_t thread_len = MAX_THREAD_SIZE / agt_ctrs_size;
      dim3 thread_size(agt_ctrs_size, thread_len);
      size_t part = (ctx_ctrs_size + thread_len - 1) / thread_len * 2;
      if (ctx_ctrs_size == 4096 && agt_ctrs_size == 32) {
        sparse_nonzero_1<float, 16, 32>
            <<<1, thread_size, 0, stream>>>((float*)dist,
                                            (float*)agt_ctrs,
                                            (float*)ctx_ctrs,
                                            (float*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 16 = 4096 * 32 / 8192
      } else if (ctx_ctrs_size == 3072 && agt_ctrs_size == 64) {
        sparse_nonzero_1<float, 24, 48>
            <<<1, thread_size, 0, stream>>>((float*)dist,
                                            (float*)agt_ctrs,
                                            (float*)ctx_ctrs,
                                            (float*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 24 = 3072 * 64 / 8192
      } else if (ctx_ctrs_size == 3072 && agt_ctrs_size == 32) {
        sparse_nonzero_1<float, 12, 24>
            <<<1, thread_size, 0, stream>>>((float*)dist,
                                            (float*)agt_ctrs,
                                            (float*)ctx_ctrs,
                                            (float*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 12 = 3072 * 32 / 8192
      } else if (ctx_ctrs_size == 1024 && agt_ctrs_size == 32) {
        sparse_nonzero_1<float, 4, 8>
            <<<1, thread_size, 0, stream>>>((float*)dist,
                                            (float*)agt_ctrs,
                                            (float*)ctx_ctrs,
                                            (float*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 4 = 1024 * 32 / 8192
      } else if (ctx_ctrs_size == 1024 && agt_ctrs_size == 64) {
        sparse_nonzero_1<float, 8, 16>
            <<<1, thread_size, 0, stream>>>((float*)dist,
                                            (float*)agt_ctrs,
                                            (float*)ctx_ctrs,
                                            (float*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 8 = 1024 * 64 / 8192
      } else if (ctx_ctrs_size == 384 && agt_ctrs_size == 64) {
        sparse_nonzero_1<float, 3, 6>
            <<<1, thread_size, 0, stream>>>((float*)dist,
                                            (float*)agt_ctrs,
                                            (float*)ctx_ctrs,
                                            (float*)dist_idx,
                                            cuda_ret_len,
                                            (int*)hi,
                                            (int*)wi,
                                            ctx_ctrs_size * 2,
                                            part,
                                            nonzero_len * 2);  // 3 = 384 * 64 / 8192
      } else {
        printf("no op suit ctx_ctrs_size %d\n", ctx_ctrs_size);
      }
    }
  }
  CHECK_CUDA_STATUS("sparse_nonzero");

  return STATUS_SUCCESS;
}

/*
__global__ void sparse_nonzero_1_for_4096_width(float* ret, const float* m1, const float* m2, const
float* dist_th, int* len, int* hi, int* wi, size_t n, size_t part, int max_nonzero_len) { register
int mat_1_part_size = 2; register int mat_2_part_size = part; register int offset = threadIdx.y *
mat_2_part_size; size_t part_end = offset + mat_2_part_size; register size_t end = (n < part_end) ?
n : part_end; register const float* ptr_m1 = m1 + threadIdx.x * mat_1_part_size; register const
float* ptr_m2 = m2 + threadIdx.y * mat_2_part_size; register const float dist_th_val = *dist_th;
    register float dist_threshold_square = dist_th_val * dist_th_val;
    register float tmp_dist_square[8];
    register float tmp_dist[8][2];
    register int tmp_hi[8];
    register int tmp_wi[8];

    for (int block_num = 0; block_num < 16; offset += 2, block_num++) { // sample_interval = 16;
offset += mat_1_part_size for (int n = 0; n < 8; n++) { // one_thread_n_group = part /
mat_1_part_size / sample_interval; // one_thread_n_group = 8
            // tmp_dist_square[n] = .0;
            register int sub_offset = offset + n * 32; // n * mat_1_part_size * sample_interval
            for (int i = 0; i < 2; i++) { // i < mat_1_part_size
                register int mat1_relative_offset = i;
                register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
                tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 +
mat2_relative_offset);
            }
            tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
            tmp_hi[n] = threadIdx.x;
            tmp_wi[n] = threadIdx.y * part / 2 + block_num + n * 16; // threadIdx.y * part /
mat_1_part_size + block_num + n * sample_interval
        }
        // __syncthreads();
        for (int n = 0; n < 8; n++) { // one_thread_n_group = 8
            if (tmp_dist_square[n] <= dist_threshold_square){
                int32_t ret_offset = atomicAdd(len, 2); //  mat_1_part_size = 2
                if (ret_offset < max_nonzero_len) {
                    for (int i = 0 ; i < 2; i++) { // i < mat_1_part_size
                        ret[ret_offset + i] = tmp_dist[n][i];
                    }
                    hi[ret_offset / 2] = tmp_hi[n];
                    wi[ret_offset / 2] = tmp_wi[n];
                }
            }
        }
        __syncthreads();
    }
}

__global__ void sparse_nonzero_h(__half* ret, const __half* m1, const __half* m2, const __half*
dist_th, int* len, int* hi, int* wi, size_t n, size_t part, int max_nonzero_len) { register int
offset = threadIdx.x * part; size_t part_end = offset + part; register size_t end = (n < part_end) ?
n : part_end; register const __half* ptr_m1 = m1 + blockIdx.x * part; register const __half* ptr_m2
= m2 + threadIdx.x * part; register __half tmp = .0; register const __half dist_th_val = *dist_th;

    for (; offset < end; offset++) {
        register int relative_offset = part - (end - offset);
        register __half base_value = *(ptr_m1 + relative_offset) - *(ptr_m2 + relative_offset);
        // *(ret + blockIdx.x * n + offset) = *(ptr_m1 + relative_offset) - *(ptr_m2 +
relative_offset) ; tmp += base_value * base_value ;
    }
    if((float)sqrtf(tmp) <= (float)dist_th_val) {
        int32_t ret_offset = atomicAdd(len, part);
        if (ret_offset < max_nonzero_len) {
        for (int i = 0 ; i < part; i++) {
            ret[ret_offset + i] = m1[blockIdx.x * part + i] - m2[threadIdx.x * part + i];
        }
        hi[ret_offset / 2] = blockIdx.x;
        wi[ret_offset / 2] = threadIdx.x;}
    }
}

__global__ void sparse_nonzero_h1_for_4096_width(__half* ret, const __half* m1, const __half* m2,
const __half* dist_th, int* len, int* hi, int* wi, size_t n, size_t part, int max_nonzero_len) {
    register int mat_1_part_size = 2;
    register int mat_2_part_size = part;
    register int offset = threadIdx.y * mat_2_part_size;
    size_t part_end = offset + mat_2_part_size;
    register size_t end = (n < part_end) ? n : part_end;
    register const __half* ptr_m1 = m1 + threadIdx.x * mat_1_part_size;
    register const __half* ptr_m2 = m2 + threadIdx.y * mat_2_part_size;
    register const __half dist_th_val = *dist_th;
    register __half dist_threshold_square = dist_th_val * dist_th_val;
    register __half tmp_dist_square[8];
    register __half tmp_dist[8][2];
    register int tmp_hi[8];
    register int tmp_wi[8];

    for (int block_num = 0; block_num < 16; offset += 2, block_num++) { // sample_interval = 16;
offset += mat_1_part_size for (int n = 0; n < 8; n++) { // one_thread_n_group = part /
mat_1_part_size / sample_interval; // one_thread_n_group = 8
            // tmp_dist_square[n] = .0;
            register int sub_offset = offset + n * 32; // n * mat_1_part_size * sample_interval
            for (int i = 0; i < 2; i++) { // i < mat_1_part_size
                register int mat1_relative_offset = i;
                register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
                tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 +
mat2_relative_offset);
            }
            tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
            tmp_hi[n] = threadIdx.x;
            tmp_wi[n] = threadIdx.y * part / 2 + block_num + n * 16; // threadIdx.y * part /
mat_1_part_size + block_num + n * sample_interval
        }
        // __syncthreads();
        for (int n = 0; n < 8; n++) { // one_thread_n_group = 8
            if (tmp_dist_square[n] <= dist_threshold_square){
                int32_t ret_offset = atomicAdd(len, 2); //  mat_1_part_size = 2
                if (ret_offset < max_nonzero_len) {
                    for (int i = 0 ; i < 2; i++) { // i < mat_1_part_size
                        ret[ret_offset + i] = tmp_dist[n][i];
                    }
                    hi[ret_offset / 2] = tmp_hi[n];
                    wi[ret_offset / 2] = tmp_wi[n];
                }
            }
        }
        __syncthreads();
    }
}


__global__ void sparse_nonzero_1_for_1024_width(float* ret, const float* m1, const float* m2, const
float* dist_th, int* len, int* hi, int* wi, size_t n, size_t part, int max_nonzero_len) { register
int mat_1_part_size = 2; register int mat_2_part_size = part; register int offset = threadIdx.y *
mat_2_part_size; size_t part_end = offset + mat_2_part_size; register size_t end = (n < part_end) ?
n : part_end; register const float* ptr_m1 = m1 + threadIdx.x * mat_1_part_size; register const
float* ptr_m2 = m2 + threadIdx.y * mat_2_part_size; register const float dist_th_val = *dist_th;
    register float dist_threshold_square = dist_th_val * dist_th_val;
    register float tmp_dist_square[8];
    register float tmp_dist[8][2];
    register int tmp_hi[8];
    register int tmp_wi[8];

    for (int block_num = 0; block_num < 4; offset += 2, block_num++) { // sample_interval = 16;
offset += mat_1_part_size for (int n = 0; n < 8; n++) { // one_thread_n_group = part /
mat_1_part_size / sample_interval; // one_thread_n_group = 8
            // tmp_dist_square[n] = .0;
            register int sub_offset = offset + n * 8; // n * mat_1_part_size * sample_interval
            for (int i = 0; i < 2; i++) { // i < mat_1_part_size
                register int mat1_relative_offset = i;
                register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
                tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 +
mat2_relative_offset);
            }
            tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
            tmp_hi[n] = threadIdx.x;
            tmp_wi[n] = threadIdx.y * part / 2 + block_num + n * 4; // threadIdx.y * part /
mat_1_part_size + block_num + n * sample_interval
        }
        // __syncthreads();
        for (int n = 0; n < 8; n++) { // one_thread_n_group = 8
            if (tmp_dist_square[n] <= dist_threshold_square){
                int32_t ret_offset = atomicAdd(len, 2); //  mat_1_part_size = 2
                if (ret_offset < max_nonzero_len) {
                    for (int i = 0 ; i < 2; i++) { // i < mat_1_part_size
                        ret[ret_offset + i] = tmp_dist[n][i];
                    }
                    hi[ret_offset / 2] = tmp_hi[n];
                    wi[ret_offset / 2] = tmp_wi[n];
                }
            }
        }
        __syncthreads();
    }
}


__global__ void sparse_nonzero_h1_for_1024_width(__half* ret, const __half* m1, const __half* m2,
const __half* dist_th, int* len, int* hi, int* wi, size_t n, size_t part, int max_nonzero_len) {
    register int mat_1_part_size = 2;
    register int mat_2_part_size = part;
    register int offset = threadIdx.y * mat_2_part_size;
    size_t part_end = offset + mat_2_part_size;
    register size_t end = (n < part_end) ? n : part_end;
    register const __half* ptr_m1 = m1 + threadIdx.x * mat_1_part_size;
    register const __half* ptr_m2 = m2 + threadIdx.y * mat_2_part_size;
    register const __half dist_th_val = *dist_th;
    register __half dist_threshold_square = dist_th_val * dist_th_val;
    register __half tmp_dist_square[8];
    register __half tmp_dist[8][2];
    register int tmp_hi[8];
    register int tmp_wi[8];

    for (int block_num = 0; block_num < 4; offset += 2, block_num++) { // sample_interval = 16;
offset += mat_1_part_size for (int n = 0; n < 8; n++) { // one_thread_n_group = part /
mat_1_part_size / sample_interval; // one_thread_n_group = 8
            // tmp_dist_square[n] = .0;
            register int sub_offset = offset + n * 8; // n * mat_1_part_size * sample_interval
            for (int i = 0; i < 2; i++) { // i < mat_1_part_size
                register int mat1_relative_offset = i;
                register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
                tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 +
mat2_relative_offset);
            }
            tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
            tmp_hi[n] = threadIdx.x;
            tmp_wi[n] = threadIdx.y * part / 2 + block_num + n * 4; // threadIdx.y * part /
mat_1_part_size + block_num + n * sample_interval
        }
        // __syncthreads();
        for (int n = 0; n < 8; n++) { // one_thread_n_group = 8
            if (tmp_dist_square[n] <= dist_threshold_square){
                int32_t ret_offset = atomicAdd(len, 2); //  mat_1_part_size = 2
                if (ret_offset < max_nonzero_len) {
                    for (int i = 0 ; i < 2; i++) { // i < mat_1_part_size
                        ret[ret_offset + i] = tmp_dist[n][i];
                    }
                    hi[ret_offset / 2] = tmp_hi[n];
                    wi[ret_offset / 2] = tmp_wi[n];
                }
            }
        }
        __syncthreads();
    }
}*/