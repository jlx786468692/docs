#include "linfer/ops/trt/SparsityNonzero/SparsityNonzero.h"

#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

pluginStatus_t sparsity_nonzero_op(cudaStream_t stream,
                                   int agt_ctrs_size,
                                   int ctx_ctrs_size,
                                   int sizeOfElementInBytes,
                                   const void* agt_ctrs,
                                   const void* ctx_ctrs,
                                   const void* dist_idx,
                                   void* dist,
                                   void* hi,
                                   void* wi,
                                   int nonzero_len,
                                   void* workspace);

using linfer::ops::trt::SparsityNonzeroPluginCreator;
REGISTER_TENSORRT_PLUGIN(SparsityNonzeroPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

extern int32_t get_row_size(const nvinfer1::Dims& input);

const char* SUPER_PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"SparsityNonzero"};

// int32_t get_row_size(const nvinfer1::Dims& input) { return input.d[0]; }

int SparsityNonzero::agt_ctrs_idx_ = 0;
int SparsityNonzero::ctx_ctrs_idx_ = 1;
int SparsityNonzero::dist_th_idx_ = 2;
int SparsityNonzero::dist_idx_ = 0;
int SparsityNonzero::hi_idx_ = 1;
int SparsityNonzero::wi_idx_ = 2;
int SparsityNonzero::nonzero_length_ = 8192;

SparsityNonzero::SparsityNonzero() {}

SparsityNonzero::~SparsityNonzero() {}

bool SparsityNonzero::supportsFormatCombination(int32_t pos,
                                                const nvinfer1::PluginTensorDesc* inOut,
                                                int32_t nbInputs,
                                                int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  if (pos <= nbInputs && pos > 0) {
    return desc.type == inOut[agt_ctrs_idx_].type && desc.format == inOut[agt_ctrs_idx_].format;
  }
  return ((desc.type == nvinfer1::DataType::kHALF || desc.type == nvinfer1::DataType::kFLOAT ||
           desc.type == nvinfer1::DataType::kINT32) &&
          desc.format == nvinfer1::TensorFormat::kLINEAR);
}

void SparsityNonzero::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                      int32_t nbInputs,
                                      const nvinfer1::DynamicPluginTensorDesc* out,
                                      int32_t nbOutputs) noexcept {}

size_t SparsityNonzero::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                         int32_t nbInputs,
                                         const nvinfer1::PluginTensorDesc* outputs,
                                         int32_t nbOutputs) const noexcept {
  int32_t agt_r_size = get_row_size(inputs[agt_ctrs_idx_].dims);
  int32_t ctx_r_size = get_row_size(inputs[ctx_ctrs_idx_].dims);
  return (1) * sizeof(float);
}

int SparsityNonzero::initialize() noexcept { return 0; }

void SparsityNonzero::terminate() noexcept {}

int32_t SparsityNonzero::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                 const nvinfer1::PluginTensorDesc* outputDesc,
                                 const void* const* inputs,
                                 void* const* outputs,
                                 void* workspace,
                                 cudaStream_t stream) noexcept {
  nvinfer1::Dims agt_ctrs_Dims = inputDesc[agt_ctrs_idx_].dims;
  nvinfer1::Dims ctx_ctrs_Dims = inputDesc[ctx_ctrs_idx_].dims;
  int32_t agt_ctrs_r_size = get_row_size(agt_ctrs_Dims);
  int32_t ctx_ctrs_r_size = get_row_size(ctx_ctrs_Dims);
  int32_t elementSizeInBytes = linfer::util::getElementSize(inputDesc[agt_ctrs_idx_].type);
  sparsity_nonzero_op(stream,
                      agt_ctrs_r_size,
                      ctx_ctrs_r_size,
                      elementSizeInBytes,
                      inputs[agt_ctrs_idx_],
                      inputs[ctx_ctrs_idx_],
                      inputs[dist_th_idx_],
                      outputs[dist_idx_],
                      outputs[hi_idx_],
                      outputs[wi_idx_],
                      nonzero_length_,
                      workspace);
  return 0;
}

size_t SparsityNonzero::getSerializationSize() const noexcept { return 0; }

void SparsityNonzero::serialize(void* buffer) const noexcept { return; }

const char* SparsityNonzero::getPluginType() const noexcept { return PLUGIN_NAME; }

const char* SparsityNonzero::getPluginVersion() const noexcept { return SUPER_PLUGIN_VERSION; }

void SparsityNonzero::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* SparsityNonzero::clone() const noexcept {
  auto att = new SparsityNonzero();
  att->setPluginNamespace(mPluginNamespace.c_str());
  return att;
}

void SparsityNonzero::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* SparsityNonzero::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

int SparsityNonzero::getNbOutputs() const noexcept { return 3; }

nvinfer1::DimsExprs SparsityNonzero::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs ret;
  switch (outputIndex) {
    case 0:
      ret.d[0] = exprBuilder.constant(nonzero_length_);
      ret.d[1] = exprBuilder.constant(2);
      ret.nbDims = 2;
      break;
    case 1:
      ret.d[0] = exprBuilder.constant(nonzero_length_);
      ret.nbDims = 1;
      break;
    case 2:
      ret.d[0] = exprBuilder.constant(nonzero_length_);
      ret.nbDims = 1;
      break;
  }
  return ret;
}

nvinfer1::DataType SparsityNonzero::getOutputDataType(int index,
                                                      const nvinfer1::DataType* inputTypes,
                                                      int nbInputs) const noexcept {
  if (index == dist_idx_) {
    return inputTypes[agt_ctrs_idx_];
  }
  return nvinfer1::DataType::kINT32;
}

void SparsityNonzero::attachToContext(cudnnContext* cudnnContext,
                                      cublasContext* cublasContext,
                                      nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void SparsityNonzero::detachFromContext() noexcept {}

nvinfer1::PluginFieldCollection SparsityNonzeroPluginCreator::mFC{};

SparsityNonzeroPluginCreator::SparsityNonzeroPluginCreator() {
  mFC.nbFields = 0;
  mFC.fields = nullptr;
  plugin_name_ = PLUGIN_NAME;
}
const char* SparsityNonzeroPluginCreator::getPluginVersion() const noexcept {
  return SUPER_PLUGIN_VERSION;
}
const char* SparsityNonzeroPluginCreator::getPluginName() const noexcept {
  return plugin_name_.c_str();
}
const nvinfer1::PluginFieldCollection* SparsityNonzeroPluginCreator::getFieldNames() noexcept {
  return &SparsityNonzeroPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* SparsityNonzeroPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  auto obj = new SparsityNonzero();
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* SparsityNonzeroPluginCreator::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  auto obj = new SparsityNonzero();
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

void SparsityNonzeroPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mNamespace = libNamespace;
}

const char* SparsityNonzeroPluginCreator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
