#include "max_selected.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "max_selected_kernel.h"

using linfer::ops::trt::MaxSelectedPluginCreator;
REGISTER_TENSORRT_PLUGIN(MaxSelectedPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

static size_t getElementSize(nvinfer1::DataType dataType) {
  switch (dataType) {
    case nvinfer1::DataType::kFLOAT:
      return sizeof(float);
    case nvinfer1::DataType::kHALF:
      // 半精度浮点数通常为 2 字节
      return 2;
    case nvinfer1::DataType::kINT8:
      return sizeof(int8_t);
    case nvinfer1::DataType::kINT32:
      return sizeof(int32_t);
    default:
      std::cerr << "Unsupported data type." << std::endl;
      return 0;
  }
}

enum INOUT_POS {
  input = 0,
  output_base = 1,
  output_base_input = output_base,
  output = output_base_input - output_base,
};
const char* MAXSELECTED_PLUGIN_VERSION{"1"};
static const char* MAXSELECTED_PLUGIN_NAME{"LinferMaxSelected"};

nvinfer1::PluginFieldCollection MaxSelectedPluginCreator::mFC{};

MaxSelected::MaxSelected() {}

MaxSelected::~MaxSelected() {}

int MaxSelected::getNbOutputs() const noexcept { return 2; }

nvinfer1::DataType MaxSelected::getOutputDataType(int index,
                                                  const nvinfer1::DataType* inputTypes,
                                                  int nbInputs) const noexcept {
  return inputTypes[index];
}

nvinfer1::DimsExprs MaxSelected::getOutputDimensions(int32_t outputIndex,
                                                     const nvinfer1::DimsExprs* inputs,
                                                     int32_t nbInputs,
                                                     nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs output_dims = inputs[0];
  output_dims.d[1] = inputs[1].d[0];
  return output_dims;
}

bool MaxSelected::supportsFormatCombination(int32_t pos,
                                            const nvinfer1::PluginTensorDesc* inOut,
                                            int32_t nbInputs,
                                            int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];

  auto dtype = inOut[pos].type;
  auto dformat = inOut[pos].format;

  switch (pos) {
    case 0:
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
             (dformat == nvinfer1::PluginFormat::kLINEAR ||
              dformat == nvinfer1::PluginFormat::kCHW32);
    case 1:
      return (dtype == nvinfer1::DataType::kINT32) && (dformat == nvinfer1::PluginFormat::kLINEAR ||
                                                       dformat == nvinfer1::PluginFormat::kCHW32);
    case 2:
      return (dtype == inOut[0].type && dformat == inOut[0].format);

    case 3:
      return (dtype == nvinfer1::DataType::kINT32) && (dformat == nvinfer1::PluginFormat::kLINEAR ||
                                                       dformat == nvinfer1::PluginFormat::kCHW32);
    default:
      return false;
  }

  return true;
}

void MaxSelected::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                  int32_t nbInputs,
                                  const nvinfer1::DynamicPluginTensorDesc* out,
                                  int32_t nbOutputs) noexcept {
  ASSERT(nbInputs == 2 && nbOutputs == 2);
  for (int index = 0; index < nbInputs; index++) {
    ASSERT(out[index].desc.dims.d[1] == in[1].desc.dims.d[0]);
    ASSERT(out[index].desc.dims.d[0] == in[0].desc.dims.d[0]);
  }
}

size_t MaxSelected::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                     int32_t nbInputs,
                                     const nvinfer1::PluginTensorDesc* outputs,
                                     int32_t nbOutputs) const noexcept {
  return 0;
}

int MaxSelected::initialize() noexcept { return 0; }

void MaxSelected::terminate() noexcept {}

int32_t MaxSelected::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                             const nvinfer1::PluginTensorDesc* outputDesc,
                             const void* const* inputs,
                             void* const* outputs,
                             void* workspace,
                             cudaStream_t stream) noexcept {
  const void* input_ptr0 = inputs[0];
  const void* input_ptr1 = inputs[1];
  void* output_ptr0 = outputs[0];
  void* output_ptr1 = outputs[1];

  int num_vectors = inputDesc[0].dims.d[0];
  int vector_length = inputDesc[0].dims.d[1];
  int out_vectorlength = outputDesc[1].dims.d[1];

  bool use_float16 = (inputDesc[0].type == nvinfer1::DataType::kHALF);
  if (use_float16) {
    launch_max_selected_kernel((const __half*)input_ptr0,
                               (const int*)input_ptr1,
                               (__half*)output_ptr0,
                               (int*)output_ptr1,
                               num_vectors,
                               vector_length,
                               out_vectorlength,
                               stream);
  } else {  // use float32
    launch_max_selected_kernel((const float*)input_ptr0,
                               (const int*)input_ptr1,
                               (float*)output_ptr0,
                               (int*)output_ptr1,
                               num_vectors,
                               vector_length,
                               out_vectorlength,
                               stream);
  }
  return 0;
}

size_t MaxSelected::getSerializationSize() const noexcept { return 0; }

void MaxSelected::serialize(void* buffer) const noexcept {}

const char* MaxSelected::getPluginType() const noexcept { return MAXSELECTED_PLUGIN_NAME; }

const char* MaxSelected::getPluginVersion() const noexcept { return MAXSELECTED_PLUGIN_VERSION; }

void MaxSelected::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* MaxSelected::clone() const noexcept {
  auto plugin = new MaxSelected();
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void MaxSelected::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* MaxSelected::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void MaxSelected::attachToContext(cudnnContext* cudnnContext,
                                  cublasContext* cublasContext,
                                  nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void MaxSelected::detachFromContext() noexcept {}

MaxSelectedPluginCreator::MaxSelectedPluginCreator() {
  pluginName_ = MAXSELECTED_PLUGIN_NAME;
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* MaxSelectedPluginCreator::getPluginVersion() const noexcept {
  return MAXSELECTED_PLUGIN_VERSION;
}
const char* MaxSelectedPluginCreator::getPluginName() const noexcept { return pluginName_.c_str(); }
const nvinfer1::PluginFieldCollection* MaxSelectedPluginCreator::getFieldNames() noexcept {
  return &MaxSelectedPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* MaxSelectedPluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  MaxSelected* obj = new MaxSelected();
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* MaxSelectedPluginCreator::deserializePlugin(const char* plugin_name,
                                                                    const void* serialData,
                                                                    size_t serialLength) noexcept {
  auto obj = new MaxSelected();
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void MaxSelectedPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* MaxSelectedPluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
