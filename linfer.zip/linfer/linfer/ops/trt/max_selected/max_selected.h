#pragma once

#include <NvInfer.h>
#include <cublas_v2.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <mutex>
#include <string>
#include <vector>

#include "linfer/util/trt/model.h"
#include "linfer/util/util.h"

namespace linfer {
namespace ops {
namespace trt {

class MaxSelected : public nvinfer1::IPluginV2DynamicExt {
 public:
  MaxSelected();

  ~MaxSelected(void) override;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  virtual size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                  int32_t nbInputs,
                                  const nvinfer1::PluginTensorDesc* outputs,
                                  int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  int getNbOutputs() const noexcept override;

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

 private:
  std::string namespace_;
};

class MaxSelectedPluginCreator : public nvinfer1::IPluginCreator {
 private:
  static nvinfer1::PluginFieldCollection mFC;
  std::vector<nvinfer1::PluginField> mPluginAttributes;
  std::string pluginName_;

 protected:
  std::string namespace_;

 public:
  MaxSelectedPluginCreator();
  ~MaxSelectedPluginCreator() override = default;
  const char* getPluginVersion() const noexcept override;
  const char* getPluginName() const noexcept override;
  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;
  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept;
  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept;
  void setPluginNamespace(const char* libNamespace) noexcept;
  const char* getPluginNamespace() const noexcept;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer
