#pragma once

#include <cuda_fp16.h>
#include <cuda_runtime.h>

namespace linfer {
namespace ops {
namespace trt {

void launch_max_selected_kernel(const float* input,
                                const int* segment_offset,
                                float* output_maxscores,
                                int* output_labels,
                                int num_vectors,
                                int vector_length,
                                int out_vectorlength,
                                cudaStream_t stream);
void launch_max_selected_kernel(const __half* input,
                                const int* segment_offset,
                                __half* output_maxscores,
                                int* output_labels,
                                int num_vectors,
                                int vector_length,
                                int out_vectorlength,
                                cudaStream_t stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer