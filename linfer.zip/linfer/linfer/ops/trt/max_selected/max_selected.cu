#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <chrono>
#include <ctime>
#include <type_traits>

#include "linfer/util/log.h"
#include "max_selected_kernel.h"

#define DEBUG_LOG_MAX_SELECTED_LOCAL 0

namespace linfer {
namespace ops {
namespace trt {

// 列分类小于128
template <typename T>
__global__ void scores_labels_kernel_(const T* input,
                                      const int* segment_offsets,
                                      T* output_maxscores,
                                      int* output_labels,
                                      int num_vectors,
                                      int vector_length,
                                      int out_vectorlength) {
  size_t tid = blockIdx.x * blockDim.x + threadIdx.x;

  if (tid < num_vectors) {
    size_t row_index = tid / out_vectorlength;
    size_t out_row_index = row_index * out_vectorlength;
    size_t out_col_index = tid % out_vectorlength;

    size_t input_row_index = row_index * vector_length;
    __shared__ int segment_offsets_s[16];

    segment_offsets_s[0] = 0;
    for (size_t i = 0; i < out_vectorlength; i++) {
      segment_offsets_s[i + 1] = segment_offsets[i] + segment_offsets_s[i];
    }

    __syncthreads();

    int start_cur = segment_offsets_s[out_col_index];
    int end_cur = segment_offsets_s[out_col_index + 1];

    for (int j = start_cur; j < end_cur; j++) {
      size_t out_index_cur = out_row_index + out_col_index;
      size_t in_index_cur = input_row_index + j;
      if (input[in_index_cur] > output_maxscores[out_index_cur]) {
        output_maxscores[out_index_cur] = input[in_index_cur];
        output_labels[out_index_cur] = j - start_cur;
      }
    }
  }
}

template <typename T>
void launch_max_selected_kernel_(const T* input,
                                 const int* segment_offset,
                                 T* output_maxscores,
                                 int* output_labels,
                                 int num_vectors,
                                 int vector_length,
                                 int out_vectorlength,
                                 cudaStream_t stream) {
  int threadsPerBlock = 256;
  int num_threads = num_vectors * out_vectorlength;
  int blocksPerGrid = (num_threads + threadsPerBlock - 1) / threadsPerBlock;
  scores_labels_kernel_<<<blocksPerGrid, threadsPerBlock, 0, stream>>>(input,
                                                                       segment_offset,
                                                                       output_maxscores,
                                                                       output_labels,
                                                                       num_threads,
                                                                       vector_length,
                                                                       out_vectorlength);
  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    LERROR_FMT("error in launch_max_value_selected_kernel: %s\n", cudaGetErrorString(err));
  }
}

void launch_max_selected_kernel(const float* input,
                                const int* segment_offset,
                                float* output_maxscores,
                                int* output_labels,
                                int num_vectors,
                                int vector_length,
                                int out_vectorlength,
                                cudaStream_t stream) {
#if DEBUG_LOG_MAX_SELECTED_LOCAL
  cudaEvent_t start_event, stop_event;
  cudaEventCreate(&start_event);
  cudaEventCreate(&stop_event);
  cudaEventRecord(start_event);
#endif

  size_t num_out_elements = num_vectors * out_vectorlength * sizeof(float);
  cudaMemsetAsync(output_maxscores, 0, num_out_elements, stream);
  launch_max_selected_kernel_(input,
                              segment_offset,
                              output_maxscores,
                              output_labels,
                              num_vectors,
                              vector_length,
                              out_vectorlength,
                              stream);

#if DEBUG_LOG_MAX_SELECTED_LOCAL
  cudaEventRecord(stop_event);
  cudaEventSynchronize(stop_event);
  float time;
  cudaEventElapsedTime(&time, start_event, stop_event);
  printf("cudaevent 程序运行fp32耗时: %f 毫秒\n", time);  // << " 毫秒" << std::endl;
  cudaEventDestroy(start_event);
  cudaEventDestroy(stop_event);
#endif
}

void launch_max_selected_kernel(const __half* input,
                                const int* segment_offset,
                                __half* output_maxscores,
                                int* output_labels,
                                int num_vectors,
                                int vector_length,
                                int out_vectorlength,
                                cudaStream_t stream) {
#if DEBUG_LOG_MAX_SELECTED_LOCAL
  cudaEvent_t start_event, stop_event;
  cudaEventCreate(&start_event);
  cudaEventCreate(&stop_event);
  cudaEventRecord(start_event);
#endif

  size_t num_out_elements = num_vectors * out_vectorlength * sizeof(__half);
  cudaMemsetAsync(output_maxscores, 0, num_out_elements, stream);
  launch_max_selected_kernel_(input,
                              segment_offset,
                              output_maxscores,
                              output_labels,
                              num_vectors,
                              vector_length,
                              out_vectorlength,
                              stream);

#if DEBUG_LOG_MAX_SELECTED_LOCAL
  cudaEventRecord(stop_event);
  cudaEventSynchronize(stop_event);
  float time;
  cudaEventElapsedTime(&time, start_event, stop_event);
  printf("cudaevent 程序运行fp16耗时: %f 毫秒\n", time);  // << " 毫秒" << std::endl;
  cudaEventDestroy(start_event);
  cudaEventDestroy(stop_event);
#endif
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer