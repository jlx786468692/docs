#include <NvInfer.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

#ifndef TRT_PLUGIN_COMMON_TEMPLATES_H_
#define TRT_PLUGIN_COMMON_TEMPLATES_H_
namespace nvinfer1 {
namespace plugin {

template <typename ToType, typename FromType>
ToType* toPointer(FromType* ptr) {
  return static_cast<ToType*>(static_cast<void*>(ptr));
}
template <typename ToType, typename FromType>
ToType const* toPointer(FromType const* ptr) {
  return static_cast<ToType const*>(static_cast<void const*>(ptr));
}
// Helper function for serializing plugin
template <typename ValType, typename BufferType>
void writeToBuffer(BufferType*& buffer, ValType const& val) {
  *toPointer<ValType>(buffer) = val;
  buffer += sizeof(ValType);
}

// Helper function for deserializing plugin
template <typename ValType, typename BufferType>
ValType readFromBuffer(BufferType const*& buffer) {
  auto val = *toPointer<ValType const>(buffer);
  buffer += sizeof(ValType);
  return val;
}

// Assuming outputs[0] is a pointer to the data and dataSize is the size of the data in
// bytes
inline void saveAsBinaryFile(const void* data, size_t dataSize, const std::string& fileName) {
  std::ofstream outFile(fileName, std::ios::out | std::ios::binary);
  if (outFile) {
    outFile.write(reinterpret_cast<const char*>(data), dataSize);
    outFile.close();
  } else {
    // Handle error
    std::cerr << "Failed to open file for writing: " << fileName << std::endl;
  }
}

// Function to copy data from device to host and save it
inline void saveDeviceDataAsBinaryFile(const void* deviceData,
                                       size_t dataSize,
                                       const std::string& fileName) {
  // Allocate host memory
  void* hostData = malloc(dataSize);
  if (!hostData) {
    std::cerr << "Failed to allocate host memory" << std::endl;
    return;
  }

  // Copy data from device to host
  cudaError_t err = cudaMemcpy(hostData, deviceData, dataSize, cudaMemcpyDeviceToHost);
  if (err != cudaSuccess) {
    std::cerr << "Failed to copy data from device to host: " << cudaGetErrorString(err)
              << std::endl;
    free(hostData);
    return;
  }

  // Save data as binary file
  saveAsBinaryFile(hostData, dataSize, fileName);

  // Free host memory
  free(hostData);
}

inline void caughtError(const std::exception& e) {
#ifdef ENABLE_TENSORRT_LOGGING
  glogError << e.what() << std::endl;
#endif
}

#define DEBUG_TENSORRT_PLUGIN 0

}  // namespace plugin
}  // namespace nvinfer1
#endif  // TRT_PLUGIN_COMMON_TEMPLATES_H_
