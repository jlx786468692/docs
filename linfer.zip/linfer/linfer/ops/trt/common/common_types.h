#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

#include <cuda_fp16.h>  // for __half2
#include <stdint.h>

// 8-byte aligned 2x int32 struct
struct __align__(8) int32_t2 {
  int32_t x, y;
};

// 8-byte aligned 2x __half2 struct
struct __align__(8) half4 {
  __half2 left, right;
};

#endif  // COMMON_TYPES_H
