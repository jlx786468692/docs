// Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
// modify from
// https://github.com/NVIDIA/TensorRT/tree/master/plugin/batchedNMSPlugin
#ifndef TRT_KERNEL_H
#define TRT_KERNEL_H

#include <cuda_runtime.h>

#include <cassert>
#include <cstdio>

#include "cublas_v2.h"
#include "linfer/util/internal/trt/plugin.h"
#include "trt_plugin_helper.hpp"

using namespace nvinfer1;
#define DEBUG_ENABLE 0

template <typename T>
struct Bbox {
  T xmin, ymin, xmax, ymax;
  Bbox(T xmin, T ymin, T xmax, T ymax) : xmin(xmin), ymin(ymin), xmax(xmax), ymax(ymax) {}
  Bbox() = default;
};

size_t get_cuda_arch(int devID);

int8_t* alignPtr(int8_t* ptr, uintptr_t to);

int8_t* nextWorkspacePtr(int8_t* ptr, uintptr_t previousWorkspaceSize);

void setUniformOffsets(cudaStream_t stream, int num_segments, int offset, int* d_offsets);

/*********************Adapt TRT plugin ***********************/
pluginStatus_t allClassNMS(cudaStream_t stream,
                           int num,
                           int num_classes,
                           int num_preds_per_class,
                           int top_k,
                           const float* nms_thr_array,
                           int nms_thr_array_len,
                           float nms_thr,
                           bool share_location,
                           bool isNormalized,
                           DataType DT_SCORE,
                           DataType DT_BBOX,
                           void* bbox_data,
                           void* beforeNMS_scores,
                           void* beforeNMS_index_array,
                           void* afterNMS_scores,
                           void* afterNMS_index_array,
                           bool flipXY,
                           const float score_shift,
                           bool caffeSemantics);

pluginStatus_t allClassNMS(cudaStream_t stream,
                           int num,
                           int num_classes,
                           int num_preds_per_class,
                           int top_k,
                           const float* nms_thr_array,
                           int nms_thr_array_len,
                           float nms_thr,
                           bool share_location,
                           bool isNormalized,
                           DataType DT_SCORE,
                           DataType DT_BBOX,
                           void* bbox_data,
                           void* beforeNMS_scores,
                           void* beforeNMS_index_array,
                           void* afterNMS_scores,
                           void* afterNMS_index_array,
                           bool flipXY = false);

pluginStatus_t allClassRotatedNMS(cudaStream_t stream,
                                  int num,
                                  int num_classes,
                                  int num_preds_per_class,
                                  int top_k,
                                  const float* nms_thr_array,
                                  int nms_thr_array_len,
                                  float nms_thr,
                                  bool share_location,
                                  bool isNormalized,
                                  DataType DT_SCORE,
                                  DataType DT_BBOX,
                                  void* bbox_data,
                                  void* beforeNMS_scores,
                                  void* beforeNMS_index_array,
                                  void* afterNMS_scores,
                                  void* afterNMS_index_array,
                                  bool flipXY = false,
                                  bool anchor_free = false);

size_t detectionForwardBBoxDataSize(int N, int C1, DataType DT_BBOX);

size_t detectionForwardBBoxPermuteSize(bool shareLocation, int N, int C1, DataType DT_BBOX);

size_t sortScoresPerClassWorkspaceSize(int num,
                                       int num_classes,
                                       int num_preds_per_class,
                                       DataType DT_CONF);

size_t sortScoresPerImageWorkspaceSize(int num_images, int num_items_per_image, DataType DT_SCORE);

/*********************Adapt TRT plugin***********************/
pluginStatus_t sortScoresPerImage(cudaStream_t stream,
                                  int num_images,
                                  int num_items_per_image,
                                  DataType DT_SCORE,
                                  void* unsorted_scores,
                                  void* unsorted_bbox_indices,
                                  void* sorted_scores,
                                  void* sorted_bbox_indices,
                                  void* workspace,
                                  int score_bits);

pluginStatus_t sortScoresPerImage(cudaStream_t stream,
                                  int num_images,
                                  int num_items_per_image,
                                  DataType DT_SCORE,
                                  void* unsorted_scores,
                                  void* unsorted_bbox_indices,
                                  void* sorted_scores,
                                  void* sorted_bbox_indices,
                                  void* workspace);

/*********************Adapt TRT plugin***********************/
pluginStatus_t sortScoresPerClass(cudaStream_t stream,
                                  int num,
                                  int num_classes,
                                  int num_preds_per_class,
                                  int background_label_id,
                                  float confidence_threshold,
                                  DataType DT_SCORE,
                                  void* conf_scores_gpu,
                                  void* index_array_gpu,
                                  void* workspace,
                                  const int score_bits,
                                  const float score_shift);

pluginStatus_t sortScoresPerClass(cudaStream_t stream,
                                  int num,
                                  int num_classes,
                                  int num_preds_per_class,
                                  int background_label_id,
                                  float confidence_threshold,
                                  DataType DT_SCORE,
                                  void* conf_scores_gpu,
                                  void* index_array_gpu,
                                  void* workspace);

size_t calculateTotalWorkspaceSize(size_t* workspaces, int count);

pluginStatus_t permuteData(cudaStream_t stream,
                           int nthreads,
                           int num_classes,
                           int num_data,
                           int num_dim,
                           DataType DT_DATA,
                           bool confSigmoid,
                           const void* data,
                           void* new_data);

size_t detectionForwardPreNMSSize(int N, int C2);

size_t detectionForwardPostNMSSize(int N, int numClasses, int topK);

pluginStatus_t gatherNMSOutputs(cudaStream_t stream,
                                bool shareLocation,
                                int numImages,
                                int numPredsPerClass,
                                int numClasses,
                                int topK,
                                int keepTopK,
                                DataType DT_BBOX,
                                DataType DT_SCORE,
                                const void* indices,
                                const void* scores,
                                const void* bboxData,
                                void* nmsedDets,
                                void* nmsedLabels,
                                void* nmsedIndex = nullptr,
                                bool clipBoxes = true,
                                bool rotated = false,
                                bool multiclass_output_flag = false);

size_t detectionInferenceWorkspaceSize(bool shareLocation,
                                       int N,
                                       int C1,
                                       int C2,
                                       int numClasses,
                                       int numPredsPerClass,
                                       int topK,
                                       DataType DT_BBOX,
                                       DataType DT_SCORE);

void makeNmsInput(const float* heatmap_preds,
                  const float* reg_preds,
                  const float* height_preds,
                  const float* dim_preds,
                  const float* rotc_preds,
                  const float* rots_preds,
                  float* filtered_score,
                  int* filtered_index,
                  float* box_for_nms,
                  int* filter_count,
                  const float score_threshold,
                  const int num_class,
                  const int feat_x_size,
                  const int feat_y_size,
                  const float pillar_x_size,
                  const float pillar_y_size,
                  const float min_x_range,
                  const float min_y_range,
                  const int stride,
                  const int topK,
                  const bool shareLocation,
                  cudaStream_t stream);
void makeBevNmsInput(const float* heatmap_preds,
                     const float* reg_preds,
                     const float* height_preds,
                     const float* dim_preds,
                     const float* rot_preds,
                     float* filtered_score,
                     int* filtered_index,
                     float* box_for_nms,
                     int* filter_count,
                     const float score_threshold,
                     const int num_class,
                     const int feat_x_size,
                     const int feat_y_size,
                     const float pillar_x_size,
                     const float pillar_y_size,
                     const float min_x_range,
                     const float min_y_range,
                     const int stride,
                     const int topK,
                     const bool shareLocation,
                     const float* rescale_factor,
                     int rescale_factor_len,
                     cudaStream_t stream);

void makeFinalNmsOutput(const float* height_preds,
                        const float* dim_preds,
                        float* nmsedDets,
                        const int* featMapIndex,
                        const int* nmsedIndex,
                        float* nmsedFinalDetsOutput,
                        int* nmsedLabels,
                        const int keep_topK,
                        const int topK,
                        const int num_class,
                        const bool shareLocation,
                        cudaStream_t stream);
void makeFinalBevNmsOutput(const float* height_preds,
                           const float* dim_preds,
                           float* nmsedDets,
                           const int* featMapIndex,
                           const int* nmsedIndex,
                           float* nmsedFinalDetsOutput,
                           int* nmsedLabels,
                           const int keep_topK,
                           const int topK,
                           const int num_class,
                           const bool shareLocation,
                           const float* rescale_factor,
                           int rescale_factor_len,
                           cudaStream_t stream);

__device__ inline float get_nms_iou_threshold(int cls_idx,
                                              const float* iou_thr_array,
                                              int iou_thr_array_len,
                                              float iou_thr) {
  if (iou_thr_array != nullptr) {
    if (iou_thr_array_len > 1) {
      return iou_thr_array[cls_idx];
    } else {
      return iou_thr_array[0];
    }
  } else {
    return iou_thr;
  }
}

#endif
