// Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
// modify from
// https://github.com/NVIDIA/TensorRT/tree/master/plugin/batchedNMSPlugin
#include <array>  // Add this include for std::array
#include <vector>

#include "cuda_fp16.h"
#include "nms/kernel.h"

template <typename T_BBOX>
__device__ T_BBOX bboxSize(const Bbox<T_BBOX>& bbox, const bool normalized, T_BBOX offset) {
  if (bbox.xmax < bbox.xmin || bbox.ymax < bbox.ymin) {
    // If bbox is invalid (e.g. xmax < xmin or ymax < ymin), return 0.
    return 0;
  } else {
    T_BBOX width = bbox.xmax - bbox.xmin;
    T_BBOX height = bbox.ymax - bbox.ymin;
    if (normalized) {
      return width * height;
    } else {
      // If bbox is not within range [0, 1].
      return (width + offset) * (height + offset);
    }
  }
}

template <typename T_BBOX>
__device__ void intersectBbox(const Bbox<T_BBOX>& bbox1,
                              const Bbox<T_BBOX>& bbox2,
                              Bbox<T_BBOX>* intersect_bbox) {
  if (bbox2.xmin > bbox1.xmax || bbox2.xmax < bbox1.xmin || bbox2.ymin > bbox1.ymax ||
      bbox2.ymax < bbox1.ymin) {
    // Return [0, 0, 0, 0] if there is no intersection.
    intersect_bbox->xmin = T_BBOX(0);
    intersect_bbox->ymin = T_BBOX(0);
    intersect_bbox->xmax = T_BBOX(0);
    intersect_bbox->ymax = T_BBOX(0);
  } else {
    intersect_bbox->xmin = max(bbox1.xmin, bbox2.xmin);
    intersect_bbox->ymin = max(bbox1.ymin, bbox2.ymin);
    intersect_bbox->xmax = min(bbox1.xmax, bbox2.xmax);
    intersect_bbox->ymax = min(bbox1.ymax, bbox2.ymax);
  }
}

template <typename T_BBOX>
__device__ float jaccardOverlap(const Bbox<T_BBOX>& bbox1,
                                const Bbox<T_BBOX>& bbox2,
                                const bool normalized,
                                T_BBOX offset) {
  Bbox<T_BBOX> intersect_bbox;
  intersectBbox(bbox1, bbox2, &intersect_bbox);
  float intersect_width, intersect_height;
  if (normalized) {
    intersect_width = intersect_bbox.xmax - intersect_bbox.xmin;
    intersect_height = intersect_bbox.ymax - intersect_bbox.ymin;
  } else {
    intersect_width = intersect_bbox.xmax - intersect_bbox.xmin + offset;
    intersect_height = intersect_bbox.ymax - intersect_bbox.ymin + offset;
  }
  if (intersect_width > 0 && intersect_height > 0) {
    float intersect_size = intersect_width * intersect_height;
    float bbox1_size = bboxSize(bbox1, normalized, offset);
    float bbox2_size = bboxSize(bbox2, normalized, offset);
    return intersect_size / (bbox1_size + bbox2_size - intersect_size);
  } else {
    return 0.;
  }
}

/********** new NMS for only score and index array **********/

template <typename T_SCORE, typename T_BBOX, int TSIZE>
__global__ void allClassNMS_kernel(const int num,
                                   const int num_classes,
                                   const int num_preds_per_class,
                                   const int top_k,
                                   const float* nms_iou_thr_array,
                                   int nms_iou_thr_array_len,
                                   float nms_iou_thr,
                                   const bool share_location,
                                   const bool isNormalized,
                                   T_BBOX* bbox_data,  // bbox_data should be float to preserve
                                                       // location information
                                   T_SCORE* beforeNMS_scores,
                                   int* beforeNMS_index_array,
                                   T_SCORE* afterNMS_scores,
                                   int* afterNMS_index_array,
                                   bool flipXY = false) {
  //__shared__ bool kept_bboxinfo_flag[CAFFE_CUDA_NUM_THREADS * TSIZE];
  extern __shared__ bool kept_bboxinfo_flag[];

  float nms_threshold =
      get_nms_iou_threshold(blockIdx.x, nms_iou_thr_array, nms_iou_thr_array_len, nms_iou_thr);

  for (int i = 0; i < num; i++) {
    const int offset = i * num_classes * num_preds_per_class + blockIdx.x * num_preds_per_class;
    const int max_idx = offset + top_k;  // put top_k bboxes into NMS calculation
    const int bbox_idx_offset =
        share_location ? (i * num_preds_per_class) : (i * num_classes * num_preds_per_class);

    // local thread data
    int loc_bboxIndex[TSIZE];
    Bbox<T_BBOX> loc_bbox[TSIZE];

    // initialize Bbox, Bboxinfo, kept_bboxinfo_flag
    // Eliminate shared memory RAW hazard
    __syncthreads();
#pragma unroll
    for (int t = 0; t < TSIZE; t++) {
      const int cur_idx = threadIdx.x + blockDim.x * t;
      const int item_idx = offset + cur_idx;

      if (item_idx < max_idx) {
        loc_bboxIndex[t] = beforeNMS_index_array[item_idx];

        if (loc_bboxIndex[t] >= 0)
        // if (loc_bboxIndex[t] != -1)
        {
          const int bbox_data_idx = share_location
                                        ? (loc_bboxIndex[t] % num_preds_per_class + bbox_idx_offset)
                                        : loc_bboxIndex[t];

          loc_bbox[t].xmin =
              flipXY ? bbox_data[bbox_data_idx * 4 + 1] : bbox_data[bbox_data_idx * 4 + 0];
          loc_bbox[t].ymin =
              flipXY ? bbox_data[bbox_data_idx * 4 + 0] : bbox_data[bbox_data_idx * 4 + 1];
          loc_bbox[t].xmax =
              flipXY ? bbox_data[bbox_data_idx * 4 + 3] : bbox_data[bbox_data_idx * 4 + 2];
          loc_bbox[t].ymax =
              flipXY ? bbox_data[bbox_data_idx * 4 + 2] : bbox_data[bbox_data_idx * 4 + 3];
          kept_bboxinfo_flag[cur_idx] = true;
        } else {
          kept_bboxinfo_flag[cur_idx] = false;
        }
      } else {
        kept_bboxinfo_flag[cur_idx] = false;
      }
    }

    // filter out overlapped boxes with lower scores
    int ref_item_idx = offset;
    int ref_bbox_idx =
        share_location
            ? (beforeNMS_index_array[ref_item_idx] % num_preds_per_class + bbox_idx_offset)
            : beforeNMS_index_array[ref_item_idx];

    while ((ref_bbox_idx != -1) && ref_item_idx < max_idx) {
      Bbox<T_BBOX> ref_bbox;
      ref_bbox.xmin = flipXY ? bbox_data[ref_bbox_idx * 4 + 1] : bbox_data[ref_bbox_idx * 4 + 0];
      ref_bbox.ymin = flipXY ? bbox_data[ref_bbox_idx * 4 + 0] : bbox_data[ref_bbox_idx * 4 + 1];
      ref_bbox.xmax = flipXY ? bbox_data[ref_bbox_idx * 4 + 3] : bbox_data[ref_bbox_idx * 4 + 2];
      ref_bbox.ymax = flipXY ? bbox_data[ref_bbox_idx * 4 + 2] : bbox_data[ref_bbox_idx * 4 + 3];

      // Eliminate shared memory RAW hazard
      __syncthreads();

      for (int t = 0; t < TSIZE; t++) {
        const int cur_idx = threadIdx.x + blockDim.x * t;
        const int item_idx = offset + cur_idx;

        if ((kept_bboxinfo_flag[cur_idx]) && (item_idx > ref_item_idx)) {
          // TODO: may need to add bool normalized as argument, HERE true means
          // normalized
          if (jaccardOverlap(ref_bbox, loc_bbox[t], isNormalized, T_BBOX(0)) > nms_threshold) {
            kept_bboxinfo_flag[cur_idx] = false;
          }
        }
      }
      __syncthreads();

      do {
        ref_item_idx++;
      } while (ref_item_idx < max_idx && !kept_bboxinfo_flag[ref_item_idx - offset]);

      ref_bbox_idx =
          share_location
              ? (beforeNMS_index_array[ref_item_idx] % num_preds_per_class + bbox_idx_offset)
              : beforeNMS_index_array[ref_item_idx];
    }

    // store data
    for (int t = 0; t < TSIZE; t++) {
      const int cur_idx = threadIdx.x + blockDim.x * t;
      const int read_item_idx = offset + cur_idx;
      const int write_item_idx = (i * num_classes * top_k + blockIdx.x * top_k) + cur_idx;
      /*
       * If not not keeping the bbox
       * Set the score to 0
       * Set the bounding box index to -1
       */
      if (read_item_idx < max_idx) {
        afterNMS_scores[write_item_idx] =
            kept_bboxinfo_flag[cur_idx] ? beforeNMS_scores[read_item_idx] : 0.0f;
        afterNMS_index_array[write_item_idx] = kept_bboxinfo_flag[cur_idx] ? loc_bboxIndex[t] : -1;
      }
    }
  }
}

template <typename T_SCORE, typename T_BBOX>
pluginStatus_t allClassNMS_gpu(cudaStream_t stream,
                               const int num,
                               const int num_classes,
                               const int num_preds_per_class,
                               const int top_k,
                               const float* nms_thr_array,
                               int nms_thr_array_len,
                               float nms_thr,
                               const bool share_location,
                               const bool isNormalized,
                               void* bbox_data,
                               void* beforeNMS_scores,
                               void* beforeNMS_index_array,
                               void* afterNMS_scores,
                               void* afterNMS_index_array,
                               bool flipXY = false) {
#define P(tsize) allClassNMS_kernel<T_SCORE, T_BBOX, (tsize)>

  void (*kernel[10])(const int,
                     const int,
                     const int,
                     const int,
                     const float*,
                     int,
                     const float,
                     const bool,
                     const bool,
                     float*,
                     T_SCORE*,
                     int*,
                     T_SCORE*,
                     int*,
                     bool) = {
      P(1),
      P(2),
      P(3),
      P(4),
      P(5),
      P(6),
      P(7),
      P(8),
      P(9),
      P(10),
  };

  const int BS = 512;
  const int GS = num_classes;
  const int t_size = (top_k + BS - 1) / BS;

  ASSERT(t_size <= 10);
  kernel[t_size - 1]<<<GS, BS, BS * t_size * sizeof(bool), stream>>>(num,
                                                                     num_classes,
                                                                     num_preds_per_class,
                                                                     top_k,
                                                                     nms_thr_array,
                                                                     nms_thr_array_len,
                                                                     nms_thr,
                                                                     share_location,
                                                                     isNormalized,
                                                                     (T_BBOX*)bbox_data,
                                                                     (T_SCORE*)beforeNMS_scores,
                                                                     (int*)beforeNMS_index_array,
                                                                     (T_SCORE*)afterNMS_scores,
                                                                     (int*)afterNMS_index_array,
                                                                     flipXY);

  cudaError_t code = cudaGetLastError();
  if (code != cudaSuccess) {
    // Verify if cuda dev0 requires top_k to be reduced;
    // sm_53 (Jetson Nano) and sm_62 (Jetson TX2) requires reduced top_k < 1000
    auto __cuda_arch__ = get_cuda_arch(0);
    if ((__cuda_arch__ == 530 || __cuda_arch__ == 620) && top_k >= 1000) {
      printf(
          "Warning: pre_top_k need to be reduced for devices with arch 5.3, 6.2, got "
          "pre_top_k=%d\n",
          top_k);
    }
  }
  CSC(cudaGetLastError(), STATUS_FAILURE);
  return STATUS_SUCCESS;
}

// allClassNMS LAUNCH CONFIG
typedef pluginStatus_t (*nmsFunc)(cudaStream_t,
                                  const int,
                                  const int,
                                  const int,
                                  const int,
                                  const float*,
                                  int,
                                  float,
                                  const bool,
                                  const bool,
                                  void*,
                                  void*,
                                  void*,
                                  void*,
                                  void*,
                                  bool);

struct nmsLaunchConfigSSD {
  DataType t_score;
  DataType t_bbox;
  nmsFunc function;

  nmsLaunchConfigSSD(DataType t_score, DataType t_bbox) : t_score(t_score), t_bbox(t_bbox) {}
  nmsLaunchConfigSSD(DataType t_score, DataType t_bbox, nmsFunc function)
      : t_score(t_score), t_bbox(t_bbox), function(function) {}
  bool operator==(const nmsLaunchConfigSSD& other) {
    return t_score == other.t_score && t_bbox == other.t_bbox;
  }
};

static std::vector<nmsLaunchConfigSSD> nmsFuncVec;

bool nmsInit() {
  nmsFuncVec.push_back(
      nmsLaunchConfigSSD(DataType::kFLOAT, DataType::kFLOAT, allClassNMS_gpu<float, float>));
  return true;
}

static bool initialized = nmsInit();

/*********************Adapt TRT plugin***********************/

template <typename T_BBOX>
__device__ Bbox<T_BBOX> getDiagonalMinMaxSortedBox(const Bbox<T_BBOX>& bbox1) {
  Bbox<T_BBOX> result;
  result.xmin = min(bbox1.xmin, bbox1.xmax);
  result.xmax = max(bbox1.xmin, bbox1.xmax);

  result.ymin = min(bbox1.ymin, bbox1.ymax);
  result.ymax = max(bbox1.ymin, bbox1.ymax);
  return result;
}

template <>
__device__ Bbox<__half> getDiagonalMinMaxSortedBox(const Bbox<__half>& bbox1) {
  Bbox<__half> result;
  result.xmin = min(float(bbox1.xmin), float(bbox1.xmax));
  result.xmax = max(float(bbox1.xmin), float(bbox1.xmax));

  result.ymin = min(float(bbox1.ymin), float(bbox1.ymax));
  result.ymax = max(float(bbox1.ymin), float(bbox1.ymax));
  return result;
}

template <typename T_BBOX>
__device__ float bboxSize(const Bbox<T_BBOX>& bbox, const bool normalized) {
  if (float(bbox.xmax) < float(bbox.xmin) || float(bbox.ymax) < float(bbox.ymin)) {
    // If bbox is invalid (e.g. xmax < xmin or ymax < ymin), return 0.
    return 0;
  } else {
    float width = float(bbox.xmax) - float(bbox.xmin);
    float height = float(bbox.ymax) - float(bbox.ymin);
    if (normalized) {
      return width * height;
    } else {
      // If bbox is not within range [0, 1].
      return (width + 1.f) * (height + 1.f);
    }
  }
}

template <>
__device__ void intersectBbox<__half>(const Bbox<__half>& bbox1,
                                      const Bbox<__half>& bbox2,
                                      Bbox<__half>* intersect_bbox) {
  if (float(bbox2.xmin) > float(bbox1.xmax) || float(bbox2.xmax) < float(bbox1.xmin) ||
      float(bbox2.ymin) > float(bbox1.ymax) || float(bbox2.ymax) < float(bbox1.ymin)) {
    // Return [0, 0, 0, 0] if there is no intersection.
    intersect_bbox->xmin = __half(0);
    intersect_bbox->ymin = __half(0);
    intersect_bbox->xmax = __half(0);
    intersect_bbox->ymax = __half(0);
  } else {
    intersect_bbox->xmin = max(float(bbox1.xmin), float(bbox2.xmin));
    intersect_bbox->ymin = max(float(bbox1.ymin), float(bbox2.ymin));
    intersect_bbox->xmax = min(float(bbox1.xmax), float(bbox2.xmax));
    intersect_bbox->ymax = min(float(bbox1.ymax), float(bbox2.ymax));
  }
}

template <typename T_BBOX>
__device__ float jaccardOverlap(const Bbox<T_BBOX>& bbox1,
                                const Bbox<T_BBOX>& bbox2,
                                const bool normalized,
                                const bool caffeSemantics) {
  Bbox<T_BBOX> intersect_bbox;

  Bbox<T_BBOX> localbbox1 = getDiagonalMinMaxSortedBox(bbox1);
  Bbox<T_BBOX> localbbox2 = getDiagonalMinMaxSortedBox(bbox2);

  intersectBbox(localbbox1, localbbox2, &intersect_bbox);

  float intersect_width, intersect_height;
  // Only when using Caffe semantics, IOU calculation adds "1" to width and height if bbox is not
  // normalized. https://github.com/weiliu89/caffe/blob/ssd/src/caffe/util/bbox_util.cpp#L92-L97
  if (normalized || !caffeSemantics) {
    intersect_width = float(intersect_bbox.xmax) - float(intersect_bbox.xmin);
    intersect_height = float(intersect_bbox.ymax) - float(intersect_bbox.ymin);
  } else {
    intersect_width = float(intersect_bbox.xmax) - float(intersect_bbox.xmin) + float(T_BBOX(1));
    intersect_height = float(intersect_bbox.ymax) - float(intersect_bbox.ymin) + float(T_BBOX(1));
  }
  if (intersect_width > 0 && intersect_height > 0) {
    float intersect_size = intersect_width * intersect_height;
    float bbox1_size = bboxSize(localbbox1, normalized);
    float bbox2_size = bboxSize(localbbox2, normalized);
    return intersect_size / (bbox1_size + bbox2_size - intersect_size);
  } else {
    return 0.;
  }
}

template <typename T_SCORE, typename T_BBOX, int TSIZE>
__global__ void allClassNMS_kernel(
    const int num,
    const int num_classes,
    const int num_preds_per_class,
    const int top_k,
    const float* nms_iou_thr_array,
    int nms_iou_thr_array_len,
    float nms_iou_thr,
    const bool share_location,
    const bool isNormalized,
    T_BBOX* bbox_data,  // bbox_data should be float to preserve location information
    T_SCORE* beforeNMS_scores,
    int* beforeNMS_index_array,
    T_SCORE* afterNMS_scores,
    int* afterNMS_index_array,
    bool flipXY,
    const float score_shift,
    bool caffeSemantics) {
  //__shared__ bool kept_bboxinfo_flag[CAFFE_CUDA_NUM_THREADS * TSIZE];
  extern __shared__ bool kept_bboxinfo_flag[];

  float nms_threshold =
      get_nms_iou_threshold(blockIdx.x, nms_iou_thr_array, nms_iou_thr_array_len, nms_iou_thr);

  for (int i = 0; i < num; i++) {
    int32_t const offset = i * num_classes * num_preds_per_class + blockIdx.x * num_preds_per_class;
    // Should not write data beyond [offset, top_k).
    int32_t const max_idx = offset + top_k;
    // Should not read beyond [offset, num_preds_per_class).
    int32_t const max_read_idx = offset + min(top_k, num_preds_per_class);
    int32_t const bbox_idx_offset = i * num_preds_per_class * (share_location ? 1 : num_classes);

    // local thread data
    int loc_bboxIndex[TSIZE];
    Bbox<T_BBOX> loc_bbox[TSIZE];

    // initialize Bbox, Bboxinfo, kept_bboxinfo_flag
    // Eliminate shared memory RAW hazard
    __syncthreads();
#pragma unroll
    for (int t = 0; t < TSIZE; t++) {
      const int cur_idx = threadIdx.x + blockDim.x * t;
      const int item_idx = offset + cur_idx;
      // Init all output data
      if (item_idx < max_idx) {
        // Do not access data if it exceeds read boundary
        if (item_idx < max_read_idx) {
          loc_bboxIndex[t] = beforeNMS_index_array[item_idx];
        } else {
          loc_bboxIndex[t] = -1;
        }

        if (loc_bboxIndex[t] != -1) {
          const int bbox_data_idx = share_location
                                        ? (loc_bboxIndex[t] % num_preds_per_class + bbox_idx_offset)
                                        : loc_bboxIndex[t];

          loc_bbox[t].xmin =
              flipXY ? bbox_data[bbox_data_idx * 4 + 1] : bbox_data[bbox_data_idx * 4 + 0];
          loc_bbox[t].ymin =
              flipXY ? bbox_data[bbox_data_idx * 4 + 0] : bbox_data[bbox_data_idx * 4 + 1];
          loc_bbox[t].xmax =
              flipXY ? bbox_data[bbox_data_idx * 4 + 3] : bbox_data[bbox_data_idx * 4 + 2];
          loc_bbox[t].ymax =
              flipXY ? bbox_data[bbox_data_idx * 4 + 2] : bbox_data[bbox_data_idx * 4 + 3];
          kept_bboxinfo_flag[cur_idx] = true;
        } else {
          kept_bboxinfo_flag[cur_idx] = false;
        }
      } else {
        kept_bboxinfo_flag[cur_idx] = false;
      }
    }

    // filter out overlapped boxes with lower scores
    int ref_item_idx = offset;

    int32_t ref_bbox_idx = -1;
    if (ref_item_idx < max_read_idx) {
      ref_bbox_idx =
          share_location
              ? (beforeNMS_index_array[ref_item_idx] % num_preds_per_class + bbox_idx_offset)
              : beforeNMS_index_array[ref_item_idx];
    }
    while ((ref_bbox_idx != -1) && ref_item_idx < max_read_idx) {
      Bbox<T_BBOX> ref_bbox;
      ref_bbox.xmin = flipXY ? bbox_data[ref_bbox_idx * 4 + 1] : bbox_data[ref_bbox_idx * 4 + 0];
      ref_bbox.ymin = flipXY ? bbox_data[ref_bbox_idx * 4 + 0] : bbox_data[ref_bbox_idx * 4 + 1];
      ref_bbox.xmax = flipXY ? bbox_data[ref_bbox_idx * 4 + 3] : bbox_data[ref_bbox_idx * 4 + 2];
      ref_bbox.ymax = flipXY ? bbox_data[ref_bbox_idx * 4 + 2] : bbox_data[ref_bbox_idx * 4 + 3];

      // Eliminate shared memory RAW hazard
      __syncthreads();

      for (int t = 0; t < TSIZE; t++) {
        const int cur_idx = threadIdx.x + blockDim.x * t;
        const int item_idx = offset + cur_idx;

        if ((kept_bboxinfo_flag[cur_idx]) && (item_idx > ref_item_idx)) {
          if (jaccardOverlap(ref_bbox, loc_bbox[t], isNormalized, caffeSemantics) > nms_threshold) {
            kept_bboxinfo_flag[cur_idx] = false;
          }
        }
      }
      __syncthreads();

      do {
        ref_item_idx++;
      } while (ref_item_idx < max_read_idx && !kept_bboxinfo_flag[ref_item_idx - offset]);

      // Move to next valid point
      if (ref_item_idx < max_read_idx) {
        ref_bbox_idx =
            share_location
                ? (beforeNMS_index_array[ref_item_idx] % num_preds_per_class + bbox_idx_offset)
                : beforeNMS_index_array[ref_item_idx];
      }
    }

    // store data
    for (int t = 0; t < TSIZE; t++) {
      const int cur_idx = threadIdx.x + blockDim.x * t;
      const int read_item_idx = offset + cur_idx;
      const int write_item_idx = (i * num_classes * top_k + blockIdx.x * top_k) + cur_idx;
      /*
       * If not not keeping the bbox
       * Set the score to 0
       * Set the bounding box index to -1
       */
      if (read_item_idx < max_idx) {
        afterNMS_scores[write_item_idx] = kept_bboxinfo_flag[cur_idx]
                                              ? T_SCORE(beforeNMS_scores[read_item_idx])
                                              : T_SCORE(score_shift);
        afterNMS_index_array[write_item_idx] = kept_bboxinfo_flag[cur_idx] ? loc_bboxIndex[t] : -1;
      }
    }
  }
}

template <typename T_SCORE, typename T_BBOX>
pluginStatus_t allClassNMS_gpu(cudaStream_t stream,
                               const int num,
                               const int num_classes,
                               const int num_preds_per_class,
                               const int top_k,
                               const float* nms_thr_array,
                               int nms_thr_array_len,
                               float nms_thr,
                               const bool share_location,
                               const bool isNormalized,
                               void* bbox_data,
                               void* beforeNMS_scores,
                               void* beforeNMS_index_array,
                               void* afterNMS_scores,
                               void* afterNMS_index_array,
                               bool flipXY,
                               const float score_shift,
                               bool caffeSemantics) {
#define P(tsize) allClassNMS_kernel<T_SCORE, T_BBOX, (tsize)>

  void (*kernel[8])(const int,
                    const int,
                    const int,
                    const int,
                    const float*,
                    int,
                    const float,
                    const bool,
                    const bool,
                    T_BBOX*,
                    T_SCORE*,
                    int*,
                    T_SCORE*,
                    int*,
                    bool,
                    const float,
                    bool) = {
      P(1),
      P(2),
      P(3),
      P(4),
      P(5),
      P(6),
      P(7),
      P(8),
  };

  const int BS = 512;
  const int GS = num_classes;
  const int t_size = (top_k + BS - 1) / BS;

  kernel[t_size - 1]<<<GS, BS, BS * t_size * sizeof(bool), stream>>>(num,
                                                                     num_classes,
                                                                     num_preds_per_class,
                                                                     top_k,
                                                                     nms_thr_array,
                                                                     nms_thr_array_len,
                                                                     nms_thr,
                                                                     share_location,
                                                                     isNormalized,
                                                                     (T_BBOX*)bbox_data,
                                                                     (T_SCORE*)beforeNMS_scores,
                                                                     (int*)beforeNMS_index_array,
                                                                     (T_SCORE*)afterNMS_scores,
                                                                     (int*)afterNMS_index_array,
                                                                     flipXY,
                                                                     score_shift,
                                                                     caffeSemantics);

  CSC(cudaGetLastError(), STATUS_FAILURE);
  return STATUS_SUCCESS;
}

// allClassNMS LAUNCH CONFIG
typedef pluginStatus_t (*nmsFunc_TRT)(cudaStream_t,
                                      const int,
                                      const int,
                                      const int,
                                      const int,
                                      const float*,
                                      int,
                                      float,
                                      const bool,
                                      const bool,
                                      void*,
                                      void*,
                                      void*,
                                      void*,
                                      void*,
                                      bool,
                                      const float,
                                      bool);

struct nmsLaunchConfigSSD_TRT {
  DataType t_score;
  DataType t_bbox;
  nmsFunc_TRT function;

  nmsLaunchConfigSSD_TRT(DataType t_score, DataType t_bbox) : t_score(t_score), t_bbox(t_bbox) {}
  nmsLaunchConfigSSD_TRT(DataType t_score, DataType t_bbox, nmsFunc_TRT function)
      : t_score(t_score), t_bbox(t_bbox), function(function) {}
  bool operator==(const nmsLaunchConfigSSD_TRT& other) {
    return t_score == other.t_score && t_bbox == other.t_bbox;
  }
};

static std::array<nmsLaunchConfigSSD_TRT, 2> nmsSsdLCOptions = {
    nmsLaunchConfigSSD_TRT(DataType::kFLOAT, DataType::kFLOAT, allClassNMS_gpu<float, float>),
    nmsLaunchConfigSSD_TRT(DataType::kHALF, DataType::kHALF, allClassNMS_gpu<__half, __half>)};

pluginStatus_t allClassNMS(cudaStream_t stream,
                           const int num,
                           const int num_classes,
                           const int num_preds_per_class,
                           const int top_k,
                           const float* nms_thr_array,
                           int nms_thr_array_len,
                           float nms_thr,
                           const bool share_location,
                           const bool isNormalized,
                           const DataType DT_SCORE,
                           const DataType DT_BBOX,
                           void* bbox_data,
                           void* beforeNMS_scores,
                           void* beforeNMS_index_array,
                           void* afterNMS_scores,
                           void* afterNMS_index_array,
                           bool flipXY,
                           const float score_shift,
                           bool caffeSemantics) {
  nmsLaunchConfigSSD_TRT lc = nmsLaunchConfigSSD_TRT(DT_SCORE, DT_BBOX);
  for (unsigned i = 0; i < nmsSsdLCOptions.size(); ++i) {
    if (lc == nmsSsdLCOptions[i]) {
      DEBUG_PRINTF("all class nms kernel %d\n", i);
      return nmsSsdLCOptions[i].function(stream,
                                         num,
                                         num_classes,
                                         num_preds_per_class,
                                         top_k,
                                         nms_thr_array,
                                         nms_thr_array_len,
                                         nms_thr,
                                         share_location,
                                         isNormalized,
                                         bbox_data,
                                         beforeNMS_scores,
                                         beforeNMS_index_array,
                                         afterNMS_scores,
                                         afterNMS_index_array,
                                         flipXY,
                                         score_shift,
                                         caffeSemantics);
    }
  }
  return STATUS_BAD_PARAM;
}

/*********************Adapt TRT plugin end***********************/

pluginStatus_t allClassNMS(cudaStream_t stream,
                           const int num,
                           const int num_classes,
                           const int num_preds_per_class,
                           const int top_k,
                           const float* nms_thr_array,
                           int nms_thr_array_len,
                           float nms_thr,
                           const bool share_location,
                           const bool isNormalized,
                           const DataType DT_SCORE,
                           const DataType DT_BBOX,
                           void* bbox_data,
                           void* beforeNMS_scores,
                           void* beforeNMS_index_array,
                           void* afterNMS_scores,
                           void* afterNMS_index_array,
                           bool flipXY) {
  nmsLaunchConfigSSD lc(DT_SCORE, DT_BBOX);
  for (unsigned i = 0; i < nmsFuncVec.size(); ++i) {
    if (lc == nmsFuncVec[i]) {
      DEBUG_PRINTF("all class nms kernel %d\n", i);
      return nmsFuncVec[i].function(stream,
                                    num,
                                    num_classes,
                                    num_preds_per_class,
                                    top_k,
                                    nms_thr_array,
                                    nms_thr_array_len,
                                    nms_thr,
                                    share_location,
                                    isNormalized,
                                    bbox_data,
                                    beforeNMS_scores,
                                    beforeNMS_index_array,
                                    afterNMS_scores,
                                    afterNMS_index_array,
                                    flipXY);
    }
  }
  return STATUS_BAD_PARAM;
}
