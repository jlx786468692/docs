// Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
// modify from
// https://github.com/NVIDIA/TensorRT/tree/master/plugin/batchedNMSPlugin
#include <stdint.h>

#include <cub/cub.cuh>

#include "cublas_v2.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "nms/kernel.h"
#include "trt_plugin_helper.hpp"
#define CUDA_MEM_ALIGN 256

// return cuda arch
size_t get_cuda_arch(int devID) {
  int computeMode = -1, major = 0, minor = 0;
  CUASSERT(cudaDeviceGetAttribute(&computeMode, cudaDevAttrComputeMode, devID));
  CUASSERT(cudaDeviceGetAttribute(&major, cudaDevAttrComputeCapabilityMajor, devID));
  CUASSERT(cudaDeviceGetAttribute(&minor, cudaDevAttrComputeCapabilityMinor, devID));
  return major * 100 + minor * 10;
}

// ALIGNPTR
int8_t* alignPtr(int8_t* ptr, uintptr_t to) {
  uintptr_t addr = (uintptr_t)ptr;
  if (addr % to) {
    addr += to - addr % to;
  }
  return (int8_t*)addr;
}

// NEXTWORKSPACEPTR
int8_t* nextWorkspacePtr(int8_t* ptr, uintptr_t previousWorkspaceSize) {
  uintptr_t addr = (uintptr_t)ptr;
  addr += previousWorkspaceSize;
  return alignPtr((int8_t*)addr, CUDA_MEM_ALIGN);
}

// CALCULATE TOTAL WORKSPACE SIZE
size_t calculateTotalWorkspaceSize(size_t* workspaces, int count) {
  size_t total = 0;
  for (int i = 0; i < count; i++) {
    total += workspaces[i];
    if (workspaces[i] % CUDA_MEM_ALIGN) {
      total += CUDA_MEM_ALIGN - (workspaces[i] % CUDA_MEM_ALIGN);
    }
  }
  return total;
}

using nvinfer1::DataType;

template <unsigned nthds_per_cta>
__launch_bounds__(nthds_per_cta) __global__
    void setUniformOffsets_kernel(const int num_segments, const int offset, int* d_offsets) {
  const int idx = blockIdx.x * nthds_per_cta + threadIdx.x;
  if (idx <= num_segments) d_offsets[idx] = idx * offset;
}

void setUniformOffsets(cudaStream_t stream,
                       const int num_segments,
                       const int offset,
                       int* d_offsets) {
  const int BS = 32;
  const int GS = (num_segments + 1 + BS - 1) / BS;
  setUniformOffsets_kernel<BS><<<GS, BS, 0, stream>>>(num_segments, offset, d_offsets);
}

// size_t detectionForwardBBoxDataSize(int N, int C1, DataType DT_BBOX) {
//   if (DT_BBOX == DataType::kFLOAT) {
//     return N * C1 * sizeof(float);
//   }

//   printf("Only FP32 type bounding boxes are supported.\n");
//   return (size_t)-1;
// }

size_t detectionForwardBBoxDataSize(int N, int C1, DataType DT_BBOX) {
  if (DT_BBOX == DataType::kFLOAT) {
    return N * C1 * sizeof(float);
  }
  if (DT_BBOX == DataType::kHALF) {
    return N * C1 * sizeof(__half);
  }

  printf("Only FP32/FP16 type bounding boxes are supported.\n");
  return (size_t)-1;
}

// size_t detectionForwardBBoxPermuteSize(bool shareLocation, int N, int C1, DataType DT_BBOX) {
//   if (DT_BBOX == DataType::kFLOAT) {
//     return shareLocation ? 0 : N * C1 * sizeof(float);
//   }
//   printf("Only FP32 type bounding boxes are supported.\n");
//   return (size_t)-1;
// }

size_t detectionForwardBBoxPermuteSize(bool shareLocation, int N, int C1, DataType DT_BBOX) {
  if (DT_BBOX == DataType::kFLOAT) {
    return shareLocation ? 0 : N * C1 * sizeof(float);
  }
  if (DT_BBOX == DataType::kHALF) {
    return shareLocation ? 0 : N * C1 * sizeof(__half);
  }

  printf("Only FP32/FP16 type bounding boxes are supported.\n");
  return (size_t)-1;
}

size_t detectionForwardPreNMSSize(int N, int C2) {
  ASSERT(sizeof(float) == sizeof(int));
  return N * C2 * sizeof(float);
}

size_t detectionForwardPostNMSSize(int N, int numClasses, int topK) {
  ASSERT(sizeof(float) == sizeof(int));
  return N * numClasses * topK * sizeof(float);
}

size_t detectionInferenceWorkspaceSize(bool shareLocation,
                                       int N,
                                       int C1,
                                       int C2,
                                       int numClasses,
                                       int numPredsPerClass,
                                       int topK,
                                       DataType DT_BBOX,
                                       DataType DT_SCORE) {
  size_t wss[7];
  wss[0] = detectionForwardBBoxDataSize(N, C1, DT_BBOX);
  wss[1] = detectionForwardBBoxPermuteSize(shareLocation, N, C1, DT_BBOX);
  wss[2] = detectionForwardPreNMSSize(N, C2);
  wss[3] = detectionForwardPreNMSSize(N, C2);
  wss[4] = detectionForwardPostNMSSize(N, numClasses, topK);
  wss[5] = detectionForwardPostNMSSize(N, numClasses, topK);
  wss[6] = std::max(sortScoresPerClassWorkspaceSize(N, numClasses, numPredsPerClass, DT_SCORE),
                    sortScoresPerImageWorkspaceSize(N, numClasses * topK, DT_SCORE));
  return calculateTotalWorkspaceSize(wss, 7);
}

__global__ void make_final_nms_output(const float* height_preds,
                                      const float* dim_preds,
                                      float* nmsedDets,
                                      const int* featMapIndex,
                                      const int* nmsedIndex,
                                      float* nmsedFinalDetsOutput,
                                      const int keep_topK,
                                      const int topK,
                                      const int num_class) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;

  if (tid >= keep_topK) return;
  int temp_index = nmsedIndex[tid];
  if (temp_index == -1) return;
  int temp_1 = int(nmsedIndex[tid] / topK);
  int temp_2 = int(nmsedIndex[tid] % topK);
  int temp_feat_index = featMapIndex[temp_2 * num_class + temp_1];
  // float4 box_info = *static_cast<float4*>(&nmsedDets[tid * 6]);
  // float2 ro_score = *static_cast<float2*>(&nmsedDets[tid * 6 + 4]);
  float box_min_x = nmsedDets[tid * 6 + 0];
  float box_min_y = nmsedDets[tid * 6 + 1];
  float box_max_x = nmsedDets[tid * 6 + 2];
  float box_max_y = nmsedDets[tid * 6 + 3];

  float box_px = (box_min_x + box_max_x) / 2;
  float box_py = (box_min_y + box_max_y) / 2;
  float box_pz = height_preds[temp_feat_index];
  float box_dx = box_max_x - box_min_x;
  float box_dy = box_max_y - box_min_y;
  float box_dz = dim_preds[3 * temp_feat_index + 2];
  box_pz = box_pz - box_dz / 2;

  nmsedFinalDetsOutput[tid * 8] = box_px;
  nmsedFinalDetsOutput[tid * 8 + 1] = box_py;
  nmsedFinalDetsOutput[tid * 8 + 2] = box_pz;
  nmsedFinalDetsOutput[tid * 8 + 3] = box_dx;
  nmsedFinalDetsOutput[tid * 8 + 4] = box_dy;
  nmsedFinalDetsOutput[tid * 8 + 5] = box_dz;
  nmsedFinalDetsOutput[tid * 8 + 6] = nmsedDets[tid * 6 + 4];
  nmsedFinalDetsOutput[tid * 8 + 7] = nmsedDets[tid * 6 + 5];
  // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro:%f, score:%f\n", box_px, box_py, box_pz,
  // box_dx, box_dy,
  //        box_dz, nmsedDets[tid * 6 + 4], nmsedDets[tid * 6 + 5]);
  return;
}

__global__ void make_share_final_nms_output(const float* height_preds,
                                            const float* dim_preds,
                                            float* nmsedDets,
                                            const int* featMapIndex,
                                            const int* nmsedIndex,
                                            float* nmsedFinalDetsOutput,
                                            int* nmsedLabels,
                                            const int keep_topK,
                                            const int topK,
                                            const int num_class) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;

  if (tid >= keep_topK) return;
  int temp_index = nmsedIndex[tid];
  if (temp_index == -1) return;
  // int temp_1 = int(nmsedIndex[tid] / topK);
  // int temp_2 = int(nmsedIndex[tid] % topK);
  int temp_feat_index = featMapIndex[nmsedIndex[tid]];
  int class_id = temp_feat_index % num_class;

  // float4 box_info = *static_cast<float4*>(&nmsedDets[tid * 6]);
  // float2 ro_score = *static_cast<float2*>(&nmsedDets[tid * 6 + 4]);
  float box_min_x = nmsedDets[tid * 6 + 0];
  float box_min_y = nmsedDets[tid * 6 + 1];
  float box_max_x = nmsedDets[tid * 6 + 2];
  float box_max_y = nmsedDets[tid * 6 + 3];

  float box_px = (box_min_x + box_max_x) / 2;
  float box_py = (box_min_y + box_max_y) / 2;
  float box_pz = height_preds[temp_feat_index];
  float box_dx = box_max_x - box_min_x;
  float box_dy = box_max_y - box_min_y;
  float box_dz = dim_preds[3 * temp_feat_index + 2];
  box_pz = box_pz - box_dz / 2;

  nmsedFinalDetsOutput[tid * 8] = box_px;
  nmsedFinalDetsOutput[tid * 8 + 1] = box_py;
  nmsedFinalDetsOutput[tid * 8 + 2] = box_pz;
  nmsedFinalDetsOutput[tid * 8 + 3] = box_dx;
  nmsedFinalDetsOutput[tid * 8 + 4] = box_dy;
  nmsedFinalDetsOutput[tid * 8 + 5] = box_dz;
  nmsedFinalDetsOutput[tid * 8 + 6] = nmsedDets[tid * 6 + 4];
  nmsedFinalDetsOutput[tid * 8 + 7] = nmsedDets[tid * 6 + 5];
  nmsedLabels[tid] = class_id;
  // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro:%f, score:%f, after label:%d\n", box_px,
  // box_py, box_pz, box_dx, box_dy,
  //        box_dz, nmsedDets[tid * 6 + 4], nmsedDets[tid * 6 + 5], nmsedLabels[tid]);
  return;
}

__device__ float get_rescale_factor(const float* rescale_factor,
                                    int rescale_factor_len,
                                    int cls_id) {
  if (rescale_factor_len > 1) {
    return rescale_factor[cls_id];
  } else {
    return rescale_factor[0];
  }
}

__global__ void make_final_bev_nms_output(const float* height_preds,
                                          const float* dim_preds,
                                          float* nmsedDets,
                                          const int* featMapIndex,
                                          const int* nmsedIndex,
                                          float* nmsedFinalDetsOutput,
                                          int* nmsedLabels,
                                          const int keep_topK,
                                          const int topK,
                                          const int num_class,
                                          const float* rescale_factor,
                                          int rescale_factor_len) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;

  if (tid >= keep_topK) return;
  int temp_index = nmsedIndex[tid];
  if (temp_index == -1) return;
  int class_id = int(nmsedIndex[tid] / topK);  // TODO 这是class id吗
  int temp_2 = int(nmsedIndex[tid] % topK);
  int temp_feat_index = featMapIndex[temp_2 * num_class + class_id];

  float rescale_factor_cls = get_rescale_factor(rescale_factor, rescale_factor_len, class_id);

  // float4 box_info = *static_cast<float4*>(&nmsedDets[tid * 6]);
  // float2 ro_score = *static_cast<float2*>(&nmsedDets[tid * 6 + 4]);
  float box_min_x = nmsedDets[tid * 6 + 0];
  float box_min_y = nmsedDets[tid * 6 + 1];
  float box_max_x = nmsedDets[tid * 6 + 2];
  float box_max_y = nmsedDets[tid * 6 + 3];

  float box_px = (box_min_x + box_max_x) / 2;
  float box_py = (box_min_y + box_max_y) / 2;
  float box_pz = height_preds[temp_feat_index];
  float box_dx = (box_max_x - box_min_x) / rescale_factor_cls;
  float box_dy = (box_max_y - box_min_y) / rescale_factor_cls;
  float box_dz = expf(dim_preds[3 * temp_feat_index + 2]);

  nmsedFinalDetsOutput[tid * 8] = box_px;
  nmsedFinalDetsOutput[tid * 8 + 1] = box_py;
  nmsedFinalDetsOutput[tid * 8 + 2] = box_pz;
  nmsedFinalDetsOutput[tid * 8 + 3] = box_dx;
  nmsedFinalDetsOutput[tid * 8 + 4] = box_dy;
  nmsedFinalDetsOutput[tid * 8 + 5] = box_dz;
  nmsedFinalDetsOutput[tid * 8 + 6] = nmsedDets[tid * 6 + 4];
  nmsedFinalDetsOutput[tid * 8 + 7] = nmsedDets[tid * 6 + 5];
  nmsedLabels[tid] = class_id;
  // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro:%f, score:%f\n", box_px, box_py, box_pz,
  // box_dx, box_dy,
  //        box_dz, nmsedDets[tid * 6 + 4], nmsedDets[tid * 6 + 5]);
  return;
}

__global__ void make_share_final_bev_nms_output(const float* height_preds,
                                                const float* dim_preds,
                                                float* nmsedDets,
                                                const int* featMapIndex,
                                                const int* nmsedIndex,
                                                float* nmsedFinalDetsOutput,
                                                int* nmsedLabels,
                                                const int keep_topK,
                                                const int topK,
                                                const int num_class,
                                                const float* rescale_factor,
                                                int rescale_factor_len) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;

  if (tid >= keep_topK) return;
  int temp_index = nmsedIndex[tid];
  if (temp_index == -1) return;
  // int temp_1 = int(nmsedIndex[tid] / topK);
  // int temp_2 = int(nmsedIndex[tid] % topK);
  int temp_feat_index = featMapIndex[nmsedIndex[tid]];
  int class_id = temp_feat_index % num_class;
  float rescale_factor_cls = get_rescale_factor(rescale_factor, rescale_factor_len, class_id);
  // float4 box_info = *static_cast<float4*>(&nmsedDets[tid * 6]);
  // float2 ro_score = *static_cast<float2*>(&nmsedDets[tid * 6 + 4]);
  float box_min_x = nmsedDets[tid * 6 + 0];
  float box_min_y = nmsedDets[tid * 6 + 1];
  float box_max_x = nmsedDets[tid * 6 + 2];
  float box_max_y = nmsedDets[tid * 6 + 3];

  float box_px = (box_min_x + box_max_x) / 2;
  float box_py = (box_min_y + box_max_y) / 2;
  float box_pz = height_preds[temp_feat_index];
  float box_dx = (box_max_x - box_min_x) / rescale_factor_cls;
  float box_dy = (box_max_y - box_min_y) / rescale_factor_cls;
  float box_dz = expf(dim_preds[3 * temp_feat_index + 2]);

  nmsedFinalDetsOutput[tid * 8] = box_px;
  nmsedFinalDetsOutput[tid * 8 + 1] = box_py;
  nmsedFinalDetsOutput[tid * 8 + 2] = box_pz;
  nmsedFinalDetsOutput[tid * 8 + 3] = box_dx;
  nmsedFinalDetsOutput[tid * 8 + 4] = box_dy;
  nmsedFinalDetsOutput[tid * 8 + 5] = box_dz;
  nmsedFinalDetsOutput[tid * 8 + 6] = nmsedDets[tid * 6 + 4];
  nmsedFinalDetsOutput[tid * 8 + 7] = nmsedDets[tid * 6 + 5];
  nmsedLabels[tid] = class_id;
  // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro:%f, score:%f, after label:%d\n", box_px,
  // box_py, box_pz, box_dx, box_dy,
  //        box_dz, nmsedDets[tid * 6 + 4], nmsedDets[tid * 6 + 5], nmsedLabels[tid]);
  return;
}

__global__ void make_nms_input_kernel(const float* heatmap_preds,
                                      const float* reg_preds,
                                      const float* height_preds,
                                      const float* dim_preds,
                                      const float* rotc_preds,
                                      const float* rots_preds,
                                      float* filtered_score,
                                      int* filtered_index,
                                      float* box_for_nms,
                                      int* filter_count,
                                      const float score_threshold,
                                      const int num_class,
                                      const int feat_x_size,
                                      const int feat_y_size,
                                      const float pillar_x_size,
                                      const float pillar_y_size,
                                      const float min_x_range,
                                      const float min_y_range,
                                      const int stride,
                                      const int topK) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;
  int stride_ = feat_x_size * feat_y_size;
  if (tid >= stride_) return;
  int grid_x = tid % feat_x_size;
  int grid_y = tid / feat_x_size;

  for (int i = 0; i < num_class; ++i) {
    float score = 1 / (1 + expf(-heatmap_preds[tid * num_class + i]));
    // printf("%d: %f \n", tid, score);
    if (score > score_threshold) {
      // printf("tid: %d, min_x_range: %f, min_y_range: %f \n", tid, min_x_range,
      // min_y_range);
      int counter = atomicAdd(&filter_count[i], 1);
      // printf("counter: %d, type id: %d\n", counter, i);
      if (counter >= topK) {
        return;
      }
      float box_px =
          (grid_x + reg_preds[2 * (tid * num_class + i)]) * pillar_x_size * stride + min_x_range;
      float box_py = (grid_y + reg_preds[2 * (tid * num_class + i) + 1]) * pillar_y_size * stride +
                     min_y_range;
      float box_pz = height_preds[tid * num_class + i];

      float box_dx = dim_preds[3 * (tid * num_class + i) + 0];
      float box_dy = dim_preds[3 * (tid * num_class + i) + 1];
      float box_dz = dim_preds[3 * (tid * num_class + i) + 2];

      float rotc = rotc_preds[tid * num_class + i];
      float rots = rots_preds[tid * num_class + i];
      // float box_ro = atan2(rotc, rots) + M_PI;
      float box_ro = atan2(rots, rotc);
      float period = M_PI * 2;
      box_ro = box_ro - floor(box_ro / period + 0.5) * period;
      box_pz = box_pz - box_dz / 2;

      // filtered_box[counter * num_output_box_feature + 0] = box_px;
      // filtered_box[counter * num_output_box_feature + 1] = box_py;
      // filtered_box[counter * num_output_box_feature + 2] = box_pz;
      // filtered_box[counter * num_output_box_feature + 3] = box_dx;
      // filtered_box[counter * num_output_box_feature + 4] = box_dy;
      // filtered_box[counter * num_output_box_feature + 5] = box_dz;
      // filtered_box[counter * num_output_box_feature + 6] = box_ro;
      filtered_score[(i + counter * num_class)] = score;
      filtered_index[(i + counter * num_class)] = tid * num_class + i;
      // printf("i+counter * 4 = %d, ref index: %d\n", i + counter * 4, tid * num_class + i);
      box_for_nms[(i + counter * num_class) * 5 + 0] = -0.5 * box_dx + box_px;
      box_for_nms[(i + counter * num_class) * 5 + 1] = -0.5 * box_dy + box_py;
      box_for_nms[(i + counter * num_class) * 5 + 2] = 0.5 * box_dx + box_px;
      box_for_nms[(i + counter * num_class) * 5 + 3] = 0.5 * box_dy + box_py;
      // float yaw = box_ro;
      box_for_nms[(i + counter * num_class) * 5 + 4] = box_ro;
      // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro: %f, score:%f\n", box_px,
      // box_py, box_pz, box_dx, box_dy, box_dz, box_ro, score); printf(
      //     "i+counter * 4 = %d, ref index: %d\nmin_x: %f, min_y: %f, "
      //     "max_x: %f, max_y: %f\n",
      //     i + counter * 4, tid * num_class + i, box_for_nms[(i + counter * 4) * 5 + 0],
      //     box_for_nms[(i + counter * 4) * 5 + 1], box_for_nms[(i + counter * 4) * 5 + 2],
      //     box_for_nms[(i + counter * 4) * 5 + 3]);
    }
  }
}

__global__ void make_share_nms_input_kernel(const float* heatmap_preds,
                                            const float* reg_preds,
                                            const float* height_preds,
                                            const float* dim_preds,
                                            const float* rotc_preds,
                                            const float* rots_preds,
                                            float* filtered_score,
                                            int* filtered_index,
                                            float* box_for_nms,
                                            int* filter_count,
                                            const float score_threshold,
                                            const int num_class,
                                            const int feat_x_size,
                                            const int feat_y_size,
                                            const float pillar_x_size,
                                            const float pillar_y_size,
                                            const float min_x_range,
                                            const float min_y_range,
                                            const int stride,
                                            const int topK) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;
  int stride_ = feat_x_size * feat_y_size;
  if (tid >= stride_) return;
  int grid_x = tid % feat_x_size;
  int grid_y = tid / feat_x_size;

  for (int i = 0; i < num_class; ++i) {
    float score = 1 / (1 + expf(-heatmap_preds[tid * num_class + i]));
    // printf("%d: %f \n", tid, score);
    if (score > score_threshold) {
      // printf("tid: %d, min_x_range: %f, min_y_range: %f \n", tid, min_x_range,
      // min_y_range);
      int counter = atomicAdd(&filter_count[0], 1);
      // printf("counter: %d, type id: %d\n", counter, i);
      if (counter >= topK) {
        return;
      }
      float box_px =
          (grid_x + reg_preds[2 * (tid * num_class + i)]) * pillar_x_size * stride + min_x_range;
      float box_py = (grid_y + reg_preds[2 * (tid * num_class + i) + 1]) * pillar_y_size * stride +
                     min_y_range;
      // float box_pz = height_preds[tid * num_class + i];

      float box_dx = dim_preds[3 * (tid * num_class + i) + 0];
      float box_dy = dim_preds[3 * (tid * num_class + i) + 1];
      // float box_dz = dim_preds[3 * (tid * num_class + i) + 2];

      float rotc = rotc_preds[tid * num_class + i];
      float rots = rots_preds[tid * num_class + i];
      // float box_ro = atan2(rotc, rots) + M_PI;
      float box_ro = atan2(rots, rotc);
      float period = M_PI * 2;
      box_ro = box_ro - floor(box_ro / period + 0.5) * period;
      // box_pz = box_pz - box_dz / 2;

      filtered_score[counter] = score;
      filtered_index[counter] = tid * num_class + i;
      // printf("i+counter * 4 = %d, ref index: %d\n", i + counter * 4, tid * num_class + i);
      box_for_nms[counter * 5 + 0] = -0.5 * box_dx + box_px;
      box_for_nms[counter * 5 + 1] = -0.5 * box_dy + box_py;
      box_for_nms[counter * 5 + 2] = 0.5 * box_dx + box_px;
      box_for_nms[counter * 5 + 3] = 0.5 * box_dy + box_py;
      // float yaw = box_ro;
      box_for_nms[counter * 5 + 4] = box_ro;
      // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro: %f, score:%f, label:%d\n",
      // box_px, box_py, box_pz, box_dx,
      //        box_dy, box_dz, box_ro, score, i);
      // printf(
      //     "i+counter * 4 = %d, ref index: %d\nmin_x: %f, min_y: %f, "
      //     "max_x: %f, max_y: %f\n",
      //     i + counter * 4, tid * num_class + i, box_for_nms[(i + counter * 4) * 5 + 0],
      //     box_for_nms[(i + counter * 4) * 5 + 1], box_for_nms[(i + counter * 4) * 5 + 2],
      //     box_for_nms[(i + counter * 4) * 5 + 3]);
    }
  }
}

__global__ void make_bev_nms_input_kernel(const float* heatmap_preds,
                                          const float* reg_preds,
                                          const float* height_preds,
                                          const float* dim_preds,
                                          const float* rot_preds,
                                          float* filtered_score,
                                          int* filtered_index,
                                          float* box_for_nms,
                                          int* filter_count,
                                          const float score_threshold,
                                          const int num_class,
                                          const int feat_x_size,
                                          const int feat_y_size,
                                          const float pillar_x_size,
                                          const float pillar_y_size,
                                          const float min_x_range,
                                          const float min_y_range,
                                          const int stride,
                                          const int topK,
                                          const float* rescale_factor,
                                          int rescale_factor_len) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;
  int stride_ = feat_x_size * feat_y_size;
  if (tid >= stride_) return;
  int grid_x = tid % feat_x_size;
  int grid_y = tid / feat_x_size;

  for (int i = 0; i < num_class; ++i) {
    float score = 1 / (1 + expf(-heatmap_preds[tid * num_class + i]));
    // printf("%d: %f \n", tid, score);
    if (score > score_threshold) {
      // printf("tid: %d, min_x_range: %f, min_y_range: %f \n", tid, min_x_range,
      // min_y_range);
      int counter = atomicAdd(&filter_count[i], 1);
      // printf("counter: %d, type id: %d\n", counter, i);
      if (counter >= topK) {
        return;
      }
      float box_px = (grid_x + reg_preds[2 * (tid * num_class + i) + 0]) * pillar_x_size * stride +
                     min_x_range;
      float box_py = (grid_y + reg_preds[2 * (tid * num_class + i) + 1]) * pillar_y_size * stride +
                     min_y_range;
      // float box_pz = height_preds[tid * num_class + i];

      float rescale_factor_cls = get_rescale_factor(rescale_factor, rescale_factor_len, i);
      float box_dx = rescale_factor_cls * expf(dim_preds[3 * (tid * num_class + i) + 0]);
      float box_dy = rescale_factor_cls * expf(dim_preds[3 * (tid * num_class + i) + 1]);
      // float box_dz = expf(dim_preds[3 * (tid * num_class + i) + 2]);

      float rots = rot_preds[2 * (tid * num_class + i) + 0];
      float rotc = rot_preds[2 * (tid * num_class + i) + 1];
      // float box_ro = atan2(rotc, rots) + M_PI;
      float box_ro = atan2(rots, rotc);
      float period = M_PI * 2;
      box_ro = box_ro - floor(box_ro / period + 0.5) * period;
      // box_pz = box_pz - box_dz / 2;

      // filtered_box[counter * num_output_box_feature + 0] = box_px;
      // filtered_box[counter * num_output_box_feature + 1] = box_py;
      // filtered_box[counter * num_output_box_feature + 2] = box_pz;
      // filtered_box[counter * num_output_box_feature + 3] = box_dx;
      // filtered_box[counter * num_output_box_feature + 4] = box_dy;
      // filtered_box[counter * num_output_box_feature + 5] = box_dz;
      // filtered_box[counter * num_output_box_feature + 6] = box_ro;
      filtered_score[(i + counter * num_class)] = score;
      filtered_index[(i + counter * num_class)] = tid * num_class + i;
      // printf("i+counter * 4 = %d, ref index: %d\n", i + counter * 4, tid * num_class + i);
      box_for_nms[(i + counter * num_class) * 5 + 0] = -0.5 * box_dx + box_px;
      box_for_nms[(i + counter * num_class) * 5 + 1] = -0.5 * box_dy + box_py;
      box_for_nms[(i + counter * num_class) * 5 + 2] = 0.5 * box_dx + box_px;
      box_for_nms[(i + counter * num_class) * 5 + 3] = 0.5 * box_dy + box_py;
      // float yaw = box_ro;
      box_for_nms[(i + counter * num_class) * 5 + 4] = box_ro;
      // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro: %f, score:%f\n", box_px,
      // box_py, box_pz, box_dx, box_dy, box_dz, box_ro, score); printf(
      //     "i+counter * 4 = %d, ref index: %d\nmin_x: %f, min_y: %f, "
      //     "max_x: %f, max_y: %f\n",
      //     i + counter * 4, tid * num_class + i, box_for_nms[(i + counter * 4) * 5 + 0],
      //     box_for_nms[(i + counter * 4) * 5 + 1], box_for_nms[(i + counter * 4) * 5 + 2],
      //     box_for_nms[(i + counter * 4) * 5 + 3]);
    }
  }
}

__global__ void make_share_bev_nms_input_kernel(const float* heatmap_preds,
                                                const float* reg_preds,
                                                const float* height_preds,
                                                const float* dim_preds,
                                                const float* rot_preds,
                                                float* filtered_score,
                                                int* filtered_index,
                                                float* box_for_nms,
                                                int* filter_count,
                                                const float score_threshold,
                                                const int num_class,
                                                const int feat_x_size,
                                                const int feat_y_size,
                                                const float pillar_x_size,
                                                const float pillar_y_size,
                                                const float min_x_range,
                                                const float min_y_range,
                                                const int stride,
                                                const int topK,
                                                const float* rescale_factor,
                                                int rescale_factor_len) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;
  int stride_ = feat_x_size * feat_y_size;
  if (tid >= stride_) return;
  int grid_x = tid % feat_x_size;
  int grid_y = tid / feat_x_size;

  for (int i = 0; i < num_class; ++i) {
    float score = 1 / (1 + expf(-heatmap_preds[tid * num_class + i]));
    // printf("%d: %f \n", tid, score);
    if (score > score_threshold) {
      // printf("tid: %d, min_x_range: %f, min_y_range: %f \n", tid, min_x_range,
      // min_y_range);
      int counter = atomicAdd(&filter_count[0], 1);
      // printf("counter: %d, type id: %d\n", counter, i);
      if (counter >= topK) {
        return;
      }
      float box_px =
          (grid_x + reg_preds[2 * (tid * num_class + i)]) * pillar_x_size * stride + min_x_range;
      float box_py = (grid_y + reg_preds[2 * (tid * num_class + i) + 1]) * pillar_y_size * stride +
                     min_y_range;
      // float box_pz = height_preds[tid * num_class + i];

      float rescale_factor_cls = get_rescale_factor(rescale_factor, rescale_factor_len, i);
      float box_dx = rescale_factor_cls * expf(dim_preds[3 * (tid * num_class + i) + 0]);
      float box_dy = rescale_factor_cls * expf(dim_preds[3 * (tid * num_class + i) + 1]);
      // float box_dz = expf(dim_preds[3 * (tid * num_class + i) + 2]);

      float rots = rot_preds[2 * (tid * num_class + i) + 0];
      float rotc = rot_preds[2 * (tid * num_class + i) + 1];
      // float box_ro = atan2(rotc, rots) + M_PI;
      float box_ro = atan2(rots, rotc);
      float period = M_PI * 2;
      box_ro = box_ro - floor(box_ro / period + 0.5) * period;
      // box_pz = box_pz - box_dz / 2;

      filtered_score[counter] = score;
      filtered_index[counter] = tid * num_class + i;
      // printf("i+counter * 4 = %d, ref index: %d\n", i + counter * 4, tid * num_class + i);
      box_for_nms[counter * 5 + 0] = -0.5 * box_dx + box_px;
      box_for_nms[counter * 5 + 1] = -0.5 * box_dy + box_py;
      box_for_nms[counter * 5 + 2] = 0.5 * box_dx + box_px;
      box_for_nms[counter * 5 + 3] = 0.5 * box_dy + box_py;
      // float yaw = box_ro;
      box_for_nms[counter * 5 + 4] = box_ro;
      // printf("px:%f, py:%f, pz:%f, dx:%f, dy:%f, dz:%f, ro: %f, score:%f, label:%d\n",
      // box_px, box_py, box_pz, box_dx,
      //        box_dy, box_dz, box_ro, score, i);
      // printf(
      //     "i+counter * 4 = %d, ref index: %d\nmin_x: %f, min_y: %f, "
      //     "max_x: %f, max_y: %f\n",
      //     i + counter * 4, tid * num_class + i, box_for_nms[(i + counter * 4) * 5 + 0],
      //     box_for_nms[(i + counter * 4) * 5 + 1], box_for_nms[(i + counter * 4) * 5 + 2],
      //     box_for_nms[(i + counter * 4) * 5 + 3]);
    }
  }
}

// __global__ void make_bbox_output(const float* heatmap_preds, const float* reg_preds, const float*
// height_preds,
//                                  const float* dim_preds, const float* rotc_preds, const float*
//                                  rots_preds, int* filtered_index, int* nmsedIndex, const float
//                                  pillar_x_size, const float pillar_y_size, const float
//                                  min_x_range, const float min_y_range, const int stride, const
//                                  int keep_topk) {}

void makeNmsInput(const float* heatmap_preds,
                  const float* reg_preds,
                  const float* height_preds,
                  const float* dim_preds,
                  const float* rotc_preds,
                  const float* rots_preds,
                  float* filtered_score,
                  int* filtered_index,
                  float* box_for_nms,
                  int* filter_count,
                  const float score_threshold,
                  const int num_class,
                  const int feat_x_size,
                  const int feat_y_size,
                  const float pillar_x_size,
                  const float pillar_y_size,
                  const float min_x_range,
                  const float min_y_range,
                  const int stride,
                  const int topK,
                  const bool shareLocation,
                  cudaStream_t stream) {
  size_t anchor_size = feat_x_size * feat_y_size;
  constexpr size_t num_threads = 64;
  const int num_blocks_filter_kernel = DIVUP(anchor_size, num_threads);
  if (!shareLocation) {
    make_nms_input_kernel<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(heatmap_preds,
                                                                                reg_preds,
                                                                                height_preds,
                                                                                dim_preds,
                                                                                rotc_preds,
                                                                                rots_preds,
                                                                                filtered_score,
                                                                                filtered_index,
                                                                                box_for_nms,
                                                                                filter_count,
                                                                                score_threshold,
                                                                                num_class,
                                                                                feat_x_size,
                                                                                feat_y_size,
                                                                                pillar_x_size,
                                                                                pillar_y_size,
                                                                                min_x_range,
                                                                                min_y_range,
                                                                                stride,
                                                                                topK);
  } else {
    make_share_nms_input_kernel<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        heatmap_preds,
        reg_preds,
        height_preds,
        dim_preds,
        rotc_preds,
        rots_preds,
        filtered_score,
        filtered_index,
        box_for_nms,
        filter_count,
        score_threshold,
        num_class,
        feat_x_size,
        feat_y_size,
        pillar_x_size,
        pillar_y_size,
        min_x_range,
        min_y_range,
        stride,
        topK);
  }
}

void makeBevNmsInput(const float* heatmap_preds,
                     const float* reg_preds,
                     const float* height_preds,
                     const float* dim_preds,
                     const float* rot_preds,
                     float* filtered_score,
                     int* filtered_index,
                     float* box_for_nms,
                     int* filter_count,
                     const float score_threshold,
                     const int num_class,
                     const int feat_x_size,
                     const int feat_y_size,
                     const float pillar_x_size,
                     const float pillar_y_size,
                     const float min_x_range,
                     const float min_y_range,
                     const int stride,
                     const int topK,
                     const bool shareLocation,
                     const float* rescale_factor,
                     int rescale_factor_len,
                     cudaStream_t stream) {
  size_t anchor_size = feat_x_size * feat_y_size;
  constexpr size_t num_threads = 64;
  const int num_blocks_filter_kernel = DIVUP(anchor_size, num_threads);
  if (!shareLocation) {
    make_bev_nms_input_kernel<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        heatmap_preds,
        reg_preds,
        height_preds,
        dim_preds,
        rot_preds,
        filtered_score,
        filtered_index,
        box_for_nms,
        filter_count,
        score_threshold,
        num_class,
        feat_x_size,
        feat_y_size,
        pillar_x_size,
        pillar_y_size,
        min_x_range,
        min_y_range,
        stride,
        topK,
        rescale_factor,
        rescale_factor_len);
  } else {
    make_share_bev_nms_input_kernel<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        heatmap_preds,
        reg_preds,
        height_preds,
        dim_preds,
        rot_preds,
        filtered_score,
        filtered_index,
        box_for_nms,
        filter_count,
        score_threshold,
        num_class,
        feat_x_size,
        feat_y_size,
        pillar_x_size,
        pillar_y_size,
        min_x_range,
        min_y_range,
        stride,
        topK,
        rescale_factor,
        rescale_factor_len);
  }
}

void makeFinalBevNmsOutput(const float* height_preds,
                           const float* dim_preds,
                           float* nmsedDets,
                           const int* featMapIndex,
                           const int* nmsedIndex,
                           float* nmsedFinalDetsOutput,
                           int* nmsedLabels,
                           const int keep_topK,
                           const int topK,
                           const int num_class,
                           const bool shareLocation,
                           const float* rescale_factor,
                           int rescale_factor_len,
                           cudaStream_t stream) {
  constexpr size_t num_threads = 64;
  const int num_blocks_filter_kernel = DIVUP(keep_topK, num_threads);
  if (!shareLocation) {
    make_final_bev_nms_output<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        height_preds,
        dim_preds,
        nmsedDets,
        featMapIndex,
        nmsedIndex,
        nmsedFinalDetsOutput,
        nmsedLabels,
        keep_topK,
        topK,
        num_class,
        rescale_factor,
        rescale_factor_len);
  } else {
    make_share_final_bev_nms_output<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        height_preds,
        dim_preds,
        nmsedDets,
        featMapIndex,
        nmsedIndex,
        nmsedFinalDetsOutput,
        nmsedLabels,
        keep_topK,
        topK,
        num_class,
        rescale_factor,
        rescale_factor_len);
  }
}

void makeFinalNmsOutput(const float* height_preds,
                        const float* dim_preds,
                        float* nmsedDets,
                        const int* featMapIndex,
                        const int* nmsedIndex,
                        float* nmsedFinalDetsOutput,
                        int* nmsedLabels,
                        const int keep_topK,
                        const int topK,
                        const int num_class,
                        const bool shareLocation,
                        cudaStream_t stream) {
  constexpr size_t num_threads = 64;
  const int num_blocks_filter_kernel = DIVUP(keep_topK, num_threads);
  if (!shareLocation) {
    make_final_nms_output<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        height_preds,
        dim_preds,
        nmsedDets,
        featMapIndex,
        nmsedIndex,
        nmsedFinalDetsOutput,
        keep_topK,
        topK,
        num_class);
  } else {
    make_share_final_nms_output<<<num_blocks_filter_kernel, num_threads, 0, stream>>>(
        height_preds,
        dim_preds,
        nmsedDets,
        featMapIndex,
        nmsedIndex,
        nmsedFinalDetsOutput,
        nmsedLabels,
        keep_topK,
        topK,
        num_class);
  }
}