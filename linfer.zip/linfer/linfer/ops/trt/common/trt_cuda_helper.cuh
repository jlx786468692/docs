// Copyright (c) OpenMMLab. All rights reserved.
#include "common_cuda_helper.hpp"
#include "trt_plugin_helper.hpp"

using linfer::TensorDesc;

template <class scalar_t>
void memcpyPermute(scalar_t* dst,
                   const scalar_t* src,
                   int* src_size,
                   int* permute,
                   int src_dim,
                   cudaStream_t stream);

template <>
cublasStatus_t cublasGemmWrap<float>(cublasHandle_t handle,
                                     cublasOperation_t transa,
                                     cublasOperation_t transb,
                                     int m,
                                     int n,
                                     int k,
                                     const float* alpha,
                                     const float* A,
                                     int lda,
                                     const float* B,
                                     int ldb,
                                     const float* beta,
                                     float* C,
                                     int ldc);

template <>
cublasStatus_t cublasGemmWrap<half>(cublasHandle_t handle,
                                    cublasOperation_t transa,
                                    cublasOperation_t transb,
                                    int m,
                                    int n,
                                    int k,
                                    const half* alpha,
                                    const half* A,
                                    int lda,
                                    const half* B,
                                    int ldb,
                                    const half* beta,
                                    half* C,
                                    int ldc);
using nvinfer1::DataType;

size_t dataTypeSize(const DataType dtype);
