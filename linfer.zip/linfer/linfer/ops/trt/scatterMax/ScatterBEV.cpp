/*
 * SPDX-FileCopyrightText: Copyright (c) 2021 NVIDIA CORPORATION & AFFILIATES.
 * All rights reserved. SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "linfer/ops/trt/scatterMax/ScatterBEV.h"

#include <unistd.h>

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>

#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/scatterMax/ScatterBEV_kernels.h"
/**
 * For the usage of those member function, please refer to the
 * offical api doc.
 * https://docs.nvidia.com/deeplearning/tensorrt/api/c_api/classnvinfer1_1_1_i_plugin_v2_ext.html
 */

#ifndef CUTEDEBUG
#define CUTEDEBUG 0  // set debug mode, if you want to see the api call, set it to 1
#endif

#if CUTEDEBUG
#define cutelog(...)                                                                             \
  {                                                                                              \
    char str[100];                                                                               \
    snprintf(str, __VA_ARGS__);                                                                  \
    std::cout << " (๑¯◡¯๑) noexcept CUSTOM PLUGIN TRACE----> call "                              \
              << "[" << __FILE__ << "][" << __FUNCTION__ << "][Line " << __LINE__ << "] " << str \
              << std::endl;                                                                      \
  }
#else
#define cutelog(...)
#endif

using nvinfer1::plugin::ScatterBevPlugin;
using nvinfer1::plugin::ScatterBevPluginCreator;

static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"ScatterBEV"};

// Static class fields initialization
nvinfer1::PluginFieldCollection ScatterBevPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> ScatterBevPluginCreator::mPluginAttributes;

// Helper function for serializing plugin
template <typename T>
void writeToBuffer(char*& buffer, const T& val) {
  *reinterpret_cast<T*>(buffer) = val;
  buffer += sizeof(T);
}

// Helper function for deserializing plugin
template <typename T>
T readFromBuffer(const char*& buffer) {
  T val = *reinterpret_cast<const T*>(buffer);
  buffer += sizeof(T);
  return val;
}

ScatterBevPlugin::ScatterBevPlugin() { cutelog("wow I run to here now"); }

ScatterBevPlugin::ScatterBevPlugin(size_t feat_num, size_t h, size_t w)
    : featureNum_(feat_num), feature_y_size_(h), feature_x_size_(w) {
  cutelog("wow I run to here now");
}

ScatterBevPlugin::ScatterBevPlugin(const void* data, size_t length) {
  const char* d = reinterpret_cast<const char*>(data);
  featureNum_ = readFromBuffer<size_t>(d);
  feature_y_size_ = readFromBuffer<size_t>(d);
  feature_x_size_ = readFromBuffer<size_t>(d);
}

// IPluginV2DynamicExt Methods
nvinfer1::IPluginV2DynamicExt* ScatterBevPlugin::clone() const noexcept {
  cutelog("wow I run to here now");
  auto* plugin = new ScatterBevPlugin(featureNum_, feature_y_size_, feature_x_size_);
  plugin->setPluginNamespace(mNamespace.c_str());
  return plugin;
}

nvinfer1::DimsExprs ScatterBevPlugin::getOutputDimensions(
    int outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  cutelog("wow I run to here now");
  assert(outputIndex == 0);
  // for(int i=0;i<nbInputs;i++) {
  //     printf("input[%d]: ", i);
  //     for(int j=0;j<inputs[i].nbDims;j++) {
  //         printf("%d ", inputs[i].d[j]->getConstantValue());
  //     }
  //     printf("\n");
  // }
  nvinfer1::DimsExprs output;
  output.nbDims = 4;
  output.d[0] = exprBuilder.constant(1);
  output.d[1] = exprBuilder.constant(featureNum_);
  output.d[2] = exprBuilder.constant(feature_y_size_);
  output.d[3] = exprBuilder.constant(feature_x_size_);

  return output;
}

bool ScatterBevPlugin::supportsFormatCombination(int pos,
                                                 const nvinfer1::PluginTensorDesc* inOut,
                                                 int nbInputs,
                                                 int nbOutputs) noexcept {
  assert(nbInputs == 3);
  assert(nbOutputs == 1);
  const PluginTensorDesc& in = inOut[pos];
  if (pos == 0) {
    return (in.type == nvinfer1::DataType::kFLOAT || in.type == nvinfer1::DataType::kHALF) &&
           (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 1) {
    return (in.type == nvinfer1::DataType::kINT32) && (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 2) {
    return (in.type == nvinfer1::DataType::kINT32) && (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 3) {
    return (inOut[0].type == nvinfer1::DataType::kFLOAT && in.type == nvinfer1::DataType::kFLOAT &&
            in.format == TensorFormat::kLINEAR) ||
           (inOut[0].type == nvinfer1::DataType::kHALF && in.type == nvinfer1::DataType::kHALF &&
            in.format == TensorFormat::kHWC8);
  }
  return false;
}

void ScatterBevPlugin::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                       int nbInputs,
                                       const nvinfer1::DynamicPluginTensorDesc* out,
                                       int nbOutputs) noexcept {
  cutelog("wow I run to here now");
}

size_t ScatterBevPlugin::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                          int nbInputs,
                                          const nvinfer1::PluginTensorDesc* outputs,
                                          int nbOutputs) const noexcept {
  cutelog("wow I run to here now");
  unsigned int cacheBEVSize = inputs[0].dims.d[0] * inputs[0].dims.d[2] * sizeof(float);
  return cacheBEVSize;
}

int ScatterBevPlugin::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                              const nvinfer1::PluginTensorDesc* outputDesc,
                              const void* const* inputs,
                              void* const* outputs,
                              void* workspace,
                              cudaStream_t stream) noexcept {
  unsigned int batch = 1;
  unsigned int featureNum = featureNum_;
  unsigned int featureY = feature_y_size_;
  unsigned int featureX = feature_x_size_;
  nvinfer1::DataType inputType = inputDesc[0].type;

  auto coords_data = reinterpret_cast<const unsigned int*>(inputs[1]);
  auto params_data = reinterpret_cast<const unsigned int*>(inputs[2]);
  // unsigned int count = 0;
  // cudaMemcpyAsync(&count, params_data, sizeof(unsigned int),
  //                 cudaMemcpyDeviceToHost, stream);
  // cudaStreamSynchronize(stream);
  // std::cout << "count:" << count << std::endl;
  if (inputType == nvinfer1::DataType::kHALF) {
    auto in = reinterpret_cast<const half*>(inputs[0]);
    auto spatial_feature_data = reinterpret_cast<half*>(outputs[0]);
    cacheBEV_ = workspace;
    half* pillar_features_data = reinterpret_cast<half*>(cacheBEV_);
    (cudaMemsetAsync(spatial_feature_data,
                     0,
                     batch * featureNum * featureY * featureX * sizeof(half),
                     stream));
    (reduceMax_kernel_half_launcher(in,
                                    pillar_features_data,
                                    params_data,
                                    featureX,
                                    featureY,
                                    stream));
    (scatterBEV_kernel_half_launcher(pillar_features_data,
                                     coords_data,
                                     params_data,
                                     featureX,
                                     featureY,
                                     spatial_feature_data,
                                     stream));
    cudaCheckError();

  } else if (inputType == nvinfer1::DataType::kFLOAT) {
    auto in = reinterpret_cast<const float*>(inputs[0]);
    float* spatial_feature_data = reinterpret_cast<float*>(outputs[0]);

    cacheBEV_ = workspace;
    float* pillar_features_data = reinterpret_cast<float*>(cacheBEV_);

    (cudaMemsetAsync(spatial_feature_data,
                     0,
                     batch * featureNum * featureY * featureX * sizeof(float),
                     stream));
    (reduceMax_kernel_launcher(in, pillar_features_data, params_data, featureX, featureY, stream));

    (scatterBEV_kernel_launcher(pillar_features_data,
                                coords_data,
                                params_data,
                                featureX,
                                featureY,
                                spatial_feature_data,
                                stream));
  } else {
    assert(0);
  }

  return 0;
}

// IPluginV2Ext Methods
nvinfer1::DataType ScatterBevPlugin::getOutputDataType(int index,
                                                       const nvinfer1::DataType* inputTypes,
                                                       int nbInputs) const noexcept {
  cutelog("wow I run to here now");
  return inputTypes[0];
}

// IPluginV2 Methods

const char* ScatterBevPlugin::getPluginType() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_NAME;
}

const char* ScatterBevPlugin::getPluginVersion() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_VERSION;
}

int ScatterBevPlugin::getNbOutputs() const noexcept {
  cutelog("wow I run to here now");
  return 1;
}

int ScatterBevPlugin::initialize() noexcept {
  cutelog("wow I run to here now");
  return 0;
}

void ScatterBevPlugin::terminate() noexcept { cutelog("wow I run to here now"); }

size_t ScatterBevPlugin::getSerializationSize() const noexcept {
  cutelog("wow I run to here now");
  return 4 * sizeof(size_t);
}

void ScatterBevPlugin::serialize(void* buffer) const noexcept {
  cutelog("wow I run to here now");
  char* d = reinterpret_cast<char*>(buffer);
  writeToBuffer<size_t>(d, featureNum_);
  writeToBuffer<size_t>(d, feature_y_size_);
  writeToBuffer<size_t>(d, feature_x_size_);
}

void ScatterBevPlugin::destroy() noexcept {
  cutelog("wow I run to here now");
  delete this;
}

void ScatterBevPlugin::setPluginNamespace(const char* libNamespace) noexcept {
  cutelog("wow I run to here now");
  mNamespace = libNamespace;
}

const char* ScatterBevPlugin::getPluginNamespace() const noexcept {
  cutelog("wow I run to here now");
  return mNamespace.c_str();
}

///////////////

ScatterBevPluginCreator::ScatterBevPluginCreator() {
  cutelog("wow I run to here now");
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      PluginField("dense_shape", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* ScatterBevPluginCreator::getPluginName() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_NAME;
}

const char* ScatterBevPluginCreator::getPluginVersion() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_VERSION;
}

const nvinfer1::PluginFieldCollection* ScatterBevPluginCreator::getFieldNames() noexcept {
  cutelog("wow I run to here now");
  return &mFC;
}

nvinfer1::IPluginV2* ScatterBevPluginCreator::createPlugin(
    const char* name,
    const PluginFieldCollection* fc) noexcept {
  const PluginField* fields = fc->fields;
  int nbFields = fc->nbFields;
  int target_featnum = 0;
  int target_h = 0;
  int target_w = 0;
  for (int i = 0; i < nbFields; ++i) {
    const char* attr_name = fields[i].name;
    if (!strcmp(attr_name, "dense_shape")) {
      const int* ts = static_cast<const int*>(fields[i].data);
      target_featnum = ts[1];
      target_h = ts[2];
      target_w = ts[3];
      // std::cout << "target_featnum:" << target_featnum
      //           << " target_h:" << target_h
      //           << " target_w:" << target_w << std::endl;
    }
  }
  nvinfer1::IPluginV2* plugin = new ScatterBevPlugin(target_featnum, target_h, target_w);
  return plugin;
}

nvinfer1::IPluginV2* ScatterBevPluginCreator::deserializePlugin(const char* name,
                                                                const void* serialData,
                                                                size_t serialLength) noexcept {
  cutelog("wow I run to here now");
  return new ScatterBevPlugin(serialData, serialLength);
}

void ScatterBevPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  cutelog("wow I run to here now");
  mNamespace = libNamespace;
}

const char* ScatterBevPluginCreator::getPluginNamespace() const noexcept {
  cutelog("wow I run to here now");
  return mNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(ScatterBevPluginCreator);