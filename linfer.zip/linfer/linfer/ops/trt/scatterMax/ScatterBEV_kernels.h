// Copyright [2022] <Lotus Robotics>
#pragma once
#include <cuda_fp16.h>
// #define PILLARS_PER_BLOCK 64
// one thread deals with one pillar and a block has PILLARS_PER_BLOCK threads
#define FEATURE_SIZE 64       // feature count for one pillar depands on "params.h"
#define POINTS_PER_PILLAR 20  // points in one pillar depands on "params.h
const int PILLARS_PER_BLOCK = 64;
// #include "kernel.h"

cudaError_t scatterBEV_kernel_launcher(const float* pillar_features_data,
                                       const unsigned int* coords_data,
                                       const unsigned int* params_data,
                                       unsigned int featureX,
                                       unsigned int featureY,
                                       float* spatial_feature_data,
                                       cudaStream_t stream = 0);
cudaError_t scatterBEV_kernel_half_launcher(const half* pillar_features_data,
                                            const unsigned int* coords_data,
                                            const unsigned int* params_data,
                                            unsigned int featureX,
                                            unsigned int featureY,
                                            half* spatial_feature_data,
                                            cudaStream_t stream = 0);
// for N*32*64
cudaError_t reduceMax_kernel_launcher(const float* in,
                                      float* out,
                                      const unsigned int* pillarCount,
                                      unsigned int featureX,
                                      unsigned int featureY,
                                      cudaStream_t stream = 0);
cudaError_t reduceMax_kernel_half_launcher(const half* in,
                                           half* out,
                                           const unsigned int* pillarCount,
                                           unsigned int featureX,
                                           unsigned int featureY,
                                           cudaStream_t stream = 0);