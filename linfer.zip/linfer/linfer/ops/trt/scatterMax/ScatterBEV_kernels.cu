// Copyright [2022] <Lotus Robotics>
#include <cuda_fp16.h>
#include <cuda_runtime_api.h>

#include <iostream>

#include "ScatterBEV_kernels.h"
__global__ void scatterBEV_kernel(const float* pillar_features_data,
                                  const unsigned int* coords_data,
                                  const unsigned int* params_data,
                                  unsigned int featureX,
                                  unsigned int featureY,
                                  float* spatial_feature_data) {
  int pillar_idx = blockIdx.x * PILLARS_PER_BLOCK + threadIdx.x;
  int valid_pillars_inBlock = PILLARS_PER_BLOCK;

  const int num_pillars = params_data[0];
  // printf("num_pillars: %d\n", num_pillars);
  if ((blockIdx.x * PILLARS_PER_BLOCK) > num_pillars) return;
  int valid_blocks = (num_pillars + PILLARS_PER_BLOCK - 1) / PILLARS_PER_BLOCK;
  if (blockIdx.x >= valid_blocks) return;

  if (blockIdx.x == (valid_blocks - 1)) {
    valid_pillars_inBlock = num_pillars % PILLARS_PER_BLOCK;
  }

  valid_pillars_inBlock = (valid_pillars_inBlock == 0) ? PILLARS_PER_BLOCK : valid_pillars_inBlock;

  __shared__ float pillarSM[PILLARS_PER_BLOCK][FEATURE_SIZE];  // pillar*64

  for (int i = 0; i < valid_pillars_inBlock; i++) {
    pillarSM[i][threadIdx.x] =
        pillar_features_data[(blockIdx.x * PILLARS_PER_BLOCK + i) * FEATURE_SIZE + threadIdx.x];
  }

  __syncthreads();

  if (pillar_idx >= num_pillars) return;

  uint4 coord = ((const uint4*)coords_data)[pillar_idx];

  unsigned int x = coord.w;
  unsigned int y = coord.z;
  // printf("x: %d, y: %d, feat: pillarSM:%.3f %.3f %.3f\n", x, y, pillarSM[threadIdx.x][0],
  // pillarSM[threadIdx.x][1], pillarSM[threadIdx.x][2]);
  for (int i = 0; i < FEATURE_SIZE; i++) {
    spatial_feature_data[i * featureY * featureX + y * featureX + x] = pillarSM[threadIdx.x][i];
  }
}

__global__ void scatterBEV_kernel_half(const half* pillar_features_data,
                                       const unsigned int* coords_data,
                                       const unsigned int* params_data,
                                       unsigned int featureX,
                                       unsigned int featureY,
                                       half* spatial_feature_data) {
  int pillar_idx = blockIdx.x * PILLARS_PER_BLOCK + threadIdx.x;
  int valid_pillars_inBlock = PILLARS_PER_BLOCK;
  const int num_pillars = params_data[0];
  int valid_blocks = (num_pillars + PILLARS_PER_BLOCK - 1) / PILLARS_PER_BLOCK;
  if (blockIdx.x >= valid_blocks) return;
  if (blockIdx.x == (valid_blocks - 1)) {
    valid_pillars_inBlock = num_pillars % PILLARS_PER_BLOCK;
  }
  valid_pillars_inBlock = (valid_pillars_inBlock == 0) ? PILLARS_PER_BLOCK : valid_pillars_inBlock;
  __shared__ half pillarSM[PILLARS_PER_BLOCK][FEATURE_SIZE];  // pillar*64
  for (int i = 0; i < valid_pillars_inBlock; i++) {
    pillarSM[i][threadIdx.x] =
        pillar_features_data[(blockIdx.x * PILLARS_PER_BLOCK + i) * FEATURE_SIZE + threadIdx.x];
  }
  __syncthreads();
  if (pillar_idx >= num_pillars) return;
  uint4 coord = ((const uint4*)coords_data)[pillar_idx];
  unsigned int x = coord.w;
  unsigned int y = coord.z;
  // Output tensor format : kHWC8, [N][H][W][(C+7)/8*8]
  int C_stride = (FEATURE_SIZE + 7) / 8 * 8;
  for (int i = 0; i < FEATURE_SIZE; i++) {
    spatial_feature_data[y * featureX * C_stride + x * C_stride + i] = pillarSM[threadIdx.x][i];
  }
}

cudaError_t scatterBEV_kernel_launcher(const float* pillar_features_data,
                                       const unsigned int* coords_data,
                                       const unsigned int* params_data,
                                       unsigned int featureX,
                                       unsigned int featureY,
                                       float* spatial_feature_data,
                                       cudaStream_t stream) {
  dim3 blocks((featureX * featureY + PILLARS_PER_BLOCK - 1) / PILLARS_PER_BLOCK);
  dim3 threads(PILLARS_PER_BLOCK);

  scatterBEV_kernel<<<blocks, threads, 0, stream>>>(pillar_features_data,
                                                    coords_data,
                                                    params_data,
                                                    featureX,
                                                    featureY,
                                                    spatial_feature_data);

  return cudaGetLastError();
}

cudaError_t scatterBEV_kernel_half_launcher(const half* pillar_features_data,
                                            const unsigned int* coords_data,
                                            const unsigned int* params_data,
                                            unsigned int featureX,
                                            unsigned int featureY,
                                            half* spatial_feature_data,
                                            cudaStream_t stream) {
  dim3 blocks((featureX * featureY + PILLARS_PER_BLOCK - 1) / PILLARS_PER_BLOCK);
  dim3 threads(PILLARS_PER_BLOCK);
  scatterBEV_kernel_half<<<blocks, threads, 0, stream>>>(pillar_features_data,
                                                         coords_data,
                                                         params_data,
                                                         featureX,
                                                         featureY,
                                                         spatial_feature_data);
  return cudaGetLastError();
}

__global__ void reduceMax_kernel(const float* in, float* out, const unsigned int* pillarCount) {
  // int pillar_idx = (blockIdx.x * blockDim.x + threadIdx.x)/POINTS_PER_PILLAR;
  int pillar_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (pillar_idx >= pillarCount[0]) return;

  int feat_idx = threadIdx.y;

  //__shared__ float2 pillarSM[POINTS_PER_PILLAR]; //pillar*64
  // printf("pillar_idx: %d, point_idx: %d\n", pillar_idx, point_idx);
  unsigned int indexIn = pillar_idx * POINTS_PER_PILLAR * FEATURE_SIZE + feat_idx * 2;
  float2 outFeature = *((float2*)(in + indexIn));
  for (int i = 1; i < POINTS_PER_PILLAR; i++) {
    indexIn = pillar_idx * POINTS_PER_PILLAR * FEATURE_SIZE + i * FEATURE_SIZE + feat_idx * 2;
    float2 maxFeature = *((float2*)(in + indexIn));
    outFeature.x = max(outFeature.x, maxFeature.x);
    outFeature.y = max(outFeature.y, maxFeature.y);
  }
  unsigned int indexOut = pillar_idx * FEATURE_SIZE + feat_idx * 2;
  outFeature.x = max(outFeature.x, 0.0);
  outFeature.y = max(outFeature.y, 0.0);
  *((float2*)(out + indexOut)) = outFeature;
}

__global__ void reduceMax_kernel_half(const half* in, half* out, const unsigned int* pillarCount) {
  // int pillar_idx = (blockIdx.x * blockDim.x + threadIdx.x)/POINTS_PER_PILLAR;
  int pillar_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (pillar_idx >= pillarCount[0]) return;

  int feat_idx = threadIdx.y;

  //__shared__ float2 pillarSM[POINTS_PER_PILLAR]; //pillar*64
  // printf("pillar_idx: %d, point_idx: %d\n", pillar_idx, point_idx);
  unsigned int indexIn = pillar_idx * POINTS_PER_PILLAR * FEATURE_SIZE + feat_idx * 2;
  // #if __CUDA_ARCH__ >= 800
  half2 outFeature = *((half2*)(in + indexIn));
  // #else
  // float2 outFeature = __half22float2(*((half2*)(in + indexIn)));
  // #endif
  for (int i = 1; i < POINTS_PER_PILLAR; i++) {
    indexIn = pillar_idx * POINTS_PER_PILLAR * FEATURE_SIZE + i * FEATURE_SIZE + feat_idx * 2;
    half2 maxFeature = *((half2*)(in + indexIn));
#if __CUDA_ARCH__ >= 800
    outFeature = __hmax2(outFeature, maxFeature);
#else
    if (__hge(maxFeature.x, outFeature.x)) outFeature.x = maxFeature.x;
    if (__hge(maxFeature.y, outFeature.y)) outFeature.y = maxFeature.y;
#endif
  }
  unsigned int indexOut = pillar_idx * FEATURE_SIZE + feat_idx * 2;
#if __CUDA_ARCH__ >= 800
  outFeature.x = __hmax(outFeature.x, 0.0);
  outFeature.y = __hmax(outFeature.y, 0.0);
#else
  if (__hge(0.0, outFeature.x)) outFeature.x = 0.0;
  if (__hge(0.0, outFeature.y)) outFeature.y = 0.0;
// outFeature.x = max(outFeature.x, 0.0);
// outFeature.y = max(outFeature.y, 0.0);
// printf("out feat x:%f, y:%f\n", __half2float((*((half2*)(out + indexOut))).x),
//   __half2float((*((half2*)(out + indexOut))).y));
#endif
  *((half2*)(out + indexOut)) = outFeature;
}

cudaError_t reduceMax_kernel_launcher(const float* in,
                                      float* out,
                                      const unsigned int* pillarCount,
                                      unsigned int featureX,
                                      unsigned int featureY,
                                      cudaStream_t stream) {
  // dim3 threads(4*POINTS_PER_PILLAR);
  // dim3 blocks((pillarCount*POINTS_PER_PILLAR+threads.x-1) / threads.x);
  dim3 threads(4, FEATURE_SIZE / 2);
  dim3 blocks((featureX * featureY + 4 - 1) / 4);
  reduceMax_kernel<<<blocks, threads, 0, stream>>>(in, out, pillarCount);

  return cudaGetLastError();
}

cudaError_t reduceMax_kernel_half_launcher(const half* in,
                                           half* out,
                                           const unsigned int* pillarCount,
                                           unsigned int featureX,
                                           unsigned int featureY,
                                           cudaStream_t stream) {
  // dim3 threads(4*POINTS_PER_PILLAR);
  // dim3 blocks((pillarCount*POINTS_PER_PILLAR+threads.x-1) / threads.x);
  dim3 threads(4, FEATURE_SIZE / 2);
  // dim3 blocks((pillarCount + 4 -1)/4);
  dim3 blocks((featureX * featureY + 4 - 1) / 4);
  reduceMax_kernel_half<<<blocks, threads, 0, stream>>>(in, out, pillarCount);

  return cudaGetLastError();
}