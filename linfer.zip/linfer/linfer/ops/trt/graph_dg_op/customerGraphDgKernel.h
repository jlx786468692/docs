

#ifndef CUSTOMER_GRAPH_DG_KERNEL_H
#define CUSTOMER_GRAPH_DG_KERNEL_H

#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cstdint>
#include <vector>

#include "NvInferRuntimeCommon.h"

namespace nvinfer1 {
namespace plugin {

#ifdef __CUDA_ARCH__
#define ASSERT(condition) __assert_fail(condition, __FILE__, __LINE__, __func__)
#else
#define ASSERT(condition) assert(condition)
#endif

// decalre the plugin creator

int32_t customerGraphDgLaunch(const void* input0,
                              const void* input1,
                              void* outputs,
                              cudaStream_t stream);

}  // namespace plugin
}  // namespace nvinfer1

#endif  // CUSTOMER_GRAPH_DG_KERNEL_H