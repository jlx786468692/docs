#include "customerGraphDgPlugin.h"

#include <NvInfer.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace nvinfer1 {
namespace plugin {

PluginFieldCollection CustomerGraphDgPluginCreator::mFC{};
std::vector<PluginField> CustomerGraphDgPluginCreator::mPluginAttributes;

CustomerGraphDgPlugin::CustomerGraphDgPlugin() {}

CustomerGraphDgPlugin::CustomerGraphDgPlugin(const void* serialData, size_t serialLength) {}

char const* CustomerGraphDgPlugin::getPluginType() const noexcept { return CUSTOMER_GRAPH_DG_NAME; }

char const* CustomerGraphDgPlugin::getPluginVersion() const noexcept {
  return CUSTOMER_GRAPH_DG_VERSION;
}

int32_t CustomerGraphDgPlugin::getNbOutputs() const noexcept { return 1; }

DimsExprs CustomerGraphDgPlugin::getOutputDimensions(int32_t outputIndex,
                                                     DimsExprs const* inputs,
                                                     int32_t nbInputs,
                                                     IExprBuilder& exprBuilder) noexcept {
  return inputs[1];
}

bool CustomerGraphDgPlugin::supportsFormatCombination(int32_t pos,
                                                      PluginTensorDesc const* inOut,
                                                      int32_t nbInputs,
                                                      int32_t nbOutputs) noexcept {
  // 1 input and 1 output
  // input.type == output.type
  ASSERT(0 <= pos && pos < 2);
  ASSERT(nbInputs == 1);
  ASSERT(nbOutputs == 1);
  ASSERT(pos < (nbInputs + nbOutputs));
  ASSERT(inOut != nullptr);

  const auto* in = &inOut[0];
  const auto* out = &inOut[1];

  // Verify format is Linear
  bool isFormatOK = (inOut[pos].format == nvinfer1::TensorFormat::kLINEAR);

  // Check data types
  if (pos == 0) {  // Input tensor
    isFormatOK &= (in->type == nvinfer1::DataType::kFLOAT || in->type == nvinfer1::DataType::kHALF);
  } else {                                  // Output tensor
    isFormatOK &= (out->type == in->type);  // Match input type
  }

  return isFormatOK;
}

void CustomerGraphDgPlugin::configurePlugin(DynamicPluginTensorDesc const* in,
                                            int32_t nbInputs,
                                            DynamicPluginTensorDesc const* out,
                                            int32_t nbOutputs) noexcept {}

size_t CustomerGraphDgPlugin::getWorkspaceSize(PluginTensorDesc const* inputs,
                                               int32_t nbInputs,
                                               PluginTensorDesc const* outputs,
                                               int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t CustomerGraphDgPlugin::enqueue(PluginTensorDesc const* inputDesc,
                                       PluginTensorDesc const* outputDesc,
                                       void const* const* inputs,
                                       void* const* outputs,
                                       void* workspace,
                                       cudaStream_t stream) noexcept {
  try {
    customerGraphDgLaunch(inputs[0], inputs[1], outputs[0], stream);
    return 0;
  } catch (std::exception const& e) {
    caughtError(e);
    return -1;
  }
}

size_t CustomerGraphDgPlugin::getSerializationSize() const noexcept { return 0; }

void CustomerGraphDgPlugin::serialize(void* buffer) const noexcept {}

void CustomerGraphDgPlugin::destroy() noexcept { delete this; }

int32_t CustomerGraphDgPlugin::initialize() noexcept { return 0; }

void CustomerGraphDgPlugin::terminate() noexcept {}

void CustomerGraphDgPlugin::setPluginNamespace(char const* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

char const* CustomerGraphDgPlugin::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

DataType CustomerGraphDgPlugin::getOutputDataType(int32_t index,
                                                  nvinfer1::DataType const* inputTypes,
                                                  int32_t nbInputs) const noexcept {
  return inputTypes[1];
}

IPluginV2DynamicExt* CustomerGraphDgPlugin::clone() const noexcept {
  try {
    auto* plugin = new CustomerGraphDgPlugin();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

// Plugin creator
CustomerGraphDgPluginCreator::CustomerGraphDgPluginCreator() {}

IPluginV2DynamicExt* CustomerGraphDgPluginCreator::createPlugin(
    char const* name,
    PluginFieldCollection const* fc) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new CustomerGraphDgPlugin();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

IPluginV2DynamicExt* CustomerGraphDgPluginCreator::deserializePlugin(char const* name,
                                                                     void const* serialData,
                                                                     size_t serialLength) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new CustomerGraphDgPlugin(serialData, serialLength);
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

const char* CustomerGraphDgPluginCreator::getPluginName() const noexcept {
  return CUSTOMER_GRAPH_DG_NAME;
}

const char* CustomerGraphDgPluginCreator::getPluginVersion() const noexcept {
  return CUSTOMER_GRAPH_DG_VERSION;
}

const PluginFieldCollection* CustomerGraphDgPluginCreator::getFieldNames() noexcept { return &mFC; }

void CustomerGraphDgPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mPluginNamespace = libNamespace;
}

const char* CustomerGraphDgPluginCreator::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(CustomerGraphDgPluginCreator);

}  // namespace plugin
}  // namespace nvinfer1