#include <NvInfer.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <iostream>
#include <type_traits>

namespace nvinfer1 {
namespace plugin {

template <typename T>
__global__ void customerKernel(const T* input1, const T* input2, T* output) {}

int customerGraphDgLaunch(const void* input0,
                          const void* input1,
                          void* outputs,
                          cudaStream_t stream) {
  const int block_size = 512;
  const int grid_size = 128;

  customerKernel<half><<<grid_size, block_size, 0, stream>>>(static_cast<const half*>(input0),
                                                             static_cast<const half*>(input1),
                                                             static_cast<__half*>(outputs));
  return 0;
}

}  // namespace plugin
}  // namespace nvinfer1