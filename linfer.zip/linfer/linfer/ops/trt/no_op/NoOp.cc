#include "NoOp.h"

#include <assert.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

using linfer::ops::trt::NoOpPluginCreator;
REGISTER_TENSORRT_PLUGIN(NoOpPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

const char* NOOP_PLUGIN_VERSION{"1"};
static const char* NOOP_PLUGIN_NAME{"LinferNoOp"};

NoOp::NoOp(int num_inputs) { num_inputs_ = num_inputs; }

NoOp::NoOp(const void* serialData, size_t serialLength) {
  deserialize_value(&serialData, &serialLength, &num_inputs_);
}

NoOp::~NoOp() {}

bool NoOp::supportsFormatCombination(int32_t pos,
                                     const nvinfer1::PluginTensorDesc* inOut,
                                     int32_t nbInputs,
                                     int32_t nbOutputs) noexcept {
  int nbTotal = nbInputs + nbOutputs;

  if (pos < nbInputs) {  // 输入
    return (inOut[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else if (pos < nbTotal) {  // 输出
    int inputIndex = pos - nbInputs;
    return (inOut[pos].type == inOut[inputIndex].type) &&
           (inOut[pos].format == inOut[inputIndex].format);
  }
  return true;
}

void NoOp::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                           int32_t nbInputs,
                           const nvinfer1::DynamicPluginTensorDesc* out,
                           int32_t nbOutputs) noexcept {}

size_t NoOp::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                              int32_t nbInputs,
                              const nvinfer1::PluginTensorDesc* outputs,
                              int32_t nbOutputs) const noexcept {
  return 0;
}

int NoOp::initialize() noexcept { return 0; }

void NoOp::terminate() noexcept {}

int32_t NoOp::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                      const nvinfer1::PluginTensorDesc* outputDesc,
                      const void* const* inputs,
                      void* const* outputs,
                      void* workspace,
                      cudaStream_t stream) noexcept {
  // bug: if the format is NOT kLINEAR, the following cudaMemcpyAsync will fail(can run but the
  // result is not correct, why?).
  for (int i = 0; i < num_inputs_; ++i) {
    cudaMemcpyAsync(outputs[i],
                    inputs[i],
                    linfer::util::getNvTensorLenInByte(inputDesc[i]),
                    cudaMemcpyDeviceToDevice,
                    stream);
  }
  return 0;
}

size_t NoOp::getSerializationSize() const noexcept { return sizeof(int); }

void NoOp::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int>(buf, num_inputs_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* NoOp::getPluginType() const noexcept { return NOOP_PLUGIN_NAME; }

const char* NoOp::getPluginVersion() const noexcept { return NOOP_PLUGIN_VERSION; }

void NoOp::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* NoOp::clone() const noexcept {
  auto plugin = new NoOp(num_inputs_);
  plugin->setPluginNamespace(pluginNamespace_.c_str());
  return plugin;
}

void NoOp::setPluginNamespace(const char* pluginNamespace) noexcept {
  pluginNamespace_ = pluginNamespace;
}

const char* NoOp::getPluginNamespace() const noexcept { return pluginNamespace_.c_str(); }

int NoOp::getNbOutputs() const noexcept { return num_inputs_; }

nvinfer1::DimsExprs NoOp::getOutputDimensions(int32_t outputIndex,
                                              const nvinfer1::DimsExprs* inputs,
                                              int32_t nbInputs,
                                              nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[outputIndex];
}

nvinfer1::DataType NoOp::getOutputDataType(int index,
                                           const nvinfer1::DataType* inputTypes,
                                           int nbInputs) const noexcept {
  return inputTypes[index];
}

void NoOp::attachToContext(cudnnContext* cudnnContext,
                           cublasContext* cublasContext,
                           nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void NoOp::detachFromContext() noexcept {}

nvinfer1::PluginFieldCollection NoOpPluginCreator::mFC{};

NoOpPluginCreator::NoOpPluginCreator() {
  PluginAttributes_.emplace_back(
      nvinfer1::PluginField{"num_inputs", nullptr, nvinfer1::PluginFieldType::kINT32, 2});
  mFC.nbFields = PluginAttributes_.size();
  mFC.fields = PluginAttributes_.data();
}
const char* NoOpPluginCreator::getPluginVersion() const noexcept { return NOOP_PLUGIN_VERSION; }
const char* NoOpPluginCreator::getPluginName() const noexcept { return NOOP_PLUGIN_NAME; }
const nvinfer1::PluginFieldCollection* NoOpPluginCreator::getFieldNames() noexcept {
  return &NoOpPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* NoOpPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int num_inputs = 1;
  for (int i = 0; i < fc->nbFields; ++i) {
    const auto& field = fc->fields[i];
    if (strcmp(field.name, "num_inputs") == 0) {
      num_inputs = *static_cast<const int*>(field.data);
    }
  }
  auto* obj = new NoOp(num_inputs);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* NoOpPluginCreator::deserializePlugin(const char* name,
                                                             const void* serialData,
                                                             size_t serialLength) noexcept {
  auto obj = new NoOp(serialData, serialLength);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void NoOpPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* NoOpPluginCreator::getPluginNamespace() const noexcept { return namespace_.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
