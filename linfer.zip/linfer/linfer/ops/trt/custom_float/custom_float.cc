#include "custom_float.h"

#include <assert.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

using linfer::ops::trt::CustomFloatPluginCreator;
REGISTER_TENSORRT_PLUGIN(CustomFloatPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

const char* CUSTOM_FLOAT_PLUGIN_VERSION{"1"};
static const char* CUSTOM_FLOAT_PLUGIN_NAME{"LinferCustomFloat"};

CustomFloat::CustomFloat() {}

CustomFloat::~CustomFloat() {}

bool CustomFloat::supportsFormatCombination(int32_t pos,
                                            const nvinfer1::PluginTensorDesc* inOut,
                                            int32_t nbInputs,
                                            int32_t nbOutputs) noexcept {
  if (0 == pos) {  // input
    return (inOut[pos].type == nvinfer1::DataType::kFLOAT &&
            inOut[0].format == nvinfer1::TensorFormat::kLINEAR);
  } else if (1 == pos) {  // output
    return (inOut[1].type == inOut[0].type) && (inOut[1].format == inOut[0].format);
  } else {
    std::cerr << "Error: CustomFloat only support 1 input and 1 output" << std::endl;
    std::terminate();
  }
  return true;
}

void CustomFloat::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                  int32_t nbInputs,
                                  const nvinfer1::DynamicPluginTensorDesc* out,
                                  int32_t nbOutputs) noexcept {}

size_t CustomFloat::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                     int32_t nbInputs,
                                     const nvinfer1::PluginTensorDesc* outputs,
                                     int32_t nbOutputs) const noexcept {
  return 0;
}

int CustomFloat::initialize() noexcept { return 0; }

void CustomFloat::terminate() noexcept {}

int32_t CustomFloat::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                             const nvinfer1::PluginTensorDesc* outputDesc,
                             const void* const* inputs,
                             void* const* outputs,
                             void* workspace,
                             cudaStream_t stream) noexcept {
  cudaMemcpyAsync(outputs[0],
                  inputs[0],
                  linfer::util::getNvTensorLenInByte(inputDesc[0]),
                  cudaMemcpyDeviceToDevice,
                  stream);
  return 0;
}

size_t CustomFloat::getSerializationSize() const noexcept { return 0; }

void CustomFloat::serialize(void* buffer) const noexcept { return; }

const char* CustomFloat::getPluginType() const noexcept { return CUSTOM_FLOAT_PLUGIN_NAME; }

const char* CustomFloat::getPluginVersion() const noexcept { return CUSTOM_FLOAT_PLUGIN_VERSION; }

void CustomFloat::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* CustomFloat::clone() const noexcept {
  auto plugin = new CustomFloat();
  plugin->setPluginNamespace(pluginNamespace_.c_str());
  return plugin;
}

void CustomFloat::setPluginNamespace(const char* pluginNamespace) noexcept {
  pluginNamespace_ = pluginNamespace;
}

const char* CustomFloat::getPluginNamespace() const noexcept { return pluginNamespace_.c_str(); }

int CustomFloat::getNbOutputs() const noexcept { return 1; }

nvinfer1::DimsExprs CustomFloat::getOutputDimensions(int32_t outputIndex,
                                                     const nvinfer1::DimsExprs* inputs,
                                                     int32_t nbInputs,
                                                     nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[0];
}

nvinfer1::DataType CustomFloat::getOutputDataType(int index,
                                                  const nvinfer1::DataType* inputTypes,
                                                  int nbInputs) const noexcept {
  return inputTypes[0];
}

void CustomFloat::attachToContext(cudnnContext* cudnnContext,
                                  cublasContext* cublasContext,
                                  nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void CustomFloat::detachFromContext() noexcept {}

nvinfer1::PluginFieldCollection CustomFloatPluginCreator::mFC{};

CustomFloatPluginCreator::CustomFloatPluginCreator() {
  pluginName_ = CUSTOM_FLOAT_PLUGIN_NAME;
  mFC.nbFields = PluginAttributes_.size();
  mFC.fields = PluginAttributes_.data();
}
const char* CustomFloatPluginCreator::getPluginVersion() const noexcept {
  return CUSTOM_FLOAT_PLUGIN_VERSION;
}
const char* CustomFloatPluginCreator::getPluginName() const noexcept { return pluginName_.c_str(); }
const nvinfer1::PluginFieldCollection* CustomFloatPluginCreator::getFieldNames() noexcept {
  return &CustomFloatPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* CustomFloatPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  auto obj = new CustomFloat();
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* CustomFloatPluginCreator::deserializePlugin(const char* name,
                                                                    const void* serialData,
                                                                    size_t serialLength) noexcept {
  auto obj = new CustomFloat();
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void CustomFloatPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* CustomFloatPluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
