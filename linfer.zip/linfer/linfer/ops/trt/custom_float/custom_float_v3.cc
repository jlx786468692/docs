#include "custom_float_v3.h"

#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

using linfer::ops::trt::CustomFloatPluginV3Creator;
REGISTER_TENSORRT_PLUGIN(CustomFloatPluginV3Creator);

namespace linfer {
namespace ops {
namespace trt {

constexpr char const* CUSTOM_FLOAT_PLUGINV3_VERSION{"1"};
constexpr char const* CUSTOM_FLOAT_PLUGINV3_NAME{"LinferCustomFloatV3"};

nvinfer1::PluginFieldCollection CustomFloatPluginV3Creator::mFC{};
std::vector<nvinfer1::PluginField> CustomFloatPluginV3Creator::mPluginAttributes;

CustomFloatPluginV3::CustomFloatPluginV3() {}

nvinfer1::IPluginCapability* CustomFloatPluginV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* CustomFloatPluginV3::getPluginName() const noexcept {
  return CUSTOM_FLOAT_PLUGINV3_NAME;
}

char const* CustomFloatPluginV3::getPluginVersion() const noexcept {
  return CUSTOM_FLOAT_PLUGINV3_VERSION;
}

int32_t CustomFloatPluginV3::getNbOutputs() const noexcept { return 1; }

void CustomFloatPluginV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* CustomFloatPluginV3::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

nvinfer1::IPluginV3* CustomFloatPluginV3::clone() noexcept {
  try {
    auto* plugin = new CustomFloatPluginV3();
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t CustomFloatPluginV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                                int32_t nbOutputs,
                                                nvinfer1::DataType const* inputTypes,
                                                int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t CustomFloatPluginV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                             int32_t nbInputs,
                                             nvinfer1::DimsExprs const* shapeInputs,
                                             int32_t nbShapeInputs,
                                             nvinfer1::DimsExprs* outputs,
                                             int32_t nbOutputs,
                                             nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    // Output shape is the same as input shape
    for (int i = 0; i < nbOutputs; i++) {
      outputs[i] = inputs[0];
    }
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool CustomFloatPluginV3::supportsFormatCombination(int32_t pos,
                                                    nvinfer1::DynamicPluginTensorDesc const* inOut,
                                                    int32_t nbInputs,
                                                    int32_t nbOutputs) noexcept {
  try {
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;

    if (pos == 0) {  // Input
      return (desc.type == nvinfer1::DataType::kFLOAT &&
              desc.format == nvinfer1::TensorFormat::kLINEAR);
    } else if (pos == 1) {  // Output
      return (desc.type == inOut[0].desc.type && desc.format == inOut[0].desc.format);
    }

    return false;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t CustomFloatPluginV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                             int32_t nbInputs,
                                             nvinfer1::DynamicPluginTensorDesc const* out,
                                             int32_t nbOutputs) noexcept {
  try {
    // Validate input arguments
    PLUGIN_ASSERT(nbInputs == 1);
    PLUGIN_ASSERT(nbOutputs == 1);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const* CustomFloatPluginV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    // This plugin has no fields to serialize
    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t CustomFloatPluginV3::getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                                             int32_t nbInputs,
                                             nvinfer1::DynamicPluginTensorDesc const* outputs,
                                             int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t CustomFloatPluginV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::PluginTensorDesc const* outputs,
                                           int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* CustomFloatPluginV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t CustomFloatPluginV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                                     nvinfer1::PluginTensorDesc const* outputDesc,
                                     void const* const* inputs,
                                     void* const* outputs,
                                     void* workspace,
                                     cudaStream_t stream) noexcept {
  try {
    cudaMemcpyAsync(outputs[0],
                    inputs[0],
                    linfer::util::getNvTensorLenInByte(inputDesc[0]),
                    cudaMemcpyDeviceToDevice,
                    stream);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

std::shared_ptr<linfer::util::TrtModelInferEngine> CustomFloatPluginV3::get_active_engine(void) {
  // This function is kept for compatibility
  return nullptr;
}

// Plugin Creator Implementation
CustomFloatPluginV3Creator::CustomFloatPluginV3Creator() {
  mPluginAttributes.clear();
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* CustomFloatPluginV3Creator::getPluginName() const noexcept {
  return CUSTOM_FLOAT_PLUGINV3_NAME;
}

char const* CustomFloatPluginV3Creator::getPluginVersion() const noexcept {
  return CUSTOM_FLOAT_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const* CustomFloatPluginV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* CustomFloatPluginV3Creator::createPlugin(
    char const* name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  try {
    // This plugin doesn't have any configurable parameters
    auto* plugin = new CustomFloatPluginV3();
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void CustomFloatPluginV3Creator::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* CustomFloatPluginV3Creator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer