#include <cuda_fp16.h>

#include <cstdint>
#include <vector>

#ifndef SCATTER_MAX_KERNEL_H
#define SCATTER_MAX_KERNEL_H

void scatter_max_launch(float* out,
                        const float* src,
                        const int32_t* index,
                        int32_t dim,
                        const std::vector<int32_t>& src_size,
                        const std::vector<int32_t>& out_size);

void scatter_max_launch(half* out,
                        const half* src,
                        const int32_t* index,
                        int32_t dim,
                        const std::vector<int32_t>& src_size,
                        const std::vector<int32_t>& out_size);

#endif  // SCATTER_MAX_KERNEL_H