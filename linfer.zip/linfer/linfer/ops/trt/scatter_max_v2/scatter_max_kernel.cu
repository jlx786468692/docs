#include <cuda_fp16.h>

#include <cstdint>
#include <limits>
#include <numeric>
#include <string>
#include <tuple>
#include <type_traits>
#include <vector>

#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/log.h"

#define THREADS 256
#define BLOCKS(N) (N + THREADS - 1) / THREADS

// ============================================
// 简化的原子操作实现
// ============================================

// half类型的原子最大值操作
static inline __device__ void atomMax(half* address, half val) {
  // 对于half类型，使用32位atomicCAS
  unsigned int* address_as_ui = (unsigned int*)((char*)address - ((size_t)address & 2));
  unsigned int old = *address_as_ui;
  unsigned int assumed;
  unsigned int new_val;

  do {
    assumed = old;
    // 提取当前的half值
    half old_half =
        (size_t)address & 2 ? __ushort_as_half(old >> 16) : __ushort_as_half(old & 0xffff);
    // 计算最大值
    half max_half = val >= old_half ? val : old_half;
    unsigned short max_ushort = __half_as_ushort(max_half);

    // 构建新的32位值
    if ((size_t)address & 2)
      new_val = (old & 0xffff) | (max_ushort << 16);
    else
      new_val = (old & 0xffff0000) | max_ushort;

    old = atomicCAS(address_as_ui, assumed, new_val);
  } while (assumed != old);
}

// float类型的原子最大值操作
static inline __device__ void atomMax(float* address, float val) {
  int* address_as_i = (int*)address;
  int old = *address_as_i;
  int assumed;

  do {
    assumed = old;
    float old_float = __int_as_float(old);
    // 计算最大值
    float max_val = val >= old_float ? val : old_float;
    old = atomicCAS(address_as_i, assumed, __float_as_int(max_val));
  } while (assumed != old);
}

// ============================================
// MAX初始化逻辑
// ============================================

template <typename scalar_t>
inline __host__ __device__ scalar_t scatter_max_init() {
  if (std::is_same<scalar_t, half>::value) {
    half min_val;
    *(reinterpret_cast<unsigned short*>(&(min_val))) = 0xFC00;  // half最小值
    return min_val;
  } else if (std::is_same<scalar_t, float>::value) {
    // 对于float，返回负无穷大
    // 使用位模式直接构造-INF
    union {
      float f;
      uint32_t i;
    } u;
    u.i = 0xff800000;  // -INF的位模式
    return u.f;
  } else {
    // 默认返回0
    return (scalar_t)0;
  }
}

// ============================================
// scatter_max核心实现
// ============================================

template <typename scalar_t>
__global__ void scatter_max_kernel(const scalar_t* src,
                                   int32_t src_numel,
                                   const int32_t* index,
                                   scalar_t* out,
                                   int32_t E,
                                   int32_t K,
                                   int32_t N) {
  int thread_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (thread_idx >= src_numel) return;

  int b = thread_idx / (E * K);
  int k = thread_idx % K;
  int idx = index[thread_idx / K];

  scalar_t reduce_val = src != nullptr ? src[thread_idx] : (scalar_t)1;
  atomMax(out + b * N * K + idx * K + k, reduce_val);
}

template <typename scalar_t>
__global__ void fill_kernel(scalar_t* data, int32_t numel, scalar_t value) {
  int thread_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (thread_idx >= numel) return;
  data[thread_idx] = value;
}

template <typename scalar_t>
__global__ void replace_kernel(scalar_t* data, int32_t numel, scalar_t old_val, scalar_t new_val) {
  int thread_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (thread_idx >= numel) return;
  if (data[thread_idx] == old_val) data[thread_idx] = new_val;
}

// ============================================
// scatter_max主函数
// ============================================
void scatter_max_launch(float* out,
                        const float* src,
                        const int32_t* index,
                        int32_t dim,
                        const std::vector<int32_t>& src_size,
                        const std::vector<int32_t>& out_size) {
  dim = dim < 0 ? dim + src_size.size() : dim;

  // 计算元素总数
  auto _mul = [](int a, int b) { return a * b; };
  auto src_numel = std::accumulate(src_size.begin(), src_size.end(), 1, _mul);
  auto out_numel = std::accumulate(out_size.begin(), out_size.end(), 1, _mul);

  // 初始化输出为最小值
  fill_kernel<float><<<BLOCKS(out_numel), THREADS, 0>>>(out, out_numel, scatter_max_init<float>());

  // 计算维度
  auto B = 1;
  for (auto i = 0; i < dim; i++) B *= src_size[i];
  auto E = src_size[dim];
  auto K = src_numel / (B * E);
  auto N = out_size[dim];

  // 执行scatter_max
  scatter_max_kernel<float><<<BLOCKS(src_numel), THREADS, 0>>>(src, src_numel, index, out, E, K, N);

  // 替换初始化值（MAX操作需要将初始化值替换为0）
  replace_kernel<float>
      <<<BLOCKS(out_numel), THREADS, 0>>>(out, out_numel, scatter_max_init<float>(), (float)0);

  CHECK_CUDA_STATUS("scatter_max_launch float");
}

void scatter_max_launch(half* out,
                        const half* src,
                        const int32_t* index,
                        int32_t dim,
                        const std::vector<int32_t>& src_size,
                        const std::vector<int32_t>& out_size) {
  dim = dim < 0 ? dim + src_size.size() : dim;

  // 计算元素总数
  auto _mul = [](int a, int b) { return a * b; };
  auto src_numel = std::accumulate(src_size.begin(), src_size.end(), 1, _mul);
  auto out_numel = std::accumulate(out_size.begin(), out_size.end(), 1, _mul);

  // 初始化输出为最小值
  fill_kernel<half><<<BLOCKS(out_numel), THREADS, 0>>>(out, out_numel, scatter_max_init<half>());

  // 计算维度
  auto B = 1;
  for (auto i = 0; i < dim; i++) B *= src_size[i];
  auto E = src_size[dim];
  auto K = src_numel / (B * E);
  auto N = out_size[dim];

  // 执行scatter_max
  scatter_max_kernel<half><<<BLOCKS(src_numel), THREADS, 0>>>(src, src_numel, index, out, E, K, N);

  // 替换初始化值（MAX操作需要将初始化值替换为0）
  replace_kernel<half>
      <<<BLOCKS(out_numel), THREADS, 0>>>(out, out_numel, scatter_max_init<half>(), (half)0);

  CHECK_CUDA_STATUS("scatter_max_launch half");
}