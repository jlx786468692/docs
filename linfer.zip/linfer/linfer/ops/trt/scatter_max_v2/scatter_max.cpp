// Copyright (c) OpenMMLab. All rights reserved.
#include "scatter_max.h"

#include <assert.h>

#include <chrono>

#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "scatter_max_kernel.h"

namespace linfer {
namespace {
static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"LinferScatterMax"};
}  // namespace

ScatterMax::ScatterMax(const std::string& name, int dim, int dim_size)
    : TRTPluginBase(name), dim_(dim), dim_size_(dim_size) {}

ScatterMax::ScatterMax(const std::string& name, const void* data, size_t length)
    : TRTPluginBase(name) {
  deserialize_value(&data, &length, &dim_);
  deserialize_value(&data, &length, &dim_size_);
}

nvinfer1::IPluginV2DynamicExt* ScatterMax::clone() const TRT_NOEXCEPT {
  ScatterMax* plugin = new ScatterMax(mLayerName, dim_, dim_size_);
  plugin->setPluginNamespace(getPluginNamespace());

  return plugin;
}

nvinfer1::DimsExprs ScatterMax::getOutputDimensions(int outputIndex,
                                                    const nvinfer1::DimsExprs* inputs,
                                                    int nbInputs,
                                                    nvinfer1::IExprBuilder& exprBuilder)
    TRT_NOEXCEPT {
  nvinfer1::DimsExprs output;

  output.nbDims = inputs[0].nbDims;

  auto index_dim = dim_ < 0 ? inputs[0].nbDims + dim_ : dim_;
  for (auto i = 0; i < inputs[0].nbDims; i++)
    if (i == index_dim)
      output.d[i] = exprBuilder.constant(dim_size_);
    else
      output.d[i] = inputs[0].d[i];

  return output;
}

bool ScatterMax::supportsFormatCombination(int pos,
                                           const nvinfer1::PluginTensorDesc* ioDesc,
                                           int nbInputs,
                                           int nbOutputs) TRT_NOEXCEPT {
  const nvinfer1::PluginTensorDesc desc = ioDesc[pos];

  if (desc.format != nvinfer1::TensorFormat::kLINEAR) return false;

  if (pos == 0)  // src
    return desc.type == nvinfer1::DataType::kFLOAT || desc.type == nvinfer1::DataType::kHALF;
  if (pos == 1)  // index
    return desc.type == nvinfer1::DataType::kINT32;
  if (pos == 2) return desc.type == ioDesc[0].type;
  return false;
}

void ScatterMax::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                 int nbInputs,
                                 const nvinfer1::DynamicPluginTensorDesc* outputs,
                                 int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
  ASSERT(nbOutputs == 1);
  const auto& src_dims = inputs[0].desc.dims;
  src_dims_.assign(src_dims.d, src_dims.d + src_dims.nbDims);

  const auto& out_dims = outputs[0].desc.dims;
  out_dims_.assign(out_dims.d, out_dims.d + out_dims.nbDims);
}

size_t ScatterMax::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                    int nbInputs,
                                    const nvinfer1::PluginTensorDesc* outputs,
                                    int nbOutputs) const TRT_NOEXCEPT {
  return 0;
}

int ScatterMax::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                        const nvinfer1::PluginTensorDesc* outputDesc,
                        const void* const* inputs,
                        void* const* outputs,
                        void* workSpace,
                        cudaStream_t stream) TRT_NOEXCEPT {
  auto data_type = inputDesc[0].type;
  switch (data_type) {
    case nvinfer1::DataType::kFLOAT:
      scatter_max_launch((float*)outputs[0],
                         (const float*)inputs[0],
                         (const int32_t*)inputs[1],
                         dim_,
                         src_dims_,
                         out_dims_);
      break;

    case nvinfer1::DataType::kHALF:
      scatter_max_launch((half*)outputs[0],
                         (const half*)inputs[0],
                         (const int32_t*)inputs[1],
                         dim_,
                         src_dims_,
                         out_dims_);
      break;
    default:
      return 1;
      break;
  }
  return 0;
}

nvinfer1::DataType ScatterMax::getOutputDataType(int index,
                                                 const nvinfer1::DataType* inputTypes,
                                                 int nbInputs) const TRT_NOEXCEPT {
  return inputTypes[0];
}

// IPluginV2 Methods
const char* ScatterMax::getPluginType() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* ScatterMax::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

int ScatterMax::getNbOutputs() const TRT_NOEXCEPT { return 1; }

size_t ScatterMax::getSerializationSize() const TRT_NOEXCEPT { return sizeof(int) + sizeof(int); }

void ScatterMax::serialize(void* buffer) const TRT_NOEXCEPT {
  serialize_value(&buffer, dim_);
  serialize_value(&buffer, dim_size_);
}

////////////////////// creator /////////////////////////////

ScatterMaxCreator::ScatterMaxCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("dim", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("dim_size", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* ScatterMaxCreator::getPluginName() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* ScatterMaxCreator::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

nvinfer1::IPluginV2* ScatterMaxCreator::createPlugin(const char* name,
                                                     const nvinfer1::PluginFieldCollection* fc)
    TRT_NOEXCEPT {
  int dim = 0;
  int dim_size = 0;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    const auto* field = &fc->fields[i];
    const char* field_name = field->name;
    if (strcmp(field_name, "dim") == 0) {
      if (field->data) {
        dim = *static_cast<const int32_t*>(field->data);
      }

    } else if (strcmp(field_name, "dim_size") == 0) {
      if (field->data) {
        dim_size = *static_cast<const int32_t*>(field->data);
      }
    }
  }

  ScatterMax* plugin = new ScatterMax(name, dim, dim_size);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

nvinfer1::IPluginV2* ScatterMaxCreator::deserializePlugin(const char* name,
                                                          const void* serialData,
                                                          size_t serialLength) TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call FCPluginDynamic::destroy()
  auto plugin = new ScatterMax(name, serialData, serialLength);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(ScatterMaxCreator);
}  // namespace linfer
