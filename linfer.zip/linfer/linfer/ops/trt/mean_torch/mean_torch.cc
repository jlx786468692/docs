#include "mean_torch.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "torch/torch.h"

using linfer::ops::trt::MeanTorchPluginCreator;
REGISTER_TENSORRT_PLUGIN(MeanTorchPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

enum INOUT_POS {
  input = 0,
  output_base = 1,
  output_base_input = output_base,
  output = output_base_input - output_base,
};

const char* MEAN_TORCH_PLUGIN_VERSION{"1"};
static const char* MEAN_TORCH_PLUGIN_NAME{"LinferReduceMeanTorch"};

nvinfer1::PluginFieldCollection MeanTorchPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> MeanTorchPluginCreator::mPluginAttributes;

MeanTorch::MeanTorch(int axis, int keepdim) : axis_(axis), keepdim_(keepdim) {}

MeanTorch::~MeanTorch() {}

int MeanTorch::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType MeanTorch::getOutputDataType(int index,
                                                const nvinfer1::DataType* inputTypes,
                                                int nbInputs) const noexcept {
  return inputTypes[INOUT_POS::input];
}

nvinfer1::DimsExprs MeanTorch::getOutputDimensions(int32_t outputIndex,
                                                   const nvinfer1::DimsExprs* inputs,
                                                   int32_t nbInputs,
                                                   nvinfer1::IExprBuilder& exprBuilder) noexcept {
  auto input_dim = inputs[INOUT_POS::input];
  if (!((axis_ >= 0 && axis_ < input_dim.nbDims) || (axis_ < 0 && axis_ >= -input_dim.nbDims))) {
    LERROR_FMT("axis is out of range, axis: %d, nbDims: %d", axis_, input_dim.nbDims);
  }
  auto axis = (axis_ < 0) ? (input_dim.nbDims + axis_) : axis_;
  if (keepdim_) {
    nvinfer1::DimsExprs output_dims = input_dim;
    output_dims.d[axis] = exprBuilder.constant(1);
    return output_dims;
  } else {
    nvinfer1::DimsExprs output_dims;
    output_dims.nbDims = input_dim.nbDims - 1;
    for (int i = 0; i < axis; i++) {
      output_dims.d[i] = input_dim.d[i];
    }

    for (int i = axis; i < input_dim.nbDims - 1; i++) {
      output_dims.d[i] = input_dim.d[i + 1];
    }

    return output_dims;
  }
}

bool MeanTorch::supportsFormatCombination(int32_t pos,
                                          const nvinfer1::PluginTensorDesc* inOut,
                                          int32_t nbInputs,
                                          int32_t nbOutputs) noexcept {
  auto dtype = inOut[pos].type;
  auto dformat = inOut[pos].format;

  switch (pos) {
    case INOUT_POS::input:
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF ||
              dtype == nvinfer1::DataType::kBF16) &&
             dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::output_base_input:
      return dtype == inOut[INOUT_POS::input].type && dformat == inOut[INOUT_POS::input].format;
    default:
      return false;
  }
}

void MeanTorch::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                int32_t nbInputs,
                                const nvinfer1::DynamicPluginTensorDesc* out,
                                int32_t nbOutputs) noexcept {}

size_t MeanTorch::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                   int32_t nbInputs,
                                   const nvinfer1::PluginTensorDesc* outputs,
                                   int32_t nbOutputs) const noexcept {
  return 0;
}

int MeanTorch::initialize() noexcept { return 0; }

void MeanTorch::terminate() noexcept {}

int32_t MeanTorch::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                           const nvinfer1::PluginTensorDesc* outputDesc,
                           const void* const* inputs,
                           void* const* outputs,
                           void* workspace,
                           cudaStream_t stream) noexcept {
  const void* input_ptr = inputs[INOUT_POS::input];
  auto& in_desc = inputDesc[INOUT_POS::input];

  std::vector<int64_t> in_shape(in_desc.dims.d, in_desc.dims.d + in_desc.dims.nbDims);

  torch::Tensor t;
  torch::Tensor mean_t;

  auto options = torch::TensorOptions().device(torch::kCUDA);
  switch (in_desc.type) {
    case nvinfer1::DataType::kFLOAT: {
      t = torch::from_blob((float*)input_ptr, in_shape, options);
      mean_t = t.mean(axis_, keepdim_);
      break;
    }
    case nvinfer1::DataType::kHALF: {
      t = torch::from_blob((at::Half*)input_ptr, in_shape, options);
      mean_t = t.mean(axis_, keepdim_);
      break;
    }
    case nvinfer1::DataType::kBF16: {
      t = torch::from_blob((at::BFloat16*)input_ptr, in_shape, options);
      mean_t = t.mean(axis_, keepdim_);
      break;
    }
  }

  size_t bytes = mean_t.nbytes();
  cudaMemcpyAsync(outputs[INOUT_POS::output],
                  mean_t.data_ptr(),
                  bytes,
                  cudaMemcpyDeviceToDevice,
                  stream);

  return 0;
}

size_t MeanTorch::getSerializationSize() const noexcept {
  // int axis_, keepdim_;
  return sizeof(int) * 2;
}

void MeanTorch::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int>(buf, axis_);
  write<int>(buf, keepdim_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* MeanTorch::getPluginType() const noexcept { return MEAN_TORCH_PLUGIN_NAME; }

const char* MeanTorch::getPluginVersion() const noexcept { return MEAN_TORCH_PLUGIN_VERSION; }

void MeanTorch::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* MeanTorch::clone() const noexcept {
  auto plugin = new MeanTorch(axis_, keepdim_);
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void MeanTorch::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* MeanTorch::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void MeanTorch::attachToContext(cudnnContext* cudnnContext,
                                cublasContext* cublasContext,
                                nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void MeanTorch::detachFromContext() noexcept {}

MeanTorchPluginCreator::MeanTorchPluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("axis", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("keepdim", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* MeanTorchPluginCreator::getPluginVersion() const noexcept {
  return MEAN_TORCH_PLUGIN_VERSION;
}
const char* MeanTorchPluginCreator::getPluginName() const noexcept {
  return MEAN_TORCH_PLUGIN_NAME;
}
const nvinfer1::PluginFieldCollection* MeanTorchPluginCreator::getFieldNames() noexcept {
  return &MeanTorchPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* MeanTorchPluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int axis, keepdim;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("axis") == 0) {
      axis = *static_cast<const int32_t*>(field_data);
    } else if (field_name.compare("keepdim") == 0) {
      keepdim = *static_cast<const int32_t*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }
  LINFO_FMT("axis: %d, keepdim: %d\n", axis, keepdim);

  MeanTorch* obj = new MeanTorch(axis, keepdim);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* MeanTorchPluginCreator::deserializePlugin(const char* plugin_name,
                                                                  const void* serialData,
                                                                  size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;
  auto axis = read<int>(buf);
  auto keepdim = read<int>(buf);

  LINFO_FMT("axis: %d, keepdim: %d\n", axis, keepdim);
  auto obj = new MeanTorch(axis, keepdim);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void MeanTorchPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* MeanTorchPluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
