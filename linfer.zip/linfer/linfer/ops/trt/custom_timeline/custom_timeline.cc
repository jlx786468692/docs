#include "custom_timeline.h"

#include <assert.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/cuda/nvtx.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

using linfer::ops::trt::CustomTimelinePluginCreator;
REGISTER_TENSORRT_PLUGIN(CustomTimelinePluginCreator);

namespace linfer {
namespace ops {
namespace trt {

const char* CUSTOM_TIMELINE_PLUGIN_VERSION{"1"};
static const char* CUSTOM_TIMELINE_PLUGIN_NAME{"LinferCustomTimeline"};

nvinfer1::PluginFieldCollection CustomTimelinePluginCreator::mFC{};
std::vector<nvinfer1::PluginField> CustomTimelinePluginCreator::mPluginAttributes;

CustomTimeline::CustomTimeline(int32_t num_input,
                               const std::string& name,
                               NVTXMode mode,
                               uint32_t color_argb,
                               int32_t cuda_sync)
    : num_input_(num_input),
      name_(name),
      mode_(mode),
      color_argb_(color_argb),
      cuda_sync_(cuda_sync) {}

CustomTimeline::~CustomTimeline() {}

int CustomTimeline::getNbOutputs() const noexcept { return num_input_; }

nvinfer1::DataType CustomTimeline::getOutputDataType(int index,
                                                     const nvinfer1::DataType* inputTypes,
                                                     int nbInputs) const noexcept {
  return inputTypes[index];
}

nvinfer1::DimsExprs CustomTimeline::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[outputIndex];
}

bool CustomTimeline::supportsFormatCombination(int32_t pos,
                                               const nvinfer1::PluginTensorDesc* inOut,
                                               int32_t nbInputs,
                                               int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];

  if (pos < nbInputs) {
    return (desc.type == nvinfer1::DataType::kFLOAT || desc.type == nvinfer1::DataType::kINT32 ||
            desc.type == nvinfer1::DataType::kHALF || desc.type == nvinfer1::DataType::kINT8);
  } else {  // output
    return (desc.type == inOut[pos - nbInputs].type) &&
           (desc.format == inOut[pos - nbInputs].format);
  }
}

void CustomTimeline::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                     int32_t nbInputs,
                                     const nvinfer1::DynamicPluginTensorDesc* out,
                                     int32_t nbOutputs) noexcept {}

size_t CustomTimeline::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                        int32_t nbInputs,
                                        const nvinfer1::PluginTensorDesc* outputs,
                                        int32_t nbOutputs) const noexcept {
  return 0;
}

int CustomTimeline::initialize() noexcept { return 0; }

void CustomTimeline::terminate() noexcept {}

int32_t CustomTimeline::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                const nvinfer1::PluginTensorDesc* outputDesc,
                                const void* const* inputs,
                                void* const* outputs,
                                void* workspace,
                                cudaStream_t stream) noexcept {
  if (mode_ == NVTXMode::POP) {
    if (1 == cuda_sync_) {
      cudaStreamSynchronize(stream);
    }
    linfer::util::nvtx_pop();
  }

  for (auto idx = 0; idx < num_input_; ++idx) {
    cudaMemcpyAsync(outputs[idx],
                    inputs[idx],
                    linfer::util::getNvTensorLenInByte(inputDesc[idx]),
                    cudaMemcpyDeviceToDevice,
                    stream);
  }

  if (mode_ == NVTXMode::PUSH) {
    if (1 == cuda_sync_) {
      cudaStreamSynchronize(stream);
    }
    linfer::util::nvtx_push(name_, static_cast<linfer::util::NvtxColor>(color_argb_));
  }
  return 0;
}

size_t CustomTimeline::getSerializationSize() const noexcept {
  return sizeof(int32_t) + sizeof(size_t) + name_.size() + sizeof(int32_t) + sizeof(uint32_t) +
         sizeof(int32_t);
}

void CustomTimeline::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int32_t>(buf, static_cast<int32_t>(num_input_));
  size_t name_len = name_.size();
  write<size_t>(buf, name_len);
  memcpy(buf, name_.data(), name_len);
  buf += name_len;
  write<int32_t>(buf, static_cast<int32_t>(mode_));
  write<uint32_t>(buf, color_argb_);
  write<int32_t>(buf, cuda_sync_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* CustomTimeline::getPluginType() const noexcept { return CUSTOM_TIMELINE_PLUGIN_NAME; }

const char* CustomTimeline::getPluginVersion() const noexcept {
  return CUSTOM_TIMELINE_PLUGIN_VERSION;
}

void CustomTimeline::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* CustomTimeline::clone() const noexcept {
  auto plugin = new CustomTimeline(num_input_, name_, mode_, color_argb_, cuda_sync_);
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void CustomTimeline::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* CustomTimeline::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void CustomTimeline::attachToContext(cudnnContext* cudnnContext,
                                     cublasContext* cublasContext,
                                     nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void CustomTimeline::detachFromContext() noexcept {}

CustomTimelinePluginCreator::CustomTimelinePluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back("num_input", nullptr, nvinfer1::PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("name", nullptr, nvinfer1::PluginFieldType::kCHAR, 1);
  mPluginAttributes.emplace_back("mode", nullptr, nvinfer1::PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("color_rgb", nullptr, nvinfer1::PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("cuda_sync", nullptr, nvinfer1::PluginFieldType::kINT32, 1);
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* CustomTimelinePluginCreator::getPluginVersion() const noexcept {
  return CUSTOM_TIMELINE_PLUGIN_VERSION;
}
const char* CustomTimelinePluginCreator::getPluginName() const noexcept {
  return CUSTOM_TIMELINE_PLUGIN_NAME;
}
const nvinfer1::PluginFieldCollection* CustomTimelinePluginCreator::getFieldNames() noexcept {
  return &CustomTimelinePluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* CustomTimelinePluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int32_t num_input, cuda_sync;
  std::string name;
  NVTXMode mode;
  uint32_t color_argb;

  LASSERT_MSG(fc->nbFields == 5, "must have 5 fields");
  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("num_input") == 0) {
      num_input = *static_cast<const int32_t*>(field_data);
    } else if (field_name.compare("name") == 0) {
      name = std::string(static_cast<const char*>(field_data), field_len);
    } else if (field_name.compare("mode") == 0) {
      auto mode_int = *static_cast<const int32_t*>(field_data);
      if (0 == mode_int) {
        mode = NVTXMode::PUSH;
      } else {
        mode = NVTXMode::POP;
      }
    } else if (field_name.compare("color_rgb") == 0) {
      auto color_rgb = *static_cast<const uint32_t*>(field_data);
      color_argb = color_rgb | 0xFF000000;  // 0xFF000000 means fully opaque
    } else if (field_name.compare("cuda_sync") == 0) {
      cuda_sync = *static_cast<const int32_t*>(field_data);
      if (0 != cuda_sync) {
        cuda_sync = 1;
      }
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }

  auto obj = new CustomTimeline(num_input, name, mode, color_argb, cuda_sync);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* CustomTimelinePluginCreator::deserializePlugin(
    const char* plugin_name,
    const void* serialData,
    size_t serialLength) noexcept {
  NVTXMode mode;

  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;

  uint32_t num_input = read<int32_t>(buf);

  auto name_len = read<size_t>(buf);
  std::string name(buf, name_len);
  buf += name_len;

  auto mode_int = read<int32_t>(buf);
  if (0 == mode_int) {
    mode = NVTXMode::PUSH;
  } else {
    mode = NVTXMode::POP;
  }

  uint32_t color_argb = read<uint32_t>(buf);
  uint32_t cuda_sync = read<int32_t>(buf);

  auto obj = new CustomTimeline(num_input, name, mode, color_argb, cuda_sync);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void CustomTimelinePluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* CustomTimelinePluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
