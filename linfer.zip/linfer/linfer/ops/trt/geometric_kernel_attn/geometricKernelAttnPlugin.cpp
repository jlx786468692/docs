//
// Created by Derry Lin on 2022/11/7.
//

#include "geometricKernelAttnPlugin.h"
// #include "checkMacrosPlugin.h"
#include "geometricKernelAttnKernel.h"
// #include "serialize.h"
#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

using linfer::GeometricKernelAttnPlugin;
using linfer::GeometricKernelAttnPluginCreator;
using linfer::GeometricKernelAttnPluginCreator2;
using namespace nvinfer1;
using namespace nvinfer1::plugin;

namespace {
constexpr char const* MSDA_PLUGIN_VERSION{"1"};
constexpr char const* MSDA_PLUGIN_NAME{"GeometricKernelAttnTRT"};
constexpr char const* MSDA_PLUGIN_NAME2{"GeometricKernelAttnTRT2"};
}  // namespace

PluginFieldCollection GeometricKernelAttnPluginCreator::mFC{};
std::vector<PluginField> GeometricKernelAttnPluginCreator::mPluginAttributes;

PluginFieldCollection GeometricKernelAttnPluginCreator2::mFC{};
std::vector<PluginField> GeometricKernelAttnPluginCreator2::mPluginAttributes;

GeometricKernelAttnPlugin::GeometricKernelAttnPlugin(bool use_h2) : use_h2(use_h2) {}

GeometricKernelAttnPlugin::GeometricKernelAttnPlugin(const void* serialData,
                                                     size_t serialLength,
                                                     bool use_h2)
    : use_h2(use_h2) {}

GeometricKernelAttnPlugin::~GeometricKernelAttnPlugin() throw() { terminate(); }

int32_t GeometricKernelAttnPlugin::getNbOutputs() const noexcept { return 1; }

DimsExprs GeometricKernelAttnPlugin::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  DimsExprs outputDim;
  outputDim.nbDims = 3;
  outputDim.d[0] = inputs[2].d[0];
  outputDim.d[1] = inputs[2].d[1];
  outputDim.d[2] =
      exprBuilder.operation(DimensionOperation::kPROD, *inputs[0].d[2], *inputs[0].d[3]);
  return outputDim;
}

int32_t GeometricKernelAttnPlugin::initialize() noexcept { return 0; }

void GeometricKernelAttnPlugin::terminate() noexcept {}

size_t GeometricKernelAttnPlugin::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                                   int32_t nbInputs,
                                                   const nvinfer1::PluginTensorDesc* outputs,
                                                   int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t GeometricKernelAttnPlugin::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                           const nvinfer1::PluginTensorDesc* outputDesc,
                                           const void* const* inputs,
                                           void* const* outputs,
                                           void* workspace,
                                           cudaStream_t stream) noexcept {
  Dims value_dims = inputDesc[0].dims;
  const int batch = value_dims.d[0];
  const int spatial_size = value_dims.d[1];
  const int num_heads = value_dims.d[2];
  const int channels = value_dims.d[3];

  const int num_levels = inputDesc[1].dims.d[0];

  const int num_query = inputDesc[2].dims.d[1];
  const int num_point = inputDesc[2].dims.d[4];

  auto data_type = inputDesc[0].type;
  ASSERT(data_type == DataType::kFLOAT || data_type == DataType::kHALF)

  switch (data_type) {
    case DataType::kFLOAT:
      gk_deformable_im2col_cuda<float>((float*)inputs[0],
                                       (int32_t*)inputs[1],
                                       (int32_t*)inputs[2],
                                       (float*)inputs[3],
                                       batch,
                                       spatial_size,
                                       num_heads,
                                       channels,
                                       num_levels,
                                       num_query,
                                       num_point,
                                       (float*)outputs[0],
                                       stream);
      break;
    case DataType::kHALF:
      // if (use_h2) {
      // gk_deformable_im2col_cuda<__half2>(
      //     (__half2 *)inputs[0], (int32_t *)inputs[1], (__half2 *)inputs[2],
      //     (__half2 *)inputs[3], batch, spatial_size, num_heads, channels,
      //     num_levels, num_query, num_point, (__half2 *)outputs[0], stream);
      // } else {
      gk_deformable_im2col_cuda<__half>((__half*)inputs[0],
                                        (int32_t*)inputs[1],
                                        (int32_t*)inputs[2],
                                        (__half*)inputs[3],
                                        batch,
                                        spatial_size,
                                        num_heads,
                                        channels,
                                        num_levels,
                                        num_query,
                                        num_point,
                                        (__half*)outputs[0],
                                        stream);
      // }
      break;
    default:
      return 1;
  }
  return 0;
}

size_t GeometricKernelAttnPlugin::getSerializationSize() const noexcept { return 0; }

void GeometricKernelAttnPlugin::serialize(void* buffer) const noexcept {}

bool GeometricKernelAttnPlugin::supportsFormatCombination(int32_t pos,
                                                          const nvinfer1::PluginTensorDesc* inOut,
                                                          int32_t nbInputs,
                                                          int32_t nbOutputs) noexcept {
  switch (pos) {
    case 0:
      return (inOut[pos].type == nvinfer1::DataType::kFLOAT ||
              inOut[pos].type == nvinfer1::DataType::kHALF) &&
             inOut[pos].format == nvinfer1::TensorFormat::kLINEAR;
    case 1:
      return inOut[pos].type == nvinfer1::DataType::kINT32 &&
             inOut[pos].format == nvinfer1::TensorFormat::kLINEAR;
    case 2:
      return inOut[pos].type == nvinfer1::DataType::kINT32 &&
             inOut[pos].format == nvinfer1::TensorFormat::kLINEAR;
    case 3:
      return inOut[pos].type == inOut[0].type && inOut[pos].format == inOut[0].format;
    case 4:
      return inOut[pos].type == inOut[0].type && inOut[pos].format == inOut[0].format;
    default:
      return false;
  }
}

char const* GeometricKernelAttnPlugin::getPluginType() const noexcept {
  return use_h2 ? MSDA_PLUGIN_NAME2 : MSDA_PLUGIN_NAME;
}

char const* GeometricKernelAttnPlugin::getPluginVersion() const noexcept {
  return MSDA_PLUGIN_VERSION;
}

void GeometricKernelAttnPlugin::destroy() noexcept { delete this; }

IPluginV2DynamicExt* GeometricKernelAttnPlugin::clone() const noexcept {
  try {
    auto* plugin = new GeometricKernelAttnPlugin{use_h2};
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    plugin->initialize();
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void GeometricKernelAttnPlugin::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

char const* GeometricKernelAttnPlugin::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

DataType GeometricKernelAttnPlugin::getOutputDataType(int32_t index,
                                                      const nvinfer1::DataType* inputTypes,
                                                      int32_t nbInputs) const noexcept {
  PLUGIN_ASSERT(inputTypes && nbInputs > 0 && index == 0)
  return inputTypes[0];
}

void GeometricKernelAttnPlugin::attachToContext(cudnnContext* cudnn,
                                                cublasContext* cublas,
                                                nvinfer1::IGpuAllocator* allocator) noexcept {}

void GeometricKernelAttnPlugin::detachFromContext() noexcept {}

void GeometricKernelAttnPlugin::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                                int32_t nbInputs,
                                                const nvinfer1::DynamicPluginTensorDesc* out,
                                                int32_t nbOutputs) noexcept {
    PLUGIN_ASSERT(nbInputs == 4)}

GeometricKernelAttnPluginCreator::GeometricKernelAttnPluginCreator() {
  mPluginAttributes.clear();
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* GeometricKernelAttnPluginCreator::getPluginName() const noexcept {
  return MSDA_PLUGIN_NAME;
}

char const* GeometricKernelAttnPluginCreator::getPluginVersion() const noexcept {
  return MSDA_PLUGIN_VERSION;
}

PluginFieldCollection const* GeometricKernelAttnPluginCreator::getFieldNames() noexcept {
  return &mFC;
}

IPluginV2DynamicExt* GeometricKernelAttnPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  try {
    auto* plugin = new GeometricKernelAttnPlugin(false);
    plugin->setPluginNamespace(mNamespace.c_str());
    plugin->initialize();
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

IPluginV2DynamicExt* GeometricKernelAttnPluginCreator::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  try {
    auto* plugin = new GeometricKernelAttnPlugin{serialData, serialLength, false};
    plugin->setPluginNamespace(mNamespace.c_str());
    plugin->initialize();
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

GeometricKernelAttnPluginCreator2::GeometricKernelAttnPluginCreator2() {
  mPluginAttributes.clear();
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* GeometricKernelAttnPluginCreator2::getPluginName() const noexcept {
  return MSDA_PLUGIN_NAME2;
}

char const* GeometricKernelAttnPluginCreator2::getPluginVersion() const noexcept {
  return MSDA_PLUGIN_VERSION;
}

PluginFieldCollection const* GeometricKernelAttnPluginCreator2::getFieldNames() noexcept {
  return &mFC;
}

IPluginV2DynamicExt* GeometricKernelAttnPluginCreator2::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  try {
    auto* plugin = new GeometricKernelAttnPlugin(true);
    plugin->setPluginNamespace(mNamespace.c_str());
    plugin->initialize();
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

IPluginV2DynamicExt* GeometricKernelAttnPluginCreator2::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  try {
    auto* plugin = new GeometricKernelAttnPlugin{serialData, serialLength, true};
    plugin->setPluginNamespace(mNamespace.c_str());
    plugin->initialize();
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

REGISTER_TENSORRT_PLUGIN(GeometricKernelAttnPluginCreator);
REGISTER_TENSORRT_PLUGIN(GeometricKernelAttnPluginCreator2);
