//
// Created by Derry Lin on 2022/11/7.
//

#include <cuda_fp16.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

// #include "cuda_helper.h"
// #include "helper.h"
#include <cstdio>

#include "geometricKernelAttnKernel.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

__device__ int clip(int n, int lower, int upper) {
  n = n >= lower ? n : lower;
  return n < upper ? n : upper;
}

template <typename scalar_t>
__device__ scalar_t gk_attn_sampling(const scalar_t*& bottom_data,
                                     const int& height,
                                     const int& width,
                                     const int& nheads,
                                     const int& channels,
                                     const int& h,
                                     const int& w,
                                     const int& m,
                                     const int& c) {
  const int w_stride = nheads * channels;
  const int h_stride = width * w_stride;

  const int base_ptr = m * channels + c;
  const int h_ptr_offset = h_stride * h;
  const int w_ptr_offset = w_stride * w;
  scalar_t val = bottom_data[base_ptr + h_ptr_offset + w_ptr_offset];

  return val;
}

template <>
__device__ __half gk_attn_sampling(const __half*& bottom_data,
                                   const int& height,
                                   const int& width,
                                   const int& nheads,
                                   const int& channels,
                                   const int& h,
                                   const int& w,
                                   const int& m,
                                   const int& c) {
  const int w_stride = nheads * channels;
  const int h_stride = width * w_stride;

  const int base_ptr = m * channels + c;
  const int h_ptr_offset = h_stride * h;
  const int w_ptr_offset = w_stride * w;
  __half val = bottom_data[base_ptr + h_ptr_offset + w_ptr_offset];

  return val;
}

__device__ __half2 gk_attn_sampling(const __half2*& bottom_data,
                                    const int& height,
                                    const int& width,
                                    const int& nheads,
                                    const int& channels,
                                    const int& h,
                                    const int& w,
                                    const int& m,
                                    const int& c) {
  const int w_stride = nheads * channels;
  const int h_stride = width * w_stride;

  const int base_ptr = m * channels + c;
  const int h_ptr_offset = h_stride * h;
  const int w_ptr_offset = w_stride * w;
  __half2 val = bottom_data[base_ptr + h_ptr_offset + w_ptr_offset];

  return val;
}

template <typename scalar_t>
__global__ void gk_deformable_im2col_gpu_kernel(const int n,
                                                const scalar_t* data_value,
                                                const int32_t* data_spatial_shapes,
                                                const int32_t* data_sampling_loc,
                                                const scalar_t* data_attn_weight,
                                                const int batch_size,
                                                const int spatial_size,
                                                const int num_heads,
                                                const int channels,
                                                const int num_levels,
                                                const int num_query,
                                                const int num_point,
                                                scalar_t* data_col) {
  CUDA_1D_KERNEL_LOOP(index, n) {
    int _temp = index;
    const int c_col = _temp % channels;
    _temp /= channels;
    const int sampling_index = _temp;
    const int m_col = _temp % num_heads;
    _temp /= num_heads;
    // const int q_col = _temp % num_query;
    _temp /= num_query;
    const int b_col = _temp;

    scalar_t* data_col_ptr = data_col + index;
    int data_weight_ptr = sampling_index * num_levels * num_point;
    int data_loc_w_ptr = data_weight_ptr << 1;
    const int qid_stride = num_heads * channels;
    const int data_value_ptr_init_offset = b_col * spatial_size * qid_stride;
    scalar_t col = 0;

    const scalar_t* data_value_ptr = data_value + data_value_ptr_init_offset;
    for (int l_col = 0; l_col < num_levels; ++l_col) {
      // const int level_start_id = data_level_start_index[l_col];
      const int spatial_h_ptr = l_col << 1;
      const int spatial_h = data_spatial_shapes[spatial_h_ptr];
      const int spatial_w = data_spatial_shapes[spatial_h_ptr + 1];
      for (int p_col = 0; p_col < num_point; ++p_col) {
        const int loc_w = data_sampling_loc[data_loc_w_ptr];
        const int loc_h = data_sampling_loc[data_loc_w_ptr + 1];
        const scalar_t weight = data_attn_weight[data_weight_ptr];
        const int loc_h_ = clip(loc_h, 0, spatial_h - 1);
        const int loc_w_ = clip(loc_w, 0, spatial_w - 1);
        col += gk_attn_sampling(data_value_ptr,
                                spatial_h,
                                spatial_w,
                                num_heads,
                                channels,
                                loc_h_,
                                loc_w_,
                                m_col,
                                c_col) *
               weight;

        data_weight_ptr += 1;
        data_loc_w_ptr += 2;
      }
      data_value_ptr += qid_stride * spatial_h * spatial_w;
    }
    *data_col_ptr = col;
  }
}

template <>
__global__ void gk_deformable_im2col_gpu_kernel(const int n,
                                                const __half* data_value,
                                                const int32_t* data_spatial_shapes,
                                                const int32_t* data_sampling_loc,
                                                const __half* data_attn_weight,
                                                const int batch_size,
                                                const int spatial_size,
                                                const int num_heads,
                                                const int channels,
                                                const int num_levels,
                                                const int num_query,
                                                const int num_point,
                                                __half* data_col) {
  CUDA_1D_KERNEL_LOOP(index, n) {
    int _temp = index;
    const int c_col = _temp % channels;
    _temp /= channels;
    const int sampling_index = _temp;
    const int m_col = _temp % num_heads;
    _temp /= num_heads;
    // const int q_col = _temp % num_query;
    _temp /= num_query;
    const int b_col = _temp;

    __half* data_col_ptr = data_col + index;
    int data_weight_ptr = sampling_index * num_levels * num_point;
    int data_loc_w_ptr = data_weight_ptr << 1;
    const int qid_stride = num_heads * channels;
    const int data_value_ptr_init_offset = b_col * spatial_size * qid_stride;
    __half col = 0;

    const __half* data_value_ptr = data_value + data_value_ptr_init_offset;
    for (int l_col = 0; l_col < num_levels; ++l_col) {
      // const int level_start_id = data_level_start_index[l_col];
      const int spatial_h_ptr = l_col << 1;
      const int spatial_h = data_spatial_shapes[spatial_h_ptr];
      const int spatial_w = data_spatial_shapes[spatial_h_ptr + 1];
      for (int p_col = 0; p_col < num_point; ++p_col) {
        const int loc_w = data_sampling_loc[data_loc_w_ptr];
        const int loc_h = data_sampling_loc[data_loc_w_ptr + 1];
        const __half weight = data_attn_weight[data_weight_ptr];
        const int loc_h_ = clip(loc_h, 0, spatial_h - 1);
        const int loc_w_ = clip(loc_w, 0, spatial_w - 1);
        col += gk_attn_sampling(data_value_ptr,
                                spatial_h,
                                spatial_w,
                                num_heads,
                                channels,
                                loc_h_,
                                loc_w_,
                                m_col,
                                c_col) *
               weight;

        data_weight_ptr += 1;
        data_loc_w_ptr += 2;
      }
      data_value_ptr += qid_stride * spatial_h * spatial_w;
    }
    *data_col_ptr = col;
  }
}

// template <>
// __global__ void gk_deformable_im2col_gpu_kernel(
//     const int n, const __half2 *data_value, const int32_t *data_spatial_shapes,
//     const __half2 *data_sampling_loc, const __half2 *data_attn_weight,
//     const int batch_size, const int spatial_size, const int num_heads,
//     const int channels, const int num_levels, const int num_query,
//     const int num_point, __half2 *data_col) {
//   CUDA_1D_KERNEL_LOOP(index, n) {

//     int _temp = index;
//     const int c_col = _temp % channels;
//     _temp /= channels;
//     const int sampling_index = _temp;
//     const int m_col = _temp % num_heads;
//     _temp /= num_heads;
//     // const int q_col = _temp % num_query;
//     _temp /= num_query;
//     const int b_col = _temp;

//     __half2 *data_col_ptr = data_col + index;
//     int data_weight_ptr = sampling_index * num_levels * num_point;
//     int data_loc_w_ptr = data_weight_ptr << 1;
//     const int qid_stride = num_heads * channels;
//     const int data_value_ptr_init_offset = b_col * spatial_size * qid_stride;
//     __half2 col = 0;

//     const __half *data_value_ptr = (__half *)data_value + data_value_ptr_init_offset;
//     for (int l_col = 0; l_col < num_levels; ++l_col) {
//       const int level_start_id = data_level_start_index[l_col];
//       const int spatial_h_ptr = l_col << 1;
//       const int spatial_h = data_spatial_shapes[spatial_h_ptr];
//       const int spatial_w = data_spatial_shapes[spatial_h_ptr + 1];
//       const __half2 *data_value_ptr =
//           data_value +
//           (data_value_ptr_init_offset + level_start_id * qid_stride);
//       for (int p_col = 0; p_col < num_point; ++p_col) {
//         const int loc_w = data_sampling_loc[data_loc_w_ptr];
//         const int loc_h = data_sampling_loc[data_loc_w_ptr + 1];
//         const __half2 weight = data_attn_weight[data_weight_ptr];
//         const int loc_h_ = clip(loc_h, 0, spatial_h-1);
//         const int loc_w_ = clip(loc_w, 0, spatial_w-1);
//         col += gk_attn_sampling(data_value_ptr, spatial_h, spatial_w, num_heads,
//                                                 channels, loc_h_, loc_w_, m_col, c_col) * weight;

//         data_weight_ptr += 1;
//         data_loc_w_ptr += 2;
//       }
//       data_value_ptr += qid_stride * spatial_h * spatial_w;
//     }
//     *data_col_ptr = col;
//   }
// }

template <typename scalar_t>
void gk_deformable_im2col_cuda(const scalar_t* data_value,
                               const int32_t* data_spatial_shapes,
                               const int32_t* data_sampling_loc,
                               const scalar_t* data_attn_weight,
                               const int batch_size,
                               const int spatial_size,
                               const int num_heads,
                               const int channels,
                               const int num_levels,
                               const int num_query,
                               const int num_point,
                               scalar_t* data_col,
                               cudaStream_t stream) {
  const int num_kernels = batch_size * num_query * num_heads * channels;
  const int num_actual_kernels = batch_size * num_query * num_heads * channels;

  gk_deformable_im2col_gpu_kernel<scalar_t>
      <<<GET_BLOCKS(num_actual_kernels), THREADS_PER_BLOCK, 0, stream>>>(num_kernels,
                                                                         data_value,
                                                                         data_spatial_shapes,
                                                                         data_sampling_loc,
                                                                         data_attn_weight,
                                                                         batch_size,
                                                                         spatial_size,
                                                                         num_heads,
                                                                         channels,
                                                                         num_levels,
                                                                         num_query,
                                                                         num_point,
                                                                         data_col);

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    printf("error in gk_deformable_im2col_cuda: %s\n", cudaGetErrorString(err));
  }
}

// template <>
// void gk_deformable_im2col_cuda(
//     const __half2 *data_value, const int32_t *data_spatial_shapes,
//     const __half2 *data_sampling_loc, const __half2 *data_attn_weight,
//     const int batch_size, const int spatial_size, const int num_heads,
//     const int channels, const int num_levels, const int num_query,
//     const int num_point, __half2 *data_col, cudaStream_t stream) {
//   const int num_kernels =
//       batch_size * num_query * num_heads * ((channels + 1) / 2);
//   const int num_actual_kernels =
//       batch_size * num_query * num_heads * ((channels + 1) / 2);

//   gk_deformable_im2col_gpu_kernel<__half2>
//       <<<GET_BLOCKS(num_actual_kernels), THREADS_PER_BLOCK, 0, stream>>>(
//           num_kernels, data_value, data_spatial_shapes, data_sampling_loc,
//           data_attn_weight, batch_size, spatial_size, num_heads, channels,
//           num_levels, num_query, num_point, data_col);

//   cudaError_t err = cudaGetLastError();
//   if (err != cudaSuccess) {
//     printf("error in gk_deformable_im2col_cuda: %s\n", cudaGetErrorString(err));
//   }
// }

template void gk_deformable_im2col_cuda<float>(const float* data_value,
                                               const int32_t* data_spatial_shapes,
                                               const int32_t* data_sampling_loc,
                                               const float* data_attn_weight,
                                               const int batch_size,
                                               const int spatial_size,
                                               const int num_heads,
                                               const int channels,
                                               const int num_levels,
                                               const int num_query,
                                               const int num_point,
                                               float* data_col,
                                               cudaStream_t stream);

template void gk_deformable_im2col_cuda<__half>(const __half* data_value,
                                                const int32_t* data_spatial_shapes,
                                                const int32_t* data_sampling_loc,
                                                const __half* data_attn_weight,
                                                const int batch_size,
                                                const int spatial_size,
                                                const int num_heads,
                                                const int channels,
                                                const int num_levels,
                                                const int num_query,
                                                const int num_point,
                                                __half* data_col,
                                                cudaStream_t stream);

// template void gk_deformable_im2col_cuda<__half2>(
//     const __half2 *data_value, const int32_t *data_spatial_shapes,
//     const __half2 *data_sampling_loc, const __half2 *data_attn_weight,
//     const int batch_size, const int spatial_size, const int num_heads,
//     const int channels, const int num_levels, const int num_query,
//     const int num_point, __half2 *data_col, cudaStream_t stream);
