#pragma once

#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include "linfer/util/internal/trt/plugin.h"

pluginStatus_t ImgPreprocessInference(cudaStream_t stream,
                                      const void* img,
                                      void* output,
                                      int h,
                                      int w,
                                      const float* weight,
                                      const float* bias,
                                      OutputDatatype output_datatype,
                                      bool bgr2rgb);
