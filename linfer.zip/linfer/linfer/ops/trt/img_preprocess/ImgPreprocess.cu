#include <string>
#include <vector>

#include "ImgPreprocessConfig.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

template <typename T, int n_point_per_thread, int channels_in>
__global__ void img_preprocess_for_float(const uint8_t* img,
                                         T* output,
                                         int h,
                                         int w,
                                         const float weight_0,
                                         const float weight_1,
                                         const float weight_2,
                                         const float bias_0,
                                         const float bias_1,
                                         const float bias_2) {
  register int hid = blockIdx.x;
  register int wid_offset = threadIdx.x * n_point_per_thread;
  register int img_size = h * w;
  register float tmp[n_point_per_thread * channels_in];
  register int h_offset;
  register int wh_offset;

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    wh_offset = hid * w * channels_in + (wid_offset + i) * channels_in;
#pragma unroll
    for (int j = 0; j < channels_in; j++) {
      tmp[h_offset + j] = img[wh_offset + j];
    }
  }

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    tmp[h_offset] = (tmp[h_offset] * weight_0 + bias_0);
    tmp[h_offset + 1] = (tmp[h_offset + 1] * weight_1 + bias_1);
    tmp[h_offset + 2] = (tmp[h_offset + 2] * weight_2 + bias_2);
  }

  // #pragma unroll
  // for(int i = 0; i < n_point_per_thread; i++) {
  //     tmp[i * channels_in] = img[hid * w * channels_in + (wid_offset + i) * channels_in];
  //     tmp[i * channels_in] = tmp[i * channels_in] * A_0 + B_0;
  //     tmp[i * channels_in + 1] = img[hid * w * channels_in + (wid_offset + i) * channels_in +
  //     1]; tmp[i * channels_in + 1] = tmp[i * channels_in + 1] * A_1 + B_1; tmp[i * channels_in
  //     + 2] = img[hid * w * channels_in + (wid_offset + i) * channels_in + 2]; tmp[i *
  //     channels_in + 2] = tmp[i * channels_in + 2] * A_2 + B_2;
  // }

#pragma unroll
  for (int i = 0; i < channels_in; i++) {
    wh_offset = i * img_size + hid * w + wid_offset;
#pragma unroll
    for (int j = 0; j < n_point_per_thread; j++) {
      output[wh_offset + j] = (T)(tmp[j * channels_in + i]);
    }
  }
}

template <typename T, int n_point_per_thread, int channels_in>
__global__ void img_preprocess_for_float_for_rgb(const uint8_t* img,
                                                 T* output,
                                                 int h,
                                                 int w,
                                                 const float weight_0,
                                                 const float weight_1,
                                                 const float weight_2,
                                                 const float bias_0,
                                                 const float bias_1,
                                                 const float bias_2) {
  register int hid = blockIdx.x;
  register int wid_offset = threadIdx.x * n_point_per_thread;
  register int img_size = h * w;
  register float tmp[n_point_per_thread * channels_in];
  register int h_offset;
  register int wh_offset;

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    wh_offset = hid * w * channels_in + (wid_offset + i) * channels_in;
#pragma unroll
    for (int j = 0; j < channels_in; j++) {
      tmp[h_offset + 2 - j] = img[wh_offset + j];
    }
  }

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    tmp[h_offset] = (tmp[h_offset] * weight_0 + bias_0);
    tmp[h_offset + 1] = (tmp[h_offset + 1] * weight_1 + bias_1);
    tmp[h_offset + 2] = (tmp[h_offset + 2] * weight_2 + bias_2);
  }

  // #pragma unroll
  // for(int i = 0; i < n_point_per_thread; i++) {
  //     tmp[i * channels_in] = img[hid * w * channels_in + (wid_offset + i) * channels_in];
  //     tmp[i * channels_in] = tmp[i * channels_in] * A_0 + B_0;
  //     tmp[i * channels_in + 1] = img[hid * w * channels_in + (wid_offset + i) * channels_in +
  //     1]; tmp[i * channels_in + 1] = tmp[i * channels_in + 1] * A_1 + B_1; tmp[i * channels_in
  //     + 2] = img[hid * w * channels_in + (wid_offset + i) * channels_in + 2]; tmp[i *
  //     channels_in + 2] = tmp[i * channels_in + 2] * A_2 + B_2;
  // }

#pragma unroll
  for (int i = 0; i < channels_in; i++) {
    wh_offset = i * img_size + hid * w + wid_offset;
#pragma unroll
    for (int j = 0; j < n_point_per_thread; j++) {
      output[wh_offset + j] = (T)(tmp[j * channels_in + i]);
    }
  }
}

template <typename T, int n_point_per_thread, int channels_in>
__global__ void img_preprocess_for_int8(const uint8_t* img,
                                        T* output,
                                        int h,
                                        int w,
                                        const float weight_0,
                                        const float weight_1,
                                        const float weight_2,
                                        const float bias_0,
                                        const float bias_1,
                                        const float bias_2) {
  register int hid = blockIdx.x;
  register int wid_offset = threadIdx.x * n_point_per_thread;
  register int img_size = h * w;
  register float tmp[n_point_per_thread * channels_in];
  register int h_offset, wh_offset, int_value, saturation_value;
  register int8_t unsaturation_flag, sign_flag;

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    wh_offset = hid * w * channels_in + (wid_offset + i) * channels_in;
#pragma unroll
    for (int j = 0; j < channels_in; j++) {
      tmp[h_offset + j] = img[wh_offset + j];
    }
  }

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    tmp[h_offset] = (tmp[h_offset] * weight_0 + bias_0);
    tmp[h_offset + 1] = (tmp[h_offset + 1] * weight_1 + bias_1);
    tmp[h_offset + 2] = (tmp[h_offset + 2] * weight_2 + bias_2);
  }

#pragma unroll
  for (int i = 0; i < channels_in; i++) {
    wh_offset = i * img_size + hid * w + wid_offset;
#pragma unroll
    for (int j = 0; j < n_point_per_thread; j++) {
      // original method to realize round op
      // if (tmp[j * channels_in + i] >= 0) {
      //     output[wh_offset + j] = (T)(tmp[j * channels_in + i] + 0.5);
      //     output[wh_offset + j] = min(output[wh_offset + j], 127);
      // } else {
      //     output[wh_offset + j] = (T)(tmp[j * channels_in + i] - 0.5);
      //     output[wh_offset + j] = max(output[wh_offset + j], -128);
      // }

      // -128的原因是反算之前加上的128.5
      int_value = (int)(tmp[j * channels_in + i]) - 128;
      // 在C++中，int数字做整除时，负数情况也按照正数情况处理，这里用来判断值域是否在-127~127.
      unsaturation_flag = (int_value / 128) == 0;
      // 这里用来判断数值的符号， 其中&
      //  0x1的原因是负数与正数的位移填充数值的方式不一致，因此仅取原来的符号位。
      sign_flag = (int_value >> 31) & 0x1;

      // test sample
      // if (blockIdx.x == 0 && threadIdx.x == 0){
      //     int test_length = 13;
      //     int test_num[] = {-1000, -256, -128, -127, -50, -1, 0, 1, 50, 127, 128, 256,
      //     1000}; for (int i = 0; i < test_length; i++) {
      //         int a = test_num[i];
      //         // int8_t asaf = ((~a + 0x1) >> 7) & 0x1;
      //         int8_t ausaf = (a / 128) == 0;
      //         int8_t asif = (a >> 31) & 0x1;
      //         int asv = (1 - asif) * 127 - asif * 128;
      //         a = (1 - ausaf) * asv + ausaf * a;
      //         printf("origin is %d it is %d x is %x ausaf is %d asif is %x, asv is %d\n",
      //         test_num[i], a, a, ausaf, asif, asv);
      //     }
      // }

      // 选择饱和阈值
      saturation_value = 127 - 255 * sign_flag;  //(1 - sign_flag) * 127 - sign_flag * 128;
      int_value = (1 - unsaturation_flag) * saturation_value + unsaturation_flag * int_value;
      output[wh_offset + j] = (int8_t)int_value;
    }
  }
}

template <typename T, int n_point_per_thread, int channels_in>
__global__ void img_preprocess_for_int8_for_rgb(const uint8_t* img,
                                                T* output,
                                                int h,
                                                int w,
                                                const float weight_0,
                                                const float weight_1,
                                                const float weight_2,
                                                const float bias_0,
                                                const float bias_1,
                                                const float bias_2) {
  register int hid = blockIdx.x;
  register int wid_offset = threadIdx.x * n_point_per_thread;
  register int img_size = h * w;
  register float tmp[n_point_per_thread * channels_in];
  register int h_offset, wh_offset, int_value, saturation_value;
  register int8_t unsaturation_flag, sign_flag;

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    wh_offset = hid * w * channels_in + (wid_offset + i) * channels_in;
#pragma unroll
    for (int j = 0; j < channels_in; j++) {
      tmp[h_offset + 2 - j] = img[wh_offset + j];
    }
  }

#pragma unroll
  for (int i = 0; i < n_point_per_thread; i++) {
    h_offset = i * channels_in;
    tmp[h_offset] = (tmp[h_offset] * weight_0 + bias_0);
    tmp[h_offset + 1] = (tmp[h_offset + 1] * weight_1 + bias_1);
    tmp[h_offset + 2] = (tmp[h_offset + 2] * weight_2 + bias_2);
  }

#pragma unroll
  for (int i = 0; i < channels_in; i++) {
    wh_offset = i * img_size + hid * w + wid_offset;
#pragma unroll
    for (int j = 0; j < n_point_per_thread; j++) {
      // original method to realize round op
      // if (tmp[j * channels_in + i] >= 0) {
      //     output[wh_offset + j] = (T)(tmp[j * channels_in + i] + 0.5);
      //     output[wh_offset + j] = min(output[wh_offset + j], 127);
      // } else {
      //     output[wh_offset + j] = (T)(tmp[j * channels_in + i] - 0.5);
      //     output[wh_offset + j] = max(output[wh_offset + j], -128);
      // }

      // -128的原因是反算之前加上的128.5
      int_value = (int)(tmp[j * channels_in + i]) - 128;
      // 在C++中，int数字做整除时，负数情况也按照正数情况处理，这里用来判断值域是否在-127~127.
      unsaturation_flag = (int_value / 128) == 0;
      // 这里用来判断数值的符号， 其中&
      //  0x1的原因是负数与正数的位移填充数值的方式不一致，因此仅取原来的符号位。
      sign_flag = (int_value >> 31) & 0x1;

      // test sample
      // if (blockIdx.x == 0 && threadIdx.x == 0){
      //     int test_length = 13;
      //     int test_num[] = {-1000, -256, -128, -127, -50, -1, 0, 1, 50, 127, 128, 256,
      //     1000}; for (int i = 0; i < test_length; i++) {
      //         int a = test_num[i];
      //         // int8_t asaf = ((~a + 0x1) >> 7) & 0x1;
      //         int8_t ausaf = (a / 128) == 0;
      //         int8_t asif = (a >> 31) & 0x1;
      //         int asv = (1 - asif) * 127 - asif * 128;
      //         a = (1 - ausaf) * asv + ausaf * a;
      //         printf("origin is %d it is %d x is %x ausaf is %d asif is %x, asv is %d\n",
      //         test_num[i], a, a, ausaf, asif, asv);
      //     }
      // }

      // 选择饱和阈值
      saturation_value = 127 - 255 * sign_flag;  //(1 - sign_flag) * 127 - sign_flag * 128;
      int_value = (1 - unsaturation_flag) * saturation_value + unsaturation_flag * int_value;
      output[wh_offset + j] = (int8_t)int_value;
    }
  }
}

pluginStatus_t ImgPreprocessInference(cudaStream_t stream,
                                      const void* img,
                                      void* output,
                                      int h,
                                      int w,
                                      const float* weight,
                                      const float* bias,
                                      OutputDatatype output_datatype,
                                      bool bgr2rgb) {
  if (bgr2rgb) {
    if (output_datatype == FP32) {
      img_preprocess_for_float_for_rgb<float, N_POINT_PER_THREAD, CHANNELS_IN>
          <<<h, w / N_POINT_PER_THREAD, 0, stream>>>((const uint8_t*)img,
                                                     (float*)output,
                                                     h,
                                                     w,
                                                     weight[0],
                                                     weight[1],
                                                     weight[2],
                                                     bias[0],
                                                     bias[1],
                                                     bias[2]);
    } else if (output_datatype == FP16) {
      img_preprocess_for_float_for_rgb<__half, N_POINT_PER_THREAD, CHANNELS_IN>
          <<<h, w / N_POINT_PER_THREAD, 0, stream>>>((const uint8_t*)img,
                                                     (__half*)output,
                                                     h,
                                                     w,
                                                     weight[0],
                                                     weight[1],
                                                     weight[2],
                                                     bias[0],
                                                     bias[1],
                                                     bias[2]);
    } else {
      img_preprocess_for_int8_for_rgb<int8_t, N_POINT_PER_THREAD, CHANNELS_IN>
          <<<h, w / N_POINT_PER_THREAD, 0, stream>>>((const uint8_t*)img,
                                                     (int8_t*)output,
                                                     h,
                                                     w,
                                                     weight[0],
                                                     weight[1],
                                                     weight[2],
                                                     bias[0],
                                                     bias[1],
                                                     bias[2]);
    }
  } else {
    if (output_datatype == FP32) {
      img_preprocess_for_float<float, N_POINT_PER_THREAD, CHANNELS_IN>
          <<<h, w / N_POINT_PER_THREAD, 0, stream>>>((const uint8_t*)img,
                                                     (float*)output,
                                                     h,
                                                     w,
                                                     weight[0],
                                                     weight[1],
                                                     weight[2],
                                                     bias[0],
                                                     bias[1],
                                                     bias[2]);
    } else if (output_datatype == FP16) {
      img_preprocess_for_float<__half, N_POINT_PER_THREAD, CHANNELS_IN>
          <<<h, w / N_POINT_PER_THREAD, 0, stream>>>((const uint8_t*)img,
                                                     (__half*)output,
                                                     h,
                                                     w,
                                                     weight[0],
                                                     weight[1],
                                                     weight[2],
                                                     bias[0],
                                                     bias[1],
                                                     bias[2]);
    } else {
      img_preprocess_for_int8<int8_t, N_POINT_PER_THREAD, CHANNELS_IN>
          <<<h, w / N_POINT_PER_THREAD, 0, stream>>>((const uint8_t*)img,
                                                     (int8_t*)output,
                                                     h,
                                                     w,
                                                     weight[0],
                                                     weight[1],
                                                     weight[2],
                                                     bias[0],
                                                     bias[1],
                                                     bias[2]);
    }
  }
  CHECK_CUDA_STATUS("img_preprocess");

  return STATUS_SUCCESS;
}