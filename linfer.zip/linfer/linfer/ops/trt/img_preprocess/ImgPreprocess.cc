#include "ImgPreprocess.h"

#include <assert.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "ImgPreprocessConfig.h"
#include "ImgPreprocess_kernel.cuh"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

using linfer::ops::trt::ImgPreprocessPluginCreator;
REGISTER_TENSORRT_PLUGIN(ImgPreprocessPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

const char* IMG_PREPROCESS_PLUGIN_VERSION{"1"};
static const char* IMG_PREPROCESS_PLUGIN_NAME{"ImgPreprocess"};

int ImgPreprocess::imgIdx_ = 0;
int ImgPreprocess::outputIdx_ = 0;

ImgPreprocess::ImgPreprocess(float qscalse,
                             int output_datatype,
                             const float* mean,
                             const float* var,
                             bool int8_input,
                             bool bgr2rgb)
    : qScalse_(qscalse), int8Input_(int8_input), bgr2rgb_(bgr2rgb) {
  w_.resize(CHANNELS_IN);
  b_.resize(CHANNELS_IN);
  mean_.resize(CHANNELS_IN);
  var_.resize(CHANNELS_IN);
  switch (output_datatype) {
    case 0:
      outputDatatype_ = FP32;
      break;
    case 1:
      outputDatatype_ = FP16;
      break;
    case 2:
      outputDatatype_ = INT8;
      break;
    default:
      printf("OutputDatatype %d is not supported\n", output_datatype);
      ASSERT(false);
  }

  for (int i = 0; i < CHANNELS_IN; i++) {
    // 原公式：(x / 255.0 - mean) / var * qscale,
    // 注意此时的qscale是pytorch的q算子的scale的倒数。 将其化简为w*x+b 因此w = qscale
    /// 255.0 / var, b = -mean / var * qscale

    w_[i] = qscalse / 255.0 / var[i];
    if (outputDatatype_ == INT8) {
      // 其中+128.5的原因是，C++中将float转为int时，是直接去尾法，例如0.9为0，
      //-0.9也为0，但是期望用四舍五入的方法将float转为int，因此在这里先提前
      //+128.5，在后面计算时减去128。
      b_[i] = -mean[i] / var[i] * qscalse + 128.5;
    } else {
      b_[i] = -mean[i] / var[i] * qscalse;
    }
    mean_[i] = mean[i];
    var_[i] = var[i];
  }
  if (outputDatatype_ != INT8 && qScalse_ != 1.0) {
    qScalse_ = 1.0;
    printf("the QScalse is set to 1.0\n");
  }
}

ImgPreprocess::ImgPreprocess(const void* data, size_t length) {
  deserialize_value(&data, &length, &qScalse_);
  deserialize_value(&data, &length, &outputDatatype_);
  deserialize_value(&data, &length, &mean_);
  deserialize_value(&data, &length, &var_);
  deserialize_value(&data, &length, &bgr2rgb_);
}

ImgPreprocess::~ImgPreprocess() {}

bool ImgPreprocess::supportsFormatCombination(int32_t pos,
                                              const nvinfer1::PluginTensorDesc* inOut,
                                              int32_t nbInputs,
                                              int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  switch (pos) {
    case 0:
      if (int8Input_) {
        return (desc.type == nvinfer1::DataType::kINT8) &&
               (desc.format == nvinfer1::TensorFormat::kLINEAR);
      }
      return (desc.type == nvinfer1::DataType::kFLOAT) &&
             (desc.format == nvinfer1::TensorFormat::kLINEAR);

    default:
      switch (outputDatatype_) {
        case 0:
          return (desc.type == nvinfer1::DataType::kFLOAT) && (desc.format == inOut[0].format);
        case 1:
          return (desc.type == nvinfer1::DataType::kHALF) && (desc.format == inOut[0].format);
        case 2:
          return (desc.type == nvinfer1::DataType::kINT8) && (desc.format == inOut[0].format);
        default:
          printf("OutputDatatype %d is not supported\n", outputDatatype_);
          return false;
      }
  }
}

void ImgPreprocess::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                    int32_t nbInputs,
                                    const nvinfer1::DynamicPluginTensorDesc* out,
                                    int32_t nbOutputs) noexcept {
  ASSERT(in[0].desc.dims.nbDims == 3);
}

size_t ImgPreprocess::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                       int32_t nbInputs,
                                       const nvinfer1::PluginTensorDesc* outputs,
                                       int32_t nbOutputs) const noexcept {
  return 0;
}

int ImgPreprocess::initialize() noexcept { return 0; }

void ImgPreprocess::terminate() noexcept {}

int32_t ImgPreprocess::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                               const nvinfer1::PluginTensorDesc* outputDesc,
                               const void* const* inputs,
                               void* const* outputs,
                               void* workspace,
                               cudaStream_t stream) noexcept {
  int channels_in = outputDesc[0].dims.d[1];
  ASSERT(channels_in == CHANNELS_IN);
  int h = outputDesc[0].dims.d[2];
  int w = outputDesc[0].dims.d[3];
  ASSERT(w % N_POINT_PER_THREAD == 0);
  ASSERT(w <= MAX_THREAD_NUMS);
  ImgPreprocessInference(stream,
                         inputs[0],
                         outputs[0],
                         h,
                         w,
                         w_.data(),
                         b_.data(),
                         outputDatatype_,
                         bgr2rgb_);
  return 0;
}

size_t ImgPreprocess::getSerializationSize() const noexcept {
  return serialized_size(qScalse_) + serialized_size(outputDatatype_) + serialized_size(mean_) +
         serialized_size(var_) + serialized_size(bgr2rgb_);
}

void ImgPreprocess::serialize(void* buffer) const noexcept {
  serialize_value(&buffer, qScalse_);
  serialize_value(&buffer, outputDatatype_);
  serialize_value(&buffer, mean_);
  serialize_value(&buffer, var_);
  serialize_value(&buffer, bgr2rgb_);
  return;
}

const char* ImgPreprocess::getPluginType() const noexcept { return IMG_PREPROCESS_PLUGIN_NAME; }

const char* ImgPreprocess::getPluginVersion() const noexcept {
  return IMG_PREPROCESS_PLUGIN_VERSION;
}

void ImgPreprocess::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* ImgPreprocess::clone() const noexcept {
  auto plugin =
      new ImgPreprocess(qScalse_, outputDatatype_, mean_.data(), var_.data(), int8Input_, bgr2rgb_);
  plugin->setPluginNamespace(pluginNamespace_.c_str());
  return plugin;
}

void ImgPreprocess::setPluginNamespace(const char* pluginNamespace) noexcept {
  pluginNamespace_ = pluginNamespace;
}

const char* ImgPreprocess::getPluginNamespace() const noexcept { return pluginNamespace_.c_str(); }

int ImgPreprocess::getNbOutputs() const noexcept { return 1; }

nvinfer1::DimsExprs ImgPreprocess::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs ret;

  if (int8Input_) {
    ret.d[2] = inputs[0].d[0];
    ret.d[3] = inputs[0].d[1];
  } else {
    ret.d[2] = exprBuilder.constant(inputs[0].d[0]->getConstantValue() * 2);
    ret.d[3] = exprBuilder.constant(inputs[0].d[1]->getConstantValue() * 2);
  }
  ret.d[0] = exprBuilder.constant(1);
  ret.d[1] = inputs[0].d[2];
  ret.nbDims = 4;
  return ret;
}

nvinfer1::DataType ImgPreprocess::getOutputDataType(int index,
                                                    const nvinfer1::DataType* inputTypes,
                                                    int nbInputs) const noexcept {
  switch (outputDatatype_) {
    case FP32:
      return nvinfer1::DataType::kFLOAT;
    case FP16:
      return nvinfer1::DataType::kHALF;
    case INT8:
      return nvinfer1::DataType::kINT8;
    default:
      return nvinfer1::DataType::kFLOAT;
  }
}

void ImgPreprocess::attachToContext(cudnnContext* cudnnContext,
                                    cublasContext* cublasContext,
                                    nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void ImgPreprocess::detachFromContext() noexcept {}

nvinfer1::PluginFieldCollection ImgPreprocessPluginCreator::mFC{};

ImgPreprocessPluginCreator::ImgPreprocessPluginCreator() {
  // mFC.nbFields = 0;
  // mFC.fields = nullptr;
  pluginName_ = IMG_PREPROCESS_PLUGIN_NAME;
  PluginAttributes_.emplace_back(nvinfer1::PluginField("QScalse"));
  PluginAttributes_.emplace_back(nvinfer1::PluginField("Int8Input"));
  PluginAttributes_.emplace_back(nvinfer1::PluginField("OutputDatatype"));
  PluginAttributes_.emplace_back(nvinfer1::PluginField("Mean"));
  PluginAttributes_.emplace_back(nvinfer1::PluginField("Var"));
  PluginAttributes_.emplace_back(nvinfer1::PluginField("BGR2RGB"));
  mFC.nbFields = PluginAttributes_.size();
  mFC.fields = PluginAttributes_.data();
}
const char* ImgPreprocessPluginCreator::getPluginVersion() const noexcept {
  return IMG_PREPROCESS_PLUGIN_VERSION;
}
const char* ImgPreprocessPluginCreator::getPluginName() const noexcept {
  return pluginName_.c_str();
}
const nvinfer1::PluginFieldCollection* ImgPreprocessPluginCreator::getFieldNames() noexcept {
  return &ImgPreprocessPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* ImgPreprocessPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  float qscalse = 1.0;
  int output_datatype = 0;
  bool int8_input = false;
  bool bgr2rgb = false;
  float mean[] = {0.0, 0.0, 0.0};
  float var[] = {1.0, 1.0, 1.0};
  for (int i = 0; i < fc->nbFields; i++) {
    if (fc->fields[i].data == nullptr) {
      continue;
    }
    std::string field_name(fc->fields[i].name);

    if (field_name.compare("QScalse") == 0) {
      qscalse = *static_cast<const float*>(fc->fields[i].data);
    } else if (field_name.compare("Int8Input") == 0) {
      int8_input = *static_cast<const bool*>(fc->fields[i].data);
    } else if (field_name.compare("OutputDatatype") == 0) {
      output_datatype = *static_cast<const int*>(fc->fields[i].data);
    } else if (field_name.compare("Mean") == 0) {
      memcpy(mean, static_cast<const float*>(fc->fields[i].data), 3 * sizeof(float));
    } else if (field_name.compare("Var") == 0) {
      memcpy(var, static_cast<const float*>(fc->fields[i].data), 3 * sizeof(float));
    } else if (field_name.compare("BGR2RGB") == 0) {
      bgr2rgb = *static_cast<const bool*>(fc->fields[i].data);
    }
  }
  auto obj = new ImgPreprocess(qscalse, output_datatype, mean, var, int8_input, bgr2rgb);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* ImgPreprocessPluginCreator::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  auto obj = new ImgPreprocess(serialData, serialLength);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void ImgPreprocessPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* ImgPreprocessPluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
