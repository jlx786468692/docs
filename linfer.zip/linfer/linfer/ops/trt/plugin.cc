/*
 * Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "linfer/ops/trt/plugin.h"

#include <NvInfer.h>
#include <NvInferPlugin.h>

#include <algorithm>
#include <array>
#include <iostream>
#include <memory>
#include <mutex>
#include <stack>
#include <unordered_set>

#include "linfer/ops/trt/att_v2/att.h"
#include "linfer/ops/trt/batched_nms/trt_batched_nms.hpp"
#include "linfer/ops/trt/scatter/scatter.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

namespace linfer {
namespace util {
extern nvinfer1::ILogger* gLogger;
}  // namespace util

namespace ops {
namespace trt {

// This singleton ensures that each plugin is only registered once for a given
// namespace and type, and attempts of duplicate registration are ignored.
class PluginCreatorRegistry {
 public:
  static PluginCreatorRegistry& getInstance() {
    static PluginCreatorRegistry instance;
    return instance;
  }

  template <typename CreatorType>
  void addPluginCreator(void* logger, const char* libNamespace) {
    // Make accesses to the plugin creator registry thread safe
    std::lock_guard<std::mutex> lock(mRegistryLock);

    std::string errorMsg;
    std::string verboseMsg;

    std::unique_ptr<CreatorType> pluginCreator{new CreatorType{}};
    pluginCreator->setPluginNamespace(libNamespace);

    linfer::util::gLogger = static_cast<nvinfer1::ILogger*>(logger);
    std::string pluginType = std::string{pluginCreator->getPluginNamespace()} +
                             "::" + std::string{pluginCreator->getPluginName()} + " version " +
                             std::string{pluginCreator->getPluginVersion()};

    if (mRegistryList.find(pluginType) == mRegistryList.end()) {
      bool status = getPluginRegistry()->registerCreator(*pluginCreator, libNamespace);
      if (status) {
        mRegistry.push(std::move(pluginCreator));
        mRegistryList.insert(pluginType);
        verboseMsg = "Registered plugin creator - " + pluginType;
      } else {
        errorMsg = "Could not register plugin creator -  " + pluginType;
      }
    } else {
      verboseMsg = "Plugin creator already registered - " + pluginType;
    }

    if (logger) {
      if (!errorMsg.empty()) {
        linfer::util::gLogger->log(nvinfer1::ILogger::Severity::kERROR, errorMsg.c_str());
      }
      if (!verboseMsg.empty()) {
        linfer::util::gLogger->log(nvinfer1::ILogger::Severity::kVERBOSE, verboseMsg.c_str());
      }
    }

    printf("err msg: %s\n", errorMsg.c_str());
    printf("ver msg: %s\n", verboseMsg.c_str());
  }

  ~PluginCreatorRegistry() {
    std::lock_guard<std::mutex> lock(mRegistryLock);

    // Release pluginCreators in LIFO order of registration.
    while (!mRegistry.empty()) {
      mRegistry.pop();
    }
    mRegistryList.clear();
  }

 private:
  PluginCreatorRegistry() {}

  std::mutex mRegistryLock;
  std::stack<std::unique_ptr<nvinfer1::IPluginCreator>> mRegistry;
  std::unordered_set<std::string> mRegistryList;

 public:
  PluginCreatorRegistry(PluginCreatorRegistry const&) = delete;
  void operator=(PluginCreatorRegistry const&) = delete;
};

template <typename CreatorType>
void initializePlugin(void* logger, const char* libNamespace) {
  PluginCreatorRegistry::getInstance().addPluginCreator<CreatorType>(logger, libNamespace);
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer

// New Plugin APIs

extern "C" {
bool initTRTInferPlugins(void* logger, const char* libNamespace) {
  // linfer::ops::trt::initializePlugin<linfer::ops::trt::ScatterNDPluginCreator>(logger,
  // libNamespace);
  // linfer::ops::trt::initializePlugin<linfer::ops::trt::LanegcnAttPluginCreator>(logger,
  // libNamespace); linfer::ops::trt::initializePlugin<linfer::TRTBatchedNMSCreator>(logger,
  // libNamespace);
  return true;
}
}  // extern "C"
