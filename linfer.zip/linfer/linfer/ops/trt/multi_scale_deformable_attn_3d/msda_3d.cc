#include "msda_3d.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "msda_3d_kernel.cuh"

using linfer::ops::trt::MultiScaleDeformableAtt3DPluginCreator;
REGISTER_TENSORRT_PLUGIN(MultiScaleDeformableAtt3DPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

enum INOUT_POS {
  value = 0,
  value_spatial_whi = 1,
  sample_height = 2,
  attention_weight = 3,
  lidar2img = 4,
  point_cloud_range = 5,
  kernel_offset = 6,
  output_base = 7,
  output_bev_feature_base_input = output_base,
  output_bev_feature = output_bev_feature_base_input - output_base,
};

const char* MSDA_3D_PLUGIN_VERSION{"1"};
static const char* MSDA_3D_PLUGIN_NAME{"LinferMultiScaleDeformableAttn3D"};

nvinfer1::PluginFieldCollection MultiScaleDeformableAtt3DPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> MultiScaleDeformableAtt3DPluginCreator::mPluginAttributes;

MultiScaleDeformableAtt3D::MultiScaleDeformableAtt3D(unsigned int img_w,
                                                     unsigned int img_h,
                                                     unsigned int bev_w,
                                                     unsigned int bev_h)
    : img_w_(img_w), img_h_(img_h), bev_w_(bev_w), bev_h_(bev_h) {}

MultiScaleDeformableAtt3D::~MultiScaleDeformableAtt3D() {}

int MultiScaleDeformableAtt3D::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType MultiScaleDeformableAtt3D::getOutputDataType(
    int index,
    const nvinfer1::DataType* inputTypes,
    int nbInputs) const noexcept {
  return inputTypes[0];
}

nvinfer1::DimsExprs MultiScaleDeformableAtt3D::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs output_dims;
  output_dims.nbDims = 3;
  output_dims.d[0] = inputs[2].d[0];
  output_dims.d[1] = inputs[2].d[1];
  auto head_size = inputs[0].d[3]->getConstantValue();
  auto channel_size = inputs[0].d[4]->getConstantValue();
  output_dims.d[2] = exprBuilder.constant(head_size * channel_size);
  return output_dims;  // [B, Q, HxC], for example: [1, 2500, 256]
}

bool MultiScaleDeformableAtt3D::supportsFormatCombination(int32_t pos,
                                                          const nvinfer1::PluginTensorDesc* inOut,
                                                          int32_t nbInputs,
                                                          int32_t nbOutputs) noexcept {
  auto dtype = inOut[pos].type;
  auto dformat = inOut[pos].format;

  switch (pos) {
    case INOUT_POS::value:
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
             dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::value_spatial_whi:
      return (dtype == nvinfer1::DataType::kINT32) && dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::sample_height:
      return dtype == nvinfer1::DataType::kFLOAT && dformat == inOut[INOUT_POS::value].format;
    case INOUT_POS::attention_weight:
      return dtype == inOut[INOUT_POS::value].type && dformat == inOut[INOUT_POS::value].format;
    case INOUT_POS::lidar2img:
      return dtype == nvinfer1::DataType::kFLOAT && dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::point_cloud_range:
      return dtype == nvinfer1::DataType::kFLOAT && dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::kernel_offset:
      return (dtype == nvinfer1::DataType::kINT32) && dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::output_bev_feature_base_input:
      return dtype == inOut[INOUT_POS::value].type && dformat == inOut[INOUT_POS::value].format;
    default:
      return false;
  }
}

void MultiScaleDeformableAtt3D::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                                int32_t nbInputs,
                                                const nvinfer1::DynamicPluginTensorDesc* out,
                                                int32_t nbOutputs) noexcept {}

size_t MultiScaleDeformableAtt3D::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                                   int32_t nbInputs,
                                                   const nvinfer1::PluginTensorDesc* outputs,
                                                   int32_t nbOutputs) const noexcept {
  // 用于存储msda3d第一个核函数的结果
  unsigned int cam_num = inputs[INOUT_POS::value].dims.d[1];
  unsigned int head_num = inputs[INOUT_POS::value].dims.d[3];
  unsigned int query_num = inputs[INOUT_POS::attention_weight].dims.d[1];
  unsigned int batch_num = inputs[INOUT_POS::value].dims.d[0];
  return batch_num * query_num * cam_num * (1 + 2 * head_num) * sizeof(float);
}

int MultiScaleDeformableAtt3D::initialize() noexcept { return 0; }

void MultiScaleDeformableAtt3D::terminate() noexcept {}

int32_t MultiScaleDeformableAtt3D::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                           const nvinfer1::PluginTensorDesc* outputDesc,
                                           const void* const* inputs,
                                           void* const* outputs,
                                           void* workspace,
                                           cudaStream_t stream) noexcept {
  const void* value = inputs[INOUT_POS::value];
  const int32_t* value_spatial_whi = (const int32_t*)inputs[INOUT_POS::value_spatial_whi];
  const float* sample_height = (const float*)inputs[INOUT_POS::sample_height];
  const void* attention_weight = inputs[INOUT_POS::attention_weight];
  const float* lidar2img = (const float*)inputs[INOUT_POS::lidar2img];
  const float* point_cloud_range = (const float*)inputs[INOUT_POS::point_cloud_range];
  const int32_t* kernel_offset = (const int32_t*)inputs[INOUT_POS::kernel_offset];
  void* output_bev_feature = outputs[INOUT_POS::output_bev_feature];

  // input, shape: [B, N, V, H, C]
  unsigned int batch_num = inputDesc[INOUT_POS::value].dims.d[0];
  unsigned int cam_num = inputDesc[INOUT_POS::value].dims.d[1];
  unsigned int value_num = inputDesc[INOUT_POS::value].dims.d[2];
  unsigned int head_num = inputDesc[INOUT_POS::value].dims.d[3];
  unsigned int channel_num = inputDesc[INOUT_POS::value].dims.d[4];
  unsigned int level_num = inputDesc[INOUT_POS::value_spatial_whi].dims.d[0];
  unsigned int query_num = inputDesc[INOUT_POS::attention_weight].dims.d[1];
  unsigned int kernel_size = inputDesc[INOUT_POS::kernel_offset].dims.d[0];

  size_t workspace_size = batch_num * query_num * cam_num * (1 + 2 * head_num) * sizeof(float);
  cudaMemsetAsync(workspace, 0, workspace_size, stream);
  float2* point2d_norm = reinterpret_cast<float2*>(workspace);
  uint32_t* cam_hit_arr =
      reinterpret_cast<uint32_t*>(point2d_norm + batch_num * query_num * cam_num * head_num);

  // TODO add same check
  if (query_num != (bev_h_ * bev_w_)) {
    LERROR_FMT(
        "query_size not equal to bev_h * bev_w, query_size: %u, bev_h: %u, bev_w: "
        "%u",
        query_num,
        bev_h_,
        bev_w_);
  }

  // 由于存在40%左右的bev
  // feature为0，因此先将memory统一置零，在kernel中结果为0的不再写入 Float point
  // arithmetic on the GPU adheres to IEEE-754, so a pattern of all 0s represents a
  // float point zero.
  auto datatype = inputDesc[0].type;
  switch (datatype) {
    case nvinfer1::DataType::kHALF:
      cudaMemsetAsync(output_bev_feature,
                      0,
                      sizeof(__half) * batch_num * query_num * head_num * channel_num,
                      stream);
      launch_msda3d_kernel((const __half*)value,
                           value_spatial_whi,
                           sample_height,
                           (const __half*)attention_weight,
                           lidar2img,
                           point_cloud_range,
                           kernel_offset,
                           cam_hit_arr,
                           point2d_norm,
                           (__half*)output_bev_feature,
                           batch_num,
                           cam_num,
                           value_num,
                           head_num,
                           channel_num,
                           level_num,
                           img_w_,
                           img_h_,
                           bev_w_,
                           bev_h_,
                           query_num,
                           kernel_size,
                           stream);
      break;

    case nvinfer1::DataType::kFLOAT:
      cudaMemsetAsync(output_bev_feature,
                      0,
                      sizeof(float) * batch_num * query_num * head_num * channel_num,
                      stream);
      launch_msda3d_kernel((const float*)value,
                           value_spatial_whi,
                           sample_height,
                           (const float*)attention_weight,
                           lidar2img,
                           point_cloud_range,
                           kernel_offset,
                           cam_hit_arr,
                           point2d_norm,
                           (float*)output_bev_feature,
                           batch_num,
                           cam_num,
                           value_num,
                           head_num,
                           channel_num,
                           level_num,
                           img_w_,
                           img_h_,
                           bev_w_,
                           bev_h_,
                           query_num,
                           kernel_size,
                           stream);
      break;

    default:
      return 1;
      break;
  }
  return 0;
}

template <typename T>
void tensor2npy(const std::string& filepath,
                const std::shared_ptr<linfer::util::TensorHostDevice>& tensor) {
  auto dims = tensor->get_dims();
  std::vector<size_t> shape(dims.nbDims, 0);
  for (auto i = 0; i < dims.nbDims; ++i) {
    shape[i] = dims.d[i];
  }
  std::vector<T> data(tensor->get_len_in_element(), 0);
  std::memcpy(data.data(), tensor->get_cpu_buf(), tensor->get_len_in_byte());
  linfer::util::numpy_save(filepath, shape, data, false);
}

size_t MultiScaleDeformableAtt3D::getSerializationSize() const noexcept {
  // unsigned int img_w_, img_h_, bev_w_, bev_h_;
  return sizeof(unsigned int) * 4;
}

void MultiScaleDeformableAtt3D::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<unsigned int>(buf, img_w_);
  write<unsigned int>(buf, img_h_);
  write<unsigned int>(buf, bev_w_);
  write<unsigned int>(buf, bev_h_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* MultiScaleDeformableAtt3D::getPluginType() const noexcept {
  return MSDA_3D_PLUGIN_NAME;
}

const char* MultiScaleDeformableAtt3D::getPluginVersion() const noexcept {
  return MSDA_3D_PLUGIN_VERSION;
}

void MultiScaleDeformableAtt3D::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* MultiScaleDeformableAtt3D::clone() const noexcept {
  auto plugin = new MultiScaleDeformableAtt3D(img_w_, img_h_, bev_w_, bev_h_);
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void MultiScaleDeformableAtt3D::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* MultiScaleDeformableAtt3D::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

void MultiScaleDeformableAtt3D::attachToContext(cudnnContext* cudnnContext,
                                                cublasContext* cublasContext,
                                                nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void MultiScaleDeformableAtt3D::detachFromContext() noexcept {}

MultiScaleDeformableAtt3DPluginCreator::MultiScaleDeformableAtt3DPluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("img_wh", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("bev_wh", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* MultiScaleDeformableAtt3DPluginCreator::getPluginVersion() const noexcept {
  return MSDA_3D_PLUGIN_VERSION;
}
const char* MultiScaleDeformableAtt3DPluginCreator::getPluginName() const noexcept {
  return MSDA_3D_PLUGIN_NAME;
}
const nvinfer1::PluginFieldCollection*
MultiScaleDeformableAtt3DPluginCreator::getFieldNames() noexcept {
  return &MultiScaleDeformableAtt3DPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* MultiScaleDeformableAtt3DPluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  unsigned int bev_w, bev_h, img_w, img_h;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("img_wh") == 0) {
      const int32_t* ptr = static_cast<const int32_t*>(field_data);
      img_w = static_cast<unsigned int>(ptr[0]);
      img_h = static_cast<unsigned int>(ptr[1]);
    } else if (field_name.compare("bev_wh") == 0) {
      const int32_t* ptr = static_cast<const int32_t*>(field_data);
      bev_w = static_cast<unsigned int>(ptr[0]);
      bev_h = static_cast<unsigned int>(ptr[1]);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }
  LINFO_FMT("img_w: %u, img_h, bev_w: %u, bev_h: %u: %u\n", img_w, img_h, bev_w, bev_h);

  MultiScaleDeformableAtt3D* obj = new MultiScaleDeformableAtt3D(img_w, img_h, bev_w, bev_h);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* MultiScaleDeformableAtt3DPluginCreator::deserializePlugin(
    const char* plugin_name,
    const void* serialData,
    size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;
  auto img_w = read<unsigned int>(buf);
  auto img_h = read<unsigned int>(buf);
  auto bev_w = read<unsigned int>(buf);
  auto bev_h = read<unsigned int>(buf);

  LINFO_FMT("img_w: %u, img_h: %u, bev_w: %u, bev_h: %u\n", img_w, img_h, bev_w, bev_h);
  auto obj = new MultiScaleDeformableAtt3D(img_w, img_h, bev_w, bev_h);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void MultiScaleDeformableAtt3DPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* MultiScaleDeformableAtt3DPluginCreator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
