#include "msda_3d_v3.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "msda_3d_kernel.cuh"

using linfer::ops::trt::MultiScaleDeformableAtt3DV3Creator;
REGISTER_TENSORRT_PLUGIN(MultiScaleDeformableAtt3DV3Creator);

namespace linfer {
namespace ops {
namespace trt {

enum INOUT_POS {
  value = 0,
  value_spatial_whi = 1,
  sample_height = 2,
  attention_weight = 3,
  lidar2img = 4,
  point_cloud_range = 5,
  kernel_offset = 6,
  output_base = 7,
  output_bev_feature_base_input = output_base,
  output_bev_feature = output_bev_feature_base_input - output_base,
};

const char* MSDA_3D_PLUGINV3_VERSION{"1"};
static const char* MSDA_3D_PLUGINV3_NAME{"LinferMultiScaleDeformableAttn3DV3"};

nvinfer1::PluginFieldCollection MultiScaleDeformableAtt3DV3Creator::mFC{};
std::vector<nvinfer1::PluginField> MultiScaleDeformableAtt3DV3Creator::mPluginAttributes;

nvinfer1::IPluginCapability* MultiScaleDeformableAtt3DV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<nvinfer1::IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<nvinfer1::IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<nvinfer1::IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

MultiScaleDeformableAtt3DV3::MultiScaleDeformableAtt3DV3(unsigned int img_w,
                                                         unsigned int img_h,
                                                         unsigned int bev_w,
                                                         unsigned int bev_h)
    : img_w_(img_w), img_h_(img_h), bev_w_(bev_w), bev_h_(bev_h) {}

MultiScaleDeformableAtt3DV3::~MultiScaleDeformableAtt3DV3() {}

// IPluginV3OneCore methods
char const* MultiScaleDeformableAtt3DV3::getPluginName() const noexcept {
  return MSDA_3D_PLUGINV3_NAME;
}

char const* MultiScaleDeformableAtt3DV3::getPluginVersion() const noexcept {
  return MSDA_3D_PLUGINV3_VERSION;
}

int32_t MultiScaleDeformableAtt3DV3::getNbOutputs() const noexcept { return 1; }

void MultiScaleDeformableAtt3DV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

char const* MultiScaleDeformableAtt3DV3::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

nvinfer1::IPluginV3* MultiScaleDeformableAtt3DV3::clone() noexcept {
  try {
    auto* plugin = new MultiScaleDeformableAtt3DV3(img_w_, img_h_, bev_w_, bev_h_);
    plugin->setPluginNamespace(namespace_.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t MultiScaleDeformableAtt3DV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                                        int32_t nbOutputs,
                                                        nvinfer1::DataType const* inputTypes,
                                                        int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as the first input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t MultiScaleDeformableAtt3DV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                                     int32_t nbInputs,
                                                     nvinfer1::DimsExprs const* shapeInputs,
                                                     int32_t nbShapeInputs,
                                                     nvinfer1::DimsExprs* outputs,
                                                     int32_t nbOutputs,
                                                     nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    outputs[0].nbDims = 3;
    outputs[0].d[0] = inputs[2].d[0];
    outputs[0].d[1] = inputs[2].d[1];
    auto head_size = inputs[0].d[3]->getConstantValue();
    auto channel_size = inputs[0].d[4]->getConstantValue();
    outputs[0].d[2] = exprBuilder.constant(head_size * channel_size);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool MultiScaleDeformableAtt3DV3::supportsFormatCombination(
    int32_t pos,
    nvinfer1::DynamicPluginTensorDesc const* inOut,
    int32_t nbInputs,
    int32_t nbOutputs) noexcept {
  try {
    // Check format
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;
    switch (pos) {
      case INOUT_POS::value:
        // return (desc.type == nvinfer1::DataType::kFLOAT ||
        //         desc.type == nvinfer1::DataType::kHALF) &&
        //        desc.format == nvinfer1::TensorFormat::kLINEAR;
        return desc.type == nvinfer1::DataType::kHALF &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case INOUT_POS::value_spatial_whi:
        return desc.type == nvinfer1::DataType::kINT32 &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case INOUT_POS::sample_height:
        return desc.type == nvinfer1::DataType::kFLOAT &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case INOUT_POS::attention_weight:
        return desc.type == inOut[INOUT_POS::value].desc.type &&
               desc.format == inOut[INOUT_POS::value].desc.format;
      case INOUT_POS::lidar2img:
        return desc.type == nvinfer1::DataType::kFLOAT &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case INOUT_POS::point_cloud_range:
        return desc.type == nvinfer1::DataType::kFLOAT &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case INOUT_POS::kernel_offset:
        return desc.type == nvinfer1::DataType::kINT32 &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case INOUT_POS::output_bev_feature_base_input:
        return desc.type == inOut[INOUT_POS::value].desc.type &&
               desc.format == inOut[INOUT_POS::value].desc.format;
      default:
        return false;
    }

  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t MultiScaleDeformableAtt3DV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                                     int32_t nbInputs,
                                                     nvinfer1::DynamicPluginTensorDesc const* out,
                                                     int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const*
MultiScaleDeformableAtt3DV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();

    // img_wh
    img_wh[0] = static_cast<int32_t>(img_w_);
    img_wh[1] = static_cast<int32_t>(img_h_);
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("img_wh", img_wh, nvinfer1::PluginFieldType::kINT32, 2));

    // bev_wh
    bev_wh[0] = static_cast<int32_t>(bev_w_);
    bev_wh[1] = static_cast<int32_t>(bev_h_);
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("bev_wh", bev_wh, nvinfer1::PluginFieldType::kINT32, 2));

    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();

    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t MultiScaleDeformableAtt3DV3::getWorkspaceSize(
    nvinfer1::DynamicPluginTensorDesc const* inputs,
    int32_t nbInputs,
    nvinfer1::DynamicPluginTensorDesc const* outputs,
    int32_t nbOutputs) const noexcept {
  // 用于存储msda3d第一个核函数的结果
  unsigned int cam_num = inputs[INOUT_POS::value].desc.dims.d[1];
  unsigned int head_num = inputs[INOUT_POS::value].desc.dims.d[3];
  unsigned int query_num = inputs[INOUT_POS::attention_weight].desc.dims.d[1];
  unsigned int batch_num = inputs[INOUT_POS::value].desc.dims.d[0];
  return batch_num * query_num * cam_num * (1 + 2 * head_num) * sizeof(float);
}

int32_t MultiScaleDeformableAtt3DV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                                   int32_t nbInputs,
                                                   nvinfer1::PluginTensorDesc const* outputs,
                                                   int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* MultiScaleDeformableAtt3DV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t MultiScaleDeformableAtt3DV3::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                             const nvinfer1::PluginTensorDesc* outputDesc,
                                             const void* const* inputs,
                                             void* const* outputs,
                                             void* workspace,
                                             cudaStream_t stream) noexcept {
  const void* value = inputs[INOUT_POS::value];
  const int32_t* value_spatial_whi = (const int32_t*)inputs[INOUT_POS::value_spatial_whi];
  const float* sample_height = (const float*)inputs[INOUT_POS::sample_height];
  const void* attention_weight = inputs[INOUT_POS::attention_weight];
  const float* lidar2img = (const float*)inputs[INOUT_POS::lidar2img];
  const float* point_cloud_range = (const float*)inputs[INOUT_POS::point_cloud_range];
  const int32_t* kernel_offset = (const int32_t*)inputs[INOUT_POS::kernel_offset];
  void* output_bev_feature = outputs[INOUT_POS::output_bev_feature];

  // input, shape: [B, N, V, H, C]
  unsigned int batch_num = inputDesc[INOUT_POS::value].dims.d[0];
  unsigned int cam_num = inputDesc[INOUT_POS::value].dims.d[1];
  unsigned int value_num = inputDesc[INOUT_POS::value].dims.d[2];
  unsigned int head_num = inputDesc[INOUT_POS::value].dims.d[3];
  unsigned int channel_num = inputDesc[INOUT_POS::value].dims.d[4];
  unsigned int level_num = inputDesc[INOUT_POS::value_spatial_whi].dims.d[0];
  unsigned int query_num = inputDesc[INOUT_POS::attention_weight].dims.d[1];
  unsigned int kernel_size = inputDesc[INOUT_POS::kernel_offset].dims.d[0];

  size_t workspace_size = batch_num * query_num * cam_num * (1 + 2 * head_num) * sizeof(float);
  cudaMemsetAsync(workspace, 0, workspace_size, stream);
  float2* point2d_norm = reinterpret_cast<float2*>(workspace);
  uint32_t* cam_hit_arr =
      reinterpret_cast<uint32_t*>(point2d_norm + batch_num * query_num * cam_num * head_num);

  // TODO add same check
  if (query_num != (bev_h_ * bev_w_)) {
    LERROR_FMT(
        "query_size not equal to bev_h * bev_w, query_size: %u, bev_h: %u, bev_w: "
        "%u",
        query_num,
        bev_h_,
        bev_w_);
  }

  // 由于存在40%左右的bev
  // feature为0，因此先将memory统一置零，在kernel中结果为0的不再写入 Float point
  // arithmetic on the GPU adheres to IEEE-754, so a pattern of all 0s represents a
  // float point zero.
  auto datatype = inputDesc[0].type;
  switch (datatype) {
    case nvinfer1::DataType::kHALF:
      cudaMemsetAsync(output_bev_feature,
                      0,
                      sizeof(__half) * batch_num * query_num * head_num * channel_num,
                      stream);
      launch_msda3d_kernel((const __half*)value,
                           value_spatial_whi,
                           sample_height,
                           (const __half*)attention_weight,
                           lidar2img,
                           point_cloud_range,
                           kernel_offset,
                           cam_hit_arr,
                           point2d_norm,
                           (__half*)output_bev_feature,
                           batch_num,
                           cam_num,
                           value_num,
                           head_num,
                           channel_num,
                           level_num,
                           img_w_,
                           img_h_,
                           bev_w_,
                           bev_h_,
                           query_num,
                           kernel_size,
                           stream);
      break;

    case nvinfer1::DataType::kFLOAT:
      cudaMemsetAsync(output_bev_feature,
                      0,
                      sizeof(float) * batch_num * query_num * head_num * channel_num,
                      stream);
      launch_msda3d_kernel((const float*)value,
                           value_spatial_whi,
                           sample_height,
                           (const float*)attention_weight,
                           lidar2img,
                           point_cloud_range,
                           kernel_offset,
                           cam_hit_arr,
                           point2d_norm,
                           (float*)output_bev_feature,
                           batch_num,
                           cam_num,
                           value_num,
                           head_num,
                           channel_num,
                           level_num,
                           img_w_,
                           img_h_,
                           bev_w_,
                           bev_h_,
                           query_num,
                           kernel_size,
                           stream);
      break;

    default:
      return 1;
      break;
  }
  return 0;
}

MultiScaleDeformableAtt3DV3Creator::MultiScaleDeformableAtt3DV3Creator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("img_wh", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("bev_wh", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* MultiScaleDeformableAtt3DV3Creator::getPluginVersion() const noexcept {
  return MSDA_3D_PLUGINV3_VERSION;
}
const char* MultiScaleDeformableAtt3DV3Creator::getPluginName() const noexcept {
  return MSDA_3D_PLUGINV3_NAME;
}
const nvinfer1::PluginFieldCollection*
MultiScaleDeformableAtt3DV3Creator::getFieldNames() noexcept {
  return &MultiScaleDeformableAtt3DV3Creator::mFC;
}

nvinfer1::IPluginV3* MultiScaleDeformableAtt3DV3Creator::createPlugin(
    char const* plugin_name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  unsigned int bev_w, bev_h, img_w, img_h;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("img_wh") == 0) {
      const int32_t* ptr = static_cast<const int32_t*>(field_data);
      img_w = static_cast<unsigned int>(ptr[0]);
      img_h = static_cast<unsigned int>(ptr[1]);
    } else if (field_name.compare("bev_wh") == 0) {
      const int32_t* ptr = static_cast<const int32_t*>(field_data);
      bev_w = static_cast<unsigned int>(ptr[0]);
      bev_h = static_cast<unsigned int>(ptr[1]);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }
  // LINFO_FMT("img_w: %u, img_h: %u, bev_w: %u, bev_h: %u\n", img_w, img_h, bev_w, bev_h);

  MultiScaleDeformableAtt3DV3* obj = new MultiScaleDeformableAtt3DV3(img_w, img_h, bev_w, bev_h);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void MultiScaleDeformableAtt3DV3Creator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* MultiScaleDeformableAtt3DV3Creator::getPluginNamespace() const noexcept {
  return namespace_.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
