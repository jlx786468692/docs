#include <cmath>

#include "linfer/ops/trt/common/common_types.h"
#include "linfer/util/log.h"
#include "msda_3d_kernel.cuh"

namespace linfer {
namespace ops {
namespace trt {

#define printf

__device__ inline void project_3d_to_2d(const float* proj_mat,
                                        float point3d_x,
                                        float point3d_y,
                                        float point3d_z,
                                        float& img_x,
                                        float& img_y) {
  // 可优化
  float tmp_x =
      proj_mat[0] * point3d_x + proj_mat[1] * point3d_y + proj_mat[2] * point3d_z + proj_mat[3];
  float tmp_y =
      proj_mat[4] * point3d_x + proj_mat[5] * point3d_y + proj_mat[6] * point3d_z + proj_mat[7];
  float tmp_z =
      proj_mat[8] * point3d_x + proj_mat[9] * point3d_y + proj_mat[10] * point3d_z + proj_mat[11];

  img_x = tmp_x / max(tmp_z, 1e-5f);
  img_y = tmp_y / max(tmp_z, 1e-5f);
}

__device__ inline float __div(const __half x, float y) { return __half2float(x) / y; }

__device__ inline float __div(const float x, float y) { return x / y; }

// 双线性插值中有两种实现，由于累加舍入误差，两种精度存在细微差别，方法2在orin-n中快0.1ms
template <typename T>
__device__ T bilinear_interpolate(const T* value_level_base_ptr,
                                  float x,
                                  float y,
                                  unsigned int level_w,
                                  unsigned int level_h,
                                  unsigned int head_ch) {
  auto x_left = __float2int_rd(x);
  auto x_right = x_left + 1;
  auto y_upper = __float2int_rd(y);
  auto y_lower = y_upper + 1;

  // //方法1
  // T value_upper_left = 0.0;
  // if (x_left >= 0 && x_left < level_w && y_upper >= 0 && y_upper < level_h) {
  //     value_upper_left = value_level_base_ptr[(y_upper * level_w + x_left) *
  //     head_ch];
  // }

  // T value_upper_right = 0.0;
  // if (x_right >= 0 && x_right < level_w && y_upper >= 0 && y_upper < level_h) {
  //     value_upper_right = value_level_base_ptr[(y_upper * level_w + x_right) *
  //     head_ch];
  // }

  // T value_lower_left = 0.0;
  // if (x_left >= 0 && x_left < level_w && y_lower >= 0 && y_lower < level_h) {
  //     value_lower_left = value_level_base_ptr[(y_lower * level_w + x_left) *
  //     head_ch];
  // }

  // T value_lower_right = 0.0;
  // if (x_right >= 0 && x_right < level_w && y_lower >= 0 && y_lower < level_h) {
  //     value_lower_right = value_level_base_ptr[(y_lower * level_w + x_right) *
  //     head_ch];
  // }

  // T w_upper_left = (x_right - x) * (y_lower - y);
  // T w_upper_right = (x - x_left) * (y_lower - y);
  // T w_lower_left = (x_right - x) * (y - y_upper);
  // T w_lower_right = (x - x_left) * (y - y_upper);

  // // printf("value_upper_left: %f, value_upper_right: %f, value_lower_left: %f,
  // value_lower_right: %f\n",
  // //        value_upper_left, value_upper_right, value_lower_left,
  // value_lower_right);
  // // printf("w_upper_left: %f, w_upper_right: %f, w_lower_left: %f, w_lower_right:
  // %f\n", w_upper_left, w_upper_right,
  // //        w_lower_left, w_lower_right);

  // T result = value_upper_left * w_upper_left + value_upper_right * w_upper_right +
  // value_lower_left * w_lower_left +
  //            value_lower_right * w_lower_right;

  // 方法2
  T w_left = x_right - x;
  T w_right = (T)1 - w_left;
  T w_upper = y_lower - y;
  T w_lower = (T)1 - w_upper;

  T result = .0;
  unsigned int y_upper_id = y_upper * level_w * head_ch;
  unsigned int y_lower_id = y_lower * level_w * head_ch;
  unsigned int x_left_id = x_left * head_ch;
  unsigned int x_right_id = x_right * head_ch;

  if (x_left >= 0 && x_right < level_w && y_upper >= 0 && y_lower < level_h) {
    result += w_left * w_upper * value_level_base_ptr[y_upper_id + x_left_id];
    result += w_left * w_lower * value_level_base_ptr[y_lower_id + x_left_id];
    result += w_right * w_upper * value_level_base_ptr[y_upper_id + x_right_id];
    result += w_right * w_lower * value_level_base_ptr[y_lower_id + x_right_id];
  } else {
    if (x_left >= 0 && x_left < level_w) {
      if (y_upper >= 0 && y_upper < level_h) {  // upper left
        result += w_left * w_upper * value_level_base_ptr[y_upper_id + x_left_id];
      }

      if (y_lower >= 0 && y_lower < level_h) {  // lower left
        result += w_left * w_lower * value_level_base_ptr[y_lower_id + x_left_id];
      }
    }

    if (x_right >= 0 && x_right < level_w) {
      if (y_upper >= 0 && y_upper < level_h) {  // upper right
        result += w_right * w_upper * value_level_base_ptr[y_upper_id + x_right_id];
      }

      if (y_lower >= 0 && y_lower < level_h) {  // lower right
        result += w_right * w_lower * value_level_base_ptr[y_lower_id + x_right_id];
      }
    }
  }

  return result;
}

template <>
__device__ __half2 bilinear_interpolate(const __half2* value_level_base_ptr,
                                        float x,
                                        float y,
                                        unsigned int level_w,
                                        unsigned int level_h,
                                        unsigned int head_ch) {
  auto x_left = __float2int_rd(x);
  auto x_right = x_left + 1;
  auto y_upper = __float2int_rd(y);
  auto y_lower = y_upper + 1;

  __half w_left = __float2half(x_right - x);
  __half w_right = __float2half(1.0f) - w_left;
  __half w_upper = __float2half(y_lower - y);
  __half w_lower = __float2half(1.0f) - w_upper;

  __half2 result = __float2half2_rn(0.f);
  unsigned int y_upper_id = y_upper * level_w * head_ch / 2;
  unsigned int y_lower_id = y_lower * level_w * head_ch / 2;
  unsigned int x_left_id = x_left * head_ch / 2;
  unsigned int x_right_id = x_right * head_ch / 2;

  if (x_left >= 0 && x_right < level_w && y_upper >= 0 && y_lower < level_h) {
    result = __hfma2(__half2half2(__hmul(w_left, w_upper)),
                     value_level_base_ptr[y_upper_id + x_left_id],
                     result);
    result = __hfma2(__half2half2(__hmul(w_left, w_lower)),
                     value_level_base_ptr[y_lower_id + x_left_id],
                     result);
    result = __hfma2(__half2half2(__hmul(w_right, w_upper)),
                     value_level_base_ptr[y_upper_id + x_right_id],
                     result);
    result = __hfma2(__half2half2(__hmul(w_right, w_lower)),
                     value_level_base_ptr[y_lower_id + x_right_id],
                     result);
  } else {
    if (x_left >= 0 && x_left < level_w) {
      if (y_upper >= 0 && y_upper < level_h) {  // upper left
        result = __hfma2(__half2half2(__hmul(w_left, w_upper)),
                         value_level_base_ptr[y_upper_id + x_left_id],
                         result);
      }

      if (y_lower >= 0 && y_lower < level_h) {  // lower left
        result = __hfma2(__half2half2(__hmul(w_left, w_lower)),
                         value_level_base_ptr[y_lower_id + x_left_id],
                         result);
      }
    }

    if (x_right >= 0 && x_right < level_w) {
      if (y_upper >= 0 && y_upper < level_h) {  // upper right
        result = __hfma2(__half2half2(__hmul(w_right, w_upper)),
                         value_level_base_ptr[y_upper_id + x_right_id],
                         result);
      }

      if (y_lower >= 0 && y_lower < level_h) {  // lower right
        result = __hfma2(__half2half2(__hmul(w_right, w_lower)),
                         value_level_base_ptr[y_lower_id + x_right_id],
                         result);
      }
    }
  }

  return result;
}

// msda3d预处理算子,计算相机是否命中
__global__ void msda3d_preprocess_kernel(const float* sample_height,
                                         const float* lidar2img,
                                         const float* point_cloud_range,
                                         uint32_t* cam_hit_arr,
                                         float2* point2d_norm,
                                         unsigned int batch_size,
                                         unsigned int cam_num,
                                         unsigned int head_num,
                                         unsigned int img_w,
                                         unsigned int img_h,
                                         unsigned int bev_w,
                                         unsigned int bev_h,
                                         unsigned int query_num) {
  unsigned batch_idx = blockIdx.z;
  unsigned bev_y = blockIdx.y;
  unsigned bev_x = blockIdx.x * blockDim.z + threadIdx.z;
  // 如果越界，则无需处理
  if (bev_x >= bev_w) {
    return;
  }
  unsigned query_idx = bev_y * bev_w + bev_x;
  unsigned head_index = threadIdx.x;
  unsigned cam_index = threadIdx.y;

  // 采样中心点归一化之后的2D坐标
  float bev_x_idx = query_idx % bev_w + 0.5f;
  float bev_y_idx = query_idx / bev_w + 0.5f;
  float point3d_x =
      point_cloud_range[0] + bev_x_idx * (point_cloud_range[3] - point_cloud_range[0]) / bev_w;
  float point3d_y =
      point_cloud_range[1] + bev_y_idx * (point_cloud_range[4] - point_cloud_range[1]) / bev_h;
  float height_range = point_cloud_range[5] - point_cloud_range[2];
  float bev_z_norm = head_index / (head_num - 1.0f);
  unsigned height_offset = (batch_idx * query_num + query_idx) * head_num + head_index;
  bev_z_norm += __div(sample_height[height_offset], height_range);
  float point3d_z = point_cloud_range[2] + bev_z_norm * height_range;
  float2 img_pos;
  project_3d_to_2d(lidar2img + (batch_idx * cam_num + cam_index) * 16,
                   point3d_x,
                   point3d_y,
                   point3d_z,
                   img_pos.x,
                   img_pos.y);
  img_pos.x /= img_w;
  img_pos.y /= img_h;
  unsigned cam_hit_index = (batch_idx * query_num + query_idx) * cam_num + cam_index;
  unsigned point2d_index = cam_hit_index * head_num + head_index;
  point2d_norm[point2d_index] = img_pos;
  // 判断2D坐标是否在图像范围内
  uint32_t cam_hit = 0;
  if (img_pos.x >= 0 && img_pos.y >= 0 && img_pos.x < 1 && img_pos.y < 1) {
    cam_hit = 1;
  }
  // 等待block内所有线程都完成采样点是否在图像范围内的判断
  __syncthreads();

  // 判断各个相机是否该head命中，在不同head进行reduce
  for (int i = head_num / 2; i >= 1; i /= 2) {
    cam_hit |= __shfl_down_sync(0xFFFFFFFF, cam_hit, i, head_num);
  }

  if (head_index == 0) {
    cam_hit_arr[cam_hit_index] = cam_hit;
  }
}

// 每个线程处理一个HEAD内的1个channel。
template <typename T>
__global__ void msda3d_kernel(const T* value,
                              const int32_t* value_spatial_whi,
                              const T* attention_weight,
                              const int32_t* kernel_offset,
                              uint32_t* cam_hit_arr,
                              float2* point2d_norm,
                              T* bev_feat,
                              unsigned int batch_size,
                              unsigned int cam_num,
                              unsigned int value_num,
                              unsigned int head_num,
                              unsigned int channel_num,
                              unsigned int level_size,
                              unsigned int bev_w,
                              unsigned int query_num,
                              unsigned int kernel_size) {
  unsigned batch_idx = blockIdx.z;
  unsigned bev_y = blockIdx.y;
  unsigned bev_x = blockIdx.x;
  unsigned query_idx = bev_y * bev_w + bev_x;
  unsigned head_idx = threadIdx.y;

  // shared_mem[0] ~ shared_mem[head_num * level_size * kernel_size -
  // 1]:用于保存weight shared_mem[head_num * level_size * kernel_size] ~
  // shared_mem[head_num * level_size * kernel_size + kernel_size * 2 -
  // 1]:用于保存kernel_offset
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int32_t2* kernel_offset_shared = reinterpret_cast<int32_t2*>(shared_mem);
  T* weight_arr = reinterpret_cast<T*>(kernel_offset_shared + kernel_size);

  unsigned head_ch = head_num * channel_num;
  T* bev_feat_base_ptr =
      bev_feat + (batch_idx * query_num + query_idx) * head_ch + head_idx * channel_num;
  unsigned head_level_point = head_num * level_size * kernel_size;
  const T* weight_base_ptr =
      attention_weight + (batch_idx * query_num + query_idx) * head_level_point;

  // 读取weight数据
  if (threadIdx.y == 0) {
    for (int index = threadIdx.x; index < head_level_point; index += blockDim.x) {
      weight_arr[index] = weight_base_ptr[index];
    }
  }
  if (threadIdx.y == blockDim.y - 1) {
    for (int index = threadIdx.x; index < kernel_size; index += blockDim.x) {
      kernel_offset_shared[index] = reinterpret_cast<const int32_t2*>(kernel_offset)[index];
    }
  }
  // 等待block内所有线程都完成采样点是否在图像范围内的判断和weight加载至共享内存
  __syncthreads();

  unsigned int VHC = value_num * head_ch;
  unsigned int cam_hit_num = 0;  // 该HEAD命中的相机数

  T feat_sum = .0;  // 可能导致溢出
  for (unsigned cam_idx = 0; cam_idx < cam_num; ++cam_idx) {
    // 相机是否被hit中，如果未hit中，则跳过该相机
    // 邻近点所命中的相机通常是一样的，因此该if判断并不会导致效率降低
    unsigned cam_hit_index = (batch_idx * query_num + query_idx) * cam_num + cam_idx;
    if (cam_hit_arr[cam_hit_index] == 0) {
      continue;
    } else {
      cam_hit_num++;
    }

    unsigned point2d_index = cam_hit_index * head_num + head_idx;
    const T* value_base_ptr_ch_cam =
        value + (batch_idx * cam_num + cam_idx) * VHC + head_idx * channel_num + threadIdx.x;

    for (int level_idx = 0; level_idx < level_size; ++level_idx) {
      int32_t level_spatial_w = value_spatial_whi[level_idx * 3];
      int32_t level_spatial_h = value_spatial_whi[level_idx * 3 + 1];
      int32_t level_start_index = value_spatial_whi[level_idx * 3 + 2];

      const T* value_level_base_ptr = value_base_ptr_ch_cam + level_start_index * head_ch;

      // 从shared memory加载图像坐标,转换为在该level的坐标
      float point2d_norm_x = point2d_norm[point2d_index].x * level_spatial_w;
      float point2d_norm_y = point2d_norm[point2d_index].y * level_spatial_h;

      unsigned int weight_index = (head_idx * level_size + level_idx) * kernel_size;
      for (int kernel_idx = 0; kernel_idx < kernel_size; ++kernel_idx) {
        T weight = weight_arr[weight_index + kernel_idx];

        int32_t2 kernel_offset_value = kernel_offset_shared[kernel_idx];

        // 转换为在该level的坐标
        float x = point2d_norm_x + kernel_offset_value.x - 0.5f;
        float y = point2d_norm_y + kernel_offset_value.y - 0.5f;

        // 调用插值函数
        T val = bilinear_interpolate(value_level_base_ptr,
                                     x,
                                     y,
                                     level_spatial_w,
                                     level_spatial_h,
                                     head_ch);
        feat_sum += weight * val;
      }
    }
  }

  if (cam_hit_num != 0) {
    auto feat = __div(feat_sum, cam_hit_num);
    bev_feat_base_ptr[threadIdx.x] = feat;
  }
}

// 每个线程处理一个HEAD内的2个channel。
__global__ void msda3d_kernel_half2(const __half* value,
                                    const int32_t* value_spatial_whi,
                                    const __half* attention_weight,
                                    const int32_t* kernel_offset,
                                    uint32_t* cam_hit_arr,
                                    float2* point2d_norm,
                                    __half* bev_feat,
                                    unsigned int batch_size,
                                    unsigned int cam_num,
                                    unsigned int value_num,
                                    unsigned int head_num,
                                    unsigned int channel_num,
                                    unsigned int level_size,
                                    unsigned int bev_w,
                                    unsigned int query_num,
                                    unsigned int kernel_size) {
  unsigned batch_idx = blockIdx.z;
  unsigned bev_y = blockIdx.y;
  unsigned bev_x = blockIdx.x * blockDim.z + threadIdx.z;
  // 如果越界，则无需处理
  if (bev_x >= bev_w) {
    return;
  }
  unsigned query_idx = bev_y * bev_w + bev_x;
  unsigned head_idx = threadIdx.y;

  unsigned head_ch = head_num * channel_num;
  unsigned batch_query_idx = batch_idx * query_num + query_idx;
  unsigned level_point = level_size * kernel_size;
  unsigned cam_level_point = cam_num * level_point;
  unsigned head_level_point = head_num * level_size * kernel_size;
  unsigned interpolate_offset = blockDim.z * head_num * cam_level_point;

  // unsigned interpolate_offset = blockDim.z * head_num * cam_num * level_size *
  // kernel_size;
  //  shared_mem[0] ~ shared_mem[interpolate_offset - 1]:用于保存双线性插值的4个位置
  //  shared_mem[interpolate_offset] ~ shared_mem[2 * interpolate_offset -
  //  1]:用于保存双线性插值的4个位置的权重 shared_mem[2 * interpolate_offset] ~
  //  shared_mem[2 * interpolate_offset + threadIdx.z * head_num * level_size *
  //  kernel_size - 1]:用于保存weight shared_mem[2 * interpolate_offset + threadIdx.z
  //  * head_num * level_size * kernel_size] ~ shared_mem[2 * interpolate_offset +
  //  threadIdx.z * head_num * level_size * kernel_size + kernel_size * 2 -
  //  1]:用于保存kernel_offset shared_mem[2 * interpolate_offset + threadIdx.z * head_num
  //  * level_size * kernel_size + kernel_size * 2] ~ shared_mem[2 *
  //  interpolate_offset + threadIdx.z * head_num * level_size * kernel_size +
  //  kernel_size * 2 + tile_size_w * cam_num -1]:用于保存cam_hit_arr
  extern __shared__ __align__(16) unsigned char shared_mem[];
  uint4* interpolate_pos = reinterpret_cast<uint4*>(shared_mem);
  half4* interpolate_weight = reinterpret_cast<half4*>(interpolate_pos + interpolate_offset);
  int32_t2* kernel_offset_shared =
      reinterpret_cast<int32_t2*>(interpolate_weight + interpolate_offset);
  uint32_t* cam_hit_shared = reinterpret_cast<uint32_t*>(kernel_offset_shared + kernel_size);
  __half* weight_arr = reinterpret_cast<__half*>(cam_hit_shared + blockDim.z * cam_num);

  __half2* bev_feat_base_ptr =
      reinterpret_cast<__half2*>(bev_feat + batch_query_idx * head_ch + head_idx * channel_num);
  const __half2* weight_base_ptr =
      reinterpret_cast<const __half2*>(attention_weight + batch_query_idx * head_level_point);

  if (threadIdx.y == 0 && threadIdx.z == 0) {
    for (int index = threadIdx.x; index < kernel_size; index += blockDim.x) {
      kernel_offset_shared[index] = reinterpret_cast<const int32_t2*>(kernel_offset)[index];
    }
  }

  if (threadIdx.y == 0 && threadIdx.z == 0) {
    int cam_hit_count = blockDim.z * cam_num;
    for (int index = threadIdx.x; index < cam_hit_count; index += blockDim.x) {
      cam_hit_shared[index] = cam_hit_arr[query_idx * cam_num + index];
    }
  }
  __syncthreads();

  // 读取weight数据
  unsigned weight_num = head_level_point >> 1;
  for (unsigned index = threadIdx.y * blockDim.x + threadIdx.x; index < weight_num;
       index += blockDim.y * blockDim.x) {
    reinterpret_cast<__half2*>(weight_arr)[threadIdx.z * weight_num + index] =
        weight_base_ptr[index];
  }

  unsigned cam_offset = batch_query_idx * cam_num;
  unsigned x_offset = head_ch >> 1;
  unsigned pos_base = (threadIdx.z * head_num + head_idx) * cam_level_point;
  for (unsigned index = threadIdx.x; index < cam_level_point; index += blockDim.x) {
    unsigned cam_id = index / level_point;
    unsigned level_id = (index % level_point) / kernel_size;
    unsigned kernel_id = index % kernel_size;

    unsigned point2d_index = (cam_offset + cam_id) * head_num + head_idx;
    int32_t level_spatial_w = value_spatial_whi[level_id * 3];
    int32_t level_spatial_h = value_spatial_whi[level_id * 3 + 1];
    float2 point2d_norm_value = point2d_norm[point2d_index];
    const int32_t2 kernel_offset_value = kernel_offset_shared[kernel_id];
    // 转换为在该level的坐标
    float x = point2d_norm_value.x * level_spatial_w + kernel_offset_value.x - 0.5f;
    float y = point2d_norm_value.y * level_spatial_h + kernel_offset_value.y - 0.5f;

    auto x_left = __float2int_rd(x);
    auto x_right = x_left + 1;
    auto y_upper = __float2int_rd(y);
    auto y_lower = y_upper + 1;

    __half w_left = __float2half(x_right - x);
    __half w_right = __hsub(__float2half(1.0f), w_left);
    __half w_upper = __float2half(y_lower - y);
    __half w_lower = __hsub(__float2half(1.0f), w_upper);

    unsigned y_offset = x_offset * level_spatial_w;
    unsigned y_upper_id = y_upper * y_offset;
    unsigned y_lower_id = y_lower * y_offset;
    unsigned x_left_id = x_left * x_offset;
    unsigned x_right_id = x_right * x_offset;
    unsigned pos_index = pos_base + index;
    uint4 pos = {y_upper_id + x_left_id,
                 y_lower_id + x_left_id,
                 y_upper_id + x_right_id,
                 y_lower_id + x_right_id};
    interpolate_pos[pos_index] = pos;

    half4 weight4;
    weight4.left = __float2half2_rn(0.0f);
    weight4.right = __float2half2_rn(0.0f);

    if (x_left >= 0 && x_left < level_spatial_w) {
      if (y_upper >= 0 && y_upper < level_spatial_h) {  // upper left
        weight4.left.x = __hmul(w_left, w_upper);
      }

      if (y_lower >= 0 && y_lower < level_spatial_h) {  // lower left
        weight4.left.y = __hmul(w_left, w_lower);
      }
    }

    if (x_right >= 0 && x_right < level_spatial_w) {
      if (y_upper >= 0 && y_upper < level_spatial_h) {  // upper right
        weight4.right.x = __hmul(w_right, w_upper);
      }

      if (y_lower >= 0 && y_lower < level_spatial_h) {  // lower right
        weight4.right.y = __hmul(w_right, w_lower);
      }
    }

    interpolate_weight[pos_index] = weight4;
  }

  // 等待block内所有线程都完成采样点是否在图像范围内的判断和weight加载至共享内存
  __syncthreads();

  unsigned cam_hit_num = 0;  // 该HEAD命中的相机数

  __half2 feat_sum = __float2half2_rn(0.0f);  // 可能导致溢出
  for (unsigned cam_idx = 0; cam_idx < cam_num; ++cam_idx) {
    // 相机是否被hit中，如果未hit中，则跳过该相机
    // 邻近点所命中的相机通常是一样的，因此该if判断并不会导致效率降低
    if (cam_hit_shared[threadIdx.z * cam_num + cam_idx] == 0) {
      continue;
    } else {
      cam_hit_num++;
    }

    const __half* value_base_ptr_ch_cam =
        value + ((batch_idx * cam_num + cam_idx) * value_num * head_num + head_idx) * channel_num +
        threadIdx.x * 2;

    for (int level_idx = 0; level_idx < level_size; ++level_idx) {
      int32_t level_start_index = value_spatial_whi[level_idx * 3 + 2];

      const __half2* value_level_base_ptr =
          reinterpret_cast<const __half2*>(value_base_ptr_ch_cam + level_start_index * head_ch);

      int pos_index_base = ((threadIdx.z * head_num + head_idx) * cam_level_point +
                            cam_idx * level_point + level_idx * kernel_size);
      unsigned int weight_index =
          threadIdx.z * head_level_point + (head_idx * level_size + level_idx) * kernel_size;
      for (int kernel_idx = 0; kernel_idx < kernel_size; ++kernel_idx) {
        // 调用插值函数
        __half2 val = __float2half2_rn(0.0f);
        int pos_index = pos_index_base + kernel_idx;
        uint4 pos = interpolate_pos[pos_index];
        half4 interpolate_weights = interpolate_weight[pos_index];

        if (__hgt(interpolate_weights.left.x, __float2half(0.0f))) {
          __half2 interpolate_w = __half2half2(interpolate_weights.left.x);
          val = __hfma2(interpolate_w, value_level_base_ptr[pos.x], val);
        }

        if (__hgt(interpolate_weights.left.y, __float2half(0.0f))) {
          __half2 interpolate_w = __half2half2(interpolate_weights.left.y);
          val = __hfma2(interpolate_w, value_level_base_ptr[pos.y], val);
        }

        if (__hgt(interpolate_weights.right.x, __float2half(0.0f))) {
          __half2 interpolate_w = __half2half2(interpolate_weights.right.x);
          val = __hfma2(interpolate_w, value_level_base_ptr[pos.z], val);
        }

        if (__hgt(interpolate_weights.right.y, __float2half(0.0f))) {
          __half2 interpolate_w = __half2half2(interpolate_weights.right.y);
          val = __hfma2(interpolate_w, value_level_base_ptr[pos.w], val);
        }
        __half2 weight = __half2half2(weight_arr[weight_index + kernel_idx]);
        feat_sum = __hfma2(weight, val, feat_sum);
      }
    }
  }

  if (cam_hit_num != 0) {
    __half2 feat = __h2div(feat_sum, __float2half2_rn(static_cast<float>(cam_hit_num)));
    bev_feat_base_ptr[threadIdx.x] = feat;
  }
}

// 每个线程处理一个HEAD内的2个channel。
__global__ void msda3d_kernel_half2_no_batch_level(const __half* value,
                                                   const int32_t* value_spatial_whi,
                                                   const __half* attention_weight,
                                                   const int32_t* kernel_offset,
                                                   uint32_t* cam_hit_arr,
                                                   float2* point2d_norm,
                                                   __half* bev_feat,
                                                   unsigned int cam_num,
                                                   unsigned int value_num,
                                                   unsigned int head_num,
                                                   unsigned int channel_num,
                                                   unsigned int bev_w,
                                                   unsigned int query_num,
                                                   unsigned int kernel_size) {
  unsigned bev_y = blockIdx.y;
  unsigned bev_x = blockIdx.x * blockDim.z + threadIdx.z;
  // 如果越界，则无需处理
  if (bev_x >= bev_w) {
    return;
  }
  unsigned query_idx = bev_y * bev_w + bev_x;
  unsigned head_idx = threadIdx.y;

  unsigned head_ch = head_num * channel_num;
  unsigned cam_point = cam_num * kernel_size;
  unsigned head_point = head_num * kernel_size;
  unsigned interpolate_offset = blockDim.z * head_num * cam_point;

  // unsigned interpolate_offset = blockDim.z * head_num * cam_num * level_size *
  // kernel_size;
  //  shared_mem[0] ~ shared_mem[interpolate_offset - 1]:用于保存双线性插值的4个位置
  //  shared_mem[interpolate_offset] ~ shared_mem[2 * interpolate_offset -
  //  1]:用于保存双线性插值的4个位置的权重 shared_mem[2 * interpolate_offset] ~
  //  shared_mem[2 * interpolate_offset + threadIdx.z * head_num * level_size *
  //  kernel_size - 1]:用于保存weight shared_mem[2 * interpolate_offset + threadIdx.z
  //  * head_num * level_size * kernel_size] ~ shared_mem[2 * interpolate_offset +
  //  threadIdx.z * head_num * level_size * kernel_size + kernel_size * 2 -
  //  1]:用于保存kernel_offset shared_mem[2 * interpolate_offset + threadIdx.z *
  //  head_num * level_size * kernel_size + kernel_size * 2] ~ shared_mem[2 *
  //  interpolate_offset + threadIdx.z * head_num * level_size * kernel_size +
  //  kernel_size * 2 + tile_size_w * cam_num -1]:用于保存cam_hit_arr
  extern __shared__ __align__(16) unsigned char shared_mem[];
  uint4* interpolate_pos = reinterpret_cast<uint4*>(shared_mem);
  half4* interpolate_weight = reinterpret_cast<half4*>(interpolate_pos + interpolate_offset);
  int32_t2* kernel_offset_shared =
      reinterpret_cast<int32_t2*>(interpolate_weight + interpolate_offset);
  uint32_t* cam_hit_shared = reinterpret_cast<uint32_t*>(kernel_offset_shared + kernel_size);
  __half* weight_arr = reinterpret_cast<__half*>(cam_hit_shared + blockDim.z * cam_num);

  __half2* bev_feat_base_ptr =
      reinterpret_cast<__half2*>(bev_feat + query_idx * head_ch + head_idx * channel_num);
  const __half2* weight_base_ptr =
      reinterpret_cast<const __half2*>(attention_weight + query_idx * head_point);

  if (threadIdx.y == 0 && threadIdx.z == 0) {
    for (int index = threadIdx.x; index < kernel_size; index += blockDim.x) {
      kernel_offset_shared[index] = reinterpret_cast<const int32_t2*>(kernel_offset)[index];
    }
  }

  if (threadIdx.y == 0 && threadIdx.z == 0) {
    int cam_hit_count = blockDim.z * cam_num;
    for (int index = threadIdx.x; index < cam_hit_count; index += blockDim.x) {
      cam_hit_shared[index] = cam_hit_arr[query_idx * cam_num + index];
    }
  }
  __syncthreads();

  // 读取weight数据
  unsigned weight_num = head_point >> 1;
  for (unsigned index = threadIdx.y * blockDim.x + threadIdx.x; index < weight_num;
       index += blockDim.y * blockDim.x) {
    reinterpret_cast<__half2*>(weight_arr)[threadIdx.z * weight_num + index] =
        weight_base_ptr[index];
  }

  unsigned cam_offset = query_idx * cam_num;
  unsigned x_offset = head_ch >> 1;
  unsigned pos_base = (threadIdx.z * head_num + head_idx) * cam_point;
  for (unsigned index = threadIdx.x; index < cam_point; index += blockDim.x) {
    unsigned cam_id = index / kernel_size;
    unsigned kernel_id = index % kernel_size;

    unsigned point2d_index = (cam_offset + cam_id) * head_num + head_idx;
    int32_t level_spatial_w = value_spatial_whi[0];
    int32_t level_spatial_h = value_spatial_whi[1];
    float2 point2d_norm_value = point2d_norm[point2d_index];
    const int32_t2 kernel_offset_value = kernel_offset_shared[kernel_id];
    // 转换为在该level的坐标
    float x = point2d_norm_value.x * level_spatial_w + kernel_offset_value.x - 0.5f;
    float y = point2d_norm_value.y * level_spatial_h + kernel_offset_value.y - 0.5f;

    auto x_left = __float2int_rd(x);
    auto x_right = x_left + 1;
    auto y_upper = __float2int_rd(y);
    auto y_lower = y_upper + 1;

    __half w_left = __float2half(x_right - x);
    __half w_right = __hsub(__float2half(1.0f), w_left);
    __half w_upper = __float2half(y_lower - y);
    __half w_lower = __hsub(__float2half(1.0f), w_upper);

    unsigned y_offset = x_offset * level_spatial_w;
    unsigned y_upper_id = y_upper * y_offset;
    unsigned y_lower_id = y_lower * y_offset;
    unsigned x_left_id = x_left * x_offset;
    unsigned x_right_id = x_right * x_offset;
    unsigned pos_index = pos_base + index;
    uint4 pos = {y_upper_id + x_left_id,
                 y_lower_id + x_left_id,
                 y_upper_id + x_right_id,
                 y_lower_id + x_right_id};
    interpolate_pos[pos_index] = pos;

    half4 weight4;
    weight4.left = __float2half2_rn(0.0f);
    weight4.right = __float2half2_rn(0.0f);

    if (x_left >= 0 && x_left < level_spatial_w) {
      if (y_upper >= 0 && y_upper < level_spatial_h) {  // upper left
        weight4.left.x = __hmul(w_left, w_upper);
      }

      if (y_lower >= 0 && y_lower < level_spatial_h) {  // lower left
        weight4.left.y = __hmul(w_left, w_lower);
      }
    }

    if (x_right >= 0 && x_right < level_spatial_w) {
      if (y_upper >= 0 && y_upper < level_spatial_h) {  // upper right
        weight4.right.x = __hmul(w_right, w_upper);
      }

      if (y_lower >= 0 && y_lower < level_spatial_h) {  // lower right
        weight4.right.y = __hmul(w_right, w_lower);
      }
    }

    interpolate_weight[pos_index] = weight4;
  }

  // 等待block内所有线程都完成采样点是否在图像范围内的判断和weight加载至共享内存
  __syncthreads();

  unsigned cam_hit_num = 0;  // 该HEAD命中的相机数

  __half2 feat_sum = __float2half2_rn(0.0f);  // 可能导致溢出
  for (unsigned cam_idx = 0; cam_idx < cam_num; ++cam_idx) {
    // 相机是否被hit中，如果未hit中，则跳过该相机
    // 邻近点所命中的相机通常是一样的，因此该if判断并不会导致效率降低
    if (cam_hit_shared[threadIdx.z * cam_num + cam_idx] == 0) {
      continue;
    } else {
      cam_hit_num++;
    }

    const __half2* value_level_base_ptr = reinterpret_cast<const __half2*>(
        value + (cam_idx * value_num * head_num + head_idx) * channel_num + threadIdx.x * 2);

    int pos_index_base = ((threadIdx.z * head_num + head_idx) * cam_num + cam_idx) * kernel_size;
    unsigned int weight_index = threadIdx.z * head_point + head_idx * kernel_size;
    for (int kernel_idx = 0; kernel_idx < kernel_size; ++kernel_idx) {
      __half2 val = __float2half2_rn(0.0f);
      int pos_index = pos_index_base + kernel_idx;
      uint4 pos = interpolate_pos[pos_index];
      half4 interpolate_weights = interpolate_weight[pos_index];

      if (__hgt(interpolate_weights.left.x, __float2half(0.0f))) {
        __half2 interpolate_w = __half2half2(interpolate_weights.left.x);
        val = __hfma2(interpolate_w, value_level_base_ptr[pos.x], val);
      }

      if (__hgt(interpolate_weights.left.y, __float2half(0.0f))) {
        __half2 interpolate_w = __half2half2(interpolate_weights.left.y);
        val = __hfma2(interpolate_w, value_level_base_ptr[pos.y], val);
      }

      if (__hgt(interpolate_weights.right.x, __float2half(0.0f))) {
        __half2 interpolate_w = __half2half2(interpolate_weights.right.x);
        val = __hfma2(interpolate_w, value_level_base_ptr[pos.z], val);
      }

      if (__hgt(interpolate_weights.right.y, __float2half(0.0f))) {
        __half2 interpolate_w = __half2half2(interpolate_weights.right.y);
        val = __hfma2(interpolate_w, value_level_base_ptr[pos.w], val);
      }

      __half2 weight = __half2half2(weight_arr[weight_index + kernel_idx]);
      feat_sum = __hfma2(weight, val, feat_sum);
    }
  }

  if (cam_hit_num != 0) {
    __half2 feat = __h2div(feat_sum, __float2half2_rn(static_cast<float>(cam_hit_num)));
    bev_feat_base_ptr[threadIdx.x] = feat;
  }
}

template <typename T>
void launch_msda3d_kernel_(const T* value,
                           const int32_t* value_spatial_whi,
                           const T* sample_height,
                           const T* attention_weight,
                           const float* lidar2img,
                           const float* point_cloud_range,
                           const int32_t* kernel_offset,
                           uint32_t* cam_hit_arr,
                           float2* point2d_norm,
                           T* bev_feat,
                           unsigned int batch_size,
                           unsigned int cam_num,
                           unsigned int value_num,
                           unsigned int head_num,  // 与BEV视角上Z轴的采样点数相同
                           unsigned int channel_num,
                           unsigned int level_size,
                           unsigned int img_w,
                           unsigned int img_h,
                           unsigned int bev_w,
                           unsigned int bev_h,
                           unsigned int query_size,  // query_size = bev_h * bev_w
                           unsigned int kernel_size,
                           cudaStream_t stream) {
  if (!((head_num >= 32 && 0 == head_num % 32) || (head_num < 32 && 0 == 32 % head_num))) {
    LWARN_FMT("head_num is not best, the head_num is: %u", head_num);
  }

  unsigned int cam_hit_size = cam_num * head_num;
  unsigned int tile_size_w;
  if (cam_hit_size >= 32) {
    tile_size_w = 1;
  } else {
    tile_size_w = std::floor(32.0f / cam_hit_size);
  }
  unsigned int grid_x_pre =
      static_cast<unsigned int>(std::ceil(static_cast<float>(bev_w) / tile_size_w));
  dim3 block_size_pre(head_num, cam_num, tile_size_w);
  dim3 grid_size_pre(grid_x_pre, bev_h, batch_size);
  msda3d_preprocess_kernel<<<grid_size_pre, block_size_pre, 0, stream>>>(sample_height,
                                                                         lidar2img,
                                                                         point_cloud_range,
                                                                         cam_hit_arr,
                                                                         point2d_norm,
                                                                         batch_size,
                                                                         cam_num,
                                                                         head_num,
                                                                         img_w,
                                                                         img_h,
                                                                         bev_w,
                                                                         bev_h,
                                                                         query_size);
  dim3 block_size(channel_num, head_num);
  dim3 grid_size(bev_w, bev_h, batch_size);
  // shared_mem[0] ~ shared_mem[head_num * level_size * kernel_size -
  // 1]:用于保存weight shared_mem[head_num * level_size * kernel_size] ~
  // shared_mem[head_num * level_size * kernel_size + kernel_size * 2 -
  // 1]:用于保存kernel_offset
  unsigned shared_mem_size =
      head_num * level_size * kernel_size * sizeof(T) + kernel_size * 2 * sizeof(int32_t);
  msda3d_kernel<T><<<grid_size, block_size, shared_mem_size, stream>>>(value,
                                                                       value_spatial_whi,
                                                                       attention_weight,
                                                                       kernel_offset,
                                                                       cam_hit_arr,
                                                                       point2d_norm,
                                                                       bev_feat,
                                                                       batch_size,
                                                                       cam_num,
                                                                       value_num,
                                                                       head_num,
                                                                       channel_num,
                                                                       level_size,
                                                                       bev_w,
                                                                       query_size,
                                                                       kernel_size);

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    LERROR_FMT("error in msda3d: %s\n", cudaGetErrorString(err));
  }
}

void launch_msda3d_kernel_(const __half* value,
                           const int32_t* value_spatial_whi,
                           const float* sample_height,
                           const __half* attention_weight,
                           const float* lidar2img,
                           const float* point_cloud_range,
                           const int32_t* kernel_offset,
                           uint32_t* cam_hit_arr,
                           float2* point2d_norm,
                           __half* bev_feat,
                           unsigned int batch_size,
                           unsigned int cam_num,
                           unsigned int value_num,
                           unsigned int head_num,  // 与BEV视角上Z轴的采样点数相同
                           unsigned int channel_num,
                           unsigned int level_size,
                           unsigned int img_w,
                           unsigned int img_h,
                           unsigned int bev_w,
                           unsigned int bev_h,
                           unsigned int query_size,  // query_size = bev_h * bev_w
                           unsigned int kernel_size,
                           cudaStream_t stream) {
  if (!((head_num >= 32 && 0 == head_num % 32) || (head_num < 32 && 0 == 32 % head_num))) {
    LWARN_FMT("head_num is not best, the head_num is: %u", head_num);
  }

  unsigned int cam_hit_size = cam_num * head_num;
  unsigned int tile_size_w_pre;
  if (cam_hit_size >= 32) {
    tile_size_w_pre = 1;
  } else {
    tile_size_w_pre = std::floor(32.0f / cam_hit_size);
  }
  unsigned int grid_x_pre =
      static_cast<unsigned int>(std::ceil(static_cast<float>(bev_w) / tile_size_w_pre));
  dim3 block_size_pre(head_num, cam_num, tile_size_w_pre);
  dim3 grid_size_pre(grid_x_pre, bev_h, batch_size);
  msda3d_preprocess_kernel<<<grid_size_pre, block_size_pre, 0, stream>>>(sample_height,
                                                                         lidar2img,
                                                                         point_cloud_range,
                                                                         cam_hit_arr,
                                                                         point2d_norm,
                                                                         batch_size,
                                                                         cam_num,
                                                                         head_num,
                                                                         img_w,
                                                                         img_h,
                                                                         bev_w,
                                                                         bev_h,
                                                                         query_size);

  // 若channel_num为奇数，为避免越界不使用half2
  if (channel_num % 2 == 0) {
    // 使用half2后一个thread计算2个channel
    unsigned int tile_size_w = 2;
    unsigned int block_x = static_cast<unsigned int>(static_cast<float>(channel_num) / tile_size_w);
    unsigned int grid_x =
        static_cast<unsigned int>(std::ceil(static_cast<float>(bev_w) / tile_size_w));
    dim3 block_size(block_x, head_num, tile_size_w);
    dim3 grid_size(grid_x, bev_h, batch_size);
    // unsigned interpolate_offset = blockDim.z * head_num * cam_num * level_size *
    // kernel_size;
    //  shared_mem[0] ~ shared_mem[interpolate_offset -
    //  1]:用于保存双线性插值的4个位置 shared_mem[interpolate_offset] ~ shared_mem[2
    //  * interpolate_offset - 1]:用于保存双线性插值的4个位置的权重 shared_mem[2 *
    //  interpolate_offset] ~ shared_mem[2 * interpolate_offset + threadIdx.z *
    //  head_num * level_size * kernel_size - 1]:用于保存weight shared_mem[2 *
    //  interpolate_offset + threadIdx.z * head_num * level_size * kernel_size] ~
    //  shared_mem[2 * interpolate_offset + threadIdx.z * head_num * level_size *
    //  kernel_size + kernel_size * 2 - 1]:用于保存kernel_offset shared_mem[2 *
    //  interpolate_offset + threadIdx.z * head_num * level_size * kernel_size +
    //  kernel_size * 2] ~ shared_mem[2 * interpolate_offset + threadIdx.z *
    //  head_num * level_size * kernel_size + kernel_size * 2 + tile_size_w *
    //  cam_num -1]:用于保存cam_hit_arr
    unsigned tile_head_level_kernel = tile_size_w * head_num * level_size * kernel_size;
    unsigned tile_head_cam_level_kernel = tile_head_level_kernel * cam_num * 4;
    unsigned shared_mem_size =
        tile_head_cam_level_kernel * sizeof(unsigned int) +
        tile_head_cam_level_kernel * sizeof(__half) + tile_head_level_kernel * sizeof(__half) +
        kernel_size * 2 * sizeof(int32_t) + tile_size_w * cam_num * sizeof(uint32_t);

    if (batch_size == 1 && level_size == 1) {
      msda3d_kernel_half2_no_batch_level<<<grid_size, block_size, shared_mem_size, stream>>>(
          value,
          value_spatial_whi,
          attention_weight,
          kernel_offset,
          cam_hit_arr,
          point2d_norm,
          bev_feat,
          cam_num,
          value_num,
          head_num,
          channel_num,
          bev_w,
          query_size,
          kernel_size);
    } else {
      msda3d_kernel_half2<<<grid_size, block_size, shared_mem_size, stream>>>(value,
                                                                              value_spatial_whi,
                                                                              attention_weight,
                                                                              kernel_offset,
                                                                              cam_hit_arr,
                                                                              point2d_norm,
                                                                              bev_feat,
                                                                              batch_size,
                                                                              cam_num,
                                                                              value_num,
                                                                              head_num,
                                                                              channel_num,
                                                                              level_size,
                                                                              bev_w,
                                                                              query_size,
                                                                              kernel_size);
    }
  } else {
    dim3 block_size(channel_num, head_num);
    dim3 grid_size(bev_w, bev_h, batch_size);
    // shared_mem[0] ~ shared_mem[head_num * level_size * kernel_size -
    // 1]:用于保存weight shared_mem[head_num * level_size * kernel_size] ~
    // shared_mem[head_num * level_size * kernel_size + kernel_size * 2 -
    // 1]:用于保存kernel_offset
    unsigned shared_mem_size =
        head_num * level_size * kernel_size * sizeof(__half) + kernel_size * 2 * sizeof(int32_t);
    msda3d_kernel<__half><<<grid_size, block_size, shared_mem_size, stream>>>(value,
                                                                              value_spatial_whi,
                                                                              attention_weight,
                                                                              kernel_offset,
                                                                              cam_hit_arr,
                                                                              point2d_norm,
                                                                              bev_feat,
                                                                              batch_size,
                                                                              cam_num,
                                                                              value_num,
                                                                              head_num,
                                                                              channel_num,
                                                                              level_size,
                                                                              bev_w,
                                                                              query_size,
                                                                              kernel_size);
  }

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    LERROR_FMT("error in msda3d: %s\n", cudaGetErrorString(err));
  }
}

void launch_msda3d_kernel(const float* value,
                          const int32_t* value_spatial_whi,
                          const float* sample_height,
                          const float* attention_weight,
                          const float* lidar2img,
                          const float* point_cloud_range,
                          const int32_t* kernel_offset,
                          uint32_t* cam_hit_arr,
                          float2* point2d_norm,
                          float* bev_feat,
                          unsigned int batch_size,
                          unsigned int cam_num,
                          unsigned int value_num,
                          unsigned int head_num,  // 与BEV视角上Z轴的采样点数相同
                          unsigned int channel_num,
                          unsigned int level_size,
                          unsigned int img_w,
                          unsigned int img_h,
                          unsigned int bev_w,
                          unsigned int bev_h,
                          unsigned int query_size,  // query_size = bev_h * bev_w
                          unsigned int kernel_size,
                          cudaStream_t stream) {
  launch_msda3d_kernel_(value,
                        value_spatial_whi,
                        sample_height,
                        attention_weight,
                        lidar2img,
                        point_cloud_range,
                        kernel_offset,
                        cam_hit_arr,
                        point2d_norm,
                        bev_feat,
                        batch_size,
                        cam_num,
                        value_num,
                        head_num,
                        channel_num,
                        level_size,
                        img_w,
                        img_h,
                        bev_w,
                        bev_h,
                        query_size,
                        kernel_size,
                        stream);
}

void launch_msda3d_kernel(const __half* value,
                          const int32_t* value_spatial_whi,
                          const float* sample_height,
                          const __half* attention_weight,
                          const float* lidar2img,
                          const float* point_cloud_range,
                          const int32_t* kernel_offset,
                          uint32_t* cam_hit_arr,
                          float2* point2d_norm,
                          __half* bev_feat,
                          unsigned int batch_size,
                          unsigned int cam_num,
                          unsigned int value_num,
                          unsigned int head_num,  // 与BEV视角上Z轴的采样点数相同
                          unsigned int channel_num,
                          unsigned int level_size,
                          unsigned int img_w,
                          unsigned int img_h,
                          unsigned int bev_w,
                          unsigned int bev_h,
                          unsigned int query_size,  // query_size = bev_h * bev_w
                          unsigned int kernel_size,
                          cudaStream_t stream) {
  launch_msda3d_kernel_(value,
                        value_spatial_whi,
                        sample_height,
                        attention_weight,
                        lidar2img,
                        point_cloud_range,
                        kernel_offset,
                        cam_hit_arr,
                        point2d_norm,
                        bev_feat,
                        batch_size,
                        cam_num,
                        value_num,
                        head_num,
                        channel_num,
                        level_size,
                        img_w,
                        img_h,
                        bev_w,
                        bev_h,
                        query_size,
                        kernel_size,
                        stream);
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
