#pragma once

#include <cuda_fp16.h>

#include <cstdint>

namespace linfer {
namespace ops {
namespace trt {

void launch_msda3d_kernel(const float* value,
                          const int32_t* value_spatial_whi,
                          const float* sample_height,
                          const float* attention_weight,
                          const float* lidar2img,
                          const float* point_cloud_range,
                          const int32_t* kernel_offset,
                          uint32_t* cam_hit_arr,
                          float2* point2d_norm,
                          float* bev_feat,
                          unsigned int batch_size,
                          unsigned int cam_num,
                          unsigned int value_num,
                          unsigned int head_num,  // 与BEV视角上Z轴的采样点数相同
                          unsigned int channel_num,
                          unsigned int level_size,
                          unsigned int img_w,
                          unsigned int img_h,
                          unsigned int bev_w,
                          unsigned int bev_h,
                          unsigned int query_size,  // query_size = bev_h * bev_w
                          unsigned int kernel_size,
                          cudaStream_t stream);

void launch_msda3d_kernel(const __half* value,
                          const int32_t* value_spatial_whi,
                          const float* sample_height,
                          const __half* attention_weight,
                          const float* lidar2img,
                          const float* point_cloud_range,
                          const int32_t* kernel_offset,
                          uint32_t* cam_hit_arr,
                          float2* point2d_norm,
                          __half* bev_feat,
                          unsigned int batch_size,
                          unsigned int cam_num,
                          unsigned int value_num,
                          unsigned int head_num,  // 与BEV视角上Z轴的采样点数相同
                          unsigned int channel_num,
                          unsigned int level_size,
                          unsigned int img_w,
                          unsigned int img_h,
                          unsigned int bev_w,
                          unsigned int bev_h,
                          unsigned int query_size,  // query_size = bev_h * bev_w
                          unsigned int kernel_size,
                          cudaStream_t stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer
