#include <cuda_fp16.h>

#include "scatter_kernel.h"
__device__ inline void scatterND_float(const float* features,
                                       const int* point_index,
                                       float* output_features,
                                       int len_z,
                                       int len_y,
                                       int len_x,
                                       int input_feature_length) {
  // 2 200 176
  int4 coord = ((const int4*)point_index)[0];
  // auto pos_z = coord.y;
  // auto pos_y = coord.z;
  // auto pos_x = coord.w;
  // int pos_z = point_index[1];
  // int pos_y = point_index[2];
  // int pos_x = point_index[3];
  int grid_size = len_y * len_x;
  int shape_size = len_z * grid_size;
  int additive = coord.y * grid_size + coord.z * len_x + coord.w;

#pragma unroll
  for (size_t i = 0; i < input_feature_length; i++) {
    output_features[i * shape_size + additive] = features[i];
  }
}

__device__ inline void scatterND_half(const __half* features,
                                      const int* point_index,
                                      __half* output_features,
                                      int len_z,
                                      int len_y,
                                      int len_x,
                                      int input_feature_length) {
  // 2 200 176
  int4 coord = ((const int4*)point_index)[0];
  // auto pos_z = coord.y;
  // auto pos_y = coord.z;
  // auto pos_x = coord.w;
  // int pos_z = point_index[1];
  // int pos_y = point_index[2];
  // int pos_x = point_index[3];
  int grid_size = len_y * len_x;
  int shape_size = len_z * grid_size;
  int additive = coord.y * grid_size + coord.z * len_x + coord.w;

#pragma unroll
  for (size_t i = 0; i < input_feature_length; i++) {
    output_features[i * shape_size + additive] = features[i];
  }
}

__global__ void scatter_cuda_kernel_float(const int* dev_indice,
                                          const float* dev_features,
                                          const int* voxel_size,
                                          int grid_x,
                                          int grid_y,
                                          int grid_z,
                                          int feature_size,
                                          float* dev_output_features) {
  int voxel_id = blockIdx.x * blockDim.x + threadIdx.x;
  if (voxel_id >= *voxel_size) return;
  scatterND_float(dev_features + voxel_id * feature_size,
                  dev_indice + voxel_id * 4,
                  dev_output_features,
                  grid_z,
                  grid_y,
                  grid_x,
                  feature_size);
}

__global__ void scatter_cuda_kernel_half(const int* dev_indice,
                                         const __half* dev_features,
                                         const int* voxel_size,
                                         int grid_x,
                                         int grid_y,
                                         int grid_z,
                                         int feature_size,
                                         __half* dev_output_features) {
  int voxel_id = blockIdx.x * blockDim.x + threadIdx.x;
  if (voxel_id >= *voxel_size) return;
  scatterND_half(dev_features + voxel_id * feature_size,
                 dev_indice + voxel_id * 4,
                 dev_output_features,
                 grid_z,
                 grid_y,
                 grid_x,
                 feature_size);
}

void scatter_cuda_float(const int* dev_indice,
                        const float* dev_features,
                        const int* dev_voxel_size,
                        int grid_x,
                        int grid_y,
                        int grid_z,
                        int feature_size,
                        float* dev_output_features,
                        cudaStream_t stream) {
  BASE_CUDA_CHECK(cudaMemsetAsync(dev_output_features,
                                  0,
                                  sizeof(float) * feature_size * grid_x * grid_y * grid_z,
                                  stream));
  // int* voxel_size = new int[1];
  // BASE_CUDA_CHECK(cudaMemcpy(voxel_size, dev_voxel_size, sizeof(int),
  // cudaMemcpyDeviceToHost)); std::cout << "voxel size:" << voxel_size[0] <<
  // std::endl;
  int thread = DIVUP(grid_x * grid_y * grid_z, 512);
  scatter_cuda_kernel_float<<<thread, 512, 0, stream>>>(dev_indice,
                                                        dev_features,
                                                        dev_voxel_size,
                                                        grid_x,
                                                        grid_y,
                                                        grid_z,
                                                        feature_size,
                                                        dev_output_features);
}

void scatter_cuda_half(const int* dev_indice,
                       const __half* dev_features,
                       const int* dev_voxel_size,
                       int grid_x,
                       int grid_y,
                       int grid_z,
                       int feature_size,
                       __half* dev_output_features,
                       cudaStream_t stream) {
  BASE_CUDA_CHECK(cudaMemsetAsync(dev_output_features,
                                  0,
                                  sizeof(__half) * feature_size * grid_x * grid_y * grid_z,
                                  stream));
  // int* voxel_size = new int[1];
  // BASE_CUDA_CHECK(cudaMemcpyAsync(voxel_size, dev_voxel_size, sizeof(int),
  // cudaMemcpyDeviceToHost, stream)); cudaStreamSynchronize(stream);
  // __half* host_features = new __half[128*voxel_size[0]];
  // BASE_CUDA_CHECK(cudaMemcpyAsync(host_features, dev_features,
  //                           sizeof(__half) * 128*voxel_size[0],
  //                           cudaMemcpyDeviceToHost, stream));
  // int* host_coors = new int[4*voxel_size[0]];
  // BASE_CUDA_CHECK(cudaMemcpyAsync(host_coors, dev_indice, sizeof(int)*
  //                                 voxel_size[0]*4, cudaMemcpyDeviceToHost,
  //                                 stream));
  // cudaStreamSynchronize(stream);
  // std::cout << "voxel size:" << voxel_size[0] << std::endl;
  // for(size_t i = 0; i < 10; i++) {
  //   std::cout << "index:" << host_coors[i*4+1] << " "
  //     << host_coors[i*4+2] << " " << host_coors[i*4+3] << std::endl;
  //   std::cout << "features:" << std::endl;
  //   for(size_t j=0; j < 128; j++) {
  //     std::cout << __half2float(host_features[i*128 + j]) << " ";
  //   }
  //   std::cout << std::endl;
  // }
  // int thread = DIVUP(voxel_size[0], 512);
  int thread = DIVUP(grid_x * grid_y * grid_z, 512);
  scatter_cuda_kernel_half<<<thread, 512, 0, stream>>>(dev_indice,
                                                       dev_features,
                                                       dev_voxel_size,
                                                       grid_x,
                                                       grid_y,
                                                       grid_z,
                                                       feature_size,
                                                       dev_output_features);
  // delete voxel_size;
}