#pragma once

#define PILLARS_PER_BLOCK \
  64  // one thread deals with one pillar and a block has PILLARS_PER_BLOCK
      // threads

#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/spconv/centerpoint_util.h"
void scatter_cuda_float(const int* dev_indice,
                        const float* dev_features,
                        const int* dev_voxel_size,
                        int grid_x,
                        int grid_y,
                        int grid_z,
                        int feature_size,
                        float* dev_output_features,
                        cudaStream_t stream);

void scatter_cuda_half(const int* dev_indice,
                       const __half* dev_features,
                       const int* dev_voxel_size,
                       int grid_x,
                       int grid_y,
                       int grid_z,
                       int feature_size,
                       __half* dev_output_features,
                       cudaStream_t stream);