/*
 * SPDX-FileCopyrightText: Copyright (c) 2021 NVIDIA CORPORATION & AFFILIATES.
 * All rights reserved. SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "scatter_plugin.h"

#include <cuda_fp16.h>
#include <unistd.h>

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>

#include "scatter_kernel.h"
/**
 * For the usage of those member function, please refer to the
 * offical api doc.
 * https://docs.nvidia.com/deeplearning/tensorrt/api/c_api/classnvinfer1_1_1_i_plugin_v2_ext.html
 */

using namespace nvinfer1;
#ifndef CUTEDEBUG
#define CUTEDEBUG 0  // set debug mode, if you want to see the api call, set it to 1
#endif

#if CUTEDEBUG
#define cutelog(...)                                                                             \
  {                                                                                              \
    char str[100];                                                                               \
    sprintf(str, __VA_ARGS__);                                                                   \
    std::cout << " (๑¯◡¯๑) noexcept CUSTOM PLUGIN TRACE----> call "                              \
              << "[" << __FILE__ << "][" << __FUNCTION__ << "][Line " << __LINE__ << "] " << str \
              << std::endl;                                                                      \
  }
#else
#define cutelog(...)
#endif

using namespace nvinfer1;
using nvinfer1::plugin::Scatter3DPlugin;
using nvinfer1::plugin::Scatter3DPluginCreator;

static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"Scatter3D"};

// Static class fields initialization
PluginFieldCollection Scatter3DPluginCreator::mFC{};
std::vector<PluginField> Scatter3DPluginCreator::mPluginAttributes;

// Helper function for serializing plugin
template <typename T>
void writeToBuffer(char*& buffer, const T& val) {
  *reinterpret_cast<T*>(buffer) = val;
  buffer += sizeof(T);
}

// Helper function for deserializing plugin
template <typename T>
T readFromBuffer(const char*& buffer) {
  T val = *reinterpret_cast<const T*>(buffer);
  buffer += sizeof(T);
  return val;
}

Scatter3DPlugin::Scatter3DPlugin() { cutelog("wow I run to here now"); }

Scatter3DPlugin::Scatter3DPlugin(size_t feat_num, size_t z, size_t y, size_t x)
    : featureNum_(feat_num), feature_z_size_(z), feature_y_size_(y), feature_x_size_(x) {
  cutelog("wow I run to here now");
}

Scatter3DPlugin::Scatter3DPlugin(const void* data, size_t length) {
  const char* d = reinterpret_cast<const char*>(data);
  featureNum_ = readFromBuffer<size_t>(d);
  feature_z_size_ = readFromBuffer<size_t>(d);
  feature_y_size_ = readFromBuffer<size_t>(d);
  feature_x_size_ = readFromBuffer<size_t>(d);
}

// IPluginV2DynamicExt Methods
nvinfer1::IPluginV2DynamicExt* Scatter3DPlugin::clone() const noexcept {
  cutelog("wow I run to here now");
  auto* plugin =
      new Scatter3DPlugin(featureNum_, feature_z_size_, feature_y_size_, feature_x_size_);
  plugin->setPluginNamespace(mNamespace.c_str());
  return plugin;
}

nvinfer1::DimsExprs Scatter3DPlugin::getOutputDimensions(
    int outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  cutelog("wow I run to here now");
  assert(outputIndex == 0);
  //   for(int i=0;i<nbInputs;i++) {
  //     printf("input[%d]: ", i);
  //     for(int j=0;j<inputs[i].nbDims;j++) {
  //         printf("%d ", inputs[i].d[j]->getConstantValue());
  //     }
  //     printf("\n");
  // }
  nvinfer1::DimsExprs output;
  output.nbDims = 4;
  output.d[0] = exprBuilder.constant(1);
  output.d[1] = exprBuilder.constant(featureNum_ * feature_z_size_);
  output.d[2] = exprBuilder.constant(feature_y_size_);
  output.d[3] = exprBuilder.constant(feature_x_size_);
  // for (size_t i = 0; i < output.nbDims; i++)
  // {
  //   std::cout << "output.d[" << i << "]:" << output.d[i]->getConstantValue()
  //   << std::endl;
  // }

  return output;
}

bool Scatter3DPlugin::supportsFormatCombination(int pos,
                                                const nvinfer1::PluginTensorDesc* inOut,
                                                int nbInputs,
                                                int nbOutputs) noexcept {
  cutelog("wow I run to here now");
  assert(nbInputs == 3);
  assert(nbOutputs == 1);

  const PluginTensorDesc& in = inOut[pos];
  if (pos == 0) {
    return (in.type == nvinfer1::DataType::kINT32) && (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 1) {
    return (in.type == nvinfer1::DataType::kINT32) && (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 2) {
    return (in.type == nvinfer1::DataType::kFLOAT || in.type == nvinfer1::DataType::kHALF) &&
           (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 3) {
    return (inOut[2].type == nvinfer1::DataType::kFLOAT && in.type == nvinfer1::DataType::kFLOAT &&
            in.format == TensorFormat::kLINEAR) ||
           (inOut[2].type == nvinfer1::DataType::kHALF && in.type == nvinfer1::DataType::kHALF &&
            in.format == TensorFormat::kLINEAR);
  }
  return false;
}

void Scatter3DPlugin::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                      int nbInputs,
                                      const nvinfer1::DynamicPluginTensorDesc* out,
                                      int nbOutputs) noexcept {
  cutelog("wow I run to here now");
}

size_t Scatter3DPlugin::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                         int nbInputs,
                                         const nvinfer1::PluginTensorDesc* outputs,
                                         int nbOutputs) const noexcept {
  cutelog("wow I run to here now");
  return 0;
}

int Scatter3DPlugin::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                             const nvinfer1::PluginTensorDesc* outputDesc,
                             const void* const* inputs,
                             void* const* outputs,
                             void* workspace,
                             cudaStream_t stream) noexcept {
  cutelog("wow I run to here now");

  nvinfer1::DataType inputType = inputDesc[2].type;

  int batch = 1;
  int featureNum = featureNum_;
  int featureZ = feature_z_size_;
  int featureY = feature_y_size_;
  int featureX = feature_x_size_;

  const int* anchor_size = (const int*)inputs[0];
  const int* coords_data = (const int*)(inputs[1]);

  if (inputType == nvinfer1::DataType::kHALF) {
    const __half* feat_data = (const __half*)(inputs[2]);
    __half* spatial_feature_data = (__half*)(outputs[0]);
    scatter_cuda_half(coords_data,
                      feat_data,
                      anchor_size,
                      feature_x_size_,
                      feature_y_size_,
                      feature_z_size_,
                      featureNum_,
                      spatial_feature_data,
                      stream);
  }
  if (inputType == nvinfer1::DataType::kFLOAT) {
    const float* feat_data = (const float*)(inputs[2]);
    float* spatial_feature_data = (float*)(outputs[0]);
    scatter_cuda_float(coords_data,
                       feat_data,
                       anchor_size,
                       feature_x_size_,
                       feature_y_size_,
                       feature_z_size_,
                       featureNum_,
                       spatial_feature_data,
                       stream);
  }
  return 0;
}

// IPluginV2Ext Methods
nvinfer1::DataType Scatter3DPlugin::getOutputDataType(int index,
                                                      const nvinfer1::DataType* inputTypes,
                                                      int nbInputs) const noexcept {
  cutelog("wow I run to here now");
  return inputTypes[2];
}

// IPluginV2 Methods

const char* Scatter3DPlugin::getPluginType() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_NAME;
}

const char* Scatter3DPlugin::getPluginVersion() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_VERSION;
}

int Scatter3DPlugin::getNbOutputs() const noexcept {
  cutelog("wow I run to here now");
  return 1;
}

int Scatter3DPlugin::initialize() noexcept {
  cutelog("wow I run to here now");
  return 0;
}

void Scatter3DPlugin::terminate() noexcept { cutelog("wow I run to here now"); }

size_t Scatter3DPlugin::getSerializationSize() const noexcept {
  cutelog("wow I run to here now");
  return 4 * sizeof(size_t);
}

void Scatter3DPlugin::serialize(void* buffer) const noexcept {
  cutelog("wow I run to here now");
  char* d = reinterpret_cast<char*>(buffer);
  writeToBuffer<size_t>(d, featureNum_);
  writeToBuffer<size_t>(d, feature_z_size_);
  writeToBuffer<size_t>(d, feature_y_size_);
  writeToBuffer<size_t>(d, feature_x_size_);
}

void Scatter3DPlugin::destroy() noexcept {
  cutelog("wow I run to here now");
  delete this;
}

void Scatter3DPlugin::setPluginNamespace(const char* libNamespace) noexcept {
  cutelog("wow I run to here now");
  mNamespace = libNamespace;
}

const char* Scatter3DPlugin::getPluginNamespace() const noexcept {
  cutelog("wow I run to here now");
  return mNamespace.c_str();
}

///////////////

Scatter3DPluginCreator::Scatter3DPluginCreator() {
  cutelog("wow I run to here now");
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(PluginField("scatter_shape", nullptr, PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* Scatter3DPluginCreator::getPluginName() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_NAME;
}

const char* Scatter3DPluginCreator::getPluginVersion() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_VERSION;
}

const PluginFieldCollection* Scatter3DPluginCreator::getFieldNames() noexcept {
  cutelog("wow I run to here now");
  return &mFC;
}

IPluginV2* Scatter3DPluginCreator::createPlugin(const char* name,
                                                const PluginFieldCollection* fc) noexcept {
  const PluginField* fields = fc->fields;
  int nbFields = fc->nbFields;
  int target_featnum = 0;
  int target_z = 0;
  int target_y = 0;
  int target_x = 0;
  for (int i = 0; i < nbFields; ++i) {
    const char* attr_name = fields[i].name;
    if (!strcmp(attr_name, "scatter_shape")) {
      const int* ts = static_cast<const int*>(fields[i].data);
      target_featnum = ts[0];
      target_z = ts[1];
      target_y = ts[2];
      target_x = ts[3];
    }
  }
  IPluginV2* plugin = new Scatter3DPlugin(target_featnum, target_z, target_y, target_x);
  return plugin;
}

IPluginV2* Scatter3DPluginCreator::deserializePlugin(const char* name,
                                                     const void* serialData,
                                                     size_t serialLength) noexcept {
  cutelog("wow I run to here now");
  return new Scatter3DPlugin(serialData, serialLength);
}

void Scatter3DPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  cutelog("wow I run to here now");
  mNamespace = libNamespace;
}

const char* Scatter3DPluginCreator::getPluginNamespace() const noexcept {
  cutelog("wow I run to here now");
  return mNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(Scatter3DPluginCreator);
