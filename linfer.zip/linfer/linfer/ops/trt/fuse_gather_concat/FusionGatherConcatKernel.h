#ifndef FUSION_GATHER_CONCAT_KERNEL_H
#define FUSION_GATHER_CONCAT_KERNEL_H

#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cstdint>
#include <vector>

#include "NvInferRuntimeCommon.h"

namespace nvinfer1 {
namespace plugin {

#ifdef __CUDA_ARCH__
#define ASSERT(condition) __assert_fail(condition, __FILE__, __LINE__, __func__)
#else
#define ASSERT(condition) assert(condition)
#endif

// decalre the plugin creator

int32_t FusionGatherConcatLaunch(const void* input,
                                 void* output,
                                 const int batchsize,
                                 const int outDtype,
                                 cudaStream_t stream);

}  // namespace plugin
}  // namespace nvinfer1

#endif  // FUSION_GATHER_CONCAT_KERNEL_H