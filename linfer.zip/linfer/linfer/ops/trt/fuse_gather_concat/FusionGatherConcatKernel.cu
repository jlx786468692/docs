#include <NvInfer.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <iostream>
#include <type_traits>

namespace nvinfer1 {
namespace plugin {

__device__ float sign_func(float x) { return (x > 0.0f) ? 1.0f : ((x < 0.0f) ? -1.0f : 0.0f); }

__device__ half sign_func(half x) {
  // Convert to float for accurate comparison, then back to half
  float x_float = __half2float(x);
  float result = (x_float > 0.0f) ? 1.0f : ((x_float < 0.0f) ? -1.0f : 0.0f);
  return __float2half(result);
}

__device__ float reverse_sign_func(float x) {
  return (x > 0.0f) ? -1.0f : ((x < 0.0f) ? 1.0f : 0.0f);
}

__device__ half reverse_sign_func(half x) {
  // Convert to float for accurate comparison, then back to half
  float x_float = __half2float(x);
  float result = (x_float > 0.0f) ? -1.0f : ((x_float < 0.0f) ? 1.0f : 0.0f);
  return __float2half(result);
}

__global__ void fuse_gather_concat_fp32(const float* input, float* output, const int batch_size) {
  // Calculate thread index
  int idx = blockIdx.x * blockDim.x + threadIdx.x;

  // Each thread processes one row of the input
  if (idx < batch_size) {
    // Get pointers to the current row in input and output
    const float* input_row = input + idx * 11;
    float* output_row = output + idx * 10;  // Output has 10 columns

    // slice0 = input[:,0:3]
    for (int i = 0; i < 3; i++) {
      output_row[i] = input_row[i];
    }

    // slice2 = input[:,3:6] and exp = np.exp(slice2)
    for (int i = 0; i < 3; i++) {
      output_row[3 + i] = expf(input_row[3 + i]);
    }

    // Extract gather values
    float gather1 = input_row[6];  // input[:,6:7].squeeze()
    float gather0 = input_row[7];  // input[:,7:8].squeeze()

    // gather0-branch0
    float sign00 = sign_func(gather0);
    float add00 = sign00 + 1.0f;
    float mul00 = add00 * 0.5f;

    // gather0-branch2
    float div02;
    if (gather0 != 0.0f) {
      div02 = gather1 / gather0;
    } else {
      // Handle division by zero case
      div02 = (gather1 >= 0.0f) ? INFINITY : -INFINITY;
    }
    float atan02 = atanf(div02);
    float mul00_02 = mul00 * atan02;

    // gather0-branch1
    float sign01 = reverse_sign_func(gather0);
    float add01 = sign01 + 1.0f;
    float mul01 = add01 * 0.5f;

    // gather1-branch0
    float sign10 = sign_func(gather1);
    float add10 = sign10 + 1.0f;
    float mul10 = add10 * 0.5f;

    float add02_b0 = atan02 + 3.14159265358979323846f;  // M_PI
    float sub02_b1 = atan02 - 3.14159265358979323846f;  // M_PI

    float mul10_02b0 = mul10 * add02_b0;

    // gather1-branch1

    float sign11 = reverse_sign_func(gather1);

    float add11 = sign11 + 1.0f;
    float mul11 = add11 * 0.5f;

    float mul02b1_11 = mul11 * sub02_b1;
    float add10_11 = mul10_02b0 + mul02b1_11;
    float mul01_1011 = mul01 * add10_11;
    float mul00_01 = mul00_02 + mul01_1011;

    // unsqueeze0 value
    output_row[6] = mul00_01;

    // slice1 = input[:,8:11]
    for (int i = 0; i < 3; i++) {
      output_row[7 + i] = input_row[8 + i];
    }
  }
}

__global__ void fuse_gather_concat_fp16(const half* input, half* output, const int batch_size) {
  // Calculate thread index
  int idx = blockIdx.x * blockDim.x + threadIdx.x;

  // Process multiple rows per thread for better occupancy with small batches
  const int stride = blockDim.x * gridDim.x;

  // Define PI constant in half precision
  const half PI_HALF = __float2half(3.14159265358979323846f);
  const half HALF_VAL = __float2half(0.5f);
  const half ONE = __float2half(1.0f);

  for (int row = idx; row < batch_size; row += stride) {
    // Get pointers to the current row
    const half* input_row = input + row * 11;
    half* output_row = output + row * 10;  // Output has 10 columns

// slice0 = input[:,0:3] - Direct copy
#pragma unroll
    for (int i = 0; i < 3; i++) {
      output_row[i] = input_row[i];
    }

// slice2 = input[:,3:6] and exp = np.exp(slice2)
#pragma unroll
    for (int i = 0; i < 3; i++) {
      // exp计算在float中进行以提高精度
      float val = __half2float(input_row[3 + i]);
      output_row[3 + i] = __float2half(expf(val));
    }

    // Extract gather values (保持为half类型)
    half gather1 = input_row[6];
    half gather0 = input_row[7];

    // gather0-branch0 (使用half计算)
    half sign00 = sign_func(gather0);
    half add00 = __hadd(sign00, ONE);
    half mul00 = __hmul(add00, HALF_VAL);

    // gather0-branch2 (除法和atan使用float计算)
    float gather0_float = __half2float(gather0);
    float gather1_float = __half2float(gather1);
    float div02;

    if (fabsf(gather0_float) > 1e-6f) {
      div02 = gather1_float / gather0_float;
    } else {
      div02 = (gather1_float >= 0.0f) ? INFINITY : -INFINITY;
    }

    float atan02_float = atanf(div02);
    half atan02 = __float2half(atan02_float);

    // 将计算结果转回half进行后续运算
    half mul00_02 = __hmul(mul00, atan02);

    // gather0-branch1 (使用half计算)
    half sign01 = reverse_sign_func(gather0);
    half add01 = __hadd(sign01, ONE);
    half mul01 = __hmul(add01, HALF_VAL);

    // gather1-branch0 (使用half计算)
    half sign10 = sign_func(gather1);
    half add10 = __hadd(sign10, ONE);
    half mul10 = __hmul(add10, HALF_VAL);

    half add02_b0 = __hadd(atan02, PI_HALF);
    half sub02_b1 = __hsub(atan02, PI_HALF);

    half mul10_02b0 = __hmul(mul10, add02_b0);

    // gather1-branch1 (使用half计算)
    half sign11 = reverse_sign_func(gather1);
    half add11 = __hadd(sign11, ONE);
    half mul11 = __hmul(add11, HALF_VAL);

    half mul02b1_11 = __hmul(mul11, sub02_b1);
    half add10_11 = __hadd(mul10_02b0, mul02b1_11);
    half mul01_1011 = __hmul(mul01, add10_11);
    half mul00_01 = __hadd(mul00_02, mul01_1011);

    // unsqueeze0 value
    output_row[6] = mul00_01;

// slice1 = input[:,8:11] - Direct copy
#pragma unroll
    for (int i = 0; i < 3; i++) {
      output_row[7 + i] = input_row[8 + i];
    }
  }
}

int FusionGatherConcatLaunch(const void* input,
                             void* output,
                             const int batchsize,
                             const int outDtype,
                             cudaStream_t stream) {
  const int threadPerBlock = 32;
  int blocksPerGrid = (batchsize + threadPerBlock - 1) / threadPerBlock;

  if (outDtype == 0) {
    // do fp32 infer
    fuse_gather_concat_fp32<<<blocksPerGrid, threadPerBlock, 0, stream>>>(
        static_cast<const float*>(input),
        static_cast<float*>(output),
        batchsize);

    // Check for kernel launch errors
    cudaError_t error = cudaGetLastError();
    if (error != cudaSuccess) {
      printf("CUDA error: %s\n", cudaGetErrorString(error));
    }

  } else {
    // do fp32 infer
    fuse_gather_concat_fp16<<<blocksPerGrid, threadPerBlock, 0, stream>>>(
        static_cast<const half*>(input),
        static_cast<half*>(output),
        batchsize);

    // Check for kernel launch errors
    cudaError_t error = cudaGetLastError();
    if (error != cudaSuccess) {
      printf("CUDA error: %s\n", cudaGetErrorString(error));
    }
  }

  return 0;
}

}  // namespace plugin
}  // namespace nvinfer1