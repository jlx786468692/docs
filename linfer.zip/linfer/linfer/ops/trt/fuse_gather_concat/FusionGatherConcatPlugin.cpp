#include "FusionGatherConcatPlugin.h"

#include <NvInfer.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace nvinfer1 {
namespace plugin {

PluginFieldCollection FusionGatherConcatCreator::mFC{};
std::vector<PluginField> FusionGatherConcatCreator::mPluginAttributes;

FusionGatherConcat::FusionGatherConcat() {}

FusionGatherConcat::FusionGatherConcat(const void* serialData, size_t serialLength) {}

char const* FusionGatherConcat::getPluginType() const noexcept { return FUSION_GATHER_CONCAT_NAME; }

char const* FusionGatherConcat::getPluginVersion() const noexcept {
  return FUSION_GATHER_CONCAT_VERSION;
}

int32_t FusionGatherConcat::getNbOutputs() const noexcept { return 1; }

DimsExprs FusionGatherConcat::getOutputDimensions(int32_t outputIndex,
                                                  DimsExprs const* inputs,
                                                  int32_t nbInputs,
                                                  IExprBuilder& exprBuilder) noexcept {
  DimsExprs output;
  output.nbDims = 2;
  output.d[0] = inputs[0].d[0];
  output.d[1] = exprBuilder.constant(10);
  return output;
}

bool FusionGatherConcat::supportsFormatCombination(int32_t pos,
                                                   PluginTensorDesc const* inOut,
                                                   int32_t nbInputs,
                                                   int32_t nbOutputs) noexcept {
  // 1 input and 1 output
  // input.type == output.type
  ASSERT(0 <= pos && pos < 2);
  ASSERT(nbInputs == 1);
  ASSERT(nbOutputs == 1);
  ASSERT(pos < (nbInputs + nbOutputs));
  ASSERT(inOut != nullptr);

  const auto* in = &inOut[0];
  const auto* out = &inOut[1];

  // Verify format is Linear
  bool isFormatOK = (inOut[pos].format == nvinfer1::TensorFormat::kLINEAR);

  // Check data types
  if (pos == 0) {  // Input tensor
    isFormatOK &= (in->type == nvinfer1::DataType::kFLOAT || in->type == nvinfer1::DataType::kHALF);
  } else {                                  // Output tensor
    isFormatOK &= (out->type == in->type);  // Match input type
  }

  return isFormatOK;
}

void FusionGatherConcat::configurePlugin(DynamicPluginTensorDesc const* in,
                                         int32_t nbInputs,
                                         DynamicPluginTensorDesc const* out,
                                         int32_t nbOutputs) noexcept {
  mOutputDtype = (in[0].desc.type == nvinfer1::DataType::kHALF) ? 1 : 0;
}

size_t FusionGatherConcat::getWorkspaceSize(PluginTensorDesc const* inputs,
                                            int32_t nbInputs,
                                            PluginTensorDesc const* outputs,
                                            int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t FusionGatherConcat::enqueue(PluginTensorDesc const* inputDesc,
                                    PluginTensorDesc const* outputDesc,
                                    void const* const* inputs,
                                    void* const* outputs,
                                    void* workspace,
                                    cudaStream_t stream) noexcept {
  try {
    const int batch_size = inputDesc[0].dims.d[0];

    FusionGatherConcatLaunch(inputs[0], outputs[0], batch_size, mOutputDtype, stream);
    return cudaPeekAtLastError();
  } catch (std::exception const& e) {
    caughtError(e);
    return -1;
  }
}

size_t FusionGatherConcat::getSerializationSize() const noexcept { return 0; }

void FusionGatherConcat::serialize(void* buffer) const noexcept {}

void FusionGatherConcat::destroy() noexcept { delete this; }

int32_t FusionGatherConcat::initialize() noexcept { return 0; }

void FusionGatherConcat::terminate() noexcept {}

void FusionGatherConcat::setPluginNamespace(char const* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

char const* FusionGatherConcat::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

DataType FusionGatherConcat::getOutputDataType(int32_t index,
                                               nvinfer1::DataType const* inputTypes,
                                               int32_t nbInputs) const noexcept {
  return inputTypes[0];
}

IPluginV2DynamicExt* FusionGatherConcat::clone() const noexcept {
  try {
    auto* plugin = new FusionGatherConcat();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

// Plugin creator
FusionGatherConcatCreator::FusionGatherConcatCreator() {}

IPluginV2DynamicExt* FusionGatherConcatCreator::createPlugin(
    char const* name,
    PluginFieldCollection const* fc) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new FusionGatherConcat();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

IPluginV2DynamicExt* FusionGatherConcatCreator::deserializePlugin(char const* name,
                                                                  void const* serialData,
                                                                  size_t serialLength) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new FusionGatherConcat(serialData, serialLength);
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

const char* FusionGatherConcatCreator::getPluginName() const noexcept {
  return FUSION_GATHER_CONCAT_NAME;
}

const char* FusionGatherConcatCreator::getPluginVersion() const noexcept {
  return FUSION_GATHER_CONCAT_VERSION;
}

const PluginFieldCollection* FusionGatherConcatCreator::getFieldNames() noexcept { return &mFC; }

void FusionGatherConcatCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mPluginNamespace = libNamespace;
}

const char* FusionGatherConcatCreator::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(FusionGatherConcatCreator);

}  // namespace plugin
}  // namespace nvinfer1