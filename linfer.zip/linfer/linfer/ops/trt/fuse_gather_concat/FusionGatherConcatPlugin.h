#ifndef FUSION_GATHER_CONCAT_PLUGIN_H
#define FUSION_GATHER_CONCAT_PLUGIN_H

// cuda runtime
#include <cuda_fp16.h>
#include <cuda_runtime.h>

// TensorRT
#include "NvInfer.h"
#include "NvInferPlugin.h"
#include "NvInferRuntime.h"
#include "NvInferRuntimeCommon.h"

// std c++ headers

#include <cassert>
#include <cstring>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "../common/templates.h"
#include "FusionGatherConcatKernel.h"

static const char* FUSION_GATHER_CONCAT_NAME{"LinferFusionGatherConcat"};
static const char* FUSION_GATHER_CONCAT_VERSION{"1"};

namespace nvinfer1 {
namespace plugin {

class FusionGatherConcat : public nvinfer1::IPluginV2DynamicExt {
 public:
  FusionGatherConcat();
  FusionGatherConcat(const void* serialData, size_t serialLength);
  ~FusionGatherConcat() noexcept override = default;

  // IPluginV2 Methods
  // Return the plugin type. Should match the plugin name returned by the corresponding plugin
  // creator
  char const* getPluginType() const noexcept override;
  // Return the plugin version. Should match the plugin version returned by the corresponding plugin
  // creator
  char const* getPluginVersion() const noexcept override;
  //	Get the number of outputs from the layer
  int32_t getNbOutputs() const noexcept override;
  // Initialize the layer for execution. This is called when the engine is created.
  int32_t initialize() noexcept override;
  // Release resources acquired during plugin layer initialization. This is called when the engine
  // is destroyed.
  void terminate() noexcept override;
  // Find the size of the serialization buffer required to store the plugin configuration in a
  // binary file.
  size_t getSerializationSize() const noexcept override;
  // Serialize the layer. buffer	A pointer to a host buffer to serialize data. Size of buffer will
  // be at least as large as the value returned by getSerializationSize.
  void serialize(void* buffer) const noexcept override;
  // Destroy the plugin object. This will be called when the network, builder or engine is
  // destroyed.
  void destroy() noexcept override;
  // Set the namespace that this plugin object belongs to. Ideally, all plugin objects from the same
  // plugin library must have the same namespace.
  void setPluginNamespace(char const* pluginNamespace) noexcept override;
  // Return the namespace of the plugin object.
  char const* getPluginNamespace() const noexcept override;

  // IPluginV2Ext Methods
  // Return the DataType of the plugin output at the requested index.
  DataType getOutputDataType(int32_t index,
                             nvinfer1::DataType const* inputTypes,
                             int32_t nbInputs) const noexcept override;

  // IPluginV2DynamicExt Methods
  /*Clone the plugin object. This copies over internal plugin parameters as well and returns a new
   * plugin object with these parameters. If the source plugin is pre-configured with
   * configurePlugin(), the returned object must also be pre-configured. The returned object must
   * allow attachToContext() with a new execution context. Cloned plugin objects can share the same
   * per-engine immutable resource (e.g. weights) with the source object (e.g. via ref-counting) to
   * avoid duplication. */
  IPluginV2DynamicExt* clone() const noexcept override;
  // Get expressions for computing dimensions of an output tensor from dimensions of the input
  // tensors.
  DimsExprs getOutputDimensions(int32_t outputIndex,
                                DimsExprs const* inputs,
                                int32_t nbInputs,
                                IExprBuilder& exprBuilder) noexcept override;
  // Return true if plugin supports the format and datatype for the input/output indexed by pos.
  bool supportsFormatCombination(int32_t pos,
                                 PluginTensorDesc const* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;
  // Configure the plugin.
  void configurePlugin(DynamicPluginTensorDesc const* in,
                       int32_t nbInputs,
                       DynamicPluginTensorDesc const* out,
                       int32_t nbOutputs) noexcept override;
  // Find the workspace size required by the layer.
  size_t getWorkspaceSize(nvinfer1::PluginTensorDesc const* inputs,
                          int32_t nbInputs,
                          PluginTensorDesc const* outputs,
                          int32_t nbOutputs) const noexcept override;
  // Execute the layer.
  int32_t enqueue(PluginTensorDesc const* inputDesc,
                  PluginTensorDesc const* outputDesc,
                  void const* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

 private:
  std::string mPluginNamespace;
  // if 0, then it is float32, if 1, then it is float16
  int32_t mOutputDtype{0};
};

class FusionGatherConcatCreator : public nvinfer1::IPluginCreator {
 public:
  FusionGatherConcatCreator();
  ~FusionGatherConcatCreator() override = default;

  // Return the plugin name.
  char const* getPluginName() const noexcept override;
  // Return the plugin version.
  char const* getPluginVersion() const noexcept override;

  // Return a list of fields that need to be passed to createPlugin.
  PluginFieldCollection const* getFieldNames() noexcept override;

  // Return a plugin object. Return nullptr in case of error.
  IPluginV2DynamicExt* createPlugin(char const* name,
                                    nvinfer1::PluginFieldCollection const* fc) noexcept override;
  // Called during deserialization of plugin layer. Return a plugin object.
  IPluginV2DynamicExt* deserializePlugin(char const* name,
                                         void const* serialData,
                                         size_t serialLength) noexcept override;

  // Set the namespace of the plugin creator based on the plugin library it belongs to. This can be
  // set while registering the plugin creator.
  void setPluginNamespace(char const* pluginNamespace) noexcept override;
  // Return the namespace of the plugin creator object.
  char const* getPluginNamespace() const noexcept override;

 protected:
  std::string mPluginNamespace;
  static nvinfer1::PluginFieldCollection mFC;
  static std::vector<nvinfer1::PluginField> mPluginAttributes;
};

}  // namespace plugin
}  // namespace nvinfer1

#endif  // CUSTOMER_SEGMENTATION_REDUCEMEAN_PLUGIN_H