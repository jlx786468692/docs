#include <cuda_fp16.h>
#include <cuda_runtime_api.h>

#include <algorithm>

#include "linfer/ops/trt/debug/common.h"
#include "linfer/ops/trt/natten1d/natten1d_common.cuh"
#include "linfer/ops/trt/natten1d/natten1d_qk.cuh"
#include "linfer/util/internal/cuda/util.h"

/*
    query: Tensor, 维度为[batch_size, head_size, seq_len, channel], 如：[30, 2, 20, 16]
    key: Tensor, 维度为[batch_size, head_size, seq_len, channel]
    rpb: Tensor, 位置编码，维度为[heads, 2 * kernel_size - 1]
    qk_out: Tensor, 输出, 维度为[batch_size, head_size, seq_len, kernel_size]
    channel_size: int, 特征维度
    dilation: int, dilation大小
*/
template <typename T>
__global__ void natten1d_qk_kernel(const T* query,
                                   const T* key,
                                   const T* rpb,
                                   T* qk_out,
                                   unsigned int channel_size,
                                   unsigned int dilation) {
  unsigned int head_size = gridDim.y;
  unsigned int seq_len = blockDim.x;
  unsigned int kernel_size = blockDim.y;

  unsigned int LC = seq_len * channel_size;
  unsigned int HLC = head_size * LC;

  unsigned int batch_idx = blockIdx.x;
  unsigned int head_idx = blockIdx.y;
  unsigned int seq_idx = threadIdx.x;
  unsigned int kernel_idx = threadIdx.y;

  // query offset
  unsigned int query_offset = batch_idx * HLC + head_idx * LC + seq_idx * channel_size;

  // key offset
  const int ws = get_window_start(seq_idx, seq_len, kernel_size, kernel_size / 2, dilation);
  unsigned int key_offset =
      batch_idx * HLC + head_idx * LC + (ws + kernel_idx * dilation) * channel_size;

  float dot_product_result = .0;
  for (unsigned int ci = 0; ci < channel_size; ++ci) {
    dot_product_result += query[query_offset + ci] * key[key_offset + ci];
  }

  // 计算位置编码
  const unsigned int RPB_LINE_SIZE = 2 * kernel_size - 1;
  const unsigned int pi = get_pb_start(seq_idx, seq_len, kernel_size, kernel_size / 2, dilation);
  unsigned int rpb_index = head_idx * RPB_LINE_SIZE + pi + kernel_idx;
  dot_product_result += rpb[rpb_index];

  unsigned int LK = seq_len * kernel_size;
  unsigned int HLK = head_size * LK;
  unsigned int out_index = batch_idx * HLK + head_idx * LK + seq_idx * kernel_size + kernel_idx;
  qk_out[out_index] = dot_product_result;  // TODO float to T
}

namespace linfer {
namespace ops {
namespace trt {

template <typename T>
void launch_natten1d_qk_kernel(const T* query,
                               const T* key,
                               const T* rpb,
                               T* qk_out,
                               unsigned int batch_size,
                               unsigned int seq_len,
                               unsigned int head_size,
                               unsigned int channel_size,
                               unsigned int kernel_size,
                               unsigned int dilation,
                               cudaStream_t stream) {
  if (kernel_size * seq_len > 1024) {
    throw std::runtime_error("kernel size * seq len > 1024");
  }
  dim3 block_size(batch_size, head_size);
  dim3 thread_size(seq_len, kernel_size);
  natten1d_qk_kernel<<<block_size, thread_size, 0, stream>>>(query,
                                                             key,
                                                             rpb,
                                                             qk_out,
                                                             channel_size,
                                                             dilation);
  CHECK_CUDA_STATUS("natten1d_qk_kernel");
}

template <typename T>
void natten1d_qk(const T* query,
                 const T* key,
                 const T* rpb,
                 T* qk_out,
                 unsigned int batch_size,
                 unsigned int seq_len,
                 unsigned int head_size,
                 unsigned int channel_size,
                 unsigned int kernel_size,
                 unsigned int dilation,
                 cudaStream_t stream) {
  launch_natten1d_qk_kernel(query,
                            key,
                            rpb,
                            qk_out,
                            batch_size,
                            seq_len,
                            head_size,
                            channel_size,
                            kernel_size,
                            dilation,
                            stream);
}

void natten1d_qk(const float* query,
                 const float* key,
                 const float* rpb,
                 float* qk_out,
                 unsigned int batch_size,
                 unsigned int seq_len,
                 unsigned int head_size,
                 unsigned int channel_size,
                 unsigned int kernel_size,
                 unsigned int dilation,
                 cudaStream_t stream) {
  launch_natten1d_qk_kernel(query,
                            key,
                            rpb,
                            qk_out,
                            batch_size,
                            seq_len,
                            head_size,
                            channel_size,
                            kernel_size,
                            dilation,
                            stream);
}

// void natten1d_qk(const __half* query, const __half* key, const __half* rpb, __half*
// qk_out, unsigned int batch_size,
//                  unsigned int seq_len, unsigned int head_size, unsigned int channel,
//                  unsigned int kernel_size, unsigned int dilation, cudaStream_t
//                  stream) {
//     launch_natten1d_qk_kernel(query, key, rpb, qk_out, batch_size, seq_len,
//     head_size, channel, kernel_size, dilation,
//                               stream);
// }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
