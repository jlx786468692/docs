#include <cuda_fp16.h>
#include <cuda_runtime_api.h>

#include <algorithm>

#include "linfer/ops/trt/debug/common.h"
#include "linfer/ops/trt/natten1d/natten1d_av.cuh"
#include "linfer/ops/trt/natten1d/natten1d_common.cuh"
#include "linfer/util/internal/cuda/util.h"

/*
    attn: Tensor, 输出, 维度为[batch_size, head_size, seq_len, kernel_size]
    value: Tensor, 维度为[batch_size, head_size, seq_len, channel], 如：[30, 2, 20, 16]
    out: Tensor, 维度为[batch_size, head_size, seq_len, channel], 如：[30, 2, 20, 16]
    kernel_size: unsigned int, kernel大小
    dilation: unsigned int, dilation大小
*/
template <typename T>
__global__ void natten1d_av_kernel(const T* attn,
                                   const T* value,
                                   T* out,
                                   unsigned int kernel_size,
                                   unsigned int dilation) {
  unsigned int head_size = gridDim.y;
  unsigned int seq_len = blockDim.x;
  unsigned int channel_size = blockDim.y;

  unsigned int LK = seq_len * kernel_size;
  unsigned int HLK = head_size * LK;

  unsigned int LC = seq_len * channel_size;
  unsigned int HLC = head_size * LC;

  unsigned int batch_idx = blockIdx.x;
  unsigned int head_idx = blockIdx.y;
  unsigned int seq_idx = threadIdx.x;
  unsigned int channel_idx = threadIdx.y;

  // att offset
  unsigned int attn_offset = batch_idx * HLK + head_idx * LK + seq_idx * kernel_size;

  // value offset
  unsigned int value_offset = batch_idx * HLC + head_idx * LC + channel_idx;
  unsigned int ws = get_window_start(seq_idx, seq_len, kernel_size, kernel_size / 2, dilation);

  float dot_product_result = 0.f;
  for (unsigned int k = 0; k < kernel_size; ++k) {
    T attn_scalar = attn[attn_offset + k];
    T value_scalar = value[value_offset + (ws + k * dilation) * channel_size];
    dot_product_result += attn_scalar * value_scalar;
  }

  // save result to HBM
  unsigned int out_index = batch_idx * HLC + head_idx * LC + seq_idx * channel_size + channel_idx;
  out[out_index] = dot_product_result;  // TODO float to T
}

template <typename T>
void launch_natten1d_av_kernel(const T* attn,
                               const T* value,
                               T* out,
                               unsigned int batch_size,
                               unsigned int seq_len,
                               unsigned int head_size,
                               unsigned int channel_size,
                               unsigned int kernel_size,
                               unsigned int dilation,
                               cudaStream_t stream) {
  if (seq_len * channel_size > 1024) {
    throw std::runtime_error("seq_len * channel_size > 1024");
  }
  dim3 block_size(batch_size, head_size);
  dim3 thread_size(seq_len, channel_size);
  natten1d_av_kernel<<<block_size, thread_size, 0, stream>>>(attn,
                                                             value,
                                                             out,
                                                             kernel_size,
                                                             dilation);
  CHECK_CUDA_STATUS("natten1d_av_kernel");
}

namespace linfer {
namespace ops {
namespace trt {

template <typename T>
void natten1d_av(const T* attn,
                 const T* value,
                 T* out,
                 unsigned int batch_size,
                 unsigned int seq_len,
                 unsigned int head_size,
                 unsigned int channel_size,
                 unsigned int kernel_size,
                 unsigned int dilation,
                 cudaStream_t stream) {
  launch_natten1d_av_kernel(attn,
                            value,
                            out,
                            batch_size,
                            seq_len,
                            head_size,
                            channel_size,
                            kernel_size,
                            dilation,
                            stream);
}

void natten1d_av(const float* attn,
                 const float* value,
                 float* out,
                 unsigned int batch_size,
                 unsigned int seq_len,
                 unsigned int head_size,
                 unsigned int channel_size,
                 unsigned int kernel_size,
                 unsigned int dilation,
                 cudaStream_t stream) {
  launch_natten1d_av_kernel(attn,
                            value,
                            out,
                            batch_size,
                            seq_len,
                            head_size,
                            channel_size,
                            kernel_size,
                            dilation,
                            stream);
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer