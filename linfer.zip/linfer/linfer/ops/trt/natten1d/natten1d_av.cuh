#pragma once

#include <cuda_fp16.h>

#include <cstdint>

namespace linfer {
namespace ops {
namespace trt {

void natten1d_av(const float* attn,
                 const float* value,
                 float* out,
                 unsigned int batch_size,
                 unsigned int seq_len,
                 unsigned int head_size,
                 unsigned int channel_size,
                 unsigned int kernel_size,
                 unsigned int dilation,
                 cudaStream_t stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer
