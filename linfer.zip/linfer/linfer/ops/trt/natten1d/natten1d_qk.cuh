#pragma once

#include <cuda_fp16.h>

#include <cstdint>

namespace linfer {
namespace ops {
namespace trt {

void natten1d_qk(const float* query,
                 const float* key,
                 const float* rpb,
                 float* qk_out,
                 unsigned int batch_size,
                 unsigned int seq_len,
                 unsigned int head_size,
                 unsigned int channel,
                 unsigned int kernel_size,
                 unsigned int dilation,
                 cudaStream_t stream);

// void natten1d_qk(const __half* query, const __half* key, const __half* rpb, __half*
// qk_out, unsigned int batch_size,
//                  unsigned int seq_len, unsigned int head_size, unsigned int channel,
//                  unsigned int kernel_size, unsigned int dilation, cudaStream_t
//                  stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer
