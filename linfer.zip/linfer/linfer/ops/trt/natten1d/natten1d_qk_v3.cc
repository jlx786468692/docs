#include "natten1d_qk_v3.h"

#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "linfer/ops/trt/debug/common.h"
#include "linfer/ops/trt/natten1d/natten1d_qk.cuh"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/numpy.h"
#include "linfer/util/print.h"

using linfer::ops::trt::Natten1DQKLayerV3Creator;
REGISTER_TENSORRT_PLUGIN(Natten1DQKLayerV3Creator);

namespace {
constexpr char const* NATTEN1DQKLAYER_PLUGINV3_VERSION{"1"};
constexpr char const* NATTEN1DQKLAYER_PLUGINV3_NAME{"Natten1DQKV3"};
}  // namespace

namespace linfer {
namespace ops {
namespace trt {

nvinfer1::PluginFieldCollection Natten1DQKLayerV3Creator::mFC{};
std::vector<nvinfer1::PluginField> Natten1DQKLayerV3Creator::mPluginAttributes;

Natten1DQKLayerV3::Natten1DQKLayerV3(int32_t kernel_size, int32_t dilation)
    : kernel_size_(kernel_size), dilation_(dilation) {}

nvinfer1::IPluginCapability* Natten1DQKLayerV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* Natten1DQKLayerV3::getPluginName() const noexcept {
  return NATTEN1DQKLAYER_PLUGINV3_NAME;
}

char const* Natten1DQKLayerV3::getPluginVersion() const noexcept {
  return NATTEN1DQKLAYER_PLUGINV3_VERSION;
}

int32_t Natten1DQKLayerV3::getNbOutputs() const noexcept { return 1; }

void Natten1DQKLayerV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* Natten1DQKLayerV3::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

nvinfer1::IPluginV3* Natten1DQKLayerV3::clone() noexcept {
  try {
    auto* plugin = new Natten1DQKLayerV3(kernel_size_, dilation_);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t Natten1DQKLayerV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                              int32_t nbOutputs,
                                              nvinfer1::DataType const* inputTypes,
                                              int32_t nbInputs) const noexcept {
  try {
    PLUGIN_ASSERT(nbOutputs == 1);
    // Output type is the same as query input type
    outputTypes[0] = inputTypes[query_idx_];
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t Natten1DQKLayerV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::DimsExprs const* shapeInputs,
                                           int32_t nbShapeInputs,
                                           nvinfer1::DimsExprs* outputs,
                                           int32_t nbOutputs,
                                           nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    PLUGIN_ASSERT(nbInputs == 3);
    PLUGIN_ASSERT(nbOutputs == 1);

    auto query_dim = inputs[query_idx_];
    PLUGIN_ASSERT(4 == query_dim.nbDims);

    nvinfer1::DimsExprs output_dim = query_dim;
    output_dim.d[3] = exprBuilder.constant(kernel_size_);
    outputs[0] = output_dim;

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool Natten1DQKLayerV3::supportsFormatCombination(int32_t pos,
                                                  nvinfer1::DynamicPluginTensorDesc const* inOut,
                                                  int32_t nbInputs,
                                                  int32_t nbOutputs) noexcept {
  try {
    PLUGIN_ASSERT(pos <= 3);
    PLUGIN_ASSERT(nbInputs == 3);
    PLUGIN_ASSERT(nbOutputs == 1);

    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;
    return (desc.type == nvinfer1::DataType::kFLOAT) &&
           (desc.format == nvinfer1::TensorFormat::kLINEAR);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t Natten1DQKLayerV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                           int32_t nbInputs,
                                           nvinfer1::DynamicPluginTensorDesc const* out,
                                           int32_t nbOutputs) noexcept {
  try {
    PLUGIN_ASSERT(nbInputs == 3);
    PLUGIN_ASSERT(nbOutputs == 1);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const* Natten1DQKLayerV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("kernel_size", &kernel_size_, nvinfer1::PluginFieldType::kINT32, 1));
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("dilation", &dilation_, nvinfer1::PluginFieldType::kINT32, 1));

    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t Natten1DQKLayerV3::getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::DynamicPluginTensorDesc const* outputs,
                                           int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t Natten1DQKLayerV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                         int32_t nbInputs,
                                         nvinfer1::PluginTensorDesc const* outputs,
                                         int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* Natten1DQKLayerV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t Natten1DQKLayerV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                                   nvinfer1::PluginTensorDesc const* outputDesc,
                                   void const* const* inputs,
                                   void* const* outputs,
                                   void* workspace,
                                   cudaStream_t stream) noexcept {
  try {
    auto input_desc_query = inputDesc[query_idx_];
    auto dims = input_desc_query.dims;
    unsigned int batch_size = static_cast<unsigned int>(dims.d[0]);
    unsigned int head_size = static_cast<unsigned int>(dims.d[1]);
    unsigned int seq_len = static_cast<unsigned int>(dims.d[2]);
    unsigned int channel_size = static_cast<unsigned int>(dims.d[3]);
    unsigned int kernel_size = static_cast<unsigned int>(kernel_size_);
    unsigned int dilation = static_cast<unsigned int>(dilation_);

    PLUGIN_ASSERT(input_desc_query.type == nvinfer1::DataType::kFLOAT);

    natten1d_qk((float*)inputs[query_idx_],
                (float*)inputs[key_idx_],
                (float*)inputs[rpb_idx_],
                (float*)outputs[0],
                batch_size,
                seq_len,
                head_size,
                channel_size,
                kernel_size,
                dilation,
                stream);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

// Plugin Creator Implementation
Natten1DQKLayerV3Creator::Natten1DQKLayerV3Creator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("kernel_size", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("dilation", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* Natten1DQKLayerV3Creator::getPluginName() const noexcept {
  return NATTEN1DQKLAYER_PLUGINV3_NAME;
}

char const* Natten1DQKLayerV3Creator::getPluginVersion() const noexcept {
  return NATTEN1DQKLAYER_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const* Natten1DQKLayerV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* Natten1DQKLayerV3Creator::createPlugin(
    char const* name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  try {
    int32_t kernel_size = 1, dilation = 1;

    for (int32_t i = 0; i < fc->nbFields; i++) {
      std::string field_name(fc->fields[i].name);
      auto field_data = fc->fields[i].data;
      auto field_len = fc->fields[i].length;

      if (field_name.compare("kernel_size") == 0) {
        kernel_size = *static_cast<const int32_t*>(field_data);
      } else if (field_name.compare("dilation") == 0) {
        dilation = *static_cast<const int32_t*>(field_data);
      } else {
        PLUGIN_ASSERT(false && "unexpected field_name");
      }
    }

    PLUGIN_ASSERT(kernel_size > 0);
    PLUGIN_ASSERT(dilation > 0);

    auto* plugin = new Natten1DQKLayerV3(kernel_size, dilation);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void Natten1DQKLayerV3Creator::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* Natten1DQKLayerV3Creator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer