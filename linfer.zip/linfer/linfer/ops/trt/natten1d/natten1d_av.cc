
#include "linfer/ops/trt/natten1d/natten1d_av.h"

#include <NvInfer.h>
#include <cublas_v2.h>

#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

#include "linfer/ops/trt/debug/common.h"
#include "linfer/ops/trt/natten1d/natten1d_av.cuh"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/numpy.h"
#include "linfer/util/print.h"

using linfer::ops::trt::Natten1DAVLayer;
using linfer::ops::trt::Natten1DAVLayerCreator;

REGISTER_TENSORRT_PLUGIN(Natten1DAVLayerCreator);

namespace {
const char* Natten1DAVLayer_PLUGIN_VERSION{"1"};
const char* Natten1DAVLayer_PLUGIN_NAME{"Natten1DAV"};
}  // namespace

namespace linfer {
namespace ops {
namespace trt {

nvinfer1::PluginFieldCollection Natten1DAVLayerCreator::mFC{};
std::vector<nvinfer1::PluginField> Natten1DAVLayerCreator::mPluginAttributes;

Natten1DAVLayer::Natten1DAVLayer(int32_t kernel_size, int32_t dilation)
    : kernel_size_(kernel_size), dilation_(dilation) {}

int Natten1DAVLayer::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType Natten1DAVLayer::getOutputDataType(int index,
                                                      const nvinfer1::DataType* inputTypes,
                                                      int nbInputs) const noexcept {
  LCHECK(index == 0);
  return inputTypes[value_idx_];
}

nvinfer1::DimsExprs Natten1DAVLayer::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[value_idx_];
  ;
}

int Natten1DAVLayer::initialize() noexcept { return 0; }

void Natten1DAVLayer::terminate() noexcept {}

bool Natten1DAVLayer::supportsFormatCombination(int32_t pos,
                                                const nvinfer1::PluginTensorDesc* inOut,
                                                int32_t nbInputs,
                                                int32_t nbOutputs) noexcept {
  LCHECK(pos <= 2);
  LCHECK(nbInputs == 2);
  LCHECK(nbOutputs == 1);
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  return (desc.type == nvinfer1::DataType::kFLOAT) &&
         (desc.format == nvinfer1::TensorFormat::kLINEAR);
}

void Natten1DAVLayer::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                      int32_t nbInputs,
                                      const nvinfer1::DynamicPluginTensorDesc* out,
                                      int32_t nbOutputs) noexcept {}

size_t Natten1DAVLayer::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                         int32_t nbInputs,
                                         const nvinfer1::PluginTensorDesc* outputs,
                                         int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t Natten1DAVLayer::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                 const nvinfer1::PluginTensorDesc* outputDesc,
                                 const void* const* inputs,
                                 void* const* outputs,
                                 void* workspace,
                                 cudaStream_t stream) noexcept {
  auto input_desc = inputDesc[value_idx_];
  auto dims = input_desc.dims;
  unsigned int batch_size = static_cast<unsigned int>(dims.d[0]);
  unsigned int head_size = static_cast<unsigned int>(dims.d[1]);
  unsigned int seq_len = static_cast<unsigned int>(dims.d[2]);
  unsigned int channel_size = static_cast<unsigned int>(dims.d[3]);
  unsigned int kernel_size = static_cast<unsigned int>(kernel_size_);
  unsigned int dilation = static_cast<unsigned int>(dilation_);

  if (input_desc.type == nvinfer1::DataType::kFLOAT) {
    natten1d_av((float*)inputs[att_idx_],
                (float*)inputs[value_idx_],
                (float*)outputs[0],
                batch_size,
                seq_len,
                head_size,
                channel_size,
                kernel_size,
                dilation,
                stream);
  }
  return 0;
}

size_t Natten1DAVLayer::getSerializationSize() const noexcept {
  return sizeof(kernel_size_) + sizeof(dilation_);
}

void Natten1DAVLayer::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int32_t>(buf, static_cast<int32_t>(kernel_size_));
  write<int32_t>(buf, static_cast<int32_t>(dilation_));
  LASSERT_MSG(buf, start + getSerializationSize());
}

void Natten1DAVLayer::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* Natten1DAVLayer::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

// Attach the plugin object to an execution context and grant the plugin the access to
// some context resource.
void Natten1DAVLayer::attachToContext(cudnnContext* cudnn,
                                      cublasContext* cublas,
                                      nvinfer1::IGpuAllocator* gpuAllocator) noexcept {
  return;
}

// Detach the plugin object from its execution context.
void Natten1DAVLayer::detachFromContext() noexcept {}

const char* Natten1DAVLayer::getPluginType() const noexcept { return Natten1DAVLayer_PLUGIN_NAME; }

const char* Natten1DAVLayer::getPluginVersion() const noexcept {
  return Natten1DAVLayer_PLUGIN_VERSION;
}

void Natten1DAVLayer::destroy() noexcept { delete this; }

nvinfer1::IPluginV2DynamicExt* Natten1DAVLayer::clone() const noexcept {
  Natten1DAVLayer* plugin = new Natten1DAVLayer(kernel_size_, dilation_);
  plugin->setPluginNamespace(mPluginNamespace.c_str());
  return plugin;
}

Natten1DAVLayerCreator::Natten1DAVLayerCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("kernel_size", nullptr, nvinfer1::PluginFieldType::kINT32, 4));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("dilation", nullptr, nvinfer1::PluginFieldType::kINT32, 4));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* Natten1DAVLayerCreator::getPluginName() const noexcept {
  return Natten1DAVLayer_PLUGIN_NAME;
}

const char* Natten1DAVLayerCreator::getPluginVersion() const noexcept {
  return Natten1DAVLayer_PLUGIN_VERSION;
}

const nvinfer1::PluginFieldCollection* Natten1DAVLayerCreator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV2Ext* Natten1DAVLayerCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int32_t kernel_size = 1, dilation = 1;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("kernel_size") == 0) {
      kernel_size = *static_cast<const int32_t*>(field_data);
    } else if (field_name.compare("dilation") == 0) {
      dilation = *static_cast<const int32_t*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }

  Natten1DAVLayer* obj = new Natten1DAVLayer(kernel_size, dilation);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* Natten1DAVLayerCreator::deserializePlugin(const char* name,
                                                                  const void* serialData,
                                                                  size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;
  int32_t kernel_size = static_cast<int32_t>(read<int32_t>(buf));
  int32_t dilation = static_cast<int32_t>(read<int32_t>(buf));
  Natten1DAVLayer* obj = new Natten1DAVLayer(kernel_size, dilation);
  obj->setPluginNamespace(mNamespace.c_str());
  LASSERT_MSG((buf - buf_start) == serialLength, "serialize and deserialize mismatch!");
  return obj;
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
