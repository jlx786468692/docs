#pragma once

#include <NvInfer.h>
#include <cublas_v2.h>

#include <string>
#include <vector>

#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/trt/plugin.h"

namespace linfer {
namespace ops {
namespace trt {

class Natten1DAVLayer : public nvinfer1::IPluginV2DynamicExt {
 public:
  Natten1DAVLayer(int32_t kernel_size, int32_t dilation);

  ~Natten1DAVLayer() override = default;

  int getNbOutputs() const noexcept override;

  virtual nvinfer1::DimsExprs getOutputDimensions(
      int32_t outputIndex,
      const nvinfer1::DimsExprs* inputs,
      int32_t nbInputs,
      nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  // virtual size_t getWorkspaceSize(PluginTensorDesc const* inputs, int32_t nbInputs,
  // PluginTensorDesc const* outputs,
  //         int32_t nbOutputs) const noexcept = 0;
  size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                          int32_t nbInputs,
                          const nvinfer1::PluginTensorDesc* outputs,
                          int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

 private:
  std::string mPluginNamespace;
  int32_t kernel_size_, dilation_;

  static constexpr int att_idx_ = 0;
  static constexpr int value_idx_ = 1;
};

class Natten1DAVLayerCreator : public BaseCreator {
 public:
  Natten1DAVLayerCreator();

  ~Natten1DAVLayerCreator() override = default;

  const char* getPluginName() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;

  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept override;

  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept override;

 private:
  static nvinfer1::PluginFieldCollection mFC;
  static std::vector<nvinfer1::PluginField> mPluginAttributes;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer
