#pragma once

inline __host__ __device__ int get_window_start(const int index,
                                                const int length,
                                                const int KERNEL_SIZE,
                                                const int NEIGHBORHOOD_SIZE,
                                                const int dilation) {
  if (dilation <= 1)
    return max(index - NEIGHBORHOOD_SIZE, 0) +
           (index + NEIGHBORHOOD_SIZE >= length) * (length - index - NEIGHBORHOOD_SIZE - 1);
  int ni = index - NEIGHBORHOOD_SIZE * dilation;
  if (ni < 0) return index % dilation;
  if (index + NEIGHBORHOOD_SIZE * dilation >= length) {
    const int imodd = index % dilation;
    const int a = int(length / dilation) * dilation;
    const int b = length - a;
    if (imodd < b) return length - b + imodd - 2 * NEIGHBORHOOD_SIZE * dilation;
    return a + imodd - KERNEL_SIZE * dilation;
  }
  return ni;
}

inline __host__ __device__ int get_pb_start(const int index,
                                            const int length,
                                            const int KERNEL_SIZE,
                                            const int NEIGHBORHOOD_SIZE,
                                            const int dilation) {
  if (dilation <= 1)
    return NEIGHBORHOOD_SIZE + (index < NEIGHBORHOOD_SIZE) * (NEIGHBORHOOD_SIZE - index) +
           (index + NEIGHBORHOOD_SIZE >= length) * (length - index - 1 - NEIGHBORHOOD_SIZE);
  if (index - NEIGHBORHOOD_SIZE * dilation < 0) return KERNEL_SIZE - 1 - (index / dilation);
  if (index + NEIGHBORHOOD_SIZE * dilation >= length) return (length - index - 1) / dilation;
  return NEIGHBORHOOD_SIZE;
}
