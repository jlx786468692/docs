#include "mean.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "mean_kernel.h"

using linfer::ops::trt::MeanPluginCreator;
REGISTER_TENSORRT_PLUGIN(MeanPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

enum INOUT_POS {
  input = 0,
  output_base = 1,
  output_base_input = output_base,
  output = output_base_input - output_base,
};

const char* MEAN_PLUGIN_VERSION{"1"};
static const char* MEAN_PLUGIN_NAME{"LinferReduceMean"};

nvinfer1::PluginFieldCollection MeanPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> MeanPluginCreator::mPluginAttributes;

Mean::Mean(int axis, int keepdim) : axis_(axis), keepdim_(keepdim) {}

Mean::~Mean() {}

int Mean::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType Mean::getOutputDataType(int index,
                                           const nvinfer1::DataType* inputTypes,
                                           int nbInputs) const noexcept {
  return inputTypes[INOUT_POS::input];
}

nvinfer1::DimsExprs Mean::getOutputDimensions(int32_t outputIndex,
                                              const nvinfer1::DimsExprs* inputs,
                                              int32_t nbInputs,
                                              nvinfer1::IExprBuilder& exprBuilder) noexcept {
  auto input_dim = inputs[INOUT_POS::input];
  if (!((axis_ >= 0 && axis_ < input_dim.nbDims) || (axis_ < 0 && axis_ >= -input_dim.nbDims))) {
    LERROR_FMT("axis is out of range, axis: %d, nbDims: %d", axis_, input_dim.nbDims);
  }
  auto axis = (axis_ < 0) ? (input_dim.nbDims + axis_) : axis_;
  if (keepdim_) {
    nvinfer1::DimsExprs output_dims = input_dim;
    output_dims.d[axis] = exprBuilder.constant(1);
    return output_dims;
  } else {
    nvinfer1::DimsExprs output_dims;
    output_dims.nbDims = input_dim.nbDims - 1;
    for (int i = 0; i < axis; i++) {
      output_dims.d[i] = input_dim.d[i];
    }

    for (int i = axis; i < input_dim.nbDims - 1; i++) {
      output_dims.d[i] = input_dim.d[i + 1];
    }

    return output_dims;
  }
}

bool Mean::supportsFormatCombination(int32_t pos,
                                     const nvinfer1::PluginTensorDesc* inOut,
                                     int32_t nbInputs,
                                     int32_t nbOutputs) noexcept {
  auto dtype = inOut[pos].type;
  auto dformat = inOut[pos].format;

  switch (pos) {
    case INOUT_POS::input:
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
             dformat == nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::output_base_input:
      return dtype == inOut[INOUT_POS::input].type && dformat == inOut[INOUT_POS::input].format;
    default:
      return false;
  }
}

void Mean::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                           int32_t nbInputs,
                           const nvinfer1::DynamicPluginTensorDesc* out,
                           int32_t nbOutputs) noexcept {}

size_t Mean::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                              int32_t nbInputs,
                              const nvinfer1::PluginTensorDesc* outputs,
                              int32_t nbOutputs) const noexcept {
  return 0;
}

int Mean::initialize() noexcept { return 0; }

void Mean::terminate() noexcept {}

int32_t Mean::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                      const nvinfer1::PluginTensorDesc* outputDesc,
                      const void* const* inputs,
                      void* const* outputs,
                      void* workspace,
                      cudaStream_t stream) noexcept {
  const void* input_ptr = inputs[INOUT_POS::input];
  auto input_dim = inputDesc[INOUT_POS::input].dims;
  auto axis = (axis_ < 0) ? (input_dim.nbDims + axis_) : axis_;

  unsigned int n_left = 1, n_right = 1, n_mean = input_dim.d[axis];
  for (int i = 0; i < axis; i++) {
    n_left *= input_dim.d[i];
  }

  for (int i = axis + 1; i < input_dim.nbDims; i++) {
    n_right *= input_dim.d[i];
  }

  void* output = outputs[INOUT_POS::output];

  // linfer::util::print_nv_tensor_desc(inputDesc[0]);
  // linfer::util::print_nv_tensor_desc(outputDesc[0]);

  bool use_float16 = inputDesc[INOUT_POS::input].type == nvinfer1::DataType::kHALF;
  if (use_float16) {
    // printf("use float16\n");
    launch_mean_kernel((const __half*)input_ptr, (__half*)output, n_left, n_mean, n_right, stream);
  } else {  // use float32
    // printf("use float32\n");
    launch_mean_kernel((const float*)input_ptr, (float*)output, n_left, n_mean, n_right, stream);
  }
  return 0;
}

size_t Mean::getSerializationSize() const noexcept {
  // int axis_, keepdim_;
  return sizeof(int) * 2;
}

void Mean::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int>(buf, axis_);
  write<int>(buf, keepdim_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* Mean::getPluginType() const noexcept { return MEAN_PLUGIN_NAME; }

const char* Mean::getPluginVersion() const noexcept { return MEAN_PLUGIN_VERSION; }

void Mean::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* Mean::clone() const noexcept {
  auto plugin = new Mean(axis_, keepdim_);
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void Mean::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* Mean::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void Mean::attachToContext(cudnnContext* cudnnContext,
                           cublasContext* cublasContext,
                           nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void Mean::detachFromContext() noexcept {}

MeanPluginCreator::MeanPluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("axis", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("keepdim", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* MeanPluginCreator::getPluginVersion() const noexcept { return MEAN_PLUGIN_VERSION; }
const char* MeanPluginCreator::getPluginName() const noexcept { return MEAN_PLUGIN_NAME; }
const nvinfer1::PluginFieldCollection* MeanPluginCreator::getFieldNames() noexcept {
  return &MeanPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* MeanPluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int axis, keepdim;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("axis") == 0) {
      axis = *static_cast<const int32_t*>(field_data);
    } else if (field_name.compare("keepdim") == 0) {
      keepdim = *static_cast<const int32_t*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }
  LINFO_FMT("axis: %d, keepdim: %d\n", axis, keepdim);

  Mean* obj = new Mean(axis, keepdim);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* MeanPluginCreator::deserializePlugin(const char* plugin_name,
                                                             const void* serialData,
                                                             size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;
  auto axis = read<int>(buf);
  auto keepdim = read<int>(buf);

  LINFO_FMT("axis: %d, keepdim: %d\n", axis, keepdim);
  auto obj = new Mean(axis, keepdim);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void MeanPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* MeanPluginCreator::getPluginNamespace() const noexcept { return namespace_.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
