#pragma once

#include <cuda_fp16.h>
#include <cuda_runtime.h>

namespace linfer {
namespace ops {
namespace trt {

void launch_mean_kernel(const float* input,
                        float* output,
                        unsigned int n_left,
                        unsigned int n_mean,
                        unsigned int n_right,
                        cudaStream_t stream);

void launch_mean_kernel(const __half* input,
                        __half* output,
                        unsigned int n_left,
                        unsigned int n_mean,
                        unsigned int n_right,
                        cudaStream_t stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer
