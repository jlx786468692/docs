

#include <cmath>

#include "linfer/util/log.h"
#include "mean.h"
#include "mean_kernel.h"

namespace linfer {
namespace ops {
namespace trt {

__device__ inline float __to_float(__half x) { return __half2float(x); }

__device__ inline float __to_float(float x) { return x; }

// FIXME 对某些任务可能会产生溢出问题，对onemodel任务已够用。
template <typename T>
__global__ void mean_kernel(const T* input,
                            T* output,
                            unsigned int n_left,
                            unsigned int n_mean,
                            unsigned int n_right) {
  unsigned int idx_global = blockIdx.x * blockDim.x + threadIdx.x;
  unsigned int n_global = n_left * n_right;
  if (idx_global >= n_global) {
    return;
  }

  unsigned int idx_left = idx_global / n_right;
  unsigned int idx_right = idx_global % n_right;

  float sum = 0.f;
  // T sum = 0.f;
  unsigned int offset = idx_left * n_mean * n_right + idx_right;
  // unsigned int NC = gridDim.x * blockDim.x;
  for (unsigned int i = 0; i < n_mean; ++i) {
    sum += __to_float(input[i * n_right + offset]) * 1e-4f;
    // sum += 1e-3 * input[i * NC + offset];
  }

  output[idx_left * n_right + idx_right] = (sum / n_mean) * 1e4f;
  // output[offset] = (sum / n) * 1e3;
}

template <typename T>
void launch_mean_kernel_(const T* input,
                         T* output,
                         unsigned int n_left,
                         unsigned int n_mean,
                         unsigned int n_right,
                         cudaStream_t stream) {
  int thread_per_block = 256;
  int block_per_grid = std::ceil((float)n_left * n_right / thread_per_block);
  mean_kernel<<<block_per_grid, thread_per_block, 0, stream>>>(input,
                                                               output,
                                                               n_left,
                                                               n_mean,
                                                               n_right);
  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    LERROR_FMT("error in launch_mean_kernel_: %s\n", cudaGetErrorString(err));
  }
}

void launch_mean_kernel(const float* input,
                        float* output,
                        unsigned int n_left,
                        unsigned int n_mean,
                        unsigned int n_right,
                        cudaStream_t stream) {
  launch_mean_kernel_(input, output, n_left, n_mean, n_right, stream);
}

void launch_mean_kernel(const __half* input,
                        __half* output,
                        unsigned int n_left,
                        unsigned int n_mean,
                        unsigned int n_right,
                        cudaStream_t stream) {
  launch_mean_kernel_(input, output, n_left, n_mean, n_right, stream);
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
