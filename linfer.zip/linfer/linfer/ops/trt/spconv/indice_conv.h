#pragma once

#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_runtime_api.h>

#include "centerpoint_util.h"
// #include <NvInfer.h>
// headers in STL
#include <cuda_fp16.h>
#include <thrust/execution_policy.h>
#include <thrust/unique.h>

#include <algorithm>
#include <iostream>
#include <memory>
#include <vector>

#include "cublas_v2.h"

typedef struct IndiceConvCuda {
  void* gemm_op_half;
  char* workspace;
  bool subM;
  int nDim;
  int numInPlanes;
  int numOutPlanes;
  int kernelVolumes;
  int numActOut;
  int numActIn;
  int use_half;
  int maxVoxelSize;
  // cublasHandle_t handle;
  float* filters;
  __half* half_filters;
  float* bias;
  __half* half_bias;
  int* host_indicePairNum;
  float* dev_inputBuffer;
  float* dev_outputBuffer;
  __half* dev_half_inputBuffer;
  __half* dev_half_outputBuffer;

  bool initial;
  IndiceConvCuda() { initial = false; }
  void Reset(bool in_subM,
             int in_nDim,
             int in_numInPlanes,
             int in_numOutPlanes,
             int in_kernelVolumes,
             int in_maxVoxels,
             float* in_filters,
             float* in_bias);
  void Reset(bool in_subM,
             int in_nDim,
             int in_numInPlanes,
             int in_numOutPlanes,
             int in_kernelVolumes,
             int in_maxVoxels,
             float* in_filters,
             float* in_bias,
             cublasHandle_t& in_handle);
  IndiceConvCuda(bool in_subM,
                 int in_nDim,
                 int in_numInPlanes,
                 int in_numOutPlanes,
                 int in_kernelVolumes,
                 int in_maxVoxels,
                 float* in_filters,
                 float* in_bias);
  IndiceConvCuda(bool in_subM,
                 int in_nDim,
                 int in_numInPlanes,
                 int in_numOutPlanes,
                 int in_kernelVolumes,
                 int in_maxVoxels,
                 float* in_filters,
                 float* in_bias,
                 cublasHandle_t& in_handle);
  ~IndiceConvCuda();
  void MemSet(float* in_filters, float* in_bias);
  void MemFree();

  void indiceConv_process(float* features,
                          int* indicesPairs,
                          int* indiceNum,
                          float* output,
                          int in_numActIn,
                          int in_numActOut,
                          cudaStream_t stream);
  void indiceConv_process(__half* features,
                          int* indicesPairs,
                          int* indiceNum,
                          __half* output,
                          int in_numActIn,
                          int in_numActOut,
                          cudaStream_t stream);
} IndiceConvCuda_t;
