#include <stdio.h>

#include <algorithm>
#include <chrono>
#include <vector>

#include "indice.h"
#include "kernel_utils.h"

using namespace std::chrono;

__device__ __host__ int getValidOutPos(const int NDim,
                                       const int* input_pos,
                                       const int* kernelSize,
                                       const int* stride,
                                       const int* padding,
                                       const int* dilation,
                                       const int* outSpatialShape,
                                       int* out) {
  int lowers[dims3_t::value];
  int uppers[dims3_t::value];
  int counter[dims3_t::value];
  int counterSize[dims3_t::value];
  int pointCounter = 0;
  int val;
  int numPoints = 1;
  int m, offset;
  bool valid = false;
  // printf("input_pos: %d %d %d\n", input_pos[0], input_pos[1], input_pos[2]);
#pragma unroll
  for (int i = 0; i < NDim; ++i) {
    lowers[i] =
        (input_pos[i] - (kernelSize[i] - 1) * dilation[i] - 1 + stride[i] + padding[i]) / stride[i];
    uppers[i] = (input_pos[i] + padding[i]) / stride[i];
  }

#pragma unroll
  for (unsigned i = 0; i < NDim; ++i) {
    counterSize[i] = ((uppers[i] - lowers[i]) / dilation[i] + 1);
    numPoints *= counterSize[i];
  }

#pragma unroll
  for (int i = 0; i < NDim; ++i) {
    counter[i] = 0;
  }
  for (int i = 0; i < numPoints; ++i) {
    valid = true;
    m = 1;
    offset = 0;
#pragma unroll
    for (int j = NDim - 1; j >= 0; --j) {
      val = uppers[j] - counter[j] * dilation[j];
      out[pointCounter * (NDim + 1) + j] = val;
      if (val < 0 || (val > outSpatialShape[j] - 1)) {
        valid = false;
        // break;
      }
      offset += m * (input_pos[j] - val * stride[j] + padding[j]) / dilation[j];
      m *= kernelSize[j];
    }

    out[pointCounter * (NDim + 1) + NDim] = offset;
    if (valid) ++pointCounter;
    counter[NDim - 1] += 1;
#pragma unroll
    for (int c = NDim - 1; c >= 0; --c) {
      if (counter[c] == counterSize[c] && c > 0) {
        counter[c - 1] += 1;
        counter[c] = 0;
      }
    }
  }
  return pointCounter;
}

__global__ void assignGridAndIndiceOutKernel(int NDim,
                                             int* indicesOut,
                                             int* gridsOut,
                                             int numAct,
                                             int* indicePairs,
                                             int* indicePairUnique,
                                             int* outSpatialShape,
                                             int batchSize) {
  int index;
  auto indicesOutPtr = indicesOut;
  for (int ix : tv::KernelLoopX<int>(numAct)) {
    index = indicePairUnique[ix];
    gridsOut[index] = ix;
    index = rowArrayIdxInv<int, 3>(index, indicesOutPtr + ix * (NDim + 1) + 1, outSpatialShape);
    indicesOut[ix * (NDim + 1)] = index % batchSize;
  }
}

__global__ void assignIndicePairsKernel(int* indicesOut,
                                        int* gridsOut,
                                        int numActIn,
                                        int kernelVolume,
                                        int* indicePairs,
                                        int* indicePairUnique,
                                        const int* outSpatialShape) {
  int index;
  // int kernelVolume = indicePairs.dim(1);
  auto indicePairsOut = indicePairs + kernelVolume * numActIn;

  for (int ix : tv::KernelLoopX<int>(numActIn)) {
    for (size_t i = 0; i < kernelVolume; i++) {
      index = indicePairsOut[i * numActIn + ix];
      if (index > -1) {
        indicePairsOut[i * numActIn + ix] = gridsOut[index];
      }
    }
  }
}

__global__ void prepareSubMGridKernel(int NDim,
                                      int numActIn,
                                      int* indicesIn,
                                      int* gridsOut,
                                      int* outSpatialShape,
                                      int spatialVolume) {
  int index = 0;
  for (int ix : tv::KernelLoopX<int>(numActIn)) {
    index = ArrayIndexRowMajor<3, 3>::runPtrs(indicesIn + ix * (NDim + 1) + 1, outSpatialShape, 0);
    gridsOut[index] = ix;
    // printf("%d,gridsOut[%d]:%d\n", ix, index, gridsOut[index]);
  }
}

__global__ void getSubMIndicePairsKernel3(int K0,
                                          int K1,
                                          int K2,
                                          int NDim,
                                          int numActIn,
                                          int* indicesIn,
                                          int* gridsOut,
                                          int* indicePairs,
                                          int* indiceNum,
                                          int* outSpatialShape) {
  int point[3];
  int index = 0;
  int offset;
  int kernelVolume = K0 * K1 * K2;
  unsigned int KV = K0 * K1 * K2;
  unsigned int center = KV / 2;
  int kvn = kernelVolume * numActIn;
  // *(indiceNum + center) = numActIn;
  int* temp_indiceNum = indiceNum + center;
  *temp_indiceNum = numActIn;
  for (int ix : tv::KernelLoopX<int>(numActIn)) {
    const int* indice_data = indicesIn + ix * (3 + 1);
#pragma unroll
    for (int i = 0; i < K0; ++i) {
#pragma unroll
      for (int j = 0; j < K1; ++j) {
#pragma unroll
        for (int k = 0; k < K2; ++k) {
          offset = i * K1 * K2 + j * K2 + k;
          if (offset > center) {
            continue;
          }
          if (center == offset) {
            indicePairs[offset * numActIn + ix] = ix;
            indicePairs[kvn + offset * numActIn + ix] = ix;
          } else {
            point[2] = indice_data[3] - k + K2 / 2;
            point[1] = indice_data[2] - j + K1 / 2;
            point[0] = indice_data[1] - i + K0 / 2;
            if (point[1] >= 0 && point[1] < outSpatialShape[1] && point[2] >= 0 &&
                point[2] < outSpatialShape[2] && point[0] >= 0 && point[0] < outSpatialShape[0]) {
              index = ArrayIndexRowMajor<3, 3>::runPtrs(point, outSpatialShape, 0);
              if (gridsOut[index] != -1) {
                int oldNum = atomicAdd(indiceNum + offset, 1);
                atomicAdd(indiceNum + KV - offset - 1, 1);
                indicePairs[kvn + offset * numActIn + oldNum] = gridsOut[index];
                indicePairs[offset * numActIn + oldNum] = ix;
                indicePairs[kvn + (KV - offset - 1) * numActIn + oldNum] = ix;
                indicePairs[(KV - offset - 1) * numActIn + oldNum] = gridsOut[index];
              }
            }
          }
        }
      }
    }
  }
}

__global__ void prepareIndicePairsKernel(const int* indicesIn,
                                         int* indicePairs,
                                         int* indiceNum,
                                         int* indicePairUnique,
                                         int* kernelSize,
                                         int* stride,
                                         int* padding,
                                         int* dilation,
                                         int* outSpatialShape,
                                         int numActIn,
                                         int NDim,
                                         int KernelMaxVolume) {
  int spatialVolume = 1;
#pragma unroll
  for (int i = 0; i < NDim; ++i) {
    spatialVolume *= outSpatialShape[i];
  }
  int kernelVolume_dev = 1;
#pragma unroll
  for (int i = 0; i < NDim; ++i) {
    kernelVolume_dev *= kernelSize[i];
  }
  int numValidPoints = 0;
  int validPoints[27 * (dims3_t::value + 1)];
  int* pointPtr = nullptr;
  auto indicePairsDim2 = numActIn;
  int index;
  int oldNum = 0;
  for (int ix : tv::KernelLoopX<int>(numActIn)) {
    numValidPoints = getValidOutPos(NDim,
                                    indicesIn + ix * (NDim + 1) + 1,
                                    kernelSize,
                                    stride,
                                    padding,
                                    dilation,
                                    outSpatialShape,
                                    validPoints);
    for (int i = 0; i < numValidPoints; ++i) {
      pointPtr = validPoints + i * (NDim + 1);
      auto offset = pointPtr[NDim];
      oldNum = atomicAdd(indiceNum + offset, int(1));
      indicePairs[offset * numActIn + oldNum] = ix;
      // indicePairs(0, offset, oldNum) = ix;
      index = ArrayIndexRowMajor<3, 3>::runPtrs(pointPtr, outSpatialShape, 0) +
              spatialVolume * indicesIn[(NDim + 1) * ix];
      // printf("index:%d\n", index);
      indicePairs[kernelVolume_dev * numActIn + offset * numActIn + oldNum] = index;
      indicePairUnique[offset * indicePairsDim2 + oldNum] = index;
    }
    // printf("valid pts:%d,oldNum:%d\n", numValidPoints, oldNum);
    // indicePairs(1, offset, oldNum) = index;
  }
}

int IndicePairsCuda::create_conv_indice_pair_p1_cuda(const int* indicesIn,
                                                     int* indicePairs,
                                                     int* indiceNum,
                                                     int* indicePairUnique,
                                                     cudaStream_t stream) {
  auto Ndim = host_kernelSize.size();
  auto numActIn = numAct;
  int KernelMaxVolume = 32;
  if (numActIn == 0) return 0;

  prepareIndicePairsKernel<<<getBlocks(numActIn), CUDA_NUM_THREADS, 0, stream>>>(indicesIn,
                                                                                 indicePairs,
                                                                                 indiceNum,
                                                                                 indicePairUnique,
                                                                                 kernelSize,
                                                                                 stride,
                                                                                 padding,
                                                                                 dilation,
                                                                                 outSpatialShape,
                                                                                 numActIn,
                                                                                 Ndim,
                                                                                 KernelMaxVolume);
  return 1;
}

int IndicePairsCuda::create_conv_indice_pair_p2_cuda(int numActOut,
                                                     int* indicesIn,
                                                     int* indicesOut,
                                                     int* indicePairs,
                                                     int* indiceNum,
                                                     int* indicePairUnique,
                                                     cudaStream_t stream) {
  auto ndim = coorDim;
  auto numActIn = numAct;
  int batchSize = 1;
  if (numActIn == 0) return 0;
  assignGridAndIndiceOutKernel<<<getBlocks(numActIn), CUDA_NUM_THREADS, 0, stream>>>(
      ndim,
      indicesOut,
      gridOut,
      numActOut,
      indicePairs,
      indicePairUnique,
      outSpatialShape,
      batchSize);
  assignIndicePairsKernel<<<getBlocks(numActIn), CUDA_NUM_THREADS, 0, stream>>>(indicesOut,
                                                                                gridOut,
                                                                                numActIn,
                                                                                kernelVolume,
                                                                                indicePairs,
                                                                                indicePairUnique,
                                                                                outSpatialShape);

  return numActOut;
}

__host__ int IndicePairsCuda::create_submconv_indice_pair_cuda(int* indicesIn,
                                                               int* gridsOut,
                                                               int* indicePairs,
                                                               int* indiceNum,
                                                               cudaStream_t stream) {
  auto numActIn = numAct;
  if (numActIn == 0) return 0;
  auto spatialVolume = outputVolume;
  prepareSubMGridKernel<<<getBlocks(numActIn), CUDA_NUM_THREADS, 0, stream>>>(coorDim,
                                                                              numActIn,
                                                                              indicesIn,
                                                                              gridsOut,
                                                                              outSpatialShape,
                                                                              spatialVolume);
  assert(coorDim == 3);
  int K0 = host_kernelSize[0];
  int K1 = host_kernelSize[1];
  int K2 = host_kernelSize[2];
  getSubMIndicePairsKernel3<<<getBlocks(numActIn), CUDA_NUM_THREADS, 0, stream>>>(K0,
                                                                                  K1,
                                                                                  K2,
                                                                                  coorDim,
                                                                                  numActIn,
                                                                                  indicesIn,
                                                                                  gridsOut,
                                                                                  indicePairs,
                                                                                  indiceNum,
                                                                                  outSpatialShape);

  return 1;
}

void IndicePairsCuda::getIndicePairs(const int in_numAct,
                                     int* indices,
                                     int* outInds,
                                     int* indicePairs,
                                     int* indiceNum,
                                     cudaStream_t stream) {
  numAct = in_numAct;

  BASE_CUDA_CHECK(
      cudaMemsetAsync(indicePairs, -1, 2 * kernelVolume * numAct * sizeof(int), stream));

  auto NDim = host_kernelSize.size();
  auto gridSize = outputVolume;
  // std::cout << "gridSize:" << gridSize << std::endl;
  BASE_CUDA_CHECK(cudaMemsetAsync(gridOut, -1, 2 * gridSize * sizeof(int), stream));
  BASE_CUDA_CHECK(cudaMemsetAsync(indiceNum, 0, kernelVolume * sizeof(int), stream));
  numActOut = -1;
  if (subM) {
    numActOut = in_numAct;
    BASE_CUDA_CHECK(cudaMemcpyAsync(outInds,
                                    indices,
                                    in_numAct * sizeof(int) * (NDim + 1),
                                    cudaMemcpyDeviceToDevice,
                                    stream));
    create_submconv_indice_pair_cuda(indices, gridOut, indicePairs, indiceNum, stream);
  } else {
    // if (indicePairUnique != nullptr) {
    //   BASE_CUDA_CHECK(cudaFree(indicePairUnique));
    // }
    // BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&indicePairUnique),
    //                            (kernelVolume * numAct + 1) * sizeof(int)));

    if (numAct > max_voxels) {
      BASE_CUDA_CHECK(
          cudaMemsetAsync(outInds, 0, (coorDim + 1) * max_voxels * sizeof(int), stream));
    } else {
      BASE_CUDA_CHECK(cudaMemsetAsync(outInds, 0, numAct * (coorDim + 1) * sizeof(int), stream));
    }
    BASE_CUDA_CHECK(
        cudaMemsetAsync(indicePairUnique, 127, (kernelVolume * numAct + 1) * sizeof(int), stream));
    numActOut =
        create_conv_indice_pair_p1_cuda(indices, indicePairs, indiceNum, indicePairUnique, stream);
    if (numActOut > 0) {
      int* indicePairUnique_end = indicePairUnique + (kernelVolume * numAct) + 1;
      thrust::sort(thrust::cuda::par.on(stream), indicePairUnique, indicePairUnique_end);
      // std::cout << "end sort" << std::endl;
      numActOut =
          thrust::unique(thrust::cuda::par.on(stream), indicePairUnique, indicePairUnique_end) -
          indicePairUnique - 1;
      // cudaStreamSynchronize(stream);
      create_conv_indice_pair_p2_cuda(numActOut,
                                      indices,
                                      outInds,
                                      indicePairs,
                                      indiceNum,
                                      indicePairUnique,
                                      stream);
    }
  }
  // BASE_CUDA_CHECK(cudaFree(gridOut));
  return;
}

void IndicePairsCuda::Reset(const int in_coorDim,
                            std::vector<int> in_outSpatialShape,
                            std::vector<int> in_kernelSize,
                            std::vector<int> in_stride,
                            std::vector<int> in_dilation,
                            std::vector<int> in_padding,
                            std::vector<int> in_outPadding,
                            bool in_subM,
                            int in_max_voxels) {
  initial = true;
  subM = in_subM;
  // numAct = in_numAct;

  max_voxels = in_max_voxels;
  coorDim = in_coorDim;
  host_outSpatialShape = in_outSpatialShape;
  // for(auto data:host_outSpatialShape) {
  //   std::cout << data << std::endl;
  // }
  host_kernelSize = in_kernelSize;
  host_stride = in_stride;
  host_padding = in_padding;
  host_dilation = in_dilation;
  host_outPadding = in_outPadding;

  kernelVolume = host_kernelSize[0];
  for (int i = 1; i < host_kernelSize.size(); ++i) {
    kernelVolume *= host_kernelSize[i];
  }
  outputVolume = host_outSpatialShape[0];
  for (int i = 1; i < host_outSpatialShape.size(); ++i) {
    outputVolume *= host_outSpatialShape[i];
  }
  IndicePairsMemSet();
  // std::cout << "init success!" << std::endl;
}

IndicePairsCuda::IndicePairsCuda(
    // const int in_numAct,
    const int in_coorDim,
    std::vector<int> in_outSpatialShape,
    std::vector<int> in_kernelSize,
    std::vector<int> in_stride,
    std::vector<int> in_dilation,
    std::vector<int> in_padding,
    std::vector<int> in_outPadding,
    bool in_subM,
    int in_max_voxels) {
  initial = true;
  max_voxels = in_max_voxels;
  subM = in_subM;
  // numAct = in_numAct;
  coorDim = in_coorDim;
  host_outSpatialShape = in_outSpatialShape;
  // for(auto data:host_outSpatialShape) {
  //   std::cout << data << std::endl;
  // }
  host_kernelSize = in_kernelSize;
  host_stride = in_stride;
  host_padding = in_padding;
  host_dilation = in_dilation;
  host_outPadding = in_outPadding;

  kernelVolume = host_kernelSize[0];
  for (int i = 1; i < host_kernelSize.size(); ++i) {
    kernelVolume *= host_kernelSize[i];
  }
  outputVolume = host_outSpatialShape[0];
  for (int i = 1; i < host_outSpatialShape.size(); ++i) {
    outputVolume *= host_outSpatialShape[i];
  }
  // std::cout << "init success!" << std::endl;
}

void IndicePairsCuda::IndicePairsMemSet() {
  auto NDim = coorDim;
  if (subM) {
    for (int i = 0; i < NDim; ++i) {
      host_padding[i] = host_kernelSize[i] / 2;
      host_stride[i] = 1;
    }
  }
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&outSpatialShape), sizeof(int) * coorDim));
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&kernelSize), sizeof(int) * coorDim));
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&stride), sizeof(int) * coorDim));
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dilation), sizeof(int) * coorDim));
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&padding), sizeof(int) * coorDim));

  BASE_CUDA_CHECK(cudaMemcpy(outSpatialShape,
                             &host_outSpatialShape[0],
                             sizeof(int) * coorDim,
                             cudaMemcpyHostToDevice));
  BASE_CUDA_CHECK(
      cudaMemcpy(kernelSize, &host_kernelSize[0], sizeof(int) * coorDim, cudaMemcpyHostToDevice));
  BASE_CUDA_CHECK(
      cudaMemcpy(stride, &host_stride[0], sizeof(int) * coorDim, cudaMemcpyHostToDevice));
  BASE_CUDA_CHECK(
      cudaMemcpy(padding, &host_padding[0], sizeof(int) * coorDim, cudaMemcpyHostToDevice));
  BASE_CUDA_CHECK(
      cudaMemcpy(dilation, &host_dilation[0], sizeof(int) * coorDim, cudaMemcpyHostToDevice));
  // BASE_CUDA_CHECK(cudaMemset(gridOut, -1, sizeof(int) * 2 * outputVolume));
  // std::cout << "memset success!" << std::endl;
}
void IndicePairsCuda::MemFree() {
  if (initial) {
    if (outSpatialShape != nullptr) (cudaFree(outSpatialShape));
    if (kernelSize != nullptr) (cudaFree(kernelSize));
    if (stride != nullptr) (cudaFree(stride));
    if (padding != nullptr) (cudaFree(padding));
    if (dilation != nullptr) (cudaFree(dilation));
    if (gridOut != nullptr) (cudaFree(gridOut));
    initial = false;
  }
}

IndicePairsCuda::~IndicePairsCuda() {
  // std::cout << "~IndicePairsCuda!" << std::endl;
}