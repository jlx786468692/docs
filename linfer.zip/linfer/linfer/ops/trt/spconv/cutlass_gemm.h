#include <cutlass/cutlass.h>
#include <cutlass/epilogue/thread/linear_combination.h>
#include <cutlass/gemm/device/gemm_universal.h>
#include <cutlass/gemm/gemm.h>
#include <cutlass/util/device_memory.h>
#include <cutlass/util/reference/device/gemm.h>

#include <cuda_fp16.hpp>
#pragma once
// #if __CUDA_ARCH__ >= 800
using ElementAccumulator = cutlass::half_t;         // <- data type of accumulator
using ElementComputeEpilogue = ElementAccumulator;  // <- data type of epilogue operations
using ElementInputA = cutlass::half_t;              // <- data type of elements in input matrix A
using ElementInputB = cutlass::half_t;              // <- data type of elements in input matrix B
using ElementOutput = cutlass::half_t;              // <- data type of elements in output matrix D

// The code section below describes matrix layout of input and output matrices.
// Column Major for Matrix A, B and C.
//
using LayoutInputA = cutlass::layout::RowMajor;
using LayoutInputB = cutlass::layout::RowMajor;
using LayoutOutput = cutlass::layout::RowMajor;
// using RowMajor = cutlass::layout::RowMajor;
// This code section describes whether you want to use tensor cores or regular SIMT cores on GPU SM
using MMAOp = cutlass::arch::OpClassTensorOp;

// This code section describes CUDA SM architecture number
using SmArch = cutlass::arch::Sm80;

// This code section describes the tile size a thread block will compute
using ShapeMMAThreadBlock =
    cutlass::gemm::GemmShape<128, 128, 32>;  // <- threadblock tile M = 128, N = 128, K = 32
// This code section describes tile size a warp will compute
using ShapeMMAWarp = cutlass::gemm::GemmShape<64, 64, 32>;  // <- warp tile M = 64, N = 64, K = 32
// This code section describes the size of MMA op
using ShapeMMAOp = cutlass::gemm::GemmShape<16, 8, 16>;  // <- MMA Op tile M = 8, N = 8, K = 4

using ShapeMMAThreadBlockFloat =
    cutlass::gemm::GemmShape<128, 64, 16>;  // <- threadblock tile M = 128, N = 128, K = 32
// This code section describes tile size a warp will compute
using ShapeMMAWarpFloat =
    cutlass::gemm::GemmShape<64, 32, 16>;  // <- warp tile M = 64, N = 64, K = 32
// This code section describes the size of MMA op
using ShapeMMAOpFloat = cutlass::gemm::GemmShape<16, 8, 8>;  // <- MMA Op tile M = 8, N = 8, K = 4

// This code section describes how threadblocks are scheduled on GPU
using SwizzleThreadBlock = cutlass::gemm::threadblock::GemmIdentityThreadblockSwizzle<>;  // <- ??

// Define the epilogue operation as LinearCombination. This is approximately equal to
//
//    d_ij = alpha * sum_k(a_ik * b_kj) + c_ij
//
using EpilogueOpHalf = cutlass::epilogue::thread::LinearCombination<
    ElementOutput,                                     // <- data type of output matrix
    128 / cutlass::sizeof_bits<ElementOutput>::value,  // <- this is the number of elements per
                                                       // vectorized memory access. For half
                                                       // precision, it's 8 elements. This becomes
                                                       // the vector width of math instructions in
                                                       // epilogue too
    ElementAccumulator,                                // <- data type of accumulator
    ElementComputeEpilogue,  // <- data type for alpha in linear combination function
    cutlass::epilogue::thread::ScaleType::NoBetaScaling>;

using EpilogueOpFloat = cutlass::epilogue::thread::LinearCombination<
    float,                                     // <- data type of output matrix
    128 / cutlass::sizeof_bits<float>::value,  // <- this is the number of elements per
                                               // vectorized memory access. For half
                                               // precision, it's 8 elements. This becomes
                                               // the vector width of math instructions in
                                               // epilogue too
    float,                                     // <- data type of accumulator
    float>;  // <- data type for alpha in linear combination function

// Number of pipelines you want to use
constexpr int NumStages = 5;
// Ampere -> 4/5
// Turing -> 2

using GemmFloat = cutlass::gemm::device::GemmUniversal<float,
                                                       LayoutInputA,
                                                       float,
                                                       LayoutInputB,
                                                       float,
                                                       LayoutOutput,
                                                       float,
                                                       MMAOp,
                                                       SmArch,
                                                       ShapeMMAThreadBlockFloat,
                                                       ShapeMMAWarpFloat,
                                                       ShapeMMAOpFloat,
                                                       EpilogueOpFloat,
                                                       SwizzleThreadBlock,
                                                       NumStages,
                                                       4, /*alignmentA*/
                                                       4, /*alignmentB*/
                                                       cutlass::arch::OpMultiplyAdd,
                                                       cutlass::ComplexTransform::kNone,
                                                       cutlass::ComplexTransform::kNone,
                                                       true,  /*GatherA*/
                                                       false, /*GatherB*/
                                                       true   /*ScatterD*/
                                                       >;

// test
using GemmHalf = cutlass::gemm::device::GemmUniversal<ElementInputA,
                                                      LayoutInputA,
                                                      ElementInputB,
                                                      LayoutInputB,
                                                      ElementOutput,
                                                      LayoutOutput,
                                                      ElementAccumulator,
                                                      MMAOp,
                                                      SmArch,
                                                      ShapeMMAThreadBlock,
                                                      ShapeMMAWarp,
                                                      ShapeMMAOp,
                                                      EpilogueOpHalf,
                                                      SwizzleThreadBlock,
                                                      NumStages,
                                                      8, /*alignmentA*/
                                                      8, /*alignmentB*/
                                                      cutlass::arch::OpMultiplyAdd,
                                                      cutlass::ComplexTransform::kNone,
                                                      cutlass::ComplexTransform::kNone,
                                                      true,  /*GatherA*/
                                                      false, /*GatherB*/
                                                      true   /*ScatterD*/
                                                      >;
ElementComputeEpilogue alpha = ElementComputeEpilogue(1);
constexpr int split_k_slices = 1;
// #endif
