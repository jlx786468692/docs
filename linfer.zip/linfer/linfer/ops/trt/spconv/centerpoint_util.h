#pragma once
#include <cuda.h>
#include <cuda_runtime.h>

#include <iostream>

#define CUTLASS_CHECK(status)                                                                    \
  {                                                                                              \
    cutlass::Status error = status;                                                              \
    if (error != cutlass::Status::kSuccess) {                                                    \
      std::cerr << "Got cutlass error: " << cutlassGetStatusString(error) << " at: " << __LINE__ \
                << std::endl;                                                                    \
      exit(EXIT_FAILURE);                                                                        \
    }                                                                                            \
  }

#include <iostream>
#define BASE_CUDA_CHECK(condition)                          \
  /* Code block avoids redefinition of cudaError_t error */ \
  do {                                                      \
    cudaError_t error = condition;                          \
    if (error != cudaSuccess) {                             \
      std::cout << cudaGetErrorString(error) << std::endl;  \
    }                                                       \
  } while (0)

#define BASE_CUDA_CHECK(condition)                          \
  /* Code block avoids redefinition of cudaError_t error */ \
  do {                                                      \
    cudaError_t error = condition;                          \
    if (error != cudaSuccess) {                             \
      std::cout << cudaGetErrorString(error) << std::endl;  \
    }                                                       \
  } while (0)

template <typename T1, typename T2>
inline int DivUp(const T1 a, const T2 b) {
  return (a + b - 1) / b;
}

// Use 1024 threads per block, which requires cuda sm_2x or above
constexpr int CUDA_NUM_THREADS = 512;
// CUDA: number of blocks for threads.

inline int getNumThreads(const int N) {
  if (N > CUDA_NUM_THREADS) {
    return CUDA_NUM_THREADS;
  }
  return DivUp(N, 32) * 32;
}

inline int getBlocks(const int N) { return DivUp(N, getNumThreads(N)); }

template <int N, int Ndim>
struct ArrayIndexRowMajor {
  // this array index provide almost same compiled code. compile it in
  // https://godbolt.org/ for more details.
  template <typename TShape, typename Tinit, typename T, class... Ts>
  inline __device__ static unsigned run(const TShape* shape, Tinit start, T index, Ts... inds) {
    return ArrayIndexRowMajor<N - 1, Ndim>::run(shape,
                                                (index + start) * shape[Ndim - N + 1],
                                                inds...);
  }

  template <typename TShape, typename Tinit>
  inline __device__ static unsigned runPtrs(const TShape* indexes,
                                            const TShape* shape,
                                            Tinit start) {
    return ArrayIndexRowMajor<N - 1, Ndim>::runPtrs(
        indexes,
        shape,
        (indexes[Ndim - N] + start) * shape[Ndim - N + 1]);
  }
};

template <int Ndim>
struct ArrayIndexRowMajor<1, Ndim> {
  template <typename TShape, typename Tinit, typename T>
  inline __device__ static unsigned run(const TShape* shape, Tinit start, T idx) {
    return start + idx;
  }
  template <typename TShape, typename Tinit>
  inline __device__ static unsigned runPtrs(const TShape* indexes,
                                            const TShape* shape,
                                            Tinit start) {
    return start + indexes[Ndim - 1];
  }
};

template <typename Index, unsigned NDim>
inline __device__ Index rowArrayIdxInv(Index index, Index* output, const Index* shape) {
#pragma unroll
  for (int i = NDim - 1; i >= 0; --i) {
    output[i] = index % shape[i];
    index -= output[i];
    index /= shape[i];
  }
  return index;
}

// template <class... T> struct mp_list {};

// template <class T, T... I>
// using mp_list_c = mp_list<std::integral_constant<T, I>...>;

// namespace detail {

// template <class... Ts, class F>
// constexpr F mp_for_each_impl(mp_list<Ts...>, F &&f) {
//   return (void)(std::initializer_list<int>{(f(Ts()), 0)...}),
//          std::forward<F>(f);
// }

// template <class F> constexpr F mp_for_each_impl(mp_list<>, F &&f) {
//   return std::forward<F>(f);
// }

// } // namespace detail

// template <class A, template <class...> class B>
// using mp_rename = typename detail::mp_rename_impl<A, B>::type;

// template <class L> using mp_size = mp_rename<L, mp_length>;

// template <class L, class F> constexpr F mp_for_each(F &&f) {
//   return detail::mp_for_each_impl(mp_rename<L, mp_list>(), std::forward<F>(f));
// }

// template <int... Is, typename F> bool dispatch_int_noexcept(int idx, F &&f) {
//   static_assert(sizeof...(Is) > 0,
//                 "you need to provide at least one candidate");
//   bool notFound = true;
//   mp_for_each<mp_list_c<int, Is...>>([=, &notFound, &f](auto I) {
//     if (decltype(I)::value == idx && notFound) {
//       std::forward<F>(f)(I);
//       notFound = false;
//     }
//   });
//   return !notFound;
// }

// template <int... Is, typename F, class BinaryPredicate>
// bool dispatch_int_noexcept(int idx, BinaryPredicate p, F &&f) {
//   static_assert(sizeof...(Is) > 0,
//                 "you need to provide at least one candidate");
//   bool notFound = true;
//   mp_for_each<mp_list_c<int, Is...>>([=, &notFound, &f](auto I) {
//     if (p(idx, decltype(I)::value) && notFound) {
//       std::forward<F>(f)(I);
//       notFound = false;
//     }
//   });
//   return !notFound;
// }
