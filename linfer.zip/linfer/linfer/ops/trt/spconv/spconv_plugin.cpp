#include "spconv_plugin.h"

#include <iostream>

#include "linfer/ops/trt/common/common_cuda_helper.hpp"

using namespace nvinfer1;

using nvinfer1::plugin::SpconvPlugin;
using nvinfer1::plugin::SpconvPluginCreator;

static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"Spconv"};

nvinfer1::PluginFieldCollection SpconvPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> SpconvPluginCreator::mPluginAttributes;

SpconvPlugin::SpconvPlugin(int coorDim,
                           int subM,
                           int numInPlanes,
                           int numOutPlanes,
                           int maxVoxels,
                           std::vector<int> outSpatialShape,
                           std::vector<int> kernelSize,
                           std::vector<int> stride,
                           std::vector<int> dilation,
                           std::vector<int> padding,
                           std::vector<int> outPadding,
                           const std::vector<float>& filters,
                           const std::vector<float>& bias)
    : _in_coorDim(coorDim),
      _in_subM(subM),
      _in_numInPlanes(numInPlanes),
      _in_numOutPlanes(numOutPlanes),
      _in_maxVoxels(maxVoxels) {
  _in_outSpatialShape = outSpatialShape;
  _in_kernelSize = kernelSize;
  _in_stride = stride;
  _in_dilation = dilation;
  _in_padding = padding;
  _in_outPadding = outPadding;
  _in_filters = filters;
  _in_bias = bias;

  assert(_in_coorDim == _in_outSpatialShape.size());
  assert(_in_coorDim == _in_kernelSize.size());
  assert(_in_coorDim == _in_stride.size());
  assert(_in_coorDim == _in_dilation.size());
  assert(_in_coorDim == _in_padding.size());
  assert(_in_coorDim == _in_outPadding.size());

  int kernelVolumes = _in_kernelSize[0];

  for (size_t i = 1; i < _in_kernelSize.size(); i++) {
    kernelVolumes *= _in_kernelSize[i];
  }
  // cublasHandle_t in_handle;
  // indice_pairs_cuda = new IndicePairsCuda(
  //     _in_coorDim, _in_outSpatialShape, _in_kernelSize, _in_stride,
  //     _in_dilation, _in_padding, _in_outPadding,
  //     static_cast<bool>(_in_subM));
  indice_pairs_cuda.Reset(_in_coorDim,
                          _in_outSpatialShape,
                          _in_kernelSize,
                          _in_stride,
                          _in_dilation,
                          _in_padding,
                          _in_outPadding,
                          static_cast<bool>(_in_subM),
                          _in_maxVoxels);
  indice_conv.Reset(static_cast<bool>(_in_subM),
                    _in_coorDim,
                    _in_numInPlanes,
                    _in_numOutPlanes,
                    kernelVolumes,
                    _in_maxVoxels,
                    &_in_filters[0],
                    &_in_bias[0]);
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dev_indiceNum),
                             indice_pairs_cuda.kernelVolume * sizeof(int32_t)));
  in_numAct = new int[1];
}
SpconvPlugin::SpconvPlugin(nvinfer1::DataType dataType,
                           int coorDim,
                           int subM,
                           int numInPlanes,
                           int numOutPlanes,
                           int maxVoxels,
                           std::vector<int> outSpatialShape,
                           std::vector<int> kernelSize,
                           std::vector<int> stride,
                           std::vector<int> dilation,
                           std::vector<int> padding,
                           std::vector<int> outPadding,
                           const std::vector<float>& filters,
                           const std::vector<float>& bias)
    : _in_dataType(dataType),
      _in_coorDim(coorDim),
      _in_subM(subM),
      _in_numInPlanes(numInPlanes),
      _in_numOutPlanes(numOutPlanes),
      _in_maxVoxels(maxVoxels) {
  _in_outSpatialShape = outSpatialShape;
  _in_kernelSize = kernelSize;
  _in_stride = stride;
  _in_dilation = dilation;
  _in_padding = padding;
  _in_outPadding = outPadding;
  _in_filters = filters;
  _in_bias = bias;

  assert(_in_coorDim == _in_outSpatialShape.size());
  assert(_in_coorDim == _in_kernelSize.size());
  assert(_in_coorDim == _in_stride.size());
  assert(_in_coorDim == _in_dilation.size());
  assert(_in_coorDim == _in_padding.size());
  assert(_in_coorDim == _in_outPadding.size());

  int kernelVolumes = _in_kernelSize[0];

  for (size_t i = 1; i < _in_kernelSize.size(); i++) {
    kernelVolumes *= _in_kernelSize[i];
  }

  // indice_pairs_cuda = new IndicePairsCuda(
  //     _in_coorDim, _in_outSpatialShape, _in_kernelSize, _in_stride,
  //     _in_dilation, _in_padding, _in_outPadding,
  //     static_cast<bool>(_in_subM));
  indice_pairs_cuda.Reset(_in_coorDim,
                          _in_outSpatialShape,
                          _in_kernelSize,
                          _in_stride,
                          _in_dilation,
                          _in_padding,
                          _in_outPadding,
                          static_cast<bool>(_in_subM),
                          _in_maxVoxels);
  indice_conv.Reset(static_cast<bool>(_in_subM),
                    _in_coorDim,
                    _in_numInPlanes,
                    _in_numOutPlanes,
                    kernelVolumes,
                    _in_maxVoxels,
                    &_in_filters[0],
                    &_in_bias[0]);
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dev_indiceNum),
                             indice_pairs_cuda.kernelVolume * sizeof(int32_t)));
  in_numAct = new int[1];
}

int SpconvPlugin::initialize() TRT_NOEXCEPT {
  // indice_conv = new IndiceConvCuda(static_cast<bool>(_in_subM), _in_coorDim,
  //                                  _in_numInPlanes, _in_numOutPlanes,
  //                                  kernelVolumes, &_in_filters[0]);
  // assert(indice_pairs_cuda);
  // assert(indice_conv);
  // std::cout << "Initialize success" << std::endl;
  return 0;
}

void SpconvPlugin::terminate() TRT_NOEXCEPT {
  indice_pairs_cuda.MemFree();
  indice_conv.MemFree();
  BASE_CUDA_CHECK(cudaFree(dev_indiceNum));
  // delete in_numAct;
  // if (indice_pairs_cuda != nullptr) {
  //   delete indice_pairs_cuda;
  // }
  // if (indice_conv != nullptr) {
  //   delete indice_conv;
  // }
}

SpconvPlugin::~SpconvPlugin() { terminate(); }

Dims SpconvPlugin::getOutputDimensions(int index,
                                       const Dims* inputs,
                                       int nbInputDims) TRT_NOEXCEPT {
  if (index == 0) {
    return inputs[0];
  } else if (index == 2) {
    return Dims3{inputs[2].d[0], inputs[2].d[1], _in_numOutPlanes};
  } else if (index == 1) {
    return inputs[1];
  }
  return Dims3(0, 0, 0);
}
const char* SpconvPlugin::getPluginType() const TRT_NOEXCEPT { return PLUGIN_NAME; }
const char* SpconvPlugin::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

void SpconvPlugin::destroy() TRT_NOEXCEPT { delete this; }

void SpconvPlugin::setPluginNamespace(const char* pluginNamespace) TRT_NOEXCEPT {
  mPluginNamespace = pluginNamespace;
}
const char* SpconvPlugin::getPluginNamespace() const TRT_NOEXCEPT { return mPluginNamespace; }

// Attach the plugin object to an execution context and grant the plugin the
// access to some context resource.
void SpconvPlugin::attachToContext(cudnnContext* cudnnContext,
                                   cublasContext* cublasContext,
                                   IGpuAllocator* gpuAllocator) TRT_NOEXCEPT {}

// Detach the plugin object from its execution context.
void SpconvPlugin::detachFromContext() TRT_NOEXCEPT {}

IPluginV2IOExt* SpconvPlugin::clone() const TRT_NOEXCEPT {
  SpconvPlugin* p = new SpconvPlugin(_in_dataType,
                                     _in_coorDim,
                                     _in_subM,
                                     _in_numInPlanes,
                                     _in_numOutPlanes,
                                     _in_maxVoxels,
                                     _in_outSpatialShape,
                                     _in_kernelSize,
                                     _in_stride,
                                     _in_dilation,
                                     _in_padding,
                                     _in_outPadding,
                                     _in_filters,
                                     _in_bias);
  p->setPluginNamespace(mPluginNamespace);
  assert(p);
  return p;
}

int SpconvPlugin::enqueue(int batchSize,
                          const void* const* inputs,
                          void* TRT_CONST_ENQUEUE* outputs,
                          void* workspace,
                          cudaStream_t stream) TRT_NOEXCEPT {
  // input: in_numAct, features, indices
  const int* dev_numAct = static_cast<const int*>(inputs[0]);
  const int* indices = static_cast<const int*>(inputs[1]);
  // temp data: indiceParis, indiceNum
  int* indiceParis = static_cast<int*>(workspace);
  indice_pairs_cuda.gridOut =
      (int*)(workspace) + indice_pairs_cuda.kernelVolume * 2 * _in_maxVoxels;
  size_t grid_size = 2;
  for (size_t i = 0; i < _in_outSpatialShape.size(); i++) grid_size *= _in_outSpatialShape[i];

  indice_pairs_cuda.indicePairUnique = indice_pairs_cuda.gridOut + grid_size;

  // int* in_numAct = new int[1];
  // #ifdef LIDS_PLATFORM_ORIN
  //     in_numAct[0] = dev_numAct[0];
  //     std::cout << "in numAct:" << dev_numAct[0] << std::endl;
  // #else
  BASE_CUDA_CHECK(
      cudaMemcpyAsync(in_numAct, dev_numAct, sizeof(int), cudaMemcpyDeviceToHost, stream));
  // #endif
  // output: numActout, output_features, outinds
  int* dev_numActout = static_cast<int*>(outputs[0]);
  int* dev_outinds = static_cast<int*>(outputs[1]);

  indice_pairs_cuda.getIndicePairs(in_numAct[0],
                                   const_cast<int*>(indices),
                                   dev_outinds,
                                   indiceParis,
                                   dev_indiceNum,
                                   stream);
  // #if __CUDA_ARCH__ >= 800
  indice_conv.workspace = (char*)indice_pairs_cuda.indicePairUnique;
  // #endif
  if (_in_dataType == DataType::kFLOAT) {
    std::cout << "DataType::kFLOAT" << std::endl;
    indice_conv.dev_inputBuffer = (float*)indice_pairs_cuda.gridOut + grid_size;
    indice_conv.dev_outputBuffer = indice_conv.dev_inputBuffer + _in_maxVoxels * _in_numInPlanes;
    BASE_CUDA_CHECK(cudaMemsetAsync(static_cast<float*>(outputs[2]),
                                    0,
                                    sizeof(float) * _in_numOutPlanes * indice_pairs_cuda.numActOut,
                                    stream));
    // std::cout << "enqueue: use float" << std::endl;
    indice_conv.indiceConv_process((float*)(inputs[2]),
                                   indiceParis,
                                   dev_indiceNum,
                                   static_cast<float*>(outputs[2]),
                                   in_numAct[0],
                                   indice_pairs_cuda.numActOut,
                                   stream);

  } else if (_in_dataType == DataType::kHALF) {
    indice_conv.dev_half_inputBuffer = (__half*)indice_pairs_cuda.gridOut + grid_size;
    indice_conv.dev_half_outputBuffer =
        indice_conv.dev_half_inputBuffer + _in_maxVoxels * _in_numInPlanes;
    BASE_CUDA_CHECK(cudaMemsetAsync((__half*)(outputs[2]),
                                    0,
                                    sizeof(__half) * _in_numOutPlanes * indice_pairs_cuda.numActOut,
                                    stream));
    indice_conv.indiceConv_process((__half*)(inputs[2]),
                                   indiceParis,
                                   dev_indiceNum,
                                   (__half*)(outputs[2]),
                                   in_numAct[0],
                                   indice_pairs_cuda.numActOut,
                                   stream);

  } else {
    assert(0);
  }
  // #ifdef LIDS_PLATFORM_ORIN
  //     *dev_numActout = indice_pairs_cuda.numActOut;
  // #else
  BASE_CUDA_CHECK(cudaMemcpyAsync(dev_numActout,
                                  &indice_pairs_cuda.numActOut,
                                  sizeof(int32_t),
                                  cudaMemcpyHostToDevice,
                                  stream));
  // #endif

  // if (_in_numInPlanes == 16 && _in_numOutPlanes == 32) {
  //     __half* vfe_feats = new __half[indice_pairs_cuda.numActOut * _in_numOutPlanes];
  //     int* coors_dev = new int[indice_pairs_cuda.numActOut * 4];
  //     cudaMemcpyAsync(vfe_feats, outputs[2], sizeof(__half) * indice_pairs_cuda.numActOut *
  //     _in_numOutPlanes,
  //                     cudaMemcpyDeviceToHost, stream);
  //     cudaMemcpyAsync(coors_dev, outputs[1], sizeof(int) * 4 * indice_pairs_cuda.numActOut,
  //     cudaMemcpyDeviceToHost,
  //                     stream);
  //     BASE_CUDA_CHECK(cudaStreamSynchronize(stream));
  //     for (size_t i = 0; i < 10; i++) {
  //         std::cout << "index " << i << ": " << coors_dev[4 * i + 0] << " " << coors_dev[4 * i
  //         + 1] << " "
  //                   << coors_dev[4 * i + 2] << " " << coors_dev[4 * i + 3] << std::endl;
  //         for (size_t j = 0; j < _in_numOutPlanes; j++) {
  //             std::cout << __half2float(vfe_feats[j + i * _in_numOutPlanes]) << " ";
  //         }
  //         std::cout << std::endl;
  //     }
  // }
  return 0;
}

SpconvPluginCreator::SpconvPluginCreator() {
  mPluginAttributes.emplace_back("coorDim", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("subM", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("numInPlanes", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("numOutPlanes", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("maxVoxels", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("outSpatialShape", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("kernelSize", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("stride", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("dilation", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("padding", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("outPadding", nullptr, PluginFieldType::kINT32, 1);
  mPluginAttributes.emplace_back("filters", nullptr, PluginFieldType::kFLOAT32, 1);
  mPluginAttributes.emplace_back("bias", nullptr, PluginFieldType::kFLOAT32, 1);
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* SpconvPluginCreator::getPluginName() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* SpconvPluginCreator::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

const PluginFieldCollection* SpconvPluginCreator::getFieldNames() TRT_NOEXCEPT { return &mFC; }

IPluginV2IOExt* SpconvPluginCreator::createPlugin(const char* name,
                                                  const PluginFieldCollection* fc) TRT_NOEXCEPT {
  std::vector<float> filters;
  std::vector<float> bias;
  int coorDim, subM, numInPlanes, numOutPlanes, maxVoxels, dataType;
  std::vector<int> outSpatialShape, kernelSize, stride, dilation, padding, outPadding;
  const PluginField* fields = fc->fields;
  for (size_t i = 0; i < 13; i++) {
    const char* attrName = fields[i].name;
    if (!strcmp(attrName, "coorDim")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      coorDim = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "subM")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      subM = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "numInPlanes")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      numInPlanes = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "numOutPlanes")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      numOutPlanes = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "maxVoxels")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      maxVoxels = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "outSpatialShape")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      int size = fields[i].length;
      outSpatialShape.reserve(size);
      const auto* w = static_cast<const int*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        outSpatialShape.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "kernelSize")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      int size = fields[i].length;
      kernelSize.reserve(size);
      const auto* w = static_cast<const int*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        kernelSize.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "stride")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      int size = fields[i].length;
      stride.reserve(size);
      const auto* w = static_cast<const int*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        stride.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "dilation")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      int size = fields[i].length;
      dilation.reserve(size);
      const auto* w = static_cast<const int*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        dilation.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "padding")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      int size = fields[i].length;
      padding.reserve(size);
      const auto* w = static_cast<const int*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        padding.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "outPadding")) {
      assert(fields[i].type == PluginFieldType::kINT32);
      int size = fields[i].length;
      outPadding.reserve(size);
      const auto* w = static_cast<const int*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        outPadding.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "filters")) {
      assert(fields[i].type == PluginFieldType::kFLOAT32);
      // int size = fields[i].length;
      int size = fields[i].length;
      filters.reserve(size);
      const auto* w = static_cast<const float*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        filters.push_back(*w);
        w++;
      }
    } else if (!strcmp(attrName, "bias")) {
      assert(fields[i].type == PluginFieldType::kFLOAT32);
      int size = fields[i].length;
      bias.reserve(size);
      const auto* w = static_cast<const float*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        bias.push_back(*w);
        w++;
      }
    }
  }
  SpconvPlugin* obj = new SpconvPlugin(coorDim,
                                       subM,
                                       numInPlanes,
                                       numOutPlanes,
                                       maxVoxels,
                                       outSpatialShape,
                                       kernelSize,
                                       stride,
                                       dilation,
                                       padding,
                                       outPadding,
                                       filters,
                                       bias);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

IPluginV2IOExt* SpconvPluginCreator::deserializePlugin(const char* name,
                                                       const void* serialData,
                                                       size_t serialLength) TRT_NOEXCEPT {
  SpconvPlugin* obj = new SpconvPlugin{serialData, serialLength};
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

REGISTER_TENSORRT_PLUGIN(SpconvPluginCreator);