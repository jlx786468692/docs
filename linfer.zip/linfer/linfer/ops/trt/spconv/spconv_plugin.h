#pragma once
#include <NvInfer.h>
#include <NvInferPlugin.h>
#include <cuda_runtime_api.h>

#include <string>
#include <vector>

#include "indice.h"
#include "indice_conv.h"
#include "serialize.h"

#if NV_TENSORRT_MAJOR >= 8
#define TRT_NOEXCEPT noexcept
#define TRT_CONST_ENQUEUE const
#else
#define TRT_NOEXCEPT
#define TRT_CONST_ENQUEUE
#endif

namespace nvinfer1 {
namespace plugin {

class SpconvPlugin : public nvinfer1::IPluginV2IOExt {
 private:
  int _in_coorDim;
  int _in_subM;
  int _in_numInPlanes;
  int _in_numOutPlanes;
  int _in_maxVoxels;
  nvinfer1::DataType _in_dataType;
  std::vector<int> _in_outSpatialShape;
  std::vector<int> _in_kernelSize;
  std::vector<int> _in_stride;
  std::vector<int> _in_dilation;
  std::vector<int> _in_padding;
  std::vector<int> _in_outPadding;

  std::vector<float> _in_filters;
  std::vector<float> _in_bias;
  const char* mPluginNamespace;
  // cublasHandle_t _cublas_handle;
  IndiceConvCuda indice_conv;
  IndicePairsCuda indice_pairs_cuda;
  int* dev_indiceNum = nullptr;
  int* in_numAct = nullptr;

 public:
  void deserialize(void const* serialData, size_t serialLength) {
    deserialize_value(&serialData, &serialLength, &_in_coorDim);
    deserialize_value(&serialData, &serialLength, &_in_subM);
    deserialize_value(&serialData, &serialLength, &_in_numInPlanes);
    deserialize_value(&serialData, &serialLength, &_in_numOutPlanes);
    deserialize_value(&serialData, &serialLength, &_in_maxVoxels);
    deserialize_value(&serialData, &serialLength, &_in_outSpatialShape);
    deserialize_value(&serialData, &serialLength, &_in_kernelSize);
    deserialize_value(&serialData, &serialLength, &_in_stride);
    deserialize_value(&serialData, &serialLength, &_in_dilation);
    deserialize_value(&serialData, &serialLength, &_in_padding);
    deserialize_value(&serialData, &serialLength, &_in_outPadding);
    deserialize_value(&serialData, &serialLength, &_in_filters);
    deserialize_value(&serialData, &serialLength, &_in_bias);
    deserialize_value(&serialData, &serialLength, &_in_dataType);
  }
  size_t getSerializationSize() const TRT_NOEXCEPT override {
    return (serialized_size(_in_coorDim) + serialized_size(_in_subM) +
            serialized_size(_in_numInPlanes) + serialized_size(_in_numOutPlanes) +
            serialized_size(_in_maxVoxels) + serialized_size(_in_outSpatialShape) +
            serialized_size(_in_kernelSize) + serialized_size(_in_stride) +
            serialized_size(_in_dilation) + serialized_size(_in_padding) +
            serialized_size(_in_outPadding) + serialized_size(_in_filters) +
            serialized_size(_in_bias) + serialized_size(_in_dataType));
  }
  void serialize(void* buffer) const TRT_NOEXCEPT override {
    serialize_value(&buffer, _in_coorDim);
    serialize_value(&buffer, _in_subM);
    serialize_value(&buffer, _in_numInPlanes);
    serialize_value(&buffer, _in_numOutPlanes);
    serialize_value(&buffer, _in_maxVoxels);
    serialize_value(&buffer, _in_outSpatialShape);
    serialize_value(&buffer, _in_kernelSize);
    serialize_value(&buffer, _in_stride);
    serialize_value(&buffer, _in_dilation);
    serialize_value(&buffer, _in_padding);
    serialize_value(&buffer, _in_outPadding);
    serialize_value(&buffer, _in_filters);
    serialize_value(&buffer, _in_bias);
    serialize_value(&buffer, _in_dataType);
  }
  SpconvPlugin(int coorDim,
               int subM,
               int numInPlanes,
               int numOutPlanes,
               int maxVoxels,
               std::vector<int> outSpatialShape,
               std::vector<int> kernelSize,
               std::vector<int> stride,
               std::vector<int> dilation,
               std::vector<int> padding,
               std::vector<int> outPadding,
               const std::vector<float>& filters,
               const std::vector<float>& bias);
  SpconvPlugin(nvinfer1::DataType dataType,
               int coorDim,
               int subM,
               int numInPlanes,
               int numOutPlanes,
               int maxVoxels,
               std::vector<int> outSpatialShape,
               std::vector<int> kernelSize,
               std::vector<int> stride,
               std::vector<int> dilation,
               std::vector<int> padding,
               std::vector<int> outPadding,
               const std::vector<float>& filters,
               const std::vector<float>& bias);
  SpconvPlugin(void const* serialData, size_t serialLength) {
    this->deserialize(serialData, serialLength);
  }
  SpconvPlugin() = delete;

  int getNbOutputs() const TRT_NOEXCEPT override { return 3; }

  Dims getOutputDimensions(int index, const Dims* inputs, int nbInputDims) TRT_NOEXCEPT override;

  int initialize() TRT_NOEXCEPT override;

  virtual void terminate() TRT_NOEXCEPT override;

  virtual size_t getWorkspaceSize(int maxBatchSize) const TRT_NOEXCEPT override {
    size_t output_ws = 2 * _in_maxVoxels * sizeof(int);
    for (size_t i = 0; i < _in_kernelSize.size(); i++) output_ws *= _in_kernelSize[i];
    // output_ws += (sizeof(float) * _in_numOutPlanes * _in_maxVoxels);
    size_t grid_size = sizeof(int) * 2;
    for (size_t i = 0; i < _in_outSpatialShape.size(); i++) grid_size *= _in_outSpatialShape[i];
    output_ws += grid_size;
    // indicePairUnique workspace
    size_t indice_pair_ws = sizeof(int) * _in_maxVoxels;
    for (size_t i = 0; i < _in_kernelSize.size(); i++) indice_pair_ws *= _in_kernelSize[i];
    output_ws += (indice_pair_ws + sizeof(int));

    // size_t in_out_buffer = sizeof(float) * _in_maxVoxels * _in_numInPlanes;
    // in_out_buffer += sizeof(float) * _in_maxVoxels * _in_numOutPlanes;
    // output_ws += in_out_buffer;
    return output_ws;
  }
  bool supportsFormatCombination(int pos,
                                 const PluginTensorDesc* inOut,
                                 int nbInputs,
                                 int nbOutputs) const TRT_NOEXCEPT override {
    // assert(nbInputs == 3);
    // assert(nbOutputs == 3);
    assert(pos < (nbInputs + nbOutputs));
    assert(nbInputs <= 3 && nbInputs >= 0);
    assert(nbOutputs <= 3 && nbOutputs >= 0);

    if (pos == 2 || pos == 5) {
      if (pos == 2) {
        return ((inOut[pos].type == DataType::kFLOAT || inOut[pos].type == DataType::kHALF) &&
                inOut[pos].format == PluginFormat::kLINEAR);
      } else {
        const PluginTensorDesc& prev = inOut[2];
        return ((
                    //  inOut[pos].type == DataType::kFLOAT ||
                    inOut[pos].type == DataType::kHALF) &&
                inOut[pos].type == prev.type && inOut[pos].format == PluginFormat::kLINEAR);
        // const PluginTensorDesc& in = inOut[pos];
        // return (inOut[2].type == nvinfer1::DataType::kFLOAT
        //         && in.type == nvinfer1::DataType::kFLOAT
        //         && in.format == TensorFormat::kLINEAR)
        //     || (inOut[2].type == nvinfer1::DataType::kHALF
        //     && in.type == nvinfer1::DataType::kHALF
        //     && in.format == TensorFormat::kLINEAR);
      }

      // return ((inOut[pos].type == DataType::kFLOAT) && inOut[pos].format ==
      // PluginFormat::kLINEAR);
    } else {
      return inOut[pos].type == DataType::kINT32 && inOut[pos].format == PluginFormat::kLINEAR;
    }
  }

  const char* getPluginType() const TRT_NOEXCEPT override;

  const char* getPluginVersion() const TRT_NOEXCEPT override;

  void destroy() TRT_NOEXCEPT override;

  IPluginV2IOExt* clone() const TRT_NOEXCEPT override;

  void setPluginNamespace(const char* pluginNamespace) TRT_NOEXCEPT override;

  const char* getPluginNamespace() const TRT_NOEXCEPT override;
  // Return the DataType of the plugin output at the requested index
  DataType getOutputDataType(int index,
                             const nvinfer1::DataType* inputTypes,
                             int nbInputs) const TRT_NOEXCEPT override {
    return inputTypes[index];
  }

  bool isOutputBroadcastAcrossBatch(int outputIndex,
                                    const bool* inputIsBroadcasted,
                                    int nbInputs) const TRT_NOEXCEPT override {
    return false;
  }

  bool canBroadcastInputAcrossBatch(int inputIndex) const TRT_NOEXCEPT override { return false; }

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       IGpuAllocator* gpuAllocator) TRT_NOEXCEPT override;

  void configurePlugin(const PluginTensorDesc* in,
                       int nbInput,
                       const PluginTensorDesc* out,
                       int nbOutput) TRT_NOEXCEPT override {
    assert(nbOutput == 3);
    assert(nbInput == 3);
    _in_dataType = in[2].type;
    assert(_in_dataType == DataType::kFLOAT || _in_dataType == DataType::kHALF);
  }

  void detachFromContext() TRT_NOEXCEPT override;

  virtual int enqueue(int batchSize,
                      const void* const* inputs,
                      void* TRT_CONST_ENQUEUE* outputs,
                      void* workspace,
                      cudaStream_t stream) TRT_NOEXCEPT override;

  ~SpconvPlugin();
};

class SpconvPluginCreator : public nvinfer1::IPluginCreator {
 public:
  SpconvPluginCreator();

  ~SpconvPluginCreator() override = default;

  const char* getPluginName() const TRT_NOEXCEPT override;

  const char* getPluginVersion() const TRT_NOEXCEPT override;

  const PluginFieldCollection* getFieldNames() TRT_NOEXCEPT override;

  IPluginV2IOExt* createPlugin(const char* name,
                               const PluginFieldCollection* fc) TRT_NOEXCEPT override;

  IPluginV2IOExt* deserializePlugin(const char* name,
                                    const void* serialData,
                                    size_t serialLength) TRT_NOEXCEPT override;

  void setPluginNamespace(const char* libNamespace) TRT_NOEXCEPT override {
    mNamespace = libNamespace;
  }

  const char* getPluginNamespace() const TRT_NOEXCEPT override { return mNamespace.c_str(); }

 private:
  std::string mNamespace;
  static PluginFieldCollection mFC;
  static std::vector<PluginField> mPluginAttributes;
};
}  // namespace plugin
}  // namespace nvinfer1