#include <fstream>
#include <iostream>

#include "cutlass_gemm.h"
#include "indice_conv.h"
#include "kernel_utils.h"
#include "linfer/ops/trt/common/nms/kernel.h"
#include "mp_helper.h"
#include "sparseGemm.cu"
using kernel_block_t = tv::mp_list_c<int, 64, 32, 16>;

// TODO when on conditon: gtest + App.so + linfer.so, will occure cuda failed.
// so move to local temporally.
// static const size_t __cuda_arch__ = get_cuda_arch(0);
__global__ void add_bias_relu_half(__half* buffer, float* bias, int size, int numOutPlanes) {
  extern __shared__ float cache_bias_h[];
  cache_bias_h[threadIdx.x] = bias[threadIdx.x];
  __syncthreads();
  int vox_id = blockIdx.x * blockDim.y + threadIdx.y;
  if (vox_id >= size) return;
  float tmp = __half2float(buffer[vox_id * numOutPlanes + threadIdx.x]) + cache_bias_h[threadIdx.x];
  buffer[vox_id * numOutPlanes + threadIdx.x] = __float2half(fmaxf(0, tmp));
  return;
}

__global__ void add_bias_relu_float(float* buffer, float* bias, int size, int numOutPlanes) {
  extern __shared__ float cache_bias_f[];
  cache_bias_f[threadIdx.x] = bias[threadIdx.x];
  __syncthreads();
  int vox_id = blockIdx.x * blockDim.y + threadIdx.y;
  if (vox_id >= size) return;
  float tmp = buffer[vox_id * numOutPlanes + threadIdx.x] + cache_bias_f[threadIdx.x];
  if (tmp > 0) {
    buffer[vox_id * numOutPlanes + threadIdx.x] = tmp;
  } else {
    buffer[vox_id * numOutPlanes + threadIdx.x] = 0;
  }
  return;
}

void add_bias_relu_cuda_half(__half* buffer,
                             float* bias,
                             int size,
                             int numOutPlanes,
                             cudaStream_t& stream) {
  if (size <= 0) return;
  constexpr int NumWrap = 512;
  add_bias_relu_half<<<dim3(DivUp(size, NumWrap / numOutPlanes)),
                       dim3(numOutPlanes, NumWrap / numOutPlanes),
                       numOutPlanes * sizeof(float),
                       stream>>>(buffer, bias, size, numOutPlanes);
}

void add_bias_relu_cuda_float(float* buffer,
                              float* bias,
                              int size,
                              int numOutPlanes,
                              cudaStream_t stream) {
  if (size <= 0) return;
  constexpr int NumWrap = 512;
  int vox_per_block = NumWrap / numOutPlanes;

  add_bias_relu_float<<<dim3(DivUp(size, vox_per_block)),
                        dim3(numOutPlanes, vox_per_block),
                        numOutPlanes * sizeof(float),
                        stream>>>(buffer, bias, size, numOutPlanes);
}

void IndiceConvCuda::indiceConv_process(float* features,
                                        int* indicesPairs,
                                        int* indiceNum,
                                        float* output,
                                        int in_numActIn,
                                        int in_numActOut,
                                        cudaStream_t stream) {
  numActIn = in_numActIn;
  numActOut = in_numActOut;
  BASE_CUDA_CHECK(cudaMemcpyAsync(host_indicePairNum,
                                  indiceNum,
                                  sizeof(int) * kernelVolumes,
                                  cudaMemcpyDeviceToHost,
                                  stream));
  for (int i = 0; i < kernelVolumes; ++i) {
    bool notFound = true;
    constexpr int BLOCK_SIZE_M = 96;
    constexpr int THREAD_SIZE_Y = 6;
    constexpr int THREAD_SIZE_X = 4;

    tv::mp_for_each<kernel_block_t>([=, &notFound](auto BLOCK_SIZE_K) {
      if (notFound) {
        if (numInPlanes % BLOCK_SIZE_K == 0) {
          const int BLOCK_SIZE_N = BLOCK_SIZE_K;
          dim3 dimBlock(BLOCK_SIZE_N / THREAD_SIZE_X, BLOCK_SIZE_M / THREAD_SIZE_Y);
          dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, host_indicePairNum[i] / BLOCK_SIZE_M);
          // dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, numActIn / BLOCK_SIZE_M);
          if (numOutPlanes % BLOCK_SIZE_N != 0) dimGrid.x++;
          if (host_indicePairNum[i] % BLOCK_SIZE_M != 0) dimGrid.y++;
          MatrixMulCUDA6<BLOCK_SIZE_M,
                         BLOCK_SIZE_K,
                         BLOCK_SIZE_N,
                         THREAD_SIZE_Y,
                         THREAD_SIZE_X,
                         float><<<dimGrid, dimBlock, 0, stream>>>(
              features,
              filters + i * numInPlanes * numOutPlanes,
              output,
              indicesPairs + numActIn * i,
              indicesPairs + numActIn * i + kernelVolumes * numActIn,
              indiceNum + i,
              numInPlanes,
              numOutPlanes,
              1.f,
              1.f);
          notFound = false;
        }
      }
      // }
    });
    if (notFound) {
      // std::cout << "not found" << std::endl;
      const int BLOCK_SIZE_K = 4;
      const int BLOCK_SIZE_N = 16;
      dim3 dimBlock(BLOCK_SIZE_N / THREAD_SIZE_X, BLOCK_SIZE_M / THREAD_SIZE_Y);
      dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, host_indicePairNum[i] / BLOCK_SIZE_M);
      // dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, numActIn / BLOCK_SIZE_M);
      if (numOutPlanes % BLOCK_SIZE_N != 0) dimGrid.x++;
      if (host_indicePairNum[i] % BLOCK_SIZE_M != 0) dimGrid.y++;
      MatrixMulCUDA6<BLOCK_SIZE_M, BLOCK_SIZE_K, BLOCK_SIZE_N, THREAD_SIZE_Y, THREAD_SIZE_X, float>
          <<<dimGrid, dimBlock, 0, stream>>>(features,
                                             filters + i * numInPlanes * numOutPlanes,
                                             output,
                                             indicesPairs + numActIn * i,
                                             indicesPairs + numActIn * i + kernelVolumes * numActIn,
                                             indiceNum + i,
                                             numInPlanes,
                                             numOutPlanes,
                                             1.f,
                                             1.f);
    }
  }
  add_bias_relu_cuda_float(output, bias, numActOut, numOutPlanes, stream);

  return;
}

void IndiceConvCuda::indiceConv_process(__half* features,
                                        int* indicesPairs,
                                        int* indiceNum,
                                        __half* output,
                                        int in_numActIn,
                                        int in_numActOut,
                                        cudaStream_t stream) {
  size_t __cuda_arch__ = get_cuda_arch(0);
  // std::cout << "use half indice conv" << std::endl;
  // cublasSetStream(handle, stream);
  numActIn = in_numActIn;
  numActOut = in_numActOut;
  BASE_CUDA_CHECK(cudaMemcpyAsync(host_indicePairNum,
                                  indiceNum,
                                  sizeof(int) * kernelVolumes,
                                  cudaMemcpyDeviceToHost,
                                  stream));
  cutlass::gemm::GemmCoord problem_size({maxVoxelSize, numOutPlanes, numInPlanes});
  LayoutInputA layout_a = LayoutInputA::packed(problem_size.mk());
  LayoutInputB layout_b = LayoutInputB::packed(problem_size.kn());
  LayoutOutput layout_d = LayoutOutput::packed(problem_size.mn());

  // #endif
  constexpr int BLOCK_SIZE_M = 96;
  constexpr int THREAD_SIZE_Y = 6;
  constexpr int THREAD_SIZE_X = 4;
  for (int i = 0; i < kernelVolumes; ++i) {
    bool notFound = true;
    tv::mp_for_each<kernel_block_t>([=, &notFound](auto BLOCK_SIZE_K) {
      if (notFound) {
        if (numInPlanes % BLOCK_SIZE_K == 0) {
          if (__cuda_arch__ >= 800) {
            cutlass::gemm::GemmCoord problem_size_real(
                {host_indicePairNum[i], numOutPlanes, numInPlanes});
            typename GemmHalf::Arguments arguments{
                cutlass::gemm::GemmUniversalMode::kGemm,
                problem_size_real,  // <- problem size of matrix multiplication
                split_k_slices,     // <- k-dimension split factor
                {alpha},            // <- alpha, beta
                features,           // <- reference to matrix A on device
                half_filters +
                    i * numInPlanes * numOutPlanes,  // <- reference to matrix B on device
                output,                              // <- reference to matrix C on device
                output,                              // <- reference to matrix D on device
                layout_a.capacity(cutlass::make_Coord(host_indicePairNum[i], problem_size.m())),
                layout_b.capacity(problem_size.kn()),
                layout_d.capacity(problem_size.mn()),
                layout_d.capacity(problem_size.mn()),
                layout_a.stride(),
                layout_b.stride(),
                layout_d.stride(),
                layout_d.stride(),
                indicesPairs + numActIn * i,  // <- pointer to index vector to gather A
                nullptr,                      // <- pointer to index vector to gather B
                indicesPairs + numActIn * i + kernelVolumes * numActIn};
            GemmHalf* gemm_op = (GemmHalf*)gemm_op_half;
            // Check the problem size is supported or not
            // cutlass::Status status = gemm_op->can_implement(arguments);
            cutlass::Status status = (*gemm_op)(arguments, workspace, stream);
            CUTLASS_CHECK(status);
          } else {
            const int BLOCK_SIZE_N = BLOCK_SIZE_K;
            dim3 dimBlock(BLOCK_SIZE_N / THREAD_SIZE_X, BLOCK_SIZE_M / THREAD_SIZE_Y);
            dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, host_indicePairNum[i] / BLOCK_SIZE_M);
            // dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, numActIn / BLOCK_SIZE_M);
            if (numOutPlanes % BLOCK_SIZE_N != 0) dimGrid.x++;
            if (host_indicePairNum[i] % BLOCK_SIZE_M != 0) dimGrid.y++;
            MatrixMulCUDA6<BLOCK_SIZE_M,
                           BLOCK_SIZE_K,
                           BLOCK_SIZE_N,
                           THREAD_SIZE_Y,
                           THREAD_SIZE_X,
                           half><<<dimGrid, dimBlock, 0, stream>>>(
                features,
                half_filters + i * numInPlanes * numOutPlanes,
                output,
                indicesPairs + numActIn * i,
                indicesPairs + numActIn * i + kernelVolumes * numActIn,
                indiceNum + i,
                numInPlanes,
                numOutPlanes,
                1,
                1);
          }
          notFound = false;
        }
      }
    });
    if (notFound) {
      const int BLOCK_SIZE_K = 4;
      const int BLOCK_SIZE_N = 16;
      dim3 dimBlock(BLOCK_SIZE_N / THREAD_SIZE_X, BLOCK_SIZE_M / THREAD_SIZE_Y);
      dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, host_indicePairNum[i] / BLOCK_SIZE_M);
      // dim3 dimGrid(numOutPlanes / BLOCK_SIZE_N, numActIn / BLOCK_SIZE_M);
      if (numOutPlanes % BLOCK_SIZE_N != 0) dimGrid.x++;
      if (host_indicePairNum[i] % BLOCK_SIZE_M != 0) dimGrid.y++;
      MatrixMulCUDA6<BLOCK_SIZE_M, BLOCK_SIZE_K, BLOCK_SIZE_N, THREAD_SIZE_Y, THREAD_SIZE_X, half>
          <<<dimGrid, dimBlock, 0, stream>>>(features,
                                             half_filters + i * numInPlanes * numOutPlanes,
                                             output,
                                             indicesPairs + numActIn * i,
                                             indicesPairs + numActIn * i + kernelVolumes * numActIn,
                                             indiceNum + i,
                                             numInPlanes,
                                             numOutPlanes,
                                             1,
                                             1);
    }
  }
  add_bias_relu_cuda_half(output, bias, numActOut, numOutPlanes, stream);
  // std::cout << "finish" << std::endl;
  return;
}

void IndiceConvCuda::MemSet(float* in_filters, float* in_bias) {
  host_indicePairNum = new int[kernelVolumes];
  GemmHalf* gemm_op_h_temp = new GemmHalf();
  gemm_op_half = (void*)gemm_op_h_temp;

  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&filters),
                             sizeof(float) * kernelVolumes * numInPlanes * numOutPlanes));
  BASE_CUDA_CHECK(cudaMemcpy(filters,
                             in_filters,
                             sizeof(float) * kernelVolumes * numInPlanes * numOutPlanes,
                             cudaMemcpyHostToDevice));
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&bias), sizeof(float) * numOutPlanes));
  BASE_CUDA_CHECK(cudaMemcpy(bias, in_bias, sizeof(float) * numOutPlanes, cudaMemcpyHostToDevice));

  __half* half_filter = new __half[kernelVolumes * numInPlanes * numOutPlanes];
  __half* half_bias_tmp = new __half[numOutPlanes];
  for (size_t i = 0; i < kernelVolumes * numInPlanes * numOutPlanes; i++) {
    half_filter[i] = __float2half(in_filters[i]);
  }
  for (size_t i = 0; i < numOutPlanes; i++) {
    half_bias_tmp[i] = __float2half(in_bias[i]);
  }
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&half_filters),
                             sizeof(__half) * kernelVolumes * numInPlanes * numOutPlanes));
  BASE_CUDA_CHECK(cudaMemcpy(half_filters,
                             half_filter,
                             sizeof(__half) * kernelVolumes * numInPlanes * numOutPlanes,
                             cudaMemcpyHostToDevice));
  BASE_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&half_bias), sizeof(__half) * numOutPlanes));
  BASE_CUDA_CHECK(
      cudaMemcpy(half_bias, half_bias_tmp, sizeof(__half) * numOutPlanes, cudaMemcpyHostToDevice));
  delete[] half_filter;
  delete[] half_bias_tmp;
}

void IndiceConvCuda::Reset(bool in_subM,
                           int in_nDim,
                           int in_numInPlanes,
                           int in_numOutPlanes,
                           int in_kernelVolumes,
                           int in_maxVoxels,
                           float* in_filters,
                           float* in_bias) {
  initial = true;
  subM = in_subM;
  nDim = in_nDim;
  numInPlanes = in_numInPlanes;
  numOutPlanes = in_numOutPlanes;
  kernelVolumes = in_kernelVolumes;
  maxVoxelSize = in_maxVoxels;
  // numActOut = in_numActOut;
  MemSet(in_filters, in_bias);
  // cublasCreate(&handle);
}

void IndiceConvCuda::Reset(bool in_subM,
                           int in_nDim,
                           int in_numInPlanes,
                           int in_numOutPlanes,
                           int in_kernelVolumes,
                           int in_maxVoxels,
                           float* in_filters,
                           float* in_bias,
                           cublasHandle_t& in_handle) {
  initial = true;
  subM = in_subM;
  nDim = in_nDim;
  numInPlanes = in_numInPlanes;
  numOutPlanes = in_numOutPlanes;
  kernelVolumes = in_kernelVolumes;

  // numActOut = in_numActOut;
  maxVoxelSize = in_maxVoxels;
  MemSet(in_filters, in_bias);
  // handle = in_handle;
}

IndiceConvCuda::IndiceConvCuda(bool in_subM,
                               int in_nDim,
                               int in_numInPlanes,
                               int in_numOutPlanes,
                               int in_kernelVolumes,
                               int in_maxVoxels,
                               float* in_filters,
                               float* in_bias) {
  initial = true;
  // cublasCreate(&handle);
  subM = in_subM;
  nDim = in_nDim;
  numInPlanes = in_numInPlanes;
  numOutPlanes = in_numOutPlanes;
  kernelVolumes = in_kernelVolumes;
  // numActOut = in_numActOut;
  maxVoxelSize = in_maxVoxels;
  MemSet(in_filters, in_bias);
}

IndiceConvCuda::IndiceConvCuda(bool in_subM,
                               int in_nDim,
                               int in_numInPlanes,
                               int in_numOutPlanes,
                               int in_kernelVolumes,
                               int in_maxVoxels,
                               float* in_filters,
                               float* in_bias,
                               cublasHandle_t& in_handle) {
  initial = true;
  // handle = in_handle;
  // cublasCreate(&handle);
  subM = in_subM;
  nDim = in_nDim;
  numInPlanes = in_numInPlanes;
  numOutPlanes = in_numOutPlanes;
  kernelVolumes = in_kernelVolumes;
  // numActOut = in_numActOut;
  maxVoxelSize = in_maxVoxels;
  MemSet(in_filters, in_bias);
}
void IndiceConvCuda::MemFree() {
  if (initial) {
// cublasDestroy(handle);
#ifndef LIDS_PLATFORM_ORIN
    if (host_indicePairNum != nullptr) delete[] host_indicePairNum;
#endif
    if (filters != nullptr) cudaFree(filters);
    if (bias != nullptr) cudaFree(bias);
    if (half_filters != nullptr) cudaFree(half_filters);
    if (half_bias != nullptr) cudaFree(half_bias);
    // if (dev_inputBuffer != nullptr) {
    //     cudaFree(dev_inputBuffer);
    // }
    // if (dev_outputBuffer != nullptr) {
    //     cudaFree(dev_outputBuffer);
    // }
    initial = false;
  }
}
IndiceConvCuda::~IndiceConvCuda() {}