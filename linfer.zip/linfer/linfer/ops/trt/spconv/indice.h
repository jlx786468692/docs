#pragma once

#include <cuda.h>
#include <cuda_runtime.h>

#include "centerpoint_util.h"
// #include <NvInfer.h>
// headers in STL
#include <thrust/execution_policy.h>
#include <thrust/sort.h>
#include <thrust/unique.h>

#include <iostream>
#include <memory>
#include <vector>

typedef std::integral_constant<int, 4> dims4_t;
typedef std::integral_constant<int, 3> dims3_t;
typedef std::integral_constant<int, 2> dims2_t;

__global__ void assignIndicePairsKernel(int* indicesOut,
                                        int* gridsOut,
                                        int numActIn,
                                        int kernelVolume,
                                        int* indicePairs,
                                        int* indicePairUnique,
                                        const int* outSpatialShape);

__global__ void assignGridAndIndiceOutKernel(int NDim,
                                             int* indicesOut,
                                             int* gridsOut,
                                             int numAct,
                                             int* indicePairs,
                                             int* indicePairUnique,
                                             int* outSpatialShape,
                                             int batchSize);

__global__ void prepareSubMGridKernel(int NDim,
                                      int numActIn,
                                      int* indicesIn,
                                      int* gridsOut,
                                      int* outSpatialShape,
                                      int spatialVolume);

__global__ void getSubMIndicePairsKernel3(int K0,
                                          int K1,
                                          int K2,
                                          int NDim,
                                          int numActIn,
                                          int* indicesIn,
                                          int* gridsOut,
                                          int* indicePairs,
                                          int* indiceNum,
                                          int* outSpatialShape);
__device__ __host__ int getValidOutPos(const int NDim,
                                       const int* input_pos,
                                       const int* kernelSize,
                                       const int* stride,
                                       const int* padding,
                                       const int* dilation,
                                       const int* outSpatialShape,
                                       int* out);

__global__ void prepareIndicePairsKernel(const int* indicesIn,
                                         int* indicePairs,
                                         int* indiceNum,
                                         int* indicePairUnique,
                                         int* kernelSize,
                                         int* stride,
                                         int* padding,
                                         int* dilation,
                                         int* outSpatialShape,
                                         int numActIn,
                                         int NDim,
                                         int KernelMaxVolume);

typedef struct IndicePairsCuda {
  int numAct;
  int coorDim;
  bool subM;
  int kernelVolume;
  int outputVolume;
  int numActOut = -1;
  int max_voxels;
  std::vector<int> host_outSpatialShape;
  std::vector<int> host_kernelSize;
  std::vector<int> host_stride;
  std::vector<int> host_padding;
  std::vector<int> host_dilation;
  std::vector<int> host_outPadding;
  int* outSpatialShape;
  int* kernelSize;
  int* stride;
  int* padding;
  int* dilation;
  int* outPadding;
  int* indicePairUnique = nullptr;
  int* gridOut;
  bool initial;
  IndicePairsCuda() { initial = false; }
  void Reset(const int in_coorDim,
             std::vector<int> in_outSpatialShape,
             std::vector<int> in_kernelSize,
             std::vector<int> in_stride,
             std::vector<int> in_dilation,
             std::vector<int> in_padding,
             std::vector<int> in_outPadding,
             bool in_subM,
             int in_max_voxels);
  IndicePairsCuda(const int in_coorDim,
                  std::vector<int> in_outSpatialShape,
                  std::vector<int> in_kernelSize,
                  std::vector<int> in_stride,
                  std::vector<int> in_dilation,
                  std::vector<int> in_padding,
                  std::vector<int> in_outPadding,
                  bool in_subM,
                  int in_max_voxels);
  ~IndicePairsCuda();
  void IndicePairsMemSet();
  void MemFree();
  __host__ void getIndicePairs(const int in_numAct,
                               int* indices,
                               int* outInds,
                               int* indiceParis,
                               int* indiceNum,
                               cudaStream_t stream);
  __host__ int create_conv_indice_pair_p1_cuda(const int* indicesIn,
                                               int* indicePairs,
                                               int* indiceNum,
                                               int* indicePairUnique,
                                               cudaStream_t stream);
  __host__ int create_conv_indice_pair_p2_cuda(int numActOut,
                                               int* indicesIn,
                                               int* indicesOut,
                                               int* indicePairs,
                                               int* indiceNum,
                                               int* indicePairUnique,
                                               cudaStream_t stream);
  __host__ int create_submconv_indice_pair_cuda(int* indicesIn,
                                                int* gridsOut,
                                                int* indicePairs,
                                                int* indiceNum,
                                                cudaStream_t stream);
} IndicePairsCuda_t;
