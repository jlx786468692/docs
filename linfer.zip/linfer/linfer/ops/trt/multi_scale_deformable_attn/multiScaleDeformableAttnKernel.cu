#include <cuda_fp16.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

// #include "cuda_helper.h"
// #include "helper.h"
#include <cstdio>

#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/common/common_types.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "multiScaleDeformableAttnKernel.h"

__global__ void ms_deformable_im2col_gpu_kernel(const float* data_value,
                                                const int32_t* data_spatial_shapes,
                                                const float* data_sampling_loc,
                                                const float* data_attn_weight,
                                                const int spatial_size,
                                                const int num_heads,
                                                const int channels,
                                                const int num_levels,
                                                const int num_query,
                                                const int num_point,
                                                float* data_col) {
  const int c_col = threadIdx.x;
  const int m_col = threadIdx.y;
  const int b_col = blockIdx.y;
  const int query_col = blockIdx.x;
  float* data_col_ptr =
      data_col + ((b_col * num_query + query_col) * num_heads + m_col) * channels + c_col;

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(float) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(float)
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int head_level_point = num_heads * num_levels * num_point;
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);
  float4* interpolate_weight = reinterpret_cast<float4*>(interpolate_pos + head_level_point);
  int32_t2* spatial_shapes_smem =
      reinterpret_cast<int32_t2*>(interpolate_weight + head_level_point);
  float* attn_weight_smem = reinterpret_cast<float*>(spatial_shapes_smem + num_levels);

  // 进行条件判断并读取data_attn_weight、data_sampling_loc放入共享内存
  if (threadIdx.y < min(DIVUP(head_level_point, blockDim.x), blockDim.y)) {
    for (int index = threadIdx.y * blockDim.x + threadIdx.x; index < head_level_point;
         index += blockDim.y * blockDim.x) {
      int head_index = index / num_point / num_levels;
      int level_index = (index / num_point) % num_levels;
      int point_index = index % num_point;

      int data_weight_ptr =
          (((b_col * num_query + query_col) * num_heads + head_index) * num_levels + level_index) *
              num_point +
          point_index;
      const int32_t2 spatial = reinterpret_cast<const int32_t2*>(data_spatial_shapes)[level_index];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;

      if (head_index == 0 && point_index == 0) {
        spatial_shapes_smem[level_index] = spatial;
      }

      const float2 loc = reinterpret_cast<const float2*>(data_sampling_loc)[data_weight_ptr];
      const float h_im = loc.y * spatial_h - 0.5f;
      const float w_im = loc.x * spatial_w - 0.5f;

      attn_weight_smem[index] = data_attn_weight[data_weight_ptr];

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - h_low;
      const float lw = w_im - w_low;
      const float hh = 1 - lh, hw = 1 - lw;

      const int w_stride = num_heads * channels;
      const int h_stride = spatial_w * w_stride;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * w_stride;
      const int w_high_ptr_offset = w_low_ptr_offset + w_stride;

      int4 pos = {h_low_ptr_offset + w_low_ptr_offset,
                  h_low_ptr_offset + w_high_ptr_offset,
                  h_high_ptr_offset + w_low_ptr_offset,
                  h_high_ptr_offset + w_high_ptr_offset};

      interpolate_pos[index] = pos;

      float4 weight4 = {0.0f, 0.0f, 0.0f, 0.0f};

      if (h_low >= 0.0f && h_low < spatial_h) {
        if (w_low >= 0.0f && w_low < spatial_w) {
          weight4.x = hh * hw;
        }

        if (w_high >= 0.0f && w_high < spatial_w) {
          weight4.y = hh * lw;
        }
      }

      if (h_high >= 0.0f && h_high < spatial_h) {
        if (w_low >= 0.0f && w_low < spatial_w) {
          weight4.z = lh * hw;
        }

        if (w_high >= 0.0f && w_high < spatial_w) {
          weight4.w = lh * lw;
        }
      }

      interpolate_weight[index] = weight4;
    }
  }
  __syncthreads();

  const int channel_stride = channels;
  const int qid_stride = num_heads * channel_stride;
  const int data_value_ptr_init_offset = b_col * spatial_size * qid_stride;
  float col = 0.0f;
  const float* data_value_ptr =
      data_value + data_value_ptr_init_offset + m_col * channel_stride + c_col;
  for (int l_col = 0; l_col < num_levels; ++l_col) {
    const int32_t2 spatial = spatial_shapes_smem[l_col];
    const int32_t spatial_h = spatial.x;
    const int32_t spatial_w = spatial.y;
    int index_base = m_col * num_levels * num_point + l_col * num_point;
    for (int p_col = 0; p_col < num_point; ++p_col) {
      int index = index_base + p_col;
      const float weight = attn_weight_smem[index];

      int4 pos = interpolate_pos[index];
      float4 interpolate_weights = interpolate_weight[index];

      // float val = 0.0f;
      // if(interpolate_weights.x > 0.0f)
      // {
      //     val = fma(interpolate_weights.x, data_value_ptr[pos.x], val);
      // }

      // if(interpolate_weights.y > 0.0f)
      // {
      //     val = fma(interpolate_weights.y, data_value_ptr[pos.y], val);
      // }

      // if(interpolate_weights.z > 0.0f)
      // {
      //     val = fma(interpolate_weights.z, data_value_ptr[pos.z], val);
      // }

      // if(interpolate_weights.w > 0.0f)
      // {
      //     val = fma(interpolate_weights.w, data_value_ptr[pos.w], val);
      // }

      // col = fma(weight, val, col);
      float v1 = 0.0f;
      if (interpolate_weights.x > 0.0f) {
        v1 = data_value_ptr[pos.x];
      }

      float v2 = 0.0f;
      if (interpolate_weights.y > 0.0f) {
        v2 = data_value_ptr[pos.y];
      }

      float v3 = 0.0f;
      if (interpolate_weights.z > 0.0f) {
        v3 = data_value_ptr[pos.z];
      }

      float v4 = 0.0f;
      if (interpolate_weights.w > 0.0f) {
        v4 = data_value_ptr[pos.w];
      }
      float val = (interpolate_weights.x * v1 + interpolate_weights.y * v2 +
                   interpolate_weights.z * v3 + interpolate_weights.w * v4);
      col += val * weight;
    }
    data_value_ptr += qid_stride * spatial_h * spatial_w;
  }
  *data_col_ptr = col;
}

// 每个thread处理1个channels
__global__ void ms_deformable_im2col_gpu_kernel(const __half* data_value,
                                                const int32_t* data_spatial_shapes,
                                                const __half* data_sampling_loc,
                                                const __half* data_attn_weight,
                                                const int spatial_size,
                                                const int num_heads,
                                                const int channels,
                                                const int num_levels,
                                                const int num_query,
                                                const int num_point,
                                                __half* data_col) {
  const int c_col = threadIdx.x;
  const int m_col = threadIdx.y;
  const int b_col = blockIdx.y;
  const int query_col = blockIdx.x;
  __half* data_col_ptr =
      data_col + ((b_col * num_query + query_col) * num_heads + m_col) * channels + c_col;

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(__half)
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int head_level_point = num_heads * num_levels * num_point;
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);
  half4* interpolate_weight = reinterpret_cast<half4*>(interpolate_pos + head_level_point);
  int32_t2* spatial_shapes_smem =
      reinterpret_cast<int32_t2*>(interpolate_weight + head_level_point);
  __half* attn_weight_smem = reinterpret_cast<__half*>(spatial_shapes_smem + num_levels);

  // 进行条件判断并读取data_attn_weight、data_sampling_loc放入共享内存
  if (threadIdx.y < min(DIVUP(head_level_point, blockDim.x), blockDim.y)) {
    for (int index = threadIdx.y * blockDim.x + threadIdx.x; index < head_level_point;
         index += blockDim.y * blockDim.x) {
      int head_index = index / num_point / num_levels;
      int level_index = (index / num_point) % num_levels;
      int point_index = index % num_point;

      int data_weight_ptr =
          (((b_col * num_query + query_col) * num_heads + head_index) * num_levels + level_index) *
              num_point +
          point_index;
      const int32_t2 spatial = reinterpret_cast<const int32_t2*>(data_spatial_shapes)[level_index];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;

      if (head_index == 0 && point_index == 0) {
        spatial_shapes_smem[level_index] = spatial;
      }

      const __half2 loc = reinterpret_cast<const __half2*>(data_sampling_loc)[data_weight_ptr];
      const __half h_im =
          __hsub(__hmul(loc.y, __float2half(static_cast<float>(spatial_h))), __float2half(0.5f));
      const __half w_im =
          __hsub(__hmul(loc.x, __float2half(static_cast<float>(spatial_w))), __float2half(0.5f));

      attn_weight_smem[index] = data_attn_weight[data_weight_ptr];

      const __half h_low = hfloor(h_im);
      const __half w_low = hfloor(w_im);
      const __half h_high = __hadd(h_low, __float2half(1.f));
      const __half w_high = __hadd(w_low, __float2half(1.f));

      const __half lh = __hsub(h_im, h_low);
      const __half lw = __hsub(w_im, w_low);
      const __half hh = __hsub(__float2half(1.f), lh);
      const __half hw = __hsub(__float2half(1.f), lw);

      int w_stride = num_heads * channels;
      int h_stride = spatial_w * w_stride;
      int h_low_ptr_offset = static_cast<int>(h_low) * h_stride;
      int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      int w_low_ptr_offset = static_cast<int>(w_low) * w_stride;
      int w_high_ptr_offset = w_low_ptr_offset + w_stride;

      int4 pos = {h_low_ptr_offset + w_low_ptr_offset,
                  h_low_ptr_offset + w_high_ptr_offset,
                  h_high_ptr_offset + w_low_ptr_offset,
                  h_high_ptr_offset + w_high_ptr_offset};

      interpolate_pos[index] = pos;

      half4 weight4;
      weight4.left = __float2half2_rn(0.0f);
      weight4.right = __float2half2_rn(0.0f);

      if (__hge(h_low, __float2half(0.f)) &&
          __hle(h_low, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.x = __hmul(hh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.y = __hmul(hh, lw);
        }
      }

      if (__hge(h_high, __float2half(0.f)) &&
          __hle(h_high, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.x = __hmul(lh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.y = __hmul(lh, lw);
        }
      }

      interpolate_weight[index] = weight4;
    }
  }
  __syncthreads();

  const int channel_stride = channels;
  const int qid_stride = num_heads * channel_stride;
  const int data_value_ptr_init_offset = b_col * spatial_size * qid_stride;
  __half col = __float2half(0.0f);
  const __half* data_value_ptr =
      data_value + data_value_ptr_init_offset + m_col * channel_stride + c_col;
  for (int l_col = 0; l_col < num_levels; ++l_col) {
    const int32_t2 spatial = spatial_shapes_smem[l_col];
    const int32_t spatial_h = spatial.x;
    const int32_t spatial_w = spatial.y;
    int index_base = m_col * num_levels * num_point + l_col * num_point;
    for (int p_col = 0; p_col < num_point; ++p_col) {
      int index = index_base + p_col;
      const __half weight = attn_weight_smem[index];

      int4 pos = interpolate_pos[index];
      half4 interpolate_weights = interpolate_weight[index];

      __half v1 = __float2half(0.0f);
      if (__hgt(interpolate_weights.left.x, __float2half(0.0f))) {
        v1 = data_value_ptr[pos.x];
      }

      __half v2 = __float2half(0.0f);
      if (__hgt(interpolate_weights.left.y, __float2half(0.0f))) {
        v2 = data_value_ptr[pos.y];
      }

      __half v3 = __float2half(0.0f);
      if (__hgt(interpolate_weights.right.x, __float2half(0.0f))) {
        v3 = data_value_ptr[pos.z];
      }

      __half v4 = __float2half(0.0f);
      if (__hgt(interpolate_weights.right.y, __float2half(0.0f))) {
        v4 = data_value_ptr[pos.w];
      }

      __half w1 = interpolate_weights.left.x, w2 = interpolate_weights.left.y,
             w3 = interpolate_weights.right.x, w4 = interpolate_weights.right.y;

      __half val =
          __hadd(__hadd(__hmul(w1, v1), __hmul(w2, v2)), __hadd(__hmul(w3, v3), __hmul(w4, v4)));

      col = __hfma(weight, val, col);
    }
    data_value_ptr += qid_stride * spatial_h * spatial_w;
  }
  *data_col_ptr = col;
}

// 每个thread处理2个channels
__global__ void ms_deformable_im2col_gpu_half2_kernel(const __half* data_value,
                                                      const int32_t* data_spatial_shapes,
                                                      const __half* data_sampling_loc,
                                                      const __half* data_attn_weight,
                                                      const int spatial_size,
                                                      const int num_heads,
                                                      const int channels,
                                                      const int num_levels,
                                                      const int num_query,
                                                      const int num_point,
                                                      __half* data_col) {
  const int c_col = threadIdx.x;
  const int m_col = threadIdx.y;
  const int b_col = blockIdx.y;
  const int query_col = blockIdx.x;
  __half2* data_col_ptr = reinterpret_cast<__half2*>(
      data_col + ((b_col * num_query + query_col) * num_heads + m_col) * channels + c_col * 2);

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(__half)
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int head_level_point = num_heads * num_levels * num_point;
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);
  half4* interpolate_weight = reinterpret_cast<half4*>(interpolate_pos + head_level_point);
  int32_t2* spatial_shapes_smem =
      reinterpret_cast<int32_t2*>(interpolate_weight + head_level_point);
  __half* attn_weight_smem = reinterpret_cast<__half*>(spatial_shapes_smem + num_levels);

  // 进行条件判断并读取data_attn_weight、data_sampling_loc放入共享内存
  if (threadIdx.y < min(DIVUP(head_level_point, blockDim.x), blockDim.y)) {
    for (int index = threadIdx.y * blockDim.x + threadIdx.x; index < head_level_point;
         index += blockDim.y * blockDim.x) {
      int head_index = index / num_point / num_levels;
      int level_index = (index / num_point) % num_levels;
      int point_index = index % num_point;

      int data_weight_ptr =
          (((b_col * num_query + query_col) * num_heads + head_index) * num_levels + level_index) *
              num_point +
          point_index;
      const int32_t2 spatial = reinterpret_cast<const int32_t2*>(data_spatial_shapes)[level_index];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;

      if (head_index == 0 && point_index == 0) {
        spatial_shapes_smem[level_index] = spatial;
      }

      const __half2 loc = reinterpret_cast<const __half2*>(data_sampling_loc)[data_weight_ptr];
      const __half h_im =
          __hsub(__hmul(loc.y, __float2half(static_cast<float>(spatial_h))), __float2half(0.5f));
      const __half w_im =
          __hsub(__hmul(loc.x, __float2half(static_cast<float>(spatial_w))), __float2half(0.5f));

      attn_weight_smem[index] = data_attn_weight[data_weight_ptr];

      const __half h_low = hfloor(h_im);
      const __half w_low = hfloor(w_im);
      const __half h_high = __hadd(h_low, __float2half(1.f));
      const __half w_high = __hadd(w_low, __float2half(1.f));

      const __half lh = __hsub(h_im, h_low);
      const __half lw = __hsub(w_im, w_low);
      const __half hh = __hsub(__float2half(1.f), lh);
      const __half hw = __hsub(__float2half(1.f), lw);

      int w_stride = num_heads * channels / 2;
      int h_stride = spatial_w * w_stride;
      int h_low_ptr_offset = static_cast<int>(h_low) * h_stride;
      int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      int w_low_ptr_offset = static_cast<int>(w_low) * w_stride;
      int w_high_ptr_offset = w_low_ptr_offset + w_stride;

      int4 pos = {h_low_ptr_offset + w_low_ptr_offset,
                  h_low_ptr_offset + w_high_ptr_offset,
                  h_high_ptr_offset + w_low_ptr_offset,
                  h_high_ptr_offset + w_high_ptr_offset};

      interpolate_pos[index] = pos;

      half4 weight4;
      weight4.left = __float2half2_rn(0.0f);
      weight4.right = __float2half2_rn(0.0f);

      if (__hge(h_low, __float2half(0.f)) &&
          __hle(h_low, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.x = __hmul(hh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.y = __hmul(hh, lw);
        }
      }

      if (__hge(h_high, __float2half(0.f)) &&
          __hle(h_high, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.x = __hmul(lh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.y = __hmul(lh, lw);
        }
      }

      interpolate_weight[index] = weight4;
    }
  }
  __syncthreads();

  const int channel_stride = channels / 2;
  const int qid_stride = num_heads * channel_stride;
  const int data_value_ptr_init_offset = b_col * spatial_size * qid_stride;
  __half2 col = __float2half2_rn(0.0f);
  const __half2* data_value_ptr = reinterpret_cast<const __half2*>(data_value) +
                                  data_value_ptr_init_offset + m_col * channel_stride + c_col;
  for (int l_col = 0; l_col < num_levels; ++l_col) {
    const int32_t2 spatial = spatial_shapes_smem[l_col];
    const int32_t spatial_h = spatial.x;
    const int32_t spatial_w = spatial.y;
    int index_base = m_col * num_levels * num_point + l_col * num_point;
    for (int p_col = 0; p_col < num_point; ++p_col) {
      int index = index_base + p_col;
      const __half weight = attn_weight_smem[index];

      int4 pos = interpolate_pos[index];
      half4 interpolate_weights = interpolate_weight[index];

      // __half2 val1 = __float2half2_rn(0.0f);
      // __half2 val2 = __float2half2_rn(0.0f);
      // if(__hgt(interpolate_weights.left.x, __float2half(0.0f)))
      // {
      //     __half2 interpolate_w = __half2half2(interpolate_weights.left.x);
      //     val1 = __hfma2(interpolate_w, data_value_ptr[pos.x], val1);
      // }

      // if(__hgt(interpolate_weights.left.y, __float2half(0.0f)))
      // {
      //     __half2 interpolate_w = __half2half2(interpolate_weights.left.y);
      //     val1 = __hfma2(interpolate_w, data_value_ptr[pos.y], val1);
      // }

      // if(__hgt(interpolate_weights.right.x, __float2half(0.0f)))
      // {
      //     __half2 interpolate_w = __half2half2(interpolate_weights.right.x);
      //     val2 = __hfma2(interpolate_w, data_value_ptr[pos.z], val2);
      // }

      // if(__hgt(interpolate_weights.right.y, __float2half(0.0f)))
      // {
      //     __half2 interpolate_w = __half2half2(interpolate_weights.right.y);
      //     val2 = __hfma2(interpolate_w, data_value_ptr[pos.w], val2);
      // }

      // col = __hfma2(__half2half2(weight), __hadd2(val1, val2), col);

      __half2 v1 = __float2half2_rn(0.0f);
      if (__hgt(interpolate_weights.left.x, __float2half(0.0f))) {
        v1 = data_value_ptr[pos.x];
      }

      __half2 v2 = __float2half2_rn(0.0f);
      if (__hgt(interpolate_weights.left.y, __float2half(0.0f))) {
        v2 = data_value_ptr[pos.y];
      }

      __half2 v3 = __float2half2_rn(0.0f);
      if (__hgt(interpolate_weights.right.x, __float2half(0.0f))) {
        v3 = data_value_ptr[pos.z];
      }

      __half2 v4 = __float2half2_rn(0.0f);
      if (__hgt(interpolate_weights.right.y, __float2half(0.0f))) {
        v4 = data_value_ptr[pos.w];
      }

      __half2 w1 = __half2half2(interpolate_weights.left.x),
              w2 = __half2half2(interpolate_weights.left.y),
              w3 = __half2half2(interpolate_weights.right.x),
              w4 = __half2half2(interpolate_weights.right.y);

      __half2 val = __hadd2(__hadd2(__hmul2(w1, v1), __hmul2(w2, v2)),
                            __hadd2(__hmul2(w3, v3), __hmul2(w4, v4)));

      col = __hfma2(__half2half2(weight), val, col);
    }
    data_value_ptr += qid_stride * spatial_h * spatial_w;
  }
  *data_col_ptr = col;
}

void ms_deformable_im2col_cuda(const float* data_value,
                               const int32_t* data_spatial_shapes,
                               const float* data_sampling_loc,
                               const float* data_attn_weight,
                               const int batch_size,
                               const int spatial_size,
                               const int num_heads,
                               const int channels,
                               const int num_levels,
                               const int num_query,
                               const int num_point,
                               float* data_col,
                               cudaStream_t stream) {
  dim3 block_size(channels, num_heads);
  dim3 grid_size(num_query, batch_size);

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(float) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(float)
  unsigned head_level_kernel = num_heads * num_levels * num_point;
  unsigned shared_mem_size = head_level_kernel * 4 * (sizeof(float) + sizeof(int)) +
                             num_levels * 2 * sizeof(int32_t) + head_level_kernel * sizeof(float);

  ms_deformable_im2col_gpu_kernel<<<grid_size, block_size, shared_mem_size, stream>>>(
      data_value,
      data_spatial_shapes,
      data_sampling_loc,
      data_attn_weight,
      spatial_size,
      num_heads,
      channels,
      num_levels,
      num_query,
      num_point,
      data_col);

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    printf("error in ms_deformable_im2col_cuda: %s\n", cudaGetErrorString(err));
  }
}

void ms_deformable_im2col_cuda(const __half* data_value,
                               const int32_t* data_spatial_shapes,
                               const __half* data_sampling_loc,
                               const __half* data_attn_weight,
                               const int batch_size,
                               const int spatial_size,
                               const int num_heads,
                               const int channels,
                               const int num_levels,
                               const int num_query,
                               const int num_point,
                               __half* data_col,
                               cudaStream_t stream) {
  // 若channel_num为奇数，为避免越界不使用half2
  if (channels % 2 == 0) {
    dim3 block_size(channels / 2, num_heads);
    dim3 grid_size(num_query, batch_size);

    // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
    // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
    // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads *
    // num_levels * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads *
    // num_levels * num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9
    // + num_levels * 2 - 1 存储data_attn_weight(__half)
    unsigned head_level_kernel = num_heads * num_levels * num_point;
    unsigned shared_mem_size = head_level_kernel * 4 * (sizeof(__half) + sizeof(int)) +
                               num_levels * 2 * sizeof(int32_t) +
                               head_level_kernel * sizeof(__half);

    ms_deformable_im2col_gpu_half2_kernel<<<grid_size, block_size, shared_mem_size, stream>>>(
        data_value,
        data_spatial_shapes,
        data_sampling_loc,
        data_attn_weight,
        spatial_size,
        num_heads,
        channels,
        num_levels,
        num_query,
        num_point,
        data_col);
  } else {
    dim3 block_size(channels, num_heads);
    dim3 grid_size(num_query, batch_size);

    // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
    // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
    // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads *
    // num_levels * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads *
    // num_levels * num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9
    // + num_levels * 2 - 1 存储data_attn_weight(__half)
    unsigned head_level_kernel = num_heads * num_levels * num_point;
    unsigned shared_mem_size = head_level_kernel * 4 * (sizeof(__half) + sizeof(int)) +
                               num_levels * 2 * sizeof(int32_t) +
                               head_level_kernel * sizeof(__half);

    ms_deformable_im2col_gpu_kernel<<<grid_size, block_size, shared_mem_size, stream>>>(
        data_value,
        data_spatial_shapes,
        data_sampling_loc,
        data_attn_weight,
        spatial_size,
        num_heads,
        channels,
        num_levels,
        num_query,
        num_point,
        data_col);
  }

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    printf("error in ms_deformable_im2col_cuda: %s\n", cudaGetErrorString(err));
  }
}