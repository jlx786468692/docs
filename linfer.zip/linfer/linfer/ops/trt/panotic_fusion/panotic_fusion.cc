#include "linfer/ops/trt/panotic_fusion/panotic_fusion.h"

#include <NvInfer.h>
#include <cublas_v2.h>

#include <cstring>
#include <iostream>
#include <sstream>

#include "linfer/util/internal/cuda/half.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

using namespace nvinfer1;

using linfer::ops::trt::panotic_fusion;
using linfer::ops::trt::panotic_fusionPluginCreator;

REGISTER_TENSORRT_PLUGIN(panotic_fusionPluginCreator);

namespace {

const char* panotic_fusion_PLUGIN_VERSION{"1"};
const char* panotic_fusion_PLUGIN_NAME{"panotic_fusion"};
// const char* panotic_fusion_PLUGIN_NAME{"panotic_fusion"};
}  // namespace

PluginFieldCollection panotic_fusionPluginCreator::mFC_{};

panotic_fusion::panotic_fusion() {}

int panotic_fusion::getNbOutputs() const noexcept {
  // Plugin layer has 1 output
  return 2;
}

nvinfer1::DimsExprs panotic_fusion::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  // output should have same dimensions as data tensor

  nvinfer1::DimsExprs ret;
  switch (outputIndex) {
    case 0:
      ret = inputs[0];
      break;
    case 1:
      ret.nbDims = 1;
      ret.d[0] = exprBuilder.constant(inputs[1].d[0]->getConstantValue() + 20);
      break;
    default:
      break;
  }
  return ret;
}

size_t panotic_fusion::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                        int32_t nbInputs,
                                        const nvinfer1::PluginTensorDesc* outputs,
                                        int32_t nbOutputs) const noexcept {
  return 0;
}

int panotic_fusion::initialize() noexcept { return 0; }

void panotic_fusion::terminate() noexcept {}

bool panotic_fusion::supportsFormatCombination(int32_t pos,
                                               const nvinfer1::PluginTensorDesc* inOut,
                                               int32_t nbInputs,
                                               int32_t nbOutputs) noexcept {
  ASSERT(pos < 8);
  ASSERT(nbInputs == 6);
  ASSERT(nbOutputs == 2);
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  bool ret = false;
  switch (pos) {
    case sem_pred_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case cat_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case panotic_mask_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case num_stuff_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case panotic_min_stuff_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case total_unique_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case output_0_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case output_1_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
  }
  return true;
}

void panotic_fusion::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                     int32_t nbInputs,
                                     const nvinfer1::DynamicPluginTensorDesc* out,
                                     int32_t nbOutputs) noexcept {}

// void print_desc(const nvinfer1::PluginTensorDesc& desc, const std::string& name) {
//     printf("%s:  ", name.c_str());
//     printf("nbDims: %u, type: %d, shape: ", desc.dims.nbDims, static_cast<int32_t>(desc.type));
//     for (auto d : desc.dims.d) {
//         printf("%ux", d);
//     }
//     printf("\n");
// }

int32_t panotic_fusion::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                const nvinfer1::PluginTensorDesc* outputDesc,
                                const void* const* inputs,
                                void* const* outputs,
                                void* workspace,
                                cudaStream_t stream) noexcept {
  // printf("------------------------------------------------------------------------\n");
  // return 0;
  // printf("panotic_fusion Plugin\n");
  int cat_size = inputDesc[1].dims.d[0];
  int h_size = inputDesc[0].dims.d[0];
  int w_size = inputDesc[0].dims.d[1];
  int total_unique_;
  int num_stuff_;
  int min_stuff_area;

  cudaMemcpyAsync(&total_unique_, inputs[5], sizeof(int), cudaMemcpyDeviceToHost, stream);
  cudaMemcpyAsync(&num_stuff_, inputs[3], sizeof(int), cudaMemcpyDeviceToHost, stream);
  cudaMemcpyAsync(&min_stuff_area, inputs[4], sizeof(int), cudaMemcpyDeviceToHost, stream);

  panotic_fusionInference(stream,
                          total_unique_,
                          cat_size,
                          h_size,
                          w_size,
                          num_stuff_,
                          num_stuff_,
                          min_stuff_area,
                          inputs[1],
                          inputs[2],
                          inputs[0],
                          outputs[0],
                          outputs[1],
                          workspace);

  // printf("------------------------------------------------------------------------\n");
  return 0;
}

size_t panotic_fusion::getSerializationSize() const noexcept { return 0; }

void panotic_fusion::serialize(void* buffer) const noexcept { return; }

// Set plugin namespace
void panotic_fusion::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace_ = pluginNamespace;
}

const char* panotic_fusion::getPluginNamespace() const noexcept {
  return mPluginNamespace_.c_str();
}

// Return the DataType of the plugin output at the requested index
nvinfer1::DataType panotic_fusion::getOutputDataType(int index,
                                                     const nvinfer1::DataType* inputTypes,
                                                     int nbInputs) const noexcept {
  return inputTypes[0];
}

// Attach the plugin object to an execution context and grant the plugin the access to some context
// resource.
void panotic_fusion::attachToContext(cudnnContext* cudnn,
                                     cublasContext* cublas,
                                     nvinfer1::IGpuAllocator* gpuAllocator) noexcept {
  return;
}

// Detach the plugin object from its execution context.
void panotic_fusion::detachFromContext() noexcept {}

const char* panotic_fusion::getPluginType() const noexcept { return panotic_fusion_PLUGIN_NAME; }

const char* panotic_fusion::getPluginVersion() const noexcept {
  return panotic_fusion_PLUGIN_VERSION;
}

void panotic_fusion::destroy() noexcept { delete this; }

// Clone the plugin
nvinfer1::IPluginV2DynamicExt* panotic_fusion::clone() const noexcept {
  // Create a new instance
  panotic_fusion* plugin = new panotic_fusion();
  plugin->setPluginNamespace(mPluginNamespace_.c_str());
  return plugin;
}

panotic_fusionPluginCreator::panotic_fusionPluginCreator() { mFC_.nbFields = 0; }

const char* panotic_fusionPluginCreator::getPluginName() const noexcept {
  return panotic_fusion_PLUGIN_NAME;
}

const char* panotic_fusionPluginCreator::getPluginVersion() const noexcept {
  return panotic_fusion_PLUGIN_VERSION;
}

const PluginFieldCollection* panotic_fusionPluginCreator::getFieldNames() noexcept { return &mFC_; }

nvinfer1::IPluginV2Ext* panotic_fusionPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  panotic_fusion* obj = new panotic_fusion();
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* panotic_fusionPluginCreator::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  // This object will be deleted when the network is destroyed, which will
  // call Normalize::destroy()
  panotic_fusion* obj = new panotic_fusion();
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}
