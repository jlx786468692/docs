#ifndef TRT_PANOTIC_FUSION_PLUGIN_H
#define TRT_PANOTIC_FUSION_PLUGIN_H

#include <NvInfer.h>
#include <cublas_v2.h>

#include <string>
#include <vector>

// #include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/trt/plugin.h"

namespace linfer {
namespace ops {
namespace trt {

class panotic_fusion : public nvinfer1::IPluginV2DynamicExt {
 public:
  panotic_fusion();

  ~panotic_fusion() override = default;

  int getNbOutputs() const noexcept override;

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  virtual size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                  int32_t nbInputs,
                                  const nvinfer1::PluginTensorDesc* outputs,
                                  int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

 private:
  static constexpr int sem_pred_ = 0;
  static constexpr int cat_ = 1;
  static constexpr int panotic_mask_ = 2;
  static constexpr int num_stuff_ = 3;
  static constexpr int panotic_min_stuff_ = 4;
  static constexpr int total_unique_ = 5;
  static constexpr int output_0_ = 6;
  static constexpr int output_1_ = 7;
  int32_t calculateNumSlices(nvinfer1::Dims indexTensorDims) const noexcept;
  int32_t calculateCopySize(const nvinfer1::Dims& dataDims) const noexcept;
  void calculateTransformCoeff(const nvinfer1::Dims& dataTensorDims,
                               int indexRank,
                               int32_t* transformCoeff) const noexcept;
  std::string mPluginNamespace_;
};

class panotic_fusionPluginCreator : public BaseCreator {
 public:
  panotic_fusionPluginCreator();

  ~panotic_fusionPluginCreator() override = default;

  const char* getPluginName() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;

  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept override;

  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept override;

 private:
  static nvinfer1::PluginFieldCollection mFC_;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer

pluginStatus_t panotic_fusionInference(cudaStream_t stream,
                                       int total_unique_,
                                       int cat_size,
                                       int h_size,
                                       int w_size,
                                       int num_stuff_,
                                       int max_cls_size,
                                       int min_stuff_area,
                                       const void* cat_,
                                       const void* panoptic_mask,
                                       const void* sem_pred_,
                                       void* output_0_,
                                       void* output_1_,
                                       void* workspace);

#endif  // TRT_panotic_fusion_PLUGIN_H
