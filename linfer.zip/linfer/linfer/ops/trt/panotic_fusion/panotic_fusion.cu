#include <algorithm>
#include <string>
#include <vector>

#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

#define CUBLAS_CHECK(condition)                                                           \
  do {                                                                                    \
    cublasStatus_t status = condition;                                                    \
    if (status != CUBLAS_STATUS_SUCCESS) {                                                \
      printf("%s %d CUBLAS FAIL %s\n", __FILE__, __LINE__, cublasGetErrorString(status)); \
    }                                                                                     \
  } while (0)

// this scatter kernel works on a 2d table writing rows
// index is 1-D array
// updates is 2-D array
// output is 2-D array
// output[index[i]] = updates[i]
__global__ void unique(int* area,
                       const int* sem_pred,
                       const int w_size,
                       const int area_per_thread) {
  for (int i = 0; i < area_per_thread; i++) {
    int idx = blockIdx.x * w_size + threadIdx.x * area_per_thread + i;
    if (threadIdx.x * area_per_thread + i < w_size) {
      atomicAdd(&(area[sem_pred[idx]]), 1);
    }
  }
}

__global__ void get_panoptic_mask(
    int* output,
    const int* panoptic_mask,
    const int* sem_pred,  // these are actually the output pitches of the respective dimensions
    const int* tmp,
    const int num_stuff,
    const int total_unique,
    const int w_size,
    const int area_per_thread) {
  for (int i = 0; i < area_per_thread; i++) {
    int idx = blockIdx.x * w_size + threadIdx.x * area_per_thread + i;
    if (threadIdx.x * area_per_thread + i < w_size) {
      int subsitude_val = tmp[sem_pred[idx]];
      if (subsitude_val != num_stuff) {
        output[idx] = subsitude_val + total_unique;
      } else {
        output[idx] = panoptic_mask[idx];
      }
    }
  }
}

pluginStatus_t panotic_fusionInference(cudaStream_t stream,
                                       int total_unique,
                                       int cat_size,
                                       int h_size,
                                       int w_size,
                                       int num_stuff,
                                       int max_cls_size,
                                       int min_stuff_area,
                                       const void* cat,
                                       const void* panoptic_mask,
                                       const void* sem_pred,
                                       void* output_0,
                                       void* output_1,
                                       void* workspace) {
  if (max_cls_size <= 0) {
    return STATUS_SUCCESS;
  }
  int *cuda_area, *cuda_tmp;
  cudaMalloc((void**)&cuda_area, sizeof(int) * max_cls_size);
  cudaMemset(cuda_area, 0, sizeof(int) * max_cls_size);
  cudaMalloc((void**)&cuda_tmp, sizeof(int) * num_stuff);
  int area_cpu[max_cls_size];
  // see_n<int>((const int*)sem_pred,  100, "sem_pred", stream);

  const size_t max_thread = 1024;
  const size_t area_per_thread = (w_size - 1) / max_thread + 1;
  const size_t thread_size = std::min(w_size, (int)max_thread);
  unique<<<h_size, thread_size, 0, stream>>>((int*)cuda_area,
                                             (const int*)sem_pred,
                                             w_size,
                                             area_per_thread);
  CHECK_CUDA_STATUS("unique");
  // printf("error is %s h_size is %d w_size is %d\n", cudaGetErrorString(cudaGetLastError()),
  // h_size, w_size);

  cudaMemcpyAsync(area_cpu, cuda_area, sizeof(int) * max_cls_size, cudaMemcpyDeviceToHost, stream);

  std::vector<int> cls_stuff;
  for (int i = 0; i < max_cls_size; i++) {
    // printf("it is %d\n", area_cpu[i]);
    if (area_cpu[i] > min_stuff_area) {
      cls_stuff.push_back(i);
      // printf("it is into %d\n", i);
    }
  }
  // printf("finish cls_stuff\n");

  std::vector<int> tmp(num_stuff + 1, num_stuff);
  for (int i = 0; i < cls_stuff.size(); i++) {
    tmp[cls_stuff[i]] = i;
  }

  cudaMemcpyAsync(cuda_tmp, tmp.data(), sizeof(int) * num_stuff, cudaMemcpyHostToDevice, stream);

  cudaMemcpyAsync(output_1, cat, sizeof(int) * cat_size, cudaMemcpyDeviceToDevice, stream);

  // printf("finish cp cat to output_1\n");

  cls_stuff.push_back(-1);

  cudaMemcpyAsync((int*)output_1 + cat_size,
                  cls_stuff.data(),
                  sizeof(int) * cls_stuff.size(),
                  cudaMemcpyHostToDevice,
                  stream);

  // CHECK_CUDA(get_panoptic_mask<<<h_size, thread_size, 0, stream>>>(
  //     (int*)output_0, (const int*)panoptic_mask, (const int*)sem_pred, (const int*)cuda_tmp,
  //     num_stuff, total_unique, w_size, area_per_thread));
  get_panoptic_mask<<<h_size, thread_size, 0, stream>>>((int*)output_0,
                                                        (const int*)panoptic_mask,
                                                        (const int*)sem_pred,
                                                        (const int*)cuda_tmp,
                                                        num_stuff,
                                                        total_unique,
                                                        w_size,
                                                        area_per_thread);
  CHECK_CUDA_STATUS("get_panoptic_mask");
  // printf("error is %s\n", cudaGetErrorString(cudaGetLastError()));

  return STATUS_SUCCESS;
}
