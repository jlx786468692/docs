/*
 * Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "linfer/ops/trt/scatter/scatter.h"

#include <NvInfer.h>
#include <cublas_v2.h>

#include <cstring>
#include <iostream>
#include <sstream>

#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/util/internal/cuda/half.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

using namespace nvinfer1;

using linfer::ops::trt::ScatterND;
using linfer::ops::trt::ScatterNDPluginCreator;

REGISTER_TENSORRT_PLUGIN(ScatterNDPluginCreator);

namespace {

const char* SCATTERND_PLUGIN_VERSION{"1"};
const char* SCATTERND_PLUGIN_NAME{"ScatterNDPlugin"};
// const char* SCATTERND_PLUGIN_NAME{"ScatterND"};
}  // namespace

PluginFieldCollection ScatterNDPluginCreator::mFC{};

ScatterND::ScatterND(bool use_fp16) : use_fp16_(use_fp16) {}

int ScatterND::getNbOutputs() const noexcept {
  // Plugin layer has 1 output
  return 1;
}

nvinfer1::DimsExprs ScatterND::getOutputDimensions(int32_t outputIndex,
                                                   const nvinfer1::DimsExprs* inputs,
                                                   int32_t nbInputs,
                                                   nvinfer1::IExprBuilder& exprBuilder) noexcept {
  // output should have same dimensions as data tensor
  nvinfer1::DimsExprs ret = inputs[dataTensorIdx];
  return ret;
}

int ScatterND::initialize() noexcept { return 0; }

void ScatterND::terminate() noexcept {}

bool ScatterND::supportsFormatCombination(int32_t pos,
                                          const nvinfer1::PluginTensorDesc* inOut,
                                          int32_t nbInputs,
                                          int32_t nbOutputs) noexcept {
  ASSERT(pos < 4);
  ASSERT(nbInputs == 3);
  ASSERT(nbOutputs == 1);
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  // printf("%s index %d input precision is %d \n", mPluginNamespace.c_str(), pos, desc.type);
  bool ret = false;
  if (use_fp16_) {
    switch (pos) {
      case dataTensorIdx:
        if (desc.type != nvinfer1::DataType::kHALF) {
          printf("precision setting wrongly attr is fp32 but use fp16\n");
          // ASSERT(false);
        }
        ret = ((desc.type == nvinfer1::DataType::kHALF) &&
               desc.format == nvinfer1::TensorFormat::kLINEAR);
        break;
      case updateTensorIdx:
      case 3:
        ret = (desc.type == inOut[dataTensorIdx].type);
        break;
      case indexTensorIdx:
        ret = (desc.type == nvinfer1::DataType::kINT32 &&
               desc.format == nvinfer1::TensorFormat::kLINEAR);
        break;
    }
    // printf("input %d type is %d a input is %d ret is %d\n", pos, desc.type,
    // inOut[dataTensorIdx].type, ret);
    return ret;
  }
  switch (pos) {
    case dataTensorIdx:
      if (desc.type != nvinfer1::DataType::kFLOAT) {
        printf("precision setting wrongly attr is fp16 but use fp32\n");
        // ASSERT(false);
      }
      ret = ((desc.type == nvinfer1::DataType::kFLOAT) &&
             desc.format == nvinfer1::TensorFormat::kLINEAR);
      break;
    case updateTensorIdx:
    case 3:
      ret = (desc.type == inOut[dataTensorIdx].type);
      break;
    case indexTensorIdx:
      ret = (desc.type == nvinfer1::DataType::kINT32 &&
             desc.format == nvinfer1::TensorFormat::kLINEAR);
      break;
  }
  return ret;
}

void ScatterND::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                int32_t nbInputs,
                                const nvinfer1::DynamicPluginTensorDesc* out,
                                int32_t nbOutputs) noexcept {
  if (in[0].desc.type == nvinfer1::DataType::kHALF) {
    ASSERT(use_fp16_);
    return;
  }
  ASSERT(!use_fp16_);
}

int32_t ScatterND::calculateNumSlices(nvinfer1::Dims indexTensorDims) const noexcept {
  int32_t nSlices = 1;
  for (int i = 0; i < indexTensorDims.nbDims - 1; i++) {
    nSlices *= indexTensorDims.d[i];
  }
  return nSlices;
}

size_t ScatterND::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                   int32_t nbInputs,
                                   const nvinfer1::PluginTensorDesc* outputs,
                                   int32_t nbOutputs) const noexcept {
  int32_t nSlices = calculateNumSlices(inputs[indexTensorIdx].dims);
  // transformCoeffs + transformed indices
  // return outputs[0].dims.MAX_DIMS * sizeof(int32_t) + nSlices * sizeof(int32_t);
  return 0;
}

void ScatterND::calculateTransformCoeff(const nvinfer1::Dims& dataTensorDims,
                                        int indexRank,
                                        int32_t* transformCoeff) const noexcept {
  std::vector<int32_t> pitches;
  for (int32_t i = indexRank - 1, nIndx = 1; i >= 0; i--) {
    pitches.push_back(nIndx);
    nIndx *= dataTensorDims.d[i];
  }

  std::reverse(pitches.begin(),
               pitches.end());  // last dimension pitch is always one (assuming linear mem)

  std::copy(pitches.begin(), pitches.end(), transformCoeff);
}

int32_t ScatterND::calculateCopySize(const nvinfer1::Dims& dataDims) const noexcept {
  int32_t copySize = 1;
  for (int i = 0; i < dataDims.nbDims; i++) {
    copySize *= dataDims.d[i];
  }
  copySize *= sizeof(float);
  return copySize;
}

int32_t ScatterND::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                           const nvinfer1::PluginTensorDesc* outputDesc,
                           const void* const* inputs,
                           void* const* outputs,
                           void* workspace,
                           cudaStream_t stream) noexcept {
  float self_op_msecTotal = 0.0f;

  int32_t transformCoeff[outputDesc[0].dims.MAX_DIMS];
  std::memset(transformCoeff, 0, sizeof(int32_t) * outputDesc[0].dims.MAX_DIMS);
  nvinfer1::Dims IndexDims = inputDesc[indexTensorIdx].dims;

  nvinfer1::Dims dataDims = inputDesc[dataTensorIdx].dims;
  // Dims srcDims = inputDesc[updateTensorIdx].dims;

  int32_t indexRank = IndexDims.d[IndexDims.nbDims - 1];
  ASSERT(indexRank <= dataDims.nbDims);

  int32_t nSlices = calculateNumSlices(IndexDims);
  int32_t rowSize = 1;
  int32_t srcRowSize = 1;
  int32_t copySize = calculateCopySize(dataDims);
  int32_t dest_nRow = inputDesc[dataTensorIdx].dims.d[0];
  int32_t elementSizeInBytes = 1;
  switch (inputDesc->type) {
    case nvinfer1::DataType::kFLOAT:
    case nvinfer1::DataType::kINT32:
      elementSizeInBytes = 4;
      break;
    case nvinfer1::DataType::kHALF:
      elementSizeInBytes = 2;
      break;
    case nvinfer1::DataType::kINT8:
    case nvinfer1::DataType::kBOOL:
      elementSizeInBytes = 1;
      break;
  }

  for (int i = indexRank; i < dataDims.nbDims; i++) {
    rowSize *= dataDims.d[i];
  }

  calculateTransformCoeff(dataDims, indexRank, transformCoeff);

  scatterNDInference(stream,
                     transformCoeff,
                     dataDims.nbDims,
                     indexRank,
                     nSlices,
                     rowSize,
                     copySize,
                     dest_nRow,
                     elementSizeInBytes,
                     inputs[indexTensorIdx],
                     inputs[updateTensorIdx],
                     inputs[dataTensorIdx],
                     outputs[0],
                     workspace);

  return 0;
}

size_t ScatterND::getSerializationSize() const noexcept { return sizeof(use_fp16_); }

void ScatterND::serialize(void* buffer) const noexcept { serialize_value(&buffer, use_fp16_); }

// Set plugin namespace
void ScatterND::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* ScatterND::getPluginNamespace() const noexcept { return mPluginNamespace.c_str(); }

// Return the DataType of the plugin output at the requested index
nvinfer1::DataType ScatterND::getOutputDataType(int index,
                                                const nvinfer1::DataType* inputTypes,
                                                int nbInputs) const noexcept {
  // ASSERT(index == 0);
  // printf("the output type is %d\n", inputTypes[dataTensorIdx]);
  // return inputTypes[dataTensorIdx];
  if (use_fp16_) return nvinfer1::DataType::kHALF;
  return nvinfer1::DataType::kFLOAT;
  // return nvinfer1::DataType::kHALF;
}

// Attach the plugin object to an execution context and grant the plugin the access to some context
// resource.
void ScatterND::attachToContext(cudnnContext* cudnn,
                                cublasContext* cublas,
                                nvinfer1::IGpuAllocator* gpuAllocator) noexcept {
  return;
}

// Detach the plugin object from its execution context.
void ScatterND::detachFromContext() noexcept {}

const char* ScatterND::getPluginType() const noexcept { return SCATTERND_PLUGIN_NAME; }

const char* ScatterND::getPluginVersion() const noexcept { return SCATTERND_PLUGIN_VERSION; }

void ScatterND::destroy() noexcept { delete this; }

// Clone the plugin
nvinfer1::IPluginV2DynamicExt* ScatterND::clone() const noexcept {
  // Create a new instance
  ScatterND* plugin = new ScatterND(use_fp16_);
  plugin->setPluginNamespace(mPluginNamespace.c_str());
  return plugin;
}

ScatterNDPluginCreator::ScatterNDPluginCreator() { mFC.nbFields = 0; }

const char* ScatterNDPluginCreator::getPluginName() const noexcept { return SCATTERND_PLUGIN_NAME; }

const char* ScatterNDPluginCreator::getPluginVersion() const noexcept {
  return SCATTERND_PLUGIN_VERSION;
}

const PluginFieldCollection* ScatterNDPluginCreator::getFieldNames() noexcept { return &mFC; }

nvinfer1::IPluginV2Ext* ScatterNDPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  bool use_fp16 = false;
  for (int i = 0; i < fc->nbFields; i++) {
    if (fc->fields[i].data == nullptr) {
      continue;
    }
    std::string field_name(fc->fields[i].name);

    if (field_name.compare("use_fp16") == 0) {
      int use_fp16_int = static_cast<const int*>(fc->fields[i].data)[0];
      use_fp16 = use_fp16_int != 0;
    }
  }

  ScatterND* obj = new ScatterND(use_fp16);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* ScatterNDPluginCreator::deserializePlugin(const char* name,
                                                                  const void* serialData,
                                                                  size_t serialLength) noexcept {
  // This object will be deleted when the network is destroyed, which will
  // call Normalize::destroy()
  bool use_fp16_ = false;
  // deserialize_value(&serialData, &serialLength, &use_fp16_); FIX ME
  if (use_fp16_) {
    printf("%s use fp16\n", name);
  } else {
    printf("%s use fp32\n", name);
  }
  ScatterND* obj = new ScatterND(use_fp16_);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}
