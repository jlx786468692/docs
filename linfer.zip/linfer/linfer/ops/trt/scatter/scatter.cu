#include <string>
#include <vector>

#include "cuda_fp16.h"
#include "linfer/ops/cuda/index_add/index_add.cuh"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

#define CUBLAS_CHECK(condition)                                                           \
  do {                                                                                    \
    cublasStatus_t status = condition;                                                    \
    if (status != CUBLAS_STATUS_SUCCESS) {                                                \
      printf("%s %d CUBLAS FAIL %s\n", __FILE__, __LINE__, cublasGetErrorString(status)); \
    }                                                                                     \
  } while (0)

// this scatter kernel works on a 2d table writing rows
// index is 1-D array
// updates is 2-D array
// output is 2-D array
// output[index[i]] = updates[i]

__global__ void scatterKernel(char* output,
                              const char* updates,
                              const int* indices,
                              int pitch,
                              int rowSize) {
  int idx = indices[blockIdx.x];
  char* pDst = (char*)output + idx * pitch;
  const char* pSrc = updates + blockIdx.x * rowSize;
  memcpy(pDst, pSrc, rowSize);
}

// Transform nd index to 1 - d index
__global__ void transformIdxKernel(
    int* output,
    const int*
        transformCoeff,  // these are actually the output pitches of the respective dimensions
    const int* indices,
    int sliceRank) {
  const int* idx = indices + sliceRank * blockIdx.x;
  int transformedIdx = 0;
  for (int i = 0; i < sliceRank; i++) {
    transformedIdx += idx[i] * transformCoeff[i];
  }
  output[blockIdx.x] = transformedIdx;
}

pluginStatus_t scatterNDInference(cudaStream_t stream,
                                  int* transformCoeff,
                                  int nOutputDims,
                                  int sliceRank,
                                  int nRows,
                                  int rowSize,
                                  int copySize,
                                  int dest_nRow,
                                  int sizeOfElementInBytes,
                                  const void* index,
                                  const void* updates,
                                  const void* data,
                                  void* output,
                                  void* workspace) {
  copySize = copySize / sizeof(float) * sizeOfElementInBytes;
  cudaMemcpyAsync(output, data, copySize, cudaMemcpyDeviceToDevice, stream);
  if (sizeOfElementInBytes == 4) {
    index_add_wrapper((float*)output,
                      (const int*)index,
                      (const float*)updates,
                      dest_nRow,
                      nRows,
                      rowSize,
                      stream);
  } else {
    index_add_wrapper((__half*)output,
                      (const int*)index,
                      (const __half*)updates,
                      dest_nRow,
                      nRows,
                      rowSize,
                      stream);
  }

  return STATUS_SUCCESS;
}