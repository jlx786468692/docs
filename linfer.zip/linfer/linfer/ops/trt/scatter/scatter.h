/*
 * Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef TRT_SCATTER_PLUGIN_H
#define TRT_SCATTER_PLUGIN_H

#include <NvInfer.h>
#include <cublas_v2.h>

#include <string>
#include <vector>

#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/trt/plugin.h"

namespace linfer {
namespace ops {
namespace trt {

class ScatterND : public nvinfer1::IPluginV2DynamicExt {
 public:
  ScatterND(bool use_fp16);

  ~ScatterND() override = default;

  int getNbOutputs() const noexcept override;

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  virtual size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                  int32_t nbInputs,
                                  const nvinfer1::PluginTensorDesc* outputs,
                                  int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

 private:
  // calculate how many slices we need to scatter = reduce_mul(indexTensor.shape[:-1])
  int32_t calculateNumSlices(nvinfer1::Dims indexTensorDims) const noexcept;
  int32_t calculateCopySize(const nvinfer1::Dims& dataDims) const noexcept;
  void calculateTransformCoeff(const nvinfer1::Dims& dataTensorDims,
                               int indexRank,
                               int32_t* transformCoeff) const noexcept;
  std::string mPluginNamespace;

  static constexpr int indexTensorIdx = 1;
  static constexpr int updateTensorIdx = 2;
  static constexpr int dataTensorIdx = 0;
  static constexpr int dataTensorIdx2 = 4;
  int use_fp16_ = false;
  int iter = 0;
  float record_time = 0.0f;
};

class ScatterNDPluginCreator : public BaseCreator {
 public:
  ScatterNDPluginCreator();

  ~ScatterNDPluginCreator() override = default;

  const char* getPluginName() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;

  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept override;

  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept override;

 private:
  static nvinfer1::PluginFieldCollection mFC;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer

pluginStatus_t scatterNDInference(cudaStream_t stream,
                                  int* outputDims,
                                  int nOutputDims,
                                  int sliceRank,
                                  int nRows,
                                  int rowSize,
                                  int CopySize,
                                  int dest_nRow,
                                  int sizeOfElementInBytes,
                                  const void* index,
                                  const void* updates,
                                  const void* data,
                                  void* output,
                                  void* workspace);

#endif  // TRT_SCATTER_PLUGIN_H
