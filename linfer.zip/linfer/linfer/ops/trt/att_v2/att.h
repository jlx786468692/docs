#pragma once

#include <NvInfer.h>
#include <cublas_v2.h>

#include <mutex>
#include <string>
#include <vector>

#include "linfer/util/trt/model.h"
#include "linfer/util/util.h"

namespace linfer {
namespace ops {
namespace trt {

// define in ascending order by LaneGCN att engine nonzero len.
enum class LaneGCNAttEngineScale : int32_t { MIN = 0, SMALL, MIDDLE, BIG, MAX };

class LanegcnAtt : public nvinfer1::IPluginV2DynamicExt {
 public:
  LanegcnAtt(void);
  ~LanegcnAtt(void) override;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  virtual size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                  int32_t nbInputs,
                                  const nvinfer1::PluginTensorDesc* outputs,
                                  int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  int getNbOutputs() const noexcept override;

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

  static std::shared_ptr<linfer::util::TrtModelInferEngine> get_engine(LaneGCNAttEngineScale scale);

  static void set_engine(LaneGCNAttEngineScale scale,
                         std::shared_ptr<linfer::util::TrtModelInferEngine> eng);

  static bool is_engine_existent(LaneGCNAttEngineScale scale);

  static void set_active_engine_scale(LaneGCNAttEngineScale scale);

  static LaneGCNAttEngineScale get_active_engine_scale(void);

  static std::shared_ptr<linfer::util::TrtModelInferEngine> get_active_engine(void);

  static int get_nonzero_len(LaneGCNAttEngineScale scale);

 private:
  static int agts_idx_;
  static int agt_ctrs_idx_;
  static int ctx_idx_;
  static int ctx_ctrs_idx_;
  static int dist_th_idx_;
  static int dist_0_weight_idx_;
  static int dist_0_bias_idx_;
  static int dist_2_linear_weight_idx_;
  static int dist_2_linear_norm_weight_idx_;
  static int dist_2_linear_norm_bias_idx_;
  static int query_linear_weight_idx_;
  static int query_norm_weight_idx_;
  static int query_norm_bias_idx_;
  static int ctx_0_linear_weight_idx_;
  static int ctx_0_norm_weight_idx_;
  static int ctx_0_norm_bias_idx_;
  static int ctx_1_weight_idx_;
  static int agt_weight_idx_;
  // static int max_nonzero_len_;
  static LaneGCNAttEngineScale active_eng_scale_;
  static std::unordered_map<LaneGCNAttEngineScale,
                            std::shared_ptr<linfer::util::TrtModelInferEngine>,
                            linfer::util::KeyHash<linfer::ops::trt::LaneGCNAttEngineScale>,
                            linfer::util::KeyEqual<linfer::ops::trt::LaneGCNAttEngineScale>>
      eng_map_;
  static std::unordered_map<LaneGCNAttEngineScale,
                            int,
                            linfer::util::KeyHash<linfer::ops::trt::LaneGCNAttEngineScale>,
                            linfer::util::KeyEqual<linfer::ops::trt::LaneGCNAttEngineScale>>
      eng_nonzero_len_map_;
  std::string mPluginNamespace;
};

class LanegcnAttPluginCreator : public nvinfer1::IPluginCreator {
 private:
  static nvinfer1::PluginFieldCollection mFC;
  std::string plugin_name_;

 protected:
  std::string mNamespace;

 public:
  LanegcnAttPluginCreator();
  ~LanegcnAttPluginCreator() override = default;
  const char* getPluginVersion() const noexcept override;
  const char* getPluginName() const noexcept override;
  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;
  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept;
  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept;
  void setPluginNamespace(const char* libNamespace) noexcept;
  const char* getPluginNamespace() const noexcept;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer
