
#include <string>
#include <vector>

#include "linfer/ops/cuda/index_add/index_add.cuh"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

__global__ void matrix_element_diff_and_sqrt(float* ret,
                                             const float* m1,
                                             const float* m2,
                                             const float* dist_th,
                                             int* len,
                                             int* hi,
                                             int* wi,
                                             size_t n,
                                             size_t part,
                                             int max_nonzero_len) {
  register int offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register const float* ptr_m1 = m1 + blockIdx.x * part;
  register const float* ptr_m2 = m2 + threadIdx.x * part;
  register float tmp = .0;
  register const float dist_th_val = *dist_th;

  for (; offset < end; offset++) {
    register int relative_offset = part - (end - offset);
    register float base_value = *(ptr_m1 + relative_offset) - *(ptr_m2 + relative_offset);
    // *(ret + blockIdx.x * n + offset) = *(ptr_m1 + relative_offset) - *(ptr_m2 +
    // relative_offset) ;
    tmp += base_value * base_value;
  }
  if (sqrt(tmp) <= dist_th_val) {
    int32_t ret_offset = atomicAdd(len, part);
    if (ret_offset < max_nonzero_len) {
      for (int i = 0; i < part; i++) {
        ret[ret_offset + i] = m1[blockIdx.x * part + i] - m2[threadIdx.x * part + i];
      }
      hi[ret_offset / 2] = blockIdx.x;
      wi[ret_offset / 2] = threadIdx.x;
    }
  }
}

__global__ void matrix_element_diff_and_sqrt1(float* ret,
                                              const float* m1,
                                              const float* m2,
                                              const float* dist_th,
                                              int* len,
                                              int* hi,
                                              int* wi,
                                              size_t n,
                                              size_t part,
                                              int max_nonzero_len) {
  register int mat_1_part_size = 2;
  register int mat_2_part_size = part;
  register int offset = threadIdx.x * mat_2_part_size;
  size_t part_end = offset + mat_2_part_size;
  register size_t end = (n < part_end) ? n : part_end;
  register const float* ptr_m1 = m1 + blockIdx.x * mat_1_part_size;
  register const float* ptr_m2 = m2 + threadIdx.x * mat_2_part_size;
  register const float dist_th_val = *dist_th;

  for (int block_num = 0; offset < end; offset += 2) {
    register float tmp = .0;
    for (int i = 0; i < 2; i++) {
      register int mat1_relative_offset = i;
      // register int mat2_relative_offset = mat_2_part_size - (end - offset - i);
      register int mat2_relative_offset = mat_2_part_size - (end - offset) + i;
      register float base_value =
          *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 + mat2_relative_offset);
      // *(ret + blockIdx.x * n + offset + i) = base_value ;
      tmp += base_value * base_value;
    }
    if (sqrt(tmp) <= dist_th_val) {
      int32_t ret_offset = atomicAdd(len, mat_1_part_size);
      if (ret_offset < max_nonzero_len) {
        for (int i = 0; i < mat_1_part_size; i++) {
          ret[ret_offset + i] =
              m1[blockIdx.x * mat_1_part_size + i] -
              m2[threadIdx.x * mat_2_part_size + mat_2_part_size - (end - offset) + i];
        }
        hi[ret_offset / 2] = blockIdx.x;
        wi[ret_offset / 2] = threadIdx.x * part / mat_1_part_size + block_num;
      }
    }
    block_num++;
  }
}

__global__ void matrix_element_diff_and_sqrt_h(__half* ret,
                                               const __half* m1,
                                               const __half* m2,
                                               const __half* dist_th,
                                               int* len,
                                               int* hi,
                                               int* wi,
                                               size_t n,
                                               size_t part,
                                               int max_nonzero_len) {
  register int offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register const __half* ptr_m1 = m1 + blockIdx.x * part;
  register const __half* ptr_m2 = m2 + threadIdx.x * part;
  register __half tmp = .0;
  register const __half dist_th_val = *dist_th;

  for (; offset < end; offset++) {
    register int relative_offset = part - (end - offset);
    register __half base_value = *(ptr_m1 + relative_offset) - *(ptr_m2 + relative_offset);
    // *(ret + blockIdx.x * n + offset) = *(ptr_m1 + relative_offset) - *(ptr_m2 +
    // relative_offset) ;
    tmp += base_value * base_value;
  }
  if ((float)sqrtf(tmp) <= (float)dist_th_val) {
    int32_t ret_offset = atomicAdd(len, part);
    if (ret_offset < max_nonzero_len) {
      for (int i = 0; i < part; i++) {
        ret[ret_offset + i] = m1[blockIdx.x * part + i] - m2[threadIdx.x * part + i];
      }
      hi[ret_offset / 2] = blockIdx.x;
      wi[ret_offset / 2] = threadIdx.x;
    }
  }
}

__global__ void matrix_element_diff_and_sqrt1_h(__half* ret,
                                                const __half* m1,
                                                const __half* m2,
                                                const __half* dist_th,
                                                int* len,
                                                int* hi,
                                                int* wi,
                                                size_t n,
                                                size_t part,
                                                int max_nonzero_len) {
  register int mat_1_part_size = 2;
  register int mat_2_part_size = part;
  register int offset = threadIdx.x * mat_2_part_size;
  size_t part_end = offset + mat_2_part_size;
  register size_t end = (n < part_end) ? n : part_end;
  register const __half* ptr_m1 = m1 + blockIdx.x * mat_1_part_size;
  register const __half* ptr_m2 = m2 + threadIdx.x * mat_2_part_size;
  register const __half dist_th_val = *dist_th;

  for (int block_num = 0; offset < end; offset += 2) {
    register __half tmp = .0;
    for (int i = 0; i < 2; i++) {
      register int mat1_relative_offset = i;
      // register int mat2_relative_offset = mat_2_part_size - (end - offset - i);
      register int mat2_relative_offset = mat_2_part_size - (end - offset) + i;
      register __half base_value =
          *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 + mat2_relative_offset);
      // *(ret + blockIdx.x * n + offset + i) = base_value ;
      tmp += base_value * base_value;
    }
    if ((float)sqrtf(tmp) <= (float)dist_th_val) {
      int32_t ret_offset = atomicAdd(len, mat_1_part_size);
      if (ret_offset < max_nonzero_len) {
        for (int i = 0; i < mat_1_part_size; i++) {
          ret[ret_offset + i] =
              m1[blockIdx.x * mat_1_part_size + i] -
              m2[threadIdx.x * mat_2_part_size + mat_2_part_size - (end - offset) + i];
        }
        hi[ret_offset / 2] = blockIdx.x;
        wi[ret_offset / 2] = threadIdx.x * part / mat_1_part_size + block_num;
      }
    }
    block_num++;
  }
}

__global__ void matrix_element_diff_and_sqrt1_one_block(float* ret,
                                                        const float* m1,
                                                        const float* m2,
                                                        const float* dist_th,
                                                        int* len,
                                                        int* hi,
                                                        int* wi,
                                                        size_t n,
                                                        size_t part,
                                                        int max_nonzero_len) {
  register int mat_1_part_size = 2;
  register int mat_2_part_size = part;
  register int offset = threadIdx.y * mat_2_part_size;
  size_t part_end = offset + mat_2_part_size;
  register size_t end = (n < part_end) ? n : part_end;
  register const float* ptr_m1 = m1 + threadIdx.x * mat_1_part_size;
  register const float* ptr_m2 = m2 + threadIdx.y * mat_2_part_size;
  register const float dist_th_val = *dist_th;
  register float dist_threshold_square = dist_th_val * dist_th_val;
  register float tmp_dist_square[8];
  register float tmp_dist[8][2];
  register int tmp_hi[8];
  register int tmp_wi[8];

  for (int block_num = 0; block_num < 16;
       offset += 2, block_num++) {  // sample_interval = 16; offset += mat_1_part_size
    for (int n = 0; n < 8; n++) {   // one_thread_n_group = part / mat_1_part_size /
                                    // sample_interval; // one_thread_n_group = 8
      // tmp_dist_square[n] = .0;
      register int sub_offset = offset + n * 32;  // n * mat_1_part_size * sample_interval
      for (int i = 0; i < 2; i++) {               // i < mat_1_part_size
        register int mat1_relative_offset = i;
        register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
        tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 + mat2_relative_offset);
      }
      tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
      tmp_hi[n] = threadIdx.x;
      tmp_wi[n] = threadIdx.y * part / 2 + block_num +
                  n * 16;  // threadIdx.y * part / mat_1_part_size + block_num + n * sample_interval
    }
    // __syncthreads();
    for (int n = 0; n < 8; n++) {  // one_thread_n_group = 8
      if (tmp_dist_square[n] <= dist_threshold_square) {
        int32_t ret_offset = atomicAdd(len, 2);  //  mat_1_part_size = 2
        if (ret_offset < max_nonzero_len) {
          for (int i = 0; i < 2; i++) {  // i < mat_1_part_size
            ret[ret_offset + i] = tmp_dist[n][i];
          }
          hi[ret_offset / 2] = tmp_hi[n];
          wi[ret_offset / 2] = tmp_wi[n];
        }
      }
    }
    __syncthreads();
  }
}

__global__ void matrix_element_diff_and_sqrt1_h_one_block(__half* ret,
                                                          const __half* m1,
                                                          const __half* m2,
                                                          const __half* dist_th,
                                                          int* len,
                                                          int* hi,
                                                          int* wi,
                                                          size_t n,
                                                          size_t part,
                                                          int max_nonzero_len) {
  register int mat_1_part_size = 2;
  register int mat_2_part_size = part;
  register int offset = threadIdx.y * mat_2_part_size;
  size_t part_end = offset + mat_2_part_size;
  register size_t end = (n < part_end) ? n : part_end;
  register const __half* ptr_m1 = m1 + threadIdx.x * mat_1_part_size;
  register const __half* ptr_m2 = m2 + threadIdx.y * mat_2_part_size;
  register const __half dist_th_val = *dist_th;
  register __half dist_threshold_square = dist_th_val * dist_th_val;
  register __half tmp_dist_square[8];
  register __half tmp_dist[8][2];
  register int tmp_hi[8];
  register int tmp_wi[8];

  for (int block_num = 0; block_num < 16;
       offset += 2, block_num++) {  // sample_interval = 16; offset += mat_1_part_size
    for (int n = 0; n < 8; n++) {   // one_thread_n_group = part / mat_1_part_size /
                                    // sample_interval; // one_thread_n_group = 8
      // tmp_dist_square[n] = .0;
      register int sub_offset = offset + n * 32;  // n * mat_1_part_size * sample_interval
      for (int i = 0; i < 2; i++) {               // i < mat_1_part_size
        register int mat1_relative_offset = i;
        register int mat2_relative_offset = mat_2_part_size - (end - sub_offset) + i;
        tmp_dist[n][i] = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 + mat2_relative_offset);
      }
      tmp_dist_square[n] = tmp_dist[n][0] * tmp_dist[n][0] + tmp_dist[n][1] * tmp_dist[n][1];
      tmp_hi[n] = threadIdx.x;
      tmp_wi[n] = threadIdx.y * part / 2 + block_num +
                  n * 16;  // threadIdx.y * part / mat_1_part_size + block_num + n * sample_interval
    }
    // __syncthreads();
    for (int n = 0; n < 8; n++) {  // one_thread_n_group = 8
      if (tmp_dist_square[n] <= dist_threshold_square) {
        int32_t ret_offset = atomicAdd(len, 2);  //  mat_1_part_size = 2
        if (ret_offset < max_nonzero_len) {
          for (int i = 0; i < 2; i++) {  // i < mat_1_part_size
            ret[ret_offset + i] = tmp_dist[n][i];
          }
          hi[ret_offset / 2] = tmp_hi[n];
          wi[ret_offset / 2] = tmp_wi[n];
        }
      }
    }
    __syncthreads();
  }
}

pluginStatus_t nonzero_op(cudaStream_t stream,
                          int agts_r_size,
                          int agts_c_size,
                          int ctx_r_size,
                          int ctx_c_size,
                          int agt_ctrs_size,
                          int ctx_ctrs_size,
                          int sizeOfElementInBytes,
                          const void* agts,
                          const void* ctx,
                          const void* agt_ctrs,
                          const void* ctx_ctrs,
                          const void* dist_th,
                          void* output,
                          int nonzero_len,
                          void* workspace) {
  float* dist_buff = (float*)workspace;
  int* hi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2];
  int* wi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2 + nonzero_len];
  int* cuda_ret_len = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2 + 2 * nonzero_len];
  cudaMemsetAsync(hi_buff, -1, nonzero_len * sizeof(float), stream);  // FIXME
  cudaMemsetAsync(wi_buff, -1, nonzero_len * sizeof(float), stream);  // FIXME
  cudaMemsetAsync(cuda_ret_len, 0, sizeof(int), stream);

  // printf("sizeOfElementInBytes is %d\n", sizeOfElementInBytes);
  if (sizeOfElementInBytes == 2) {
    if (ctx_ctrs_size <= 1024) {
      const size_t thread_size = ctx_ctrs_size;
      size_t part = 2;
      matrix_element_diff_and_sqrt_h<<<agt_ctrs_size, thread_size, 0, stream>>>((__half*)dist_buff,
                                                                                (__half*)agt_ctrs,
                                                                                (__half*)ctx_ctrs,
                                                                                (__half*)dist_th,
                                                                                (int*)cuda_ret_len,
                                                                                (int*)hi_buff,
                                                                                (int*)wi_buff,
                                                                                ctx_ctrs_size * 2,
                                                                                part,
                                                                                nonzero_len * 2);
    } else {
      // const size_t thread_size = 256;
      // size_t part = (ctx_ctrs_size + thread_size - 1) / thread_size * 2;
      // matrix_element_diff_and_sqrt1_h<<<agt_ctrs_size, thread_size, 0,
      // stream>>>((__half*)dist_buff, (__half*)agt_ctrs, (__half*)ctx_ctrs, \
      // 	(__half*)dist_th, (int*)cuda_ret_len, (int*)hi_buff, (int*)wi_buff, ctx_ctrs_size *
      // 2, part, nonzero_len * 2);

      size_t thread_len = 32;
      dim3 thread_size(thread_len, thread_len);
      size_t part = (ctx_ctrs_size + thread_len - 1) / thread_len * 2;
      matrix_element_diff_and_sqrt1_h_one_block<<<1, thread_size, 0, stream>>>((__half*)dist_buff,
                                                                               (__half*)agt_ctrs,
                                                                               (__half*)ctx_ctrs,
                                                                               (__half*)dist_th,
                                                                               (int*)cuda_ret_len,
                                                                               (int*)hi_buff,
                                                                               (int*)wi_buff,
                                                                               ctx_ctrs_size * 2,
                                                                               part,
                                                                               nonzero_len * 2);
    }
  } else {
    if (ctx_ctrs_size <= 1024) {
      const size_t thread_size = ctx_ctrs_size;
      size_t part = 2;
      matrix_element_diff_and_sqrt<<<agt_ctrs_size, thread_size, 0, stream>>>((float*)dist_buff,
                                                                              (float*)agt_ctrs,
                                                                              (float*)ctx_ctrs,
                                                                              (float*)dist_th,
                                                                              (int*)cuda_ret_len,
                                                                              (int*)hi_buff,
                                                                              (int*)wi_buff,
                                                                              ctx_ctrs_size * 2,
                                                                              part,
                                                                              nonzero_len * 2);
    } else {
      // const size_t thread_size = 256;
      // size_t part = (ctx_ctrs_size + thread_size - 1) / thread_size * 2;
      // matrix_element_diff_and_sqrt1<<<agt_ctrs_size, thread_size, 0,
      // stream>>>((float*)dist_buff, (float*)agt_ctrs, (float*)ctx_ctrs, \ 	(float*)dist_th,
      // (int*)cuda_ret_len, (int*)hi_buff, (int*)wi_buff, ctx_ctrs_size * 2, part,
      // nonzero_len * 2);

      size_t thread_len = 32;
      dim3 thread_size(thread_len, thread_len);
      size_t part = (ctx_ctrs_size + thread_len - 1) / thread_len * 2;
      matrix_element_diff_and_sqrt1_one_block<<<1, thread_size, 0, stream>>>((float*)dist_buff,
                                                                             (float*)agt_ctrs,
                                                                             (float*)ctx_ctrs,
                                                                             (float*)dist_th,
                                                                             (int*)cuda_ret_len,
                                                                             (int*)hi_buff,
                                                                             (int*)wi_buff,
                                                                             ctx_ctrs_size * 2,
                                                                             part,
                                                                             nonzero_len * 2);
    }
  }
  CHECK_CUDA_STATUS("matrix_element_diff_and_sqrt");

  return STATUS_SUCCESS;
}

pluginStatus_t index_add_op(cudaStream_t stream,
                            int agts_r_size,
                            int agts_c_size,
                            int ctx_r_size,
                            int ctx_c_size,
                            int agt_ctrs_size,
                            int ctx_ctrs_size,
                            int sizeOfElementInBytes,
                            int ret_len,
                            float* new_ctx,
                            void* output,
                            void* workspace) {
  float* dist_buff = (float*)workspace;
  int* hi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2];

  index_add_wrapper((float*)output,
                    (const int*)hi_buff,
                    (const float*)new_ctx,
                    agts_r_size,
                    ret_len,
                    agts_c_size,
                    stream);
  return STATUS_SUCCESS;
}
