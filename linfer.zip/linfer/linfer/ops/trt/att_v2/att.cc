#include "linfer/ops/trt/att_v2/att.h"

#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

pluginStatus_t nonzero_op(cudaStream_t stream,
                          int agts_r_size,
                          int agts_c_size,
                          int ctx_r_size,
                          int ctx_c_size,
                          int agt_ctrs_size,
                          int ctx_ctrs_size,
                          int sizeOfElementInBytes,
                          const void* agts,
                          const void* ctx,
                          const void* agt_ctrs,
                          const void* ctx_ctrs,
                          const void* dist_th,
                          void* output,
                          int ret_len,
                          void* workspace);

pluginStatus_t index_add_op(cudaStream_t stream,
                            int agts_r_size,
                            int agts_c_size,
                            int ctx_r_size,
                            int ctx_c_size,
                            int agt_ctrs_size,
                            int ctx_ctrs_size,
                            int sizeOfElementInBytes,
                            int ret_len,
                            float* new_ctx,
                            void* output,
                            void* workspace);

using linfer::ops::trt::LanegcnAttPluginCreator;
// LINFER_REGISTER_TENSORRT_PLUGIN(LanegcnAttPluginCreator, linfer);
REGISTER_TENSORRT_PLUGIN(LanegcnAttPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

const int MAX_NONZERO_LEN{65536};

const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"LanegcnAtt"};

int32_t get_row_size(const nvinfer1::Dims& input) { return input.d[0]; }

int32_t get_col_size(const nvinfer1::Dims& input) { return input.d[1]; }

// std::mutex LanegcnAtt::trt_eng_mutex_;
// std::shared_ptr<linfer::util::TrtModelInferEngine> LanegcnAtt::trt_eng_(nullptr);
int LanegcnAtt::agts_idx_ = 0;
int LanegcnAtt::agt_ctrs_idx_ = 1;
int LanegcnAtt::ctx_idx_ = 2;
int LanegcnAtt::ctx_ctrs_idx_ = 3;
int LanegcnAtt::dist_th_idx_ = 4;
int LanegcnAtt::dist_0_weight_idx_ = 5;
int LanegcnAtt::dist_0_bias_idx_ = 6;
int LanegcnAtt::dist_2_linear_weight_idx_ = 7;
int LanegcnAtt::dist_2_linear_norm_weight_idx_ = 8;
int LanegcnAtt::dist_2_linear_norm_bias_idx_ = 9;
int LanegcnAtt::query_linear_weight_idx_ = 10;
int LanegcnAtt::query_norm_weight_idx_ = 11;
int LanegcnAtt::query_norm_bias_idx_ = 12;
int LanegcnAtt::ctx_0_linear_weight_idx_ = 13;
int LanegcnAtt::ctx_0_norm_weight_idx_ = 14;
int LanegcnAtt::ctx_0_norm_bias_idx_ = 15;
int LanegcnAtt::ctx_1_weight_idx_ = 16;
int LanegcnAtt::agt_weight_idx_ = 17;
LaneGCNAttEngineScale LanegcnAtt::active_eng_scale_{LaneGCNAttEngineScale::BIG};
std::unordered_map<LaneGCNAttEngineScale,
                   std::shared_ptr<linfer::util::TrtModelInferEngine>,
                   linfer::util::KeyHash<linfer::ops::trt::LaneGCNAttEngineScale>,
                   linfer::util::KeyEqual<linfer::ops::trt::LaneGCNAttEngineScale>>
    LanegcnAtt::eng_map_{};
std::unordered_map<LaneGCNAttEngineScale,
                   int,
                   linfer::util::KeyHash<linfer::ops::trt::LaneGCNAttEngineScale>,
                   linfer::util::KeyEqual<linfer::ops::trt::LaneGCNAttEngineScale>>
    LanegcnAtt::eng_nonzero_len_map_{};

LanegcnAtt::LanegcnAtt() {}

LanegcnAtt::~LanegcnAtt() {
  eng_map_.clear();
  eng_nonzero_len_map_.clear();
}

bool LanegcnAtt::supportsFormatCombination(int32_t pos,
                                           const nvinfer1::PluginTensorDesc* inOut,
                                           int32_t nbInputs,
                                           int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  // printf("the input %d type is %d the fp16_switch is %d nbInputs is %d\n", pos,
  // desc.type, fp_16_switch, nbInputs);
  if (pos >= nbInputs) {
    return ((desc.type == nvinfer1::DataType::kFLOAT || desc.type == nvinfer1::DataType::kINT32) &&
            desc.format == nvinfer1::TensorFormat::kLINEAR);
  }
  return ((desc.type == nvinfer1::DataType::kHALF || desc.type == nvinfer1::DataType::kINT32) &&
          desc.format == nvinfer1::TensorFormat::kLINEAR);
}

void LanegcnAtt::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                 int32_t nbInputs,
                                 const nvinfer1::DynamicPluginTensorDesc* out,
                                 int32_t nbOutputs) noexcept {}

size_t LanegcnAtt::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                    int32_t nbInputs,
                                    const nvinfer1::PluginTensorDesc* outputs,
                                    int32_t nbOutputs) const noexcept {
  int32_t agt_r_size = get_row_size(inputs[agt_ctrs_idx_].dims);
  int32_t ctx_r_size = get_row_size(inputs[ctx_ctrs_idx_].dims);
  return (MAX_NONZERO_LEN * 2 + agt_r_size * ctx_r_size * 2 + 1) * sizeof(float);
}

int LanegcnAtt::initialize() noexcept { return 0; }

void LanegcnAtt::terminate() noexcept {
  eng_map_.clear();
  eng_nonzero_len_map_.clear();
}

std::shared_ptr<linfer::util::Tensor> make_input(const nvinfer1::PluginTensorDesc desc,
                                                 const void* ptr) {
  linfer::util::Dims dims;
  linfer::util::NvDims2TensorDims(desc.dims, dims);
  auto dtype = linfer::util::NvDataType2DataType(desc.type);
  return std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                  dtype,
                                                  const_cast<void*>(ptr),
                                                  dims);
}

int32_t LanegcnAtt::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                            const nvinfer1::PluginTensorDesc* outputDesc,
                            const void* const* inputs,
                            void* const* outputs,
                            void* workspace,
                            cudaStream_t stream) noexcept {
  auto trt_eng_ = get_active_engine();
  int max_nonzero_len_ = get_nonzero_len(get_active_engine_scale());

  nvinfer1::Dims agt_ctrs_Dims = inputDesc[agt_ctrs_idx_].dims;
  nvinfer1::Dims ctx_ctrs_Dims = inputDesc[ctx_ctrs_idx_].dims;
  nvinfer1::Dims agts_Dims = inputDesc[agts_idx_].dims;
  nvinfer1::Dims ctx_Dims = inputDesc[ctx_idx_].dims;
  int32_t agt_ctrs_r_size = get_row_size(agt_ctrs_Dims);
  int32_t agt_ctrs_c_size = get_col_size(agt_ctrs_Dims);
  int32_t ctx_ctrs_r_size = get_row_size(ctx_ctrs_Dims);
  int32_t ctx_ctrs_c_size = get_col_size(ctx_ctrs_Dims);
  int32_t agts_r_size = get_row_size(agts_Dims);
  int32_t agts_c_size = get_col_size(agts_Dims);
  int32_t ctx_r_size = get_row_size(ctx_Dims);
  int32_t ctx_c_size = get_col_size(ctx_Dims);
  int32_t elementSizeInBytes = linfer::util::getElementSize(inputDesc[agt_ctrs_idx_].type);
  nonzero_op(stream,
             agts_r_size,
             agts_c_size,
             ctx_r_size,
             ctx_c_size,
             agt_ctrs_r_size,
             ctx_ctrs_r_size,
             elementSizeInBytes,
             inputs[agts_idx_],
             inputs[ctx_idx_],
             inputs[agt_ctrs_idx_],
             inputs[ctx_ctrs_idx_],
             inputs[dist_th_idx_],
             outputs[0],
             max_nonzero_len_,
             workspace);
  float* dist_buff = (float*)workspace;
  int* hi_buff = (int*)&dist_buff[agt_ctrs_r_size * ctx_ctrs_r_size * 2];
  int* wi_buff = (int*)&dist_buff[agt_ctrs_r_size * ctx_ctrs_r_size * 2 + max_nonzero_len_];
  float* new_ctx;
  linfer::util::Dims dist_dim, hi_dim, wi_dim, ctx_dim, agts_dim;
  dist_dim.nbDims = 2;
  dist_dim.d[0] = max_nonzero_len_;
  dist_dim.d[1] = 2;
  hi_dim.nbDims = 1;
  hi_dim.d[0] = max_nonzero_len_;
  wi_dim.nbDims = 1;
  wi_dim.d[0] = max_nonzero_len_;
  ctx_dim.nbDims = 2;
  ctx_dim.d[0] = ctx_r_size;
  ctx_dim.d[1] = ctx_c_size;
  agts_dim.nbDims = 2;
  agts_dim.d[0] = agts_r_size;
  agts_dim.d[1] = agts_c_size;

  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> trt_inputs;
  trt_inputs["hi"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                              linfer::util::DataType::kINT32,
                                                              hi_buff,
                                                              hi_dim);
  trt_inputs["wi"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                              linfer::util::DataType::kINT32,
                                                              wi_buff,
                                                              wi_dim);
  if (elementSizeInBytes == 2) {
    trt_inputs["dist"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                                  linfer::util::DataType::kHALF,
                                                                  dist_buff,
                                                                  dist_dim);
  } else {
    trt_inputs["dist"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                                  linfer::util::DataType::kFLOAT,
                                                                  dist_buff,
                                                                  dist_dim);
  }
  trt_inputs["agts"] = make_input(inputDesc[agts_idx_], inputs[agts_idx_]);
  trt_inputs["ctx"] = make_input(inputDesc[ctx_idx_], inputs[ctx_idx_]);
  trt_inputs["dist_0_weight"] =
      make_input(inputDesc[dist_0_weight_idx_], inputs[dist_0_weight_idx_]);
  trt_inputs["dist_0_bias"] = make_input(inputDesc[dist_0_bias_idx_], inputs[dist_0_bias_idx_]);
  trt_inputs["dist_2_linear_weight"] =
      make_input(inputDesc[dist_2_linear_weight_idx_], inputs[dist_2_linear_weight_idx_]);
  trt_inputs["dist_2_linear_norm_weight"] =
      make_input(inputDesc[dist_2_linear_norm_weight_idx_], inputs[dist_2_linear_norm_weight_idx_]);
  trt_inputs["dist_2_linear_norm_bias"] =
      make_input(inputDesc[dist_2_linear_norm_bias_idx_], inputs[dist_2_linear_norm_bias_idx_]);
  trt_inputs["query_linear_weight"] =
      make_input(inputDesc[query_linear_weight_idx_], inputs[query_linear_weight_idx_]);
  trt_inputs["query_norm_weight"] =
      make_input(inputDesc[query_norm_weight_idx_], inputs[query_norm_weight_idx_]);
  trt_inputs["query_norm_bias"] =
      make_input(inputDesc[query_norm_bias_idx_], inputs[query_norm_bias_idx_]);
  trt_inputs["ctx_0_linear_weight"] =
      make_input(inputDesc[ctx_0_linear_weight_idx_], inputs[ctx_0_linear_weight_idx_]);
  trt_inputs["ctx_0_norm_weight"] =
      make_input(inputDesc[ctx_0_norm_weight_idx_], inputs[ctx_0_norm_weight_idx_]);
  trt_inputs["ctx_0_norm_bias"] =
      make_input(inputDesc[ctx_0_norm_bias_idx_], inputs[ctx_0_norm_bias_idx_]);
  trt_inputs["ctx_1_weight"] = make_input(inputDesc[ctx_1_weight_idx_], inputs[ctx_1_weight_idx_]);
  trt_inputs["agt_weight"] = make_input(inputDesc[agt_weight_idx_], inputs[agt_weight_idx_]);

  trt_eng_->set_stream(stream);
  trt_eng_->infer(trt_inputs);

  /*
      agts: trt_outputs[0]
      ctx: trt_outputs[1]
  */
  auto trt_outputs = trt_eng_->get_output(linfer::util::DeviceType::GPU);
  auto trt_agts_output = trt_outputs["out_agts"];
  cudaMemcpyAsync(outputs[0],
                  trt_agts_output->get_gpu_buf(),
                  trt_agts_output->get_len_in_byte(),
                  cudaMemcpyDeviceToDevice,
                  stream);
  new_ctx = static_cast<float*>(trt_outputs["out_ctx"]->get_gpu_buf());
  index_add_op(stream,
               agts_r_size,
               agts_c_size,
               ctx_r_size,
               ctx_c_size,
               agt_ctrs_r_size,
               ctx_ctrs_r_size,
               elementSizeInBytes,
               max_nonzero_len_,
               new_ctx,
               outputs[0],
               workspace);
  return 0;
}

size_t LanegcnAtt::getSerializationSize() const noexcept { return 0; }

void LanegcnAtt::serialize(void* buffer) const noexcept { return; }

const char* LanegcnAtt::getPluginType() const noexcept { return PLUGIN_NAME; }

const char* LanegcnAtt::getPluginVersion() const noexcept { return PLUGIN_VERSION; }

void LanegcnAtt::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* LanegcnAtt::clone() const noexcept {
  auto att = new LanegcnAtt();
  att->setPluginNamespace(mPluginNamespace.c_str());
  return att;
}

void LanegcnAtt::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* LanegcnAtt::getPluginNamespace() const noexcept { return mPluginNamespace.c_str(); }

int LanegcnAtt::getNbOutputs() const noexcept { return 1; }

nvinfer1::DimsExprs LanegcnAtt::getOutputDimensions(int32_t outputIndex,
                                                    const nvinfer1::DimsExprs* inputs,
                                                    int32_t nbInputs,
                                                    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[agts_idx_];
}

nvinfer1::DataType LanegcnAtt::getOutputDataType(int index,
                                                 const nvinfer1::DataType* inputTypes,
                                                 int nbInputs) const noexcept {
  return inputTypes[agts_idx_];
}

void LanegcnAtt::attachToContext(cudnnContext* cudnnContext,
                                 cublasContext* cublasContext,
                                 nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void LanegcnAtt::detachFromContext() noexcept {}

std::shared_ptr<linfer::util::TrtModelInferEngine> LanegcnAtt::get_engine(
    LaneGCNAttEngineScale scale) {
  if (eng_map_.find(scale) == eng_map_.end()) {
    throw std::runtime_error("lanegcn att engine is NOT initialized!");
  }
  return eng_map_[scale];
}

void LanegcnAtt::set_engine(LaneGCNAttEngineScale scale,
                            std::shared_ptr<linfer::util::TrtModelInferEngine> eng) {
  eng_map_[scale] = eng;
}

int LanegcnAtt::get_nonzero_len(LaneGCNAttEngineScale scale) {
  auto kv = eng_nonzero_len_map_.find(scale);
  if (kv != eng_nonzero_len_map_.end()) {
    return kv->second;
  } else {
    auto ptr = get_engine(scale);
    auto dims = ptr->get_binding_dims("hi");
    int nonzero_len = dims.d[0];
    if (nonzero_len <= 0) {
      nonzero_len = MAX_NONZERO_LEN;
    }
    eng_nonzero_len_map_[scale] = nonzero_len;
    return nonzero_len;
  }
}

bool LanegcnAtt::is_engine_existent(LaneGCNAttEngineScale scale) {
  return eng_map_.find(scale) != eng_map_.end();
}

void LanegcnAtt::set_active_engine_scale(LaneGCNAttEngineScale scale) { active_eng_scale_ = scale; }

LaneGCNAttEngineScale LanegcnAtt::get_active_engine_scale(void) { return active_eng_scale_; }

std::shared_ptr<linfer::util::TrtModelInferEngine> LanegcnAtt::get_active_engine(void) {
  return get_engine(active_eng_scale_);
}

nvinfer1::PluginFieldCollection LanegcnAttPluginCreator::mFC{};

LanegcnAttPluginCreator::LanegcnAttPluginCreator() {
  mFC.nbFields = 0;
  mFC.fields = nullptr;
  plugin_name_ = PLUGIN_NAME;
}
const char* LanegcnAttPluginCreator::getPluginVersion() const noexcept { return PLUGIN_VERSION; }
const char* LanegcnAttPluginCreator::getPluginName() const noexcept { return plugin_name_.c_str(); }
const nvinfer1::PluginFieldCollection* LanegcnAttPluginCreator::getFieldNames() noexcept {
  return &LanegcnAttPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* LanegcnAttPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  auto obj = new LanegcnAtt();
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* LanegcnAttPluginCreator::deserializePlugin(const char* name,
                                                                   const void* serialData,
                                                                   size_t serialLength) noexcept {
  auto obj = new LanegcnAtt();
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

void LanegcnAttPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mNamespace = libNamespace;
}

const char* LanegcnAttPluginCreator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
