#include "linfer/ops/trt/multilevel_roi_align/multilevel_roi_align.h"

#include <NvInfer.h>
#include <cublas_v2.h>

#include <cstring>
#include <iostream>
#include <sstream>

#include "../common/trt_serialize.hpp"
#include "../roi_align/trt_roi_align_kernel.hpp"
#include "linfer/util/internal/cuda/half.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

using namespace nvinfer1;

using linfer::ops::trt::multilevel_roi_align;
using linfer::ops::trt::multilevel_roi_alignPluginCreator;

REGISTER_TENSORRT_PLUGIN(multilevel_roi_alignPluginCreator);

namespace {

const char* multilevel_roi_align_PLUGIN_VERSION{"1"};
const char* multilevel_roi_align_PLUGIN_NAME{"multilevel_roi_align"};
// const char* multilevel_roi_align_PLUGIN_NAME{"multilevel_roi_align"};
}  // namespace

PluginFieldCollection multilevel_roi_alignPluginCreator::mFC_{};

multilevel_roi_align::multilevel_roi_align(const std::string& name,
                                           int outWidth,
                                           int outHeight,
                                           float* spatialScale,
                                           int sampleRatio,
                                           int poolMode,
                                           bool aligned)
    : mOutWidth_(outWidth),
      mOutHeight_(outHeight),
      mSampleRatio_(sampleRatio),
      mPoolMode_(poolMode),
      mAligned_(aligned) {
  mSpatialScale_.resize(4);
  memcpy(mSpatialScale_.data(), spatialScale, sizeof(float) * 4);
}

multilevel_roi_align::multilevel_roi_align(const std::string name,
                                           const void* data,
                                           size_t length) {
  deserialize_value(&data, &length, &mOutWidth_);
  deserialize_value(&data, &length, &mOutHeight_);
  deserialize_value(&data, &length, &mSpatialScale_);
  deserialize_value(&data, &length, &mSampleRatio_);
  deserialize_value(&data, &length, &mPoolMode_);
  deserialize_value(&data, &length, &mAligned_);
}

int multilevel_roi_align::getNbOutputs() const noexcept {
  // Plugin layer has 1 output
  return 1;
}

nvinfer1::DimsExprs multilevel_roi_align::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  // output should have same dimensions as data tensor
  // nvinfer1::DimsExprs ret = inputs[dataTensorIdx];
  // return ret;

  nvinfer1::DimsExprs ret;
  ret.nbDims = 4;
  ret.d[0] = inputs[4].d[0];
  ret.d[1] = inputs[0].d[1];
  ret.d[2] = exprBuilder.constant(mOutHeight_);
  ret.d[3] = exprBuilder.constant(mOutWidth_);
  return ret;
}

int multilevel_roi_align::initialize() noexcept { return 0; }

void multilevel_roi_align::terminate() noexcept {}

bool multilevel_roi_align::supportsFormatCombination(int32_t pos,
                                                     const nvinfer1::PluginTensorDesc* inOut,
                                                     int32_t nbInputs,
                                                     int32_t nbOutputs) noexcept {
  ASSERT(pos < 7);
  ASSERT(nbInputs == 6);
  ASSERT(nbOutputs == 1);
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  bool ret = true;
  switch (pos) {
    case feat_0_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case feat_1_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case feat_2_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case feat_3_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case rois_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case level_:
      ret =
          desc.type == nvinfer1::DataType::kINT32 && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
    case output_0_:
      ret =
          desc.type == nvinfer1::DataType::kFLOAT && desc.format == nvinfer1::TensorFormat::kLINEAR;
      break;
  }
  return ret;
}

void multilevel_roi_align::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                           int32_t nbInputs,
                                           const nvinfer1::DynamicPluginTensorDesc* out,
                                           int32_t nbOutputs) noexcept {}

int32_t multilevel_roi_align::calculateNumSlices(nvinfer1::Dims indexTensorDims) const noexcept {
  int32_t nSlices = 1;
  for (int i = 0; i < indexTensorDims.nbDims - 1; i++) {
    nSlices *= indexTensorDims.d[i];
  }
  return nSlices;
}

size_t multilevel_roi_align::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                              int32_t nbInputs,
                                              const nvinfer1::PluginTensorDesc* outputs,
                                              int32_t nbOutputs) const noexcept {
  // int32_t nSlices = calculateNumSlices(inputs[indexTensorIdx].dims);
  // transformCoeffs + transformed indices
  return inputs[4].dims.d[0] * inputs[4].dims.d[1] * sizeof(float) +
         inputs[5].dims.d[0] * sizeof(int);
}

void multilevel_roi_align::calculateTransformCoeff(const nvinfer1::Dims& dataTensorDims,
                                                   int indexRank,
                                                   int32_t* transformCoeff) const noexcept {
  std::vector<int32_t> pitches;
  for (int32_t i = indexRank - 1, nIndx = 1; i >= 0; i--) {
    pitches.push_back(nIndx);
    nIndx *= dataTensorDims.d[i];
  }

  std::reverse(pitches.begin(),
               pitches.end());  // last dimension pitch is always one (assuming linear mem)

  std::copy(pitches.begin(), pitches.end(), transformCoeff);
}

int32_t multilevel_roi_align::calculateCopySize(const nvinfer1::Dims& dataDims) const noexcept {
  int32_t copySize = 1;
  for (int i = 0; i < dataDims.nbDims; i++) {
    copySize *= dataDims.d[i];
  }
  copySize *= sizeof(float);
  return copySize;
}

int32_t multilevel_roi_align::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                      const nvinfer1::PluginTensorDesc* outputDesc,
                                      const void* const* inputs,
                                      void* const* outputs,
                                      void* workspace,
                                      cudaStream_t stream) noexcept {
  // printf("------------------------------------------------------------------------\n");
  // printf("multilevel_roi_align Plugin\n");
  // print_desc(inputDesc[0], "input");
  // print_desc(inputDesc[1], "index");
  // print_desc(inputDesc[2], "update");
  // print_desc(outputDesc[0], "output");
  // printf("the mSampleRatio_ is %d %f\n", mSampleRatio_, mSpatialScale_[0]);
  float* sorted_roi = (float*)workspace;
  int height, width;
  int channels = inputDesc[0].dims.d[1];
  int roi_num = inputDesc[4].dims.d[0];
  int* level = (int*)inputs[5];
  float* roi = (float*)inputs[4];
  int roi_wide = inputDesc[4].dims.d[1];
  int* gpu_rois_idx = (int*)&sorted_roi[roi_num * roi_wide];
  int ws_ptr = 0;
  int* cpu_level = (int*)malloc(sizeof(int) * inputDesc[5].dims.d[0]);
  float* cpu_roi = (float*)malloc(sizeof(float) * inputDesc[4].dims.d[0] * inputDesc[4].dims.d[1]);
  int output_size;
  // int feat_pic_size = channels * mOutHeight_ * mOutWidth_;
  void* argmax_y = nullptr;
  void* argmax_x = nullptr;
  std::vector<std::vector<float>> rois;
  std::vector<std::vector<int>> rois_idx;

  for (int i = 0; i < 4; i++) {
    rois.push_back(std::vector<float>());
    rois_idx.push_back(std::vector<int>());
  }
  // printf("finish create the rois_idx\n");

  cudaMemcpyAsync(cpu_level,
                  level,
                  sizeof(int) * inputDesc[5].dims.d[0],
                  cudaMemcpyDeviceToHost,
                  stream);
  cudaMemcpyAsync(cpu_roi,
                  roi,
                  sizeof(float) * inputDesc[4].dims.d[0] * inputDesc[4].dims.d[1],
                  cudaMemcpyDeviceToHost,
                  stream);

  for (int i = 0; i < roi_num; i++) {
    switch (cpu_level[i]) {
      case 0:
        // printf("get level 0\n");
        for (int j = 0; j < roi_wide; j++) {
          rois[0].push_back(cpu_roi[i * roi_wide + j]);
        }
        rois_idx[0].push_back(i);
        break;
      case 1:
        // printf("get level 1\n");
        for (int j = 0; j < roi_wide; j++) {
          rois[1].push_back(cpu_roi[i * roi_wide + j]);
        }
        rois_idx[1].push_back(i);
        break;
      case 2:
        // printf("get level 2\n");
        for (int j = 0; j < roi_wide; j++) {
          rois[2].push_back(cpu_roi[i * roi_wide + j]);
        }
        rois_idx[2].push_back(i);
        break;
      default:
        // printf("get level 3\n");
        for (int j = 0; j < roi_wide; j++) {
          rois[3].push_back(cpu_roi[i * roi_wide + j]);
        }
        rois_idx[3].push_back(i);
    }
  }
  // printf("finish store the rois_idx %p \n", sorted_roi);

  for (int i = 0; i < 4; i++) {
    // printf("the rois len is %d\n", rois[i].size());
    if (rois[i].size() == 0) continue;
    cudaMemcpyAsync(sorted_roi + ws_ptr,
                    rois[i].data(),
                    sizeof(float) * rois[i].size(),
                    cudaMemcpyHostToDevice,
                    stream);
    // printf("the rois_idx len is %d %d %p\n", rois_idx[i].size(), rois_idx[i][0], gpu_rois_idx
    // + ws_ptr / roi_wide);
    cudaMemcpyAsync(gpu_rois_idx + ws_ptr / roi_wide,
                    rois_idx[i].data(),
                    sizeof(int) * rois_idx[i].size(),
                    cudaMemcpyHostToDevice,
                    stream);
    ws_ptr += rois[i].size();
    // printf("the ws_ptr is %d\n", ws_ptr);
  }
  // return 0;

  ws_ptr = 0;

  for (int i = 0; i < 4; i++) {
    if (rois[i].size() == 0) continue;
    // printf("start %d mSpatialScale_ is %f\n", i, mSpatialScale_[i]);
    height = inputDesc[i].dims.d[2];
    width = inputDesc[i].dims.d[3];
    output_size = rois_idx[i].size() * outputDesc[0].dims.d[1] * outputDesc[0].dims.d[2] *
                  outputDesc[0].dims.d[3];
    // printf("the output_size is %d\n", output_size);
    TRTRoIAlignForwardCUDAKernelLauncher<float>((const float*)inputs[i],
                                                (const float*)sorted_roi + ws_ptr,
                                                (float*)outputs[0],
                                                (float*)argmax_y,
                                                (float*)argmax_x,
                                                gpu_rois_idx + ws_ptr / roi_wide,
                                                output_size,
                                                channels,
                                                height,
                                                width,
                                                mOutHeight_,
                                                mOutWidth_,
                                                mSpatialScale_[i],
                                                mSampleRatio_,
                                                mPoolMode_,
                                                mAligned_,
                                                stream);
    ws_ptr += rois[i].size();
    // printf("the second ws_ptr is %d\n", ws_ptr);
  }
  return 0;
}

size_t multilevel_roi_align::getSerializationSize() const noexcept {
  // printf("the getSerializationSize is %d\n", serialized_size(mOutWidth_) +
  // serialized_size(mOutHeight_) +
  //                                                serialized_size(mSpatialScale_) +
  //                                                serialized_size(mSampleRatio_) +
  //                                                serialized_size(mPoolMode_) +
  //                                                serialized_size(mAligned_));
  return serialized_size(mOutWidth_) + serialized_size(mOutHeight_) +
         serialized_size(mSpatialScale_) + serialized_size(mSampleRatio_) +
         serialized_size(mPoolMode_) + serialized_size(mAligned_);
}

void multilevel_roi_align::serialize(void* buffer) const noexcept {
  serialize_value(&buffer, mOutWidth_);
  serialize_value(&buffer, mOutHeight_);
  serialize_value(&buffer, mSpatialScale_);
  serialize_value(&buffer, mSampleRatio_);
  serialize_value(&buffer, mPoolMode_);
  serialize_value(&buffer, mAligned_);
  return;
}

// Set plugin namespace
void multilevel_roi_align::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace_ = pluginNamespace;
}

const char* multilevel_roi_align::getPluginNamespace() const noexcept {
  return mPluginNamespace_.c_str();
}

// Return the DataType of the plugin output at the requested index
nvinfer1::DataType multilevel_roi_align::getOutputDataType(int index,
                                                           const nvinfer1::DataType* inputTypes,
                                                           int nbInputs) const noexcept {
  // ASSERT(index == 0);
  return inputTypes[0];
}

// Attach the plugin object to an execution context and grant the plugin the access to some context
// resource. void multilevel_roi_align::attachToContext(cudnnContext* cudnn,
//                 cublasContext* cublas,
//                 nvinfer1::IGpuAllocator* gpuAllocator) noexcept
// {
//     return;
// }

// Detach the plugin object from its execution context.
void multilevel_roi_align::detachFromContext() noexcept {}

const char* multilevel_roi_align::getPluginType() const noexcept {
  return multilevel_roi_align_PLUGIN_NAME;
}

const char* multilevel_roi_align::getPluginVersion() const noexcept {
  return multilevel_roi_align_PLUGIN_VERSION;
}

void multilevel_roi_align::destroy() noexcept { delete this; }

// Clone the plugin
nvinfer1::IPluginV2DynamicExt* multilevel_roi_align::clone() const noexcept {
  // Create a new instance
  float mSpatialScale_ptr[4];
  for (int i = 0; i < 4; i++) {
    mSpatialScale_ptr[i] = mSpatialScale_[i];
  }
  multilevel_roi_align* plugin = new multilevel_roi_align(mLayerName_,
                                                          mOutWidth_,
                                                          mOutHeight_,
                                                          mSpatialScale_ptr,
                                                          mSampleRatio_,
                                                          mPoolMode_,
                                                          mAligned_);
  plugin->setPluginNamespace(mPluginNamespace_.c_str());
  return plugin;
}

multilevel_roi_alignPluginCreator::multilevel_roi_alignPluginCreator() {
  mFC_.nbFields = 0;
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("output_height"));
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("output_width"));
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("spatial_scale"));
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("sampling_ratio"));
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("mode"));
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("aligned"));
}

const char* multilevel_roi_alignPluginCreator::getPluginName() const noexcept {
  return multilevel_roi_align_PLUGIN_NAME;
}

const char* multilevel_roi_alignPluginCreator::getPluginVersion() const noexcept {
  return multilevel_roi_align_PLUGIN_VERSION;
}

const PluginFieldCollection* multilevel_roi_alignPluginCreator::getFieldNames() noexcept {
  return &mFC_;
}

nvinfer1::IPluginV2Ext* multilevel_roi_alignPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int output_height = 7;
  int output_width = 7;
  float spatialScale[4] = {0.25, 0.125, 0.0625, 0.003125};
  int sampleRatio = 2;
  int poolMode = 1;
  bool aligned = false;
  for (int i = 0; i < fc->nbFields; i++) {
    if (fc->fields[i].data == nullptr) {
      continue;
    }
    std::string field_name(fc->fields[i].name);

    if (field_name.compare("output_height") == 0) {
      output_height = static_cast<const int*>(fc->fields[i].data)[0];
    }

    if (field_name.compare("output_width") == 0) {
      output_width = static_cast<const int*>(fc->fields[i].data)[0];
    }

    if (field_name.compare("spatial_scale") == 0) {
      memcpy(spatialScale, static_cast<const float*>(fc->fields[i].data), 4 * sizeof(float));
    }

    if (field_name.compare("sampling_ratio") == 0) {
      sampleRatio = static_cast<const int*>(fc->fields[i].data)[0];
    }

    if (field_name.compare("mode") == 0) {
      int data_size = fc->fields[i].length;
      const char* data_start = static_cast<const char*>(fc->fields[i].data);
      std::string poolModeStr(data_start, data_size);
      if (poolModeStr == "avg") {
        poolMode = 1;
      } else if (poolModeStr == "max") {
        poolMode = 0;
      } else {
        std::cout << "Unknown pool mode \"" << poolModeStr << "\"." << std::endl;
      }
      ASSERT(poolMode >= 0);
    }

    if (field_name.compare("aligned") == 0) {
      int aligned_int = static_cast<const int*>(fc->fields[i].data)[0];
      aligned = aligned_int != 0;
    }
  }
  multilevel_roi_align* obj = new multilevel_roi_align(name,
                                                       output_height,
                                                       output_width,
                                                       spatialScale,
                                                       sampleRatio,
                                                       poolMode,
                                                       aligned);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* multilevel_roi_alignPluginCreator::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  // This object will be deleted when the network is destroyed, which will
  // call Normalize::destroy()
  multilevel_roi_align* obj = new multilevel_roi_align(name, serialData, serialLength);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}
