#ifndef MULTILEVEL_ROI_ALIGNH_H
#define MULTILEVEL_ROI_ALIGNH_H

#include <NvInfer.h>
#include <cublas_v2.h>

#include <string>
#include <vector>

// #include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/trt/model.h"

namespace linfer {
namespace ops {
namespace trt {

class multilevel_roi_align : public nvinfer1::IPluginV2DynamicExt {
 public:
  multilevel_roi_align(const std::string& name,
                       int outWidth,
                       int outHeight,
                       float* spatialScale,
                       int sampleRatio,
                       int poolMode,
                       bool aligned);

  multilevel_roi_align(const std::string name, const void* data, size_t length);

  ~multilevel_roi_align() override = default;

  int getNbOutputs() const noexcept override;

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  virtual size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                  int32_t nbInputs,
                                  const nvinfer1::PluginTensorDesc* outputs,
                                  int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  // void attachToContext(
  //     cudnnContext* cudnnContext, cublasContext* cublasContext,
  //     nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

 private:
  // calculate how many slices we need to scatter = reduce_mul(indexTensor.shape[:-1])
  int32_t calculateNumSlices(nvinfer1::Dims indexTensorDims) const noexcept;
  int32_t calculateCopySize(const nvinfer1::Dims& dataDims) const noexcept;
  void calculateTransformCoeff(const nvinfer1::Dims& dataTensorDims,
                               int indexRank,
                               int32_t* transformCoeff) const noexcept;
  std::string mPluginNamespace_;
  const std::string mLayerName_;

  static constexpr int feat_0_ = 0;
  static constexpr int feat_1_ = 1;
  static constexpr int feat_2_ = 2;
  static constexpr int feat_3_ = 3;
  static constexpr int rois_ = 4;
  static constexpr int level_ = 5;
  static constexpr int output_0_ = 6;
  int mOutWidth_;
  int mOutHeight_;
  std::vector<float> mSpatialScale_;
  int mSampleRatio_;
  int mPoolMode_;  // 1:avg 0:max
  bool mAligned_;
};

class multilevel_roi_alignPluginCreator : public BaseCreator {
 public:
  multilevel_roi_alignPluginCreator();

  ~multilevel_roi_alignPluginCreator() override = default;

  const char* getPluginName() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;

  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept override;

  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept override;

 private:
  std::vector<nvinfer1::PluginField> mPluginAttributes_;
  static nvinfer1::PluginFieldCollection mFC_;
};

}  // namespace trt
}  // namespace ops
}  // namespace linfer

pluginStatus_t multilevel_roi_alignInference(cudaStream_t stream,
                                             int rowSize,
                                             int colSize,
                                             const void* A,
                                             const void* B,
                                             void* output,
                                             void* workspace);

#endif  // multilevel_roi_align_PLUGIN_H
