// Copyright [2023] <Lotus Robotics>

#include "batched_rotated_bev_nms.hpp"

#include <cstring>

#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "nms/batched_nms_kernel.hpp"
#include "nms/kernel.h"
#include "trt_serialize.hpp"

namespace linfer {

using namespace nvinfer1;
using nvinfer1::plugin::NMSParameters;
namespace {
static const char* NMS_PLUGIN_VERSION{"1"};
static const char* NMS_PLUGIN_NAME{"BatchedBEVNMS"};
}  // namespace

BatchedBEVNMS::BatchedBEVNMS(const std::string& name,
                             nvinfer1::plugin::NMSParameters params,
                             bool clip_boxes,
                             bool returnIndex,
                             float pillar_x_size,
                             float pillar_y_size,
                             float min_x_range,
                             float min_y_range,
                             int stride,
                             std::vector<float> iou_thr,
                             std::vector<float> rescale_factor,
                             bool multiclass_output_flag)
    : TRTPluginBase(name),
      param(params),
      mClipBoxes(clip_boxes),
      mReturnIndex(returnIndex),
      mPillarXSize(pillar_x_size),
      mPillarYSize(pillar_y_size),
      mMinXRange(min_x_range),
      mMinYRange(min_y_range),
      mStride(stride),
      mIouThreshold(iou_thr),
      mRescaleFactor(rescale_factor),
      mMulticlassOutputFlag(multiclass_output_flag) {
  setupDeviceMemory();
}

BatchedBEVNMS::BatchedBEVNMS(const std::string& name, const void* data, size_t length)
    : TRTPluginBase(name) {
  deserialize_value(&data, &length, &param);
  deserialize_value(&data, &length, &mClipBoxes);
  deserialize_value(&data, &length, &mReturnIndex);
  deserialize_value(&data, &length, &mPillarXSize);
  deserialize_value(&data, &length, &mPillarYSize);
  deserialize_value(&data, &length, &mMinXRange);
  deserialize_value(&data, &length, &mMinYRange);
  deserialize_value(&data, &length, &mStride);
  deserialize_value(&data, &length, &mIouThreshold);
  deserialize_value(&data, &length, &mRescaleFactor);
  deserialize_value(&data, &length, &mMulticlassOutputFlag);
  setupDeviceMemory();
}

void BatchedBEVNMS::setupDeviceMemory() TRT_NOEXCEPT {
  auto copy2device = [](const std::vector<float>& host_data) -> Weights {
    ASSERT(host_data.size() >= 0);
    size_t byte_num = host_data.size() * sizeof(float);
    void* deviceData = nullptr;
    CHECK_CUDA(cudaMalloc(&deviceData, byte_num));
    CHECK_CUDA(cudaMemcpy(deviceData, host_data.data(), byte_num, cudaMemcpyHostToDevice));
    return Weights{DataType::kFLOAT, deviceData, static_cast<int64_t>(host_data.size())};
  };

  mIouThresholdGPU = copy2device(mIouThreshold);
  mRescaleFactorGPU = copy2device(mRescaleFactor);
}

int BatchedBEVNMS::getNbOutputs() const TRT_NOEXCEPT {
  int num = 2;
  return num;
}

nvinfer1::DimsExprs BatchedBEVNMS::getOutputDimensions(int outputIndex,
                                                       const nvinfer1::DimsExprs* inputs,
                                                       int nbInputs,
                                                       nvinfer1::IExprBuilder& exprBuilder)
    TRT_NOEXCEPT {
  ASSERT(nbInputs == 5);
  ASSERT(outputIndex >= 0 && outputIndex < this->getNbOutputs());
  ASSERT(inputs[0].nbDims == 4);
  ASSERT(inputs[1].nbDims == 4);
  ASSERT(inputs[2].nbDims == 4);
  ASSERT(inputs[3].nbDims == 4);
  ASSERT(inputs[4].nbDims == 4);
  // ASSERT(inputs[5].nbDims == 4);

  nvinfer1::DimsExprs ret;
  ret.d[0] = inputs[0].d[0];
  ret.d[1] = exprBuilder.constant(param.keepTopK);
  switch (outputIndex) {
    case 0:
      if (mMulticlassOutputFlag) {
        ret.nbDims = 4;
        ret.d[1] = exprBuilder.constant(param.numClasses);
        ret.d[2] = exprBuilder.constant(param.keepTopK);
        ret.d[3] = exprBuilder.constant(8);
      } else {
        ret.nbDims = 3;
        ret.d[2] = exprBuilder.constant(8);
      }
      break;
    case 1:
      if (mMulticlassOutputFlag) {
        ret.nbDims = 3;
        ret.d[1] = exprBuilder.constant(param.numClasses);
        ret.d[2] = exprBuilder.constant(param.keepTopK);
      } else {
        ret.nbDims = 2;
      }
      break;
    default:
      break;
  }

  return ret;
}

size_t BatchedBEVNMS::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                       int nbInputs,
                                       const nvinfer1::PluginTensorDesc* outputs,
                                       int nbOutputs) const TRT_NOEXCEPT {
  size_t batch_size = inputs[0].dims.d[0];
  size_t boxes_size = param.topK * inputs[0].dims.d[3] * 5;
  size_t score_size = param.topK * inputs[0].dims.d[3];
  size_t num_priors = param.topK;
  // bool shareLocation = (inputs[0].dims.d[2] == 1);
  // int topk = param.topK > 0 && param.topK <= inputs[1].dims.d[1] ? param.topK :
  // inputs[1].dims.d[1];
  size_t index_featmap = inputs[0].dims.d[0] * param.topK * inputs[0].dims.d[3];
  size_t index_nms_out =
      inputs[0].dims.d[0] * param.keepTopK * mMulticlassOutputFlag ? param.numClasses : 1;
  bool shareLocation = false;
  int topk = param.topK;
  return (inputs[0].dims.d[0] * boxes_size + inputs[0].dims.d[0] * score_size + index_nms_out +
                  index_featmap + inputs[0].dims.d[3] +
                  6 * inputs[0].dims.d[0] * param.keepTopK * mMulticlassOutputFlag
              ? param.numClasses
              : 1) *
             sizeof(float) +
         detectionInferenceWorkspaceSize(shareLocation,
                                         batch_size,
                                         boxes_size,
                                         score_size,
                                         param.numClasses,
                                         num_priors,
                                         topk,
                                         DataType::kFLOAT,
                                         DataType::kFLOAT);
}

// inputs[0]: heatmap, 1 x H x W x C, where C is num of class.
// inputs[1]: reg, 1 x H x W x 2C
// inputs[2]: height, 1 x H x W x C
// inputs[3]: dim, 1 x H x W x 3C
// inputs[4]: rot, 1 x H x W x C
int BatchedBEVNMS::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                           const nvinfer1::PluginTensorDesc* outputDesc,
                           const void* const* inputs,
                           void* const* outputs,
                           void* workSpace,
                           cudaStream_t stream) TRT_NOEXCEPT {
  // input
  auto heatmap_preds = static_cast<const float*>(inputs[0]);
  auto reg_preds = static_cast<const float*>(inputs[1]);
  auto height_preds = static_cast<const float*>(inputs[2]);
  auto dim_preds = static_cast<const float*>(inputs[3]);
  auto rot_preds = static_cast<const float*>(inputs[4]);

  // temp output for nms
  void* locData = (uint8_t*)workSpace;
  void* confData = (uint8_t*)workSpace +
                   inputDesc[0].dims.d[0] * param.topK * param.numClasses * 5 * sizeof(float);
  void* featMapIndex =
      (uint8_t*)confData + inputDesc[0].dims.d[0] * param.topK * param.numClasses * sizeof(float);
  void* classCounter = (uint8_t*)featMapIndex +
                       inputDesc[0].dims.d[0] * param.topK * param.numClasses * sizeof(float);
  cudaMemsetAsync(classCounter, 0, param.numClasses * sizeof(float), stream);
  cudaMemsetAsync(confData,
                  0,
                  inputDesc[0].dims.d[0] * param.topK * param.numClasses * sizeof(float),
                  stream);
  // bool shareLocation = true;
  bool shareLocation = false;
  ASSERT(!(shareLocation && mMulticlassOutputFlag));
  makeBevNmsInput(heatmap_preds,
                  reg_preds,
                  height_preds,
                  dim_preds,
                  rot_preds,
                  static_cast<float*>(confData),
                  static_cast<int*>(featMapIndex),
                  static_cast<float*>(locData),
                  static_cast<int*>(classCounter),
                  param.scoreThreshold,
                  param.numClasses,
                  inputDesc[0].dims.d[2],
                  inputDesc[0].dims.d[1],
                  mPillarXSize,
                  mPillarYSize,
                  mMinXRange,
                  mMinYRange,
                  mStride,
                  param.topK,
                  shareLocation,
                  static_cast<const float*>(mRescaleFactorGPU.values),
                  mRescaleFactorGPU.count,
                  stream);

  void* nmsedIndex = (uint8_t*)classCounter + param.numClasses * sizeof(float);

  void* nmsedDets = (uint8_t*)nmsedIndex + inputDesc[0].dims.d[0] * param.keepTopK *
                                               (mMulticlassOutputFlag ? param.numClasses : 1) *
                                               sizeof(float);

  void* nmsedFinalDetsOutput = outputs[0];
  void* nmsedLabels = outputs[1];
  // void* nmsedIndex = mReturnIndex ? outputs[2] : nullptr;

  size_t batch_size = inputDesc[0].dims.d[0];
  // size_t boxes_size = inputDesc[0].dims.d[1] * inputDesc[0].dims.d[2] *
  // inputDesc[0].dims.d[3]; size_t score_size = inputDesc[1].dims.d[1] *
  // inputDesc[1].dims.d[2]; size_t num_priors = inputDesc[0].dims.d[1];
  size_t boxes_size = param.topK * param.numClasses * 5;
  size_t score_size = param.topK * param.numClasses;
  size_t num_priors = param.topK;
  // std::cout << "score threshold" << param.scoreThreshold << " bg id:" <<
  // param.backgroundLabelId
  //           << " topK:" << param.topK << " numClasses:" << param.numClasses << std::endl;

  // int topk = param.topK > 0 && param.topK <= inputDesc[1].dims.d[1] ? param.topK :
  // inputDesc[1].dims.d[1];
  bool rotated = true;
  bool anchor_free = true;
  pluginStatus_t status =
      nmsInference(stream,
                   batch_size,
                   boxes_size,
                   score_size,
                   shareLocation,
                   param.backgroundLabelId,
                   shareLocation ? param.topK * param.numClasses : param.topK,
                   shareLocation ? 1 : param.numClasses,
                   param.topK,
                   param.keepTopK,
                   param.scoreThreshold,
                   (const float*)mIouThresholdGPU.values,
                   mIouThresholdGPU.count,
                   param.iouThreshold,
                   DataType::kFLOAT,
                   locData,
                   DataType::kFLOAT,
                   confData,
                   nmsedDets,
                   nmsedLabels,
                   nmsedIndex,
                   (uint8_t*)nmsedDets +
                       inputDesc[0].dims.d[0] * 6 * param.keepTopK * sizeof(float),  // workSpace
                   param.isNormalized,
                   false,
                   mClipBoxes,
                   rotated,
                   anchor_free,
                   mMulticlassOutputFlag);
  ASSERT(status == STATUS_SUCCESS);

  // float* host_locData = new float[inputDesc[0].dims.d[0] * param.topK * param.numClasses *
  // 5]; int* host_nmsed_index = new int[200]; cudaMemcpyAsync(host_nmsed_index, nmsedIndex,
  // sizeof(int) * 200, cudaMemcpyDeviceToHost, stream); cudaMemcpyAsync(host_locData,
  // locData, sizeof(float) * inputDesc[0].dims.d[0] * param.topK * param.numClasses * 5,
  //                 cudaMemcpyDeviceToHost, stream);
  // cudaStreamSynchronize(stream);
  // for (size_t i = 0; i < 20; i++) {
  //     if (host_nmsed_index[i] != -1) {
  //         int temp_1 = int(host_nmsed_index[i] / param.topK);
  //         int temp_2 = int(host_nmsed_index[i] % param.topK);
  //         std::cout << "index:" << host_nmsed_index[i] << " temp_1:" << temp_1 << "
  //         temp_2:" << temp_2 << std::endl; printf("loc data:%f, %f, %f, %f, %f\n",
  //         host_locData[5 * (temp_2 * 4 + temp_1)],
  //                host_locData[5 * (temp_2 * 4 + temp_1) + 1], host_locData[5 * (temp_2 * 4
  //                + temp_1) + 2], host_locData[5 * (temp_2 * 4 + temp_1) + 3],
  //                host_locData[5 * (temp_2 * 4 + temp_1) + 4]);
  //     }
  // }

  makeFinalBevNmsOutput(height_preds,
                        dim_preds,
                        static_cast<float*>(nmsedDets),
                        static_cast<int*>(featMapIndex),
                        static_cast<int*>(nmsedIndex),
                        static_cast<float*>(nmsedFinalDetsOutput),
                        static_cast<int*>(nmsedLabels),
                        mMulticlassOutputFlag ? param.keepTopK * param.numClasses : param.keepTopK,
                        param.topK,
                        param.numClasses,
                        shareLocation,
                        static_cast<const float*>(mRescaleFactorGPU.values),
                        mRescaleFactorGPU.count,
                        stream);
  return 0;
}

size_t BatchedBEVNMS::getSerializationSize() const TRT_NOEXCEPT {
  // NMSParameters
  return sizeof(NMSParameters) + sizeof(mClipBoxes) + sizeof(mReturnIndex) + sizeof(mPillarXSize) +
         sizeof(mPillarYSize) + sizeof(mMinXRange) + sizeof(mMinYRange) + sizeof(mStride) +
         2 * MAX_CLASS_NUM * sizeof(float) +
         sizeof(mMulticlassOutputFlag);  // nms_thr + nms_rescale_factor
}

void BatchedBEVNMS::serialize(void* buffer) const TRT_NOEXCEPT {
  serialize_value(&buffer, param);
  serialize_value(&buffer, mClipBoxes);
  serialize_value(&buffer, mReturnIndex);
  serialize_value(&buffer, mPillarXSize);
  serialize_value(&buffer, mPillarYSize);
  serialize_value(&buffer, mMinXRange);
  serialize_value(&buffer, mMinYRange);
  serialize_value(&buffer, mStride);
  serialize_value(&buffer, mIouThreshold);
  serialize_value(&buffer, mRescaleFactor);
  serialize_value(&buffer, mMulticlassOutputFlag);
}

void BatchedBEVNMS::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                    int nbInputs,
                                    const nvinfer1::DynamicPluginTensorDesc* outputs,
                                    int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
}

bool BatchedBEVNMS::supportsFormatCombination(int pos,
                                              const nvinfer1::PluginTensorDesc* ioDesc,
                                              int nbInputs,
                                              int nbOutputs) TRT_NOEXCEPT {
  if (pos == 6) {
    return ioDesc[pos].type == nvinfer1::DataType::kINT32 &&
           ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR;
  }
  return ioDesc[pos].type == nvinfer1::DataType::kFLOAT &&
         ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR;
}

const char* BatchedBEVNMS::getPluginType() const TRT_NOEXCEPT { return NMS_PLUGIN_NAME; }

const char* BatchedBEVNMS::getPluginVersion() const TRT_NOEXCEPT { return NMS_PLUGIN_VERSION; }

IPluginV2DynamicExt* BatchedBEVNMS::clone() const TRT_NOEXCEPT {
  auto* plugin = new BatchedBEVNMS(mLayerName,
                                   param,
                                   mClipBoxes,
                                   mReturnIndex,
                                   mPillarXSize,
                                   mPillarYSize,
                                   mMinXRange,
                                   mMinYRange,
                                   mStride,
                                   mIouThreshold,
                                   mRescaleFactor,
                                   mMulticlassOutputFlag);
  plugin->setPluginNamespace(mNamespace.c_str());
  return plugin;
}

nvinfer1::DataType BatchedBEVNMS::getOutputDataType(int index,
                                                    const nvinfer1::DataType* inputTypes,
                                                    int nbInputs) const TRT_NOEXCEPT {
  ASSERT(index >= 0 && index < this->getNbOutputs());
  if (index == 1) {
    return nvinfer1::DataType::kINT32;
  }
  return inputTypes[0];
}

void BatchedBEVNMS::destroy() TRT_NOEXCEPT {
  CHECK_CUDA(cudaFree(const_cast<void*>(mIouThresholdGPU.values)));
  CHECK_CUDA(cudaFree(const_cast<void*>(mRescaleFactorGPU.values)));
}

BatchedBEVNMSCreator::BatchedBEVNMSCreator() {
  mPluginAttributes.emplace_back(
      PluginField("background_label_id", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("num_classes", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("topk", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("keep_topk", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("score_threshold", nullptr, PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(PluginField("is_normalized", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("clip_boxes", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("return_index", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("pillar_x_size", nullptr, PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("pillar_y_size", nullptr, PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(PluginField("min_x_range", nullptr, PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(PluginField("min_y_range", nullptr, PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(PluginField("stride", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("iou_threshold", nullptr, PluginFieldType::kFLOAT32, MAX_CLASS_NUM));
  mPluginAttributes.emplace_back(
      PluginField("rescale_factor", nullptr, PluginFieldType::kFLOAT32, MAX_CLASS_NUM));
  mPluginAttributes.emplace_back(
      PluginField("is_multiclass_output", nullptr, PluginFieldType::kINT32, 1));

  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* BatchedBEVNMSCreator::getPluginName() const TRT_NOEXCEPT { return NMS_PLUGIN_NAME; }

const char* BatchedBEVNMSCreator::getPluginVersion() const TRT_NOEXCEPT {
  return NMS_PLUGIN_VERSION;
}

IPluginV2Ext* BatchedBEVNMSCreator::createPlugin(const char* name,
                                                 const PluginFieldCollection* fc) TRT_NOEXCEPT {
  const PluginField* fields = fc->fields;
  bool clipBoxes = true;
  bool returnIndex = false;
  bool multiclass_output_flag = false;
  float pillar_x_size;
  float pillar_y_size;
  float min_x_range;
  float min_y_range;
  int stride;
  nvinfer1::plugin::NMSParameters params{};

  std::vector<float> iou_threshold;
  std::vector<float> rescale_factor{1.0};
  params.iouThreshold = -1.;
  params.numClasses = -1;

  for (int i = 0; i < fc->nbFields; ++i) {
    const char* attrName = fields[i].name;
    auto length = fields[i].length;
    if (!strcmp(attrName, "background_label_id")) {
      ASSERT(fields[i].type == PluginFieldType::kINT32);
      params.backgroundLabelId = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "num_classes")) {
      ASSERT(fields[i].type == PluginFieldType::kINT32);
      params.numClasses = *(static_cast<const int*>(fields[i].data));
      ASSERT(params.numClasses <= MAX_CLASS_NUM);
    } else if (!strcmp(attrName, "topk")) {
      ASSERT(fields[i].type == PluginFieldType::kINT32);
      params.topK = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "keep_topk")) {
      ASSERT(fields[i].type == PluginFieldType::kINT32);
      params.keepTopK = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "score_threshold")) {
      ASSERT(fields[i].type == PluginFieldType::kFLOAT32);
      params.scoreThreshold = *(static_cast<const float*>(fields[i].data));
    } /* else if (!strcmp(attrName, "iou_threshold")) {
        ASSERT(fields[i].type == PluginFieldType::kFLOAT32);
        params.iouThreshold = *(static_cast<const float*>(fields[i].data));
    } */
    else if (!strcmp(attrName, "is_normalized")) {
      params.isNormalized = *(static_cast<const bool*>(fields[i].data));
    } else if (!strcmp(attrName, "clip_boxes")) {
      clipBoxes = *(static_cast<const bool*>(fields[i].data));
    } else if (!strcmp(attrName, "return_index")) {
      returnIndex = *(static_cast<const bool*>(fields[i].data));
    } else if (!strcmp(attrName, "pillar_x_size")) {
      pillar_x_size = *(static_cast<const float*>(fields[i].data));
    } else if (!strcmp(attrName, "pillar_y_size")) {
      pillar_y_size = *(static_cast<const float*>(fields[i].data));
    } else if (!strcmp(attrName, "min_x_range")) {
      min_x_range = *(static_cast<const float*>(fields[i].data));
    } else if (!strcmp(attrName, "min_y_range")) {
      min_y_range = *(static_cast<const float*>(fields[i].data));
    } else if (!strcmp(attrName, "stride")) {
      stride = *(static_cast<const int*>(fields[i].data));
    } else if (!strcmp(attrName, "iou_threshold")) {
      // length: actual elements num.
      ASSERT(params.numClasses != -1);  // must init params.numClasses before
      ASSERT(1 == length || params.numClasses == length);
      iou_threshold.resize(length);
      memcpy(iou_threshold.data(),
             static_cast<const float*>(fields[i].data),
             length * sizeof(float));
    } else if (!strcmp(attrName, "rescale_factor")) {
      ASSERT(params.numClasses != -1);  // must init params.numClasses before
      ASSERT(1 == length || params.numClasses == length);
      rescale_factor.resize(length);
      memcpy(rescale_factor.data(),
             static_cast<const float*>(fields[i].data),
             length * sizeof(float));
    } else if (!strcmp(attrName, "is_multiclass_output")) {
      multiclass_output_flag = *(static_cast<const bool*>(fields[i].data));
    } else {
      ASSERT(false);
    }
  }

  BatchedBEVNMS* plugin = new BatchedBEVNMS(name,
                                            params,
                                            clipBoxes,
                                            returnIndex,
                                            pillar_x_size,
                                            pillar_y_size,
                                            min_x_range,
                                            min_y_range,
                                            stride,
                                            iou_threshold,
                                            rescale_factor,
                                            multiclass_output_flag);

  plugin->setPluginNamespace(mNamespace.c_str());
  return plugin;
}

IPluginV2Ext* BatchedBEVNMSCreator::deserializePlugin(const char* name,
                                                      const void* serialData,
                                                      size_t serialLength) TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call NMS::destroy()
  BatchedBEVNMS* plugin = new BatchedBEVNMS(name, serialData, serialLength);
  plugin->setPluginNamespace(mNamespace.c_str());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(BatchedBEVNMSCreator);

}  // namespace linfer
