
#include "customerCropAndResizePlugin.h"

#include <NvInfer.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

// Assuming outputs[0] is a pointer to the data and dataSize is the size of the data in bytes
void saveAsBinaryFile(const void* data, size_t dataSize, const std::string& fileName) {
  std::ofstream outFile(fileName, std::ios::out | std::ios::binary);
  if (outFile) {
    outFile.write(reinterpret_cast<const char*>(data), dataSize);
    outFile.close();
  } else {
    // Handle error
    std::cerr << "Failed to open file for writing: " << fileName << std::endl;
  }
}

// Function to copy data from device to host and save it
void saveDeviceDataAsBinaryFile(const void* deviceData,
                                size_t dataSize,
                                const std::string& fileName) {
  // Allocate host memory
  void* hostData = malloc(dataSize);
  if (!hostData) {
    std::cerr << "Failed to allocate host memory" << std::endl;
    return;
  }

  // Copy data from device to host
  cudaError_t err = cudaMemcpy(hostData, deviceData, dataSize, cudaMemcpyDeviceToHost);
  if (err != cudaSuccess) {
    std::cerr << "Failed to copy data from device to host: " << cudaGetErrorString(err)
              << std::endl;
    free(hostData);
    return;
  }

  // Save data as binary file
  saveAsBinaryFile(hostData, dataSize, fileName);

  // Free host memory
  free(hostData);
}

template <typename T>
void writeToBuffer(uint8_t*& buffer, T const& val) {
  *reinterpret_cast<T*>(buffer) = val;
  buffer += sizeof(T);
}

// Helper function for deserializing plugin
template <typename T>
T readFromBuffer(uint8_t const*& buffer) {
  T val = *reinterpret_cast<const T*>(buffer);
  buffer += sizeof(T);
  return val;
}

namespace nvinfer1 {
namespace plugin {

// Static Fields
PluginFieldCollection CustomerCropAndResizePluginCreator::mFC{};
std::vector<PluginField> CustomerCropAndResizePluginCreator::mPluginAttributes;

CustomerCropAndResizeDynamicPlugin::CustomerCropAndResizeDynamicPlugin(
    int32_t inputWidth,
    int32_t inputHeight,
    int32_t depth,
    int32_t cropWidth,
    int32_t cropHeight,
    const std::vector<float>& means,
    const std::vector<float>& stds,
    const std::vector<float>& extrapolationValue,
    float quantScale,
    int32_t resizeMode,
    int32_t padMode,
    int32_t channelReverse,
    int32_t outputDType,
    int32_t isPackedFp32Input)
    : mInputWidth(inputWidth),
      mInputHeight(inputHeight),
      mDepth(depth),
      mOutputDType(outputDType),
      mCropWidth(cropWidth),
      mCropHeight(cropHeight),
      mResizeMode(resizeMode),
      mPadMode(padMode),
      mChannelReverse(channelReverse),
      mQuantScale(quantScale),
      mInputReinterpretedFp32(isPackedFp32Input) {
  mExtrapolationValue = extrapolationValue;
  mMeans = means;
  mStds = stds;
}

CustomerCropAndResizeDynamicPlugin::CustomerCropAndResizeDynamicPlugin(const void* serialData,
                                                                       size_t serialLength) {
  auto const* d = reinterpret_cast<uint8_t const*>(serialData);
  mInputWidth = readFromBuffer<int32_t>(d);
  mInputHeight = readFromBuffer<int32_t>(d);
  mDepth = readFromBuffer<int32_t>(d);
  mCropWidth = readFromBuffer<int32_t>(d);
  mCropHeight = readFromBuffer<int32_t>(d);
  for (int32_t i = 0; i < 3; i++) {
    mMeans[i] = readFromBuffer<float>(d);
  }
  for (int32_t i = 0; i < 3; i++) {
    mStds[i] = readFromBuffer<float>(d);
  }
  for (int32_t i = 0; i < 3; i++) {
    mExtrapolationValue[i] = readFromBuffer<float>(d);
  }
  mQuantScale = readFromBuffer<float>(d);
  mResizeMode = readFromBuffer<int32_t>(d);
  mPadMode = readFromBuffer<int32_t>(d);
  mChannelReverse = readFromBuffer<int32_t>(d);
  mOutputDType = readFromBuffer<int32_t>(d);
  mInputReinterpretedFp32 = readFromBuffer<int32_t>(d);
  assert(d == reinterpret_cast<uint8_t const*>(serialData) + serialLength);
}

char const* CustomerCropAndResizeDynamicPlugin::getPluginType() const noexcept {
  return kCROP_AND_RESIZE_PLUGIN_NAME;
}

char const* CustomerCropAndResizeDynamicPlugin::getPluginVersion() const noexcept {
  return kCROP_AND_RESIZE_PLUGIN_VERSION;
}

int32_t CustomerCropAndResizeDynamicPlugin::getNbOutputs() const noexcept { return 1; }

DimsExprs CustomerCropAndResizeDynamicPlugin::getOutputDimensions(
    int32_t outputIndex,
    DimsExprs const* inputs,
    int32_t nbInputs,
    IExprBuilder& exprBuilder) noexcept {
  // inputs[0]: Input image (HWC)
  // inputs[1]: ROI boxes
  nvinfer1::DimsExprs outDim;
  outDim.nbDims = 4;
  outDim.d[0] = inputs[1].d[0];           // num_boxes
  outDim.d[1] = exprBuilder.constant(3);  // C (from input HWC)
  outDim.d[2] = exprBuilder.constant(mCropHeight);
  outDim.d[3] = exprBuilder.constant(mCropWidth);
  return outDim;
}

bool CustomerCropAndResizeDynamicPlugin::supportsFormatCombination(int32_t pos,
                                                                   PluginTensorDesc const* inOut,
                                                                   int32_t nbInputs,
                                                                   int32_t nbOutputs) noexcept {
  try {
    // 2 inputs, 1 outputs, so 3 input/output in total
    ASSERT(0 <= pos && pos < 3);
    ASSERT(inOut != nullptr);
    auto const* in = inOut;
    auto const* out = inOut + nbInputs;

    switch (pos) {
      case 0:
        return (in[0].type == DataType::kFLOAT || in[0].type == DataType::kINT8);
      case 1:
        return in[1].type == DataType::kFLOAT;
      case 2: {
        switch (mOutputDType) {
          case 0:
            return (out[0].type == DataType::kFLOAT && out[0].format == PluginFormat::kLINEAR);
          case 1:
            return (out[0].type == DataType::kHALF && out[0].format == PluginFormat::kLINEAR);
          case 2:
            return (out[0].type == DataType::kINT8 && out[0].format == PluginFormat::kLINEAR);

          default:
            return false;
        }
      }
    }
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return false;
}

void CustomerCropAndResizeDynamicPlugin::configurePlugin(DynamicPluginTensorDesc const* in,
                                                         int32_t nbInputs,
                                                         DynamicPluginTensorDesc const* out,
                                                         int32_t nbOutputs) noexcept {}

size_t CustomerCropAndResizeDynamicPlugin::getWorkspaceSize(PluginTensorDesc const* inputs,
                                                            int32_t nbInputs,
                                                            PluginTensorDesc const* outputs,
                                                            int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t CustomerCropAndResizeDynamicPlugin::enqueue(PluginTensorDesc const* inputDesc,
                                                    PluginTensorDesc const* outputDesc,
                                                    void const* const* inputs,
                                                    void* const* outputs,
                                                    void* workspace,
                                                    cudaStream_t stream) noexcept {
  try {
    float extrapolation_values_0 = mExtrapolationValue[0];
    float extrapolation_values_1 = mExtrapolationValue[1];
    float extrapolation_values_2 = mExtrapolationValue[2];
    float means_0 = mMeans[0];
    float means_1 = mMeans[1];
    float means_2 = mMeans[2];
    float stds_0 = mStds[0];
    float stds_1 = mStds[1];
    float stds_2 = mStds[2];

    auto inputdtype = nvinfer1::DataType::kFLOAT;
    if (mInputReinterpretedFp32 == 0) {
      inputdtype = nvinfer1::DataType::kINT8;
    }

    auto outdtype = nvinfer1::DataType::kFLOAT;
    if (mOutputDType == 1) {
      outdtype = nvinfer1::DataType::kHALF;
    } else if (mOutputDType == 2) {
      outdtype = nvinfer1::DataType::kINT8;
    }

    int32_t numBoxes = inputDesc[1].dims.d[0];

    customerCropAndResizeLaunch(stream,
                                inputs[0],
                                inputs[1],
                                outputs[0],
                                numBoxes,
                                mInputHeight,
                                mInputWidth,
                                mCropHeight,
                                mCropWidth,
                                mDepth,
                                extrapolation_values_0,
                                extrapolation_values_1,
                                extrapolation_values_2,
                                means_0,
                                means_1,
                                means_2,
                                stds_0,
                                stds_1,
                                stds_2,
                                mQuantScale,
                                mResizeMode,
                                mPadMode,
                                mChannelReverse,
                                mOutputDType,
                                mInputReinterpretedFp32,
                                inputdtype,
                                outdtype);
    return cudaPeekAtLastError();
  } catch (std::exception const& e) {
    caughtError(e);
    return -1;
  }
}

size_t CustomerCropAndResizeDynamicPlugin::getSerializationSize() const noexcept {
  return sizeof(int32_t) * 11 + sizeof(float) +
         sizeof(float) * (mMeans.size() + mStds.size() + mExtrapolationValue.size());
}

void CustomerCropAndResizeDynamicPlugin::serialize(void* buffer) const noexcept {
  auto* d = reinterpret_cast<uint8_t*>(buffer);
  auto* const start = d;
  writeToBuffer<int32_t>(d, mInputWidth);
  writeToBuffer<int32_t>(d, mInputHeight);
  writeToBuffer<int32_t>(d, mDepth);

  writeToBuffer<int32_t>(d, mCropWidth);
  writeToBuffer<int32_t>(d, mCropHeight);

  for (int32_t i = 0; i < 3; i++) {
    writeToBuffer<float>(d, mMeans[i]);
  }
  for (int32_t i = 0; i < 3; i++) {
    writeToBuffer<float>(d, mStds[i]);
  }
  for (int32_t i = 0; i < 3; i++) {
    writeToBuffer<float>(d, mExtrapolationValue[i]);
  }

  writeToBuffer<float>(d, mQuantScale);
  writeToBuffer<int32_t>(d, mResizeMode);
  writeToBuffer<int32_t>(d, mPadMode);
  writeToBuffer<int32_t>(d, mChannelReverse);
  writeToBuffer<int32_t>(d, mOutputDType);
  writeToBuffer<int32_t>(d, mInputReinterpretedFp32);
  assert(d == start + getSerializationSize());
}

void CustomerCropAndResizeDynamicPlugin::destroy() noexcept {
  // This gets called when the network containing plugin is destroyed
  delete this;
}

int CustomerCropAndResizeDynamicPlugin::initialize() noexcept { return 0; }

void CustomerCropAndResizeDynamicPlugin::terminate() noexcept {}

void CustomerCropAndResizeDynamicPlugin::setPluginNamespace(char const* libNamespace) noexcept {
  try {
    mNamespace = libNamespace;
  } catch (std::exception const& e) {
    caughtError(e);
  }
}

char const* CustomerCropAndResizeDynamicPlugin::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

DataType CustomerCropAndResizeDynamicPlugin::getOutputDataType(int32_t index,
                                                               nvinfer1::DataType const* inputTypes,
                                                               int32_t nbInputs) const noexcept {
  // according mOutputDType to return output data type
  switch (mOutputDType) {
    case 0:
      return nvinfer1::DataType::kFLOAT;  // FP32
    case 1:
      return nvinfer1::DataType::kHALF;  // FP16
    case 2:
      return nvinfer1::DataType::kINT8;  // INT8
    default:
      std::cerr << "FATAL ERROR: Invalid output_datatype value: " << mOutputDType << std::endl;
      std::terminate();
  }
}

IPluginV2DynamicExt* CustomerCropAndResizeDynamicPlugin::clone() const noexcept {
  try {
    auto* plugin = new CustomerCropAndResizeDynamicPlugin(mInputWidth,
                                                          mInputHeight,
                                                          mDepth,
                                                          mCropWidth,
                                                          mCropHeight,
                                                          mMeans,
                                                          mStds,
                                                          mExtrapolationValue,
                                                          mQuantScale,
                                                          mResizeMode,
                                                          mPadMode,
                                                          mChannelReverse,
                                                          mOutputDType,
                                                          mInputReinterpretedFp32);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

// Plugin Creator
CustomerCropAndResizePluginCreator::CustomerCropAndResizePluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(PluginField("input_width", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("input_height", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("depth", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("crop_width", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("crop_height", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("means", nullptr, PluginFieldType::kFLOAT32, 3));
  mPluginAttributes.emplace_back(PluginField("stds", nullptr, PluginFieldType::kFLOAT32, 3));
  mPluginAttributes.emplace_back(
      PluginField("extrapolation_value", nullptr, PluginFieldType::kFLOAT32, 3));
  mPluginAttributes.emplace_back(PluginField("quant_scale", nullptr, PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(PluginField("resize_mode", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("pad_mode", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("channel_reverse", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(PluginField("output_dtype", nullptr, PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("input_reinterpreted_fp32", nullptr, PluginFieldType::kINT32, 1));

  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

IPluginV2DynamicExt* CustomerCropAndResizePluginCreator::createPlugin(
    char const* name,
    PluginFieldCollection const* fc) noexcept {
  try {
    int32_t inputWidth = 0;
    int32_t inputHeight = 0;
    int32_t depth = 0;
    int32_t cropWidth = 0;
    int32_t cropHeight = 0;
    std::vector<float> means(3, 0.0f);
    std::vector<float> stds(3, 1.0f);
    std::vector<float> extrapolationValue(3, 0.0f);
    float quantScale = 1.0f;
    int32_t resizeMode = 0;
    int32_t padMode = 0;
    int32_t channelReverse = 0;
    int32_t outputDtype = 0;
    int32_t isPackedFp32Input = 0;

    for (int32_t i = 0; i < fc->nbFields; i++) {
      auto field = fc->fields[i];
      if (!strcmp(field.name, "input_width"))
        inputWidth = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "input_height"))
        inputHeight = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "depth"))
        depth = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "crop_width"))
        cropWidth = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "crop_height"))
        cropHeight = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "means"))
        std::copy_n(static_cast<float const*>(field.data), 3, means.begin());
      else if (!strcmp(field.name, "stds"))
        std::copy_n(static_cast<float const*>(field.data), 3, stds.begin());
      else if (!strcmp(field.name, "extrapolation_value"))
        std::copy_n(static_cast<float const*>(field.data), 3, extrapolationValue.begin());
      else if (!strcmp(field.name, "quant_scale"))
        quantScale = *static_cast<float const*>(field.data);
      else if (!strcmp(field.name, "resize_mode"))
        resizeMode = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "pad_mode"))
        padMode = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "channel_reverse"))
        channelReverse = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "output_dtype"))
        outputDtype = *static_cast<int32_t const*>(field.data);
      else if (!strcmp(field.name, "input_reinterpreted_fp32"))
        isPackedFp32Input = *static_cast<int32_t const*>(field.data);
    }

    IPluginV2DynamicExt* plugin = new CustomerCropAndResizeDynamicPlugin(inputWidth,
                                                                         inputHeight,
                                                                         depth,
                                                                         cropWidth,
                                                                         cropHeight,
                                                                         means,
                                                                         stds,
                                                                         extrapolationValue,
                                                                         quantScale,
                                                                         resizeMode,
                                                                         padMode,
                                                                         channelReverse,
                                                                         outputDtype,
                                                                         isPackedFp32Input);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

IPluginV2DynamicExt* CustomerCropAndResizePluginCreator::deserializePlugin(
    char const* name,
    void const* serialData,
    size_t serialLength) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new CustomerCropAndResizeDynamicPlugin(serialData, serialLength);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

const char* CustomerCropAndResizePluginCreator::getPluginName() const noexcept {
  return kCROP_AND_RESIZE_PLUGIN_NAME;
}

const char* CustomerCropAndResizePluginCreator::getPluginVersion() const noexcept {
  return kCROP_AND_RESIZE_PLUGIN_VERSION;
}

const PluginFieldCollection* CustomerCropAndResizePluginCreator::getFieldNames() noexcept {
  return &mFC;
}

void CustomerCropAndResizePluginCreator::setPluginNamespace(const char* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

const char* CustomerCropAndResizePluginCreator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(CustomerCropAndResizePluginCreator);

}  // namespace plugin
}  // namespace nvinfer1
