#ifndef TRT_COMMON_H
#define TRT_COMMON_H

#include <cuda_runtime.h>

#include <cassert>
#include <iostream>
#include <memory>
#include <string>

#define CUDA_MEM_ALIGN 256

// 错误处理宏
#define CHECK_CUDA(call)                                                                     \
  do {                                                                                       \
    cudaError_t status = call;                                                               \
    if (status != cudaSuccess) {                                                             \
      std::cerr << "CUDA error: " << cudaGetErrorString(status) << " at " << __FILE__ << ":" \
                << __LINE__ << std::endl;                                                    \
      return -1;                                                                             \
    }                                                                                        \
  } while (0)

// 错误处理辅助函数
inline void caughtError(const std::exception& e) {
#ifdef ENABLE_TENSORRT_LOGGING
  glogError << e.what() << std::endl;
#endif
}

#endif  // TRT_COMMON_H