#ifndef CUSTOMER_CROP_AND_RESIZE_KERNEL_H
#define CUSTOMER_CROP_AND_RESIZE_KERNEL_H

// CUDA运行时
#include <cuda_fp16.h>
#include <cuda_runtime.h>

// 标准库
#include <cstdint>
#include <vector>

// TensorRT数据类型
#include "NvInferRuntimeCommon.h"

namespace nvinfer1 {
namespace plugin {

inline void caughtError(const std::exception& e) {
#ifdef ENABLE_TENSORRT_LOGGING
  glogError << e.what() << std::endl;
#endif
}

#ifdef __CUDA_ARCH__
#define ASSERT(condition) __assert_fail(condition, __FILE__, __LINE__, __func__)
#else
#define ASSERT(condition) assert(condition)
#endif

// declare kernel function
int32_t customerCropAndResizeLaunch(cudaStream_t stream,
                                    const void* image,
                                    const void* rois,
                                    void* output,
                                    int num_boxes,
                                    int input_height,
                                    int input_width,
                                    int crop_height,
                                    int crop_width,
                                    int depth,
                                    float extrapolation_values_0,
                                    float extrapolation_values_1,
                                    float extrapolation_values_2,
                                    float means_0,
                                    float means_1,
                                    float means_2,
                                    float stds_0,
                                    float stds_1,
                                    float stds_2,
                                    float quant_scale,
                                    int resize_mode,
                                    int pad_mode,
                                    int channel_reverse,
                                    int output_dtype,
                                    int input_reinterpreted_fp32,
                                    nvinfer1::DataType input_type,
                                    nvinfer1::DataType output_type);

}  // namespace plugin
}  // namespace nvinfer1

#endif  // CUSTOMER_CROP_AND_RESIZE_KERNEL_H
