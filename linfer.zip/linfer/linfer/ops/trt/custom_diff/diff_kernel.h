
#ifndef DIFF_KERNEL_H
#define DIFF_KERNEL_H
#include <cuda_runtime.h>

void diff(cudaStream_t stream, float* dest, float* input, int rows, int cols);

#endif  // DIFF_KERNEL_H
