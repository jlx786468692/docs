#include <stdio.h>
#include <stdlib.h>

#include <cmath>

template <typename T>
__global__ void compute_diff(T* dest, T* input, int rows, int cols) {
  const int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= rows * cols) {
    return;
  }

  if (idx < (rows - 1) * cols) {
    dest[idx] = input[idx + cols] - input[idx];
  } else {
    dest[idx] = input[idx] - input[idx - cols];
  }
}

void diff(cudaStream_t stream, float* dest, float* input, int rows, int cols) {
  int block_dim = 256;
  int grid_dim = (rows * cols + block_dim - 1) / block_dim;

  compute_diff<<<grid_dim, block_dim, 0, stream>>>(dest, input, rows, cols);
}