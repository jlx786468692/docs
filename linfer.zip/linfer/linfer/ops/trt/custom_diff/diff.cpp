// Copyright (c) OpenMMLab. All rights reserved.
#include "diff.hpp"

#include <assert.h>

#include <chrono>

#include "diff_kernel.h"
#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/util/log.h"

namespace linfer {
namespace {
static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"LinferCustomDiff"};
}  // namespace

CustomDiff::CustomDiff(const std::string& name) : TRTPluginBase(name) {}

nvinfer1::IPluginV2DynamicExt* CustomDiff::clone() const TRT_NOEXCEPT {
  CustomDiff* plugin = new CustomDiff(mLayerName);
  plugin->setPluginNamespace(getPluginNamespace());

  return plugin;
}

nvinfer1::DimsExprs CustomDiff::getOutputDimensions(int outputIndex,
                                                    const nvinfer1::DimsExprs* inputs,
                                                    int nbInputs,
                                                    nvinfer1::IExprBuilder& exprBuilder)
    TRT_NOEXCEPT {
  return inputs[0];
}

bool CustomDiff::supportsFormatCombination(int pos,
                                           const nvinfer1::PluginTensorDesc* ioDesc,
                                           int nbInputs,
                                           int nbOutputs) TRT_NOEXCEPT {
  if (pos == 0) {
    return ((ioDesc[pos].type == nvinfer1::DataType::kFLOAT) &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else if (pos == 1) {
    return (ioDesc[pos].type == ioDesc[0].type &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  }
  return false;
}

void CustomDiff::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                 int nbInputs,
                                 const nvinfer1::DynamicPluginTensorDesc* outputs,
                                 int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
  if (nbInputs != 1 || nbOutputs != 1) {
    LERROR_FMT(
        "Invalid number of inputs or outputs: nbInputs=%d, nbOutputs=%d. Expected 1 for both.",
        nbInputs,
        nbOutputs);
    return;
  }

  if (inputs == nullptr || inputs[0].desc.dims.nbDims <= 0) {
    LERROR_FMT("Invalid input tensor descriptor.");
    return;
  }

  const auto& input_dims = inputs[0].desc.dims;
  if (input_dims.nbDims == 3) {
    if (input_dims.d[0] != 1) {
      LERROR_FMT("The first dim must be 1 for 3D input, but got %d.", input_dims.d[0]);
      return;
    }
    rows_ = input_dims.d[1];
    cols_ = input_dims.d[2];
  } else if (input_dims.nbDims == 2) {
    rows_ = input_dims.d[0];
    cols_ = input_dims.d[1];
  } else {
    LERROR_FMT("Input dimensions must be 2 or 3, but got %d.", input_dims.nbDims);
    return;
  }
}

size_t CustomDiff::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                    int nbInputs,
                                    const nvinfer1::PluginTensorDesc* outputs,
                                    int nbOutputs) const TRT_NOEXCEPT {
  return 0;
}

int CustomDiff::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                        const nvinfer1::PluginTensorDesc* outputDesc,
                        const void* const* inputs,
                        void* const* outputs,
                        void* workSpace,
                        cudaStream_t stream) TRT_NOEXCEPT {
  diff(stream, (float*)outputs[0], (float*)inputs[0], rows_, cols_);
  return 0;
}

nvinfer1::DataType CustomDiff::getOutputDataType(int index,
                                                 const nvinfer1::DataType* inputTypes,
                                                 int nbInputs) const TRT_NOEXCEPT {
  return nvinfer1::DataType::kFLOAT;
}

// IPluginV2 Methods
const char* CustomDiff::getPluginType() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* CustomDiff::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

int CustomDiff::getNbOutputs() const TRT_NOEXCEPT { return 1; }

size_t CustomDiff::getSerializationSize() const TRT_NOEXCEPT { return 0; }

void CustomDiff::serialize(void* buffer) const TRT_NOEXCEPT { return; }

////////////////////// creator /////////////////////////////

CustomDiffCreator::CustomDiffCreator() {
  mPluginAttributes.clear();
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* CustomDiffCreator::getPluginName() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* CustomDiffCreator::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

nvinfer1::IPluginV2* CustomDiffCreator::createPlugin(const char* name,
                                                     const nvinfer1::PluginFieldCollection* fc)
    TRT_NOEXCEPT {
  CustomDiff* plugin = new CustomDiff(name);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

nvinfer1::IPluginV2* CustomDiffCreator::deserializePlugin(const char* name,
                                                          const void* serialData,
                                                          size_t serialLength) TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call FCPluginDynamic::destroy()
  auto plugin = new CustomDiff(name);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(CustomDiffCreator);
}  // namespace linfer
