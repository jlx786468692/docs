// Copyright (c) OpenMMLab. All rights reserved.
#include "select_one.hpp"

#include <assert.h>

#include <chrono>

#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "select_one_kernel.h"

namespace linfer {
namespace {
static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"LinferSelectOne"};
}  // namespace

SelectOne::SelectOne(const std::string& name, int select_num)
    : TRTPluginBase(name), select_num_(select_num) {}

SelectOne::SelectOne(const std::string name, const void* data, size_t length)
    : TRTPluginBase(name) {
  deserialize_value(&data, &length, &select_num_);
}

nvinfer1::IPluginV2DynamicExt* SelectOne::clone() const TRT_NOEXCEPT {
  SelectOne* plugin = new SelectOne(mLayerName, select_num_);
  plugin->setPluginNamespace(getPluginNamespace());

  return plugin;
}

nvinfer1::DimsExprs SelectOne::getOutputDimensions(int outputIndex,
                                                   const nvinfer1::DimsExprs* inputs,
                                                   int nbInputs,
                                                   nvinfer1::IExprBuilder& exprBuilder)
    TRT_NOEXCEPT {
  nvinfer1::DimsExprs ret;
  ret.nbDims = 1;
  ret.d[0] = exprBuilder.constant(select_num_);

  return ret;
}

bool SelectOne::supportsFormatCombination(int pos,
                                          const nvinfer1::PluginTensorDesc* ioDesc,
                                          int nbInputs,
                                          int nbOutputs) TRT_NOEXCEPT {
  if (pos == 0) {
    return ((ioDesc[pos].type == nvinfer1::DataType::kFLOAT ||
             ioDesc[pos].type == nvinfer1::DataType::kINT32) &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else if (pos == 1) {
    return (ioDesc[pos].type == ioDesc[0].type &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else {
    return (ioDesc[pos].type == nvinfer1::DataType::kINT32 &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  }
}

void SelectOne::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                int nbInputs,
                                const nvinfer1::DynamicPluginTensorDesc* outputs,
                                int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
  ASSERT(nbOutputs == 2);
}

size_t SelectOne::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                   int nbInputs,
                                   const nvinfer1::PluginTensorDesc* outputs,
                                   int nbOutputs) const TRT_NOEXCEPT {
  return 0;
}

int SelectOne::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                       const nvinfer1::PluginTensorDesc* outputDesc,
                       const void* const* inputs,
                       void* const* outputs,
                       void* workSpace,
                       cudaStream_t stream) TRT_NOEXCEPT {
  int select_num = select_num_;
  int input_size = inputDesc[0].dims.d[0];
  auto data_type = inputDesc[0].type;

  switch (data_type) {
    case nvinfer1::DataType::kFLOAT:
      launch_select_one(stream,
                        (float*)outputs[0],
                        (int*)outputs[1],
                        (const float*)inputs[0],
                        input_size,
                        select_num);
      break;

    case nvinfer1::DataType::kINT32:
      launch_select_one(stream,
                        (int*)outputs[0],
                        (int*)outputs[1],
                        (const int*)inputs[0],
                        input_size,
                        select_num);
      break;
    default:
      return 1;
      break;
  }
  return 0;
}

nvinfer1::DataType SelectOne::getOutputDataType(int index,
                                                const nvinfer1::DataType* inputTypes,
                                                int nbInputs) const TRT_NOEXCEPT {
  if (index == 0) {
    return inputTypes[0];
  } else {
    return nvinfer1::DataType::kINT32;
  }
}

// IPluginV2 Methods
const char* SelectOne::getPluginType() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* SelectOne::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

int SelectOne::getNbOutputs() const TRT_NOEXCEPT { return 2; }

size_t SelectOne::getSerializationSize() const TRT_NOEXCEPT { return sizeof(int); }

void SelectOne::serialize(void* buffer) const TRT_NOEXCEPT {
  serialize_value(&buffer, select_num_);
}

////////////////////// creator /////////////////////////////

SelectOneCreator::SelectOneCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("select_num", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* SelectOneCreator::getPluginName() const TRT_NOEXCEPT { return PLUGIN_NAME; }

const char* SelectOneCreator::getPluginVersion() const TRT_NOEXCEPT { return PLUGIN_VERSION; }

nvinfer1::IPluginV2* SelectOneCreator::createPlugin(const char* name,
                                                    const nvinfer1::PluginFieldCollection* fc)
    TRT_NOEXCEPT {
  int select_num;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("select_num") == 0) {
      select_num = *static_cast<const int32_t*>(field_data);
    }
  }

  SelectOne* plugin = new SelectOne(name, select_num);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

nvinfer1::IPluginV2* SelectOneCreator::deserializePlugin(const char* name,
                                                         const void* serialData,
                                                         size_t serialLength) TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call FCPluginDynamic::destroy()
  auto plugin = new SelectOne(name, serialData, serialLength);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(SelectOneCreator);
}  // namespace linfer
