#include "select_one_v3.h"

#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "select_one_kernel.h"

using linfer::ops::trt::SelectOnePluginV3Creator;
REGISTER_TENSORRT_PLUGIN(SelectOnePluginV3Creator);

namespace linfer {
namespace ops {
namespace trt {

constexpr char const* SELECT_ONE_PLUGINV3_VERSION{"1"};
constexpr char const* SELECT_ONE_PLUGINV3_NAME{"LinferSelectOneV3"};

nvinfer1::PluginFieldCollection SelectOnePluginV3Creator::mFC{};
std::vector<nvinfer1::PluginField> SelectOnePluginV3Creator::mPluginAttributes;

SelectOnePluginV3::SelectOnePluginV3(int select_num) : select_num_(select_num) {}

nvinfer1::IPluginCapability* SelectOnePluginV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* SelectOnePluginV3::getPluginName() const noexcept { return SELECT_ONE_PLUGINV3_NAME; }

char const* SelectOnePluginV3::getPluginVersion() const noexcept {
  return SELECT_ONE_PLUGINV3_VERSION;
}

int32_t SelectOnePluginV3::getNbOutputs() const noexcept { return 2; }

void SelectOnePluginV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* SelectOnePluginV3::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

nvinfer1::IPluginV3* SelectOnePluginV3::clone() noexcept {
  try {
    auto* plugin = new SelectOnePluginV3(select_num_);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t SelectOnePluginV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                              int32_t nbOutputs,
                                              nvinfer1::DataType const* inputTypes,
                                              int32_t nbInputs) const noexcept {
  try {
    // First output has same type as input, second output is INT32 for indices
    outputTypes[0] = inputTypes[0];
    outputTypes[1] = nvinfer1::DataType::kINT32;
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t SelectOnePluginV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::DimsExprs const* shapeInputs,
                                           int32_t nbShapeInputs,
                                           nvinfer1::DimsExprs* outputs,
                                           int32_t nbOutputs,
                                           nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    // Both outputs have shape [select_num_]
    for (int i = 0; i < nbOutputs; i++) {
      outputs[i].nbDims = 1;
      outputs[i].d[0] = exprBuilder.constant(select_num_);
    }
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool SelectOnePluginV3::supportsFormatCombination(int32_t pos,
                                                  nvinfer1::DynamicPluginTensorDesc const* inOut,
                                                  int32_t nbInputs,
                                                  int32_t nbOutputs) noexcept {
  try {
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;

    if (pos == 0) {  // Input
      return (
          (desc.type == nvinfer1::DataType::kFLOAT || desc.type == nvinfer1::DataType::kINT32) &&
          desc.format == nvinfer1::TensorFormat::kLINEAR);
    } else if (pos == 1) {  // First output (values)
      return (desc.type == inOut[0].desc.type && desc.format == nvinfer1::TensorFormat::kLINEAR);
    } else if (pos == 2) {  // Second output (indices)
      return (desc.type == nvinfer1::DataType::kINT32 &&
              desc.format == nvinfer1::TensorFormat::kLINEAR);
    }

    return false;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t SelectOnePluginV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                           int32_t nbInputs,
                                           nvinfer1::DynamicPluginTensorDesc const* out,
                                           int32_t nbOutputs) noexcept {
  try {
    // Validate input arguments
    PLUGIN_ASSERT(nbInputs == 1);
    PLUGIN_ASSERT(nbOutputs == 2);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const* SelectOnePluginV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("select_num", &select_num_, nvinfer1::PluginFieldType::kINT32, 1));

    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t SelectOnePluginV3::getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                                           int32_t nbInputs,
                                           nvinfer1::DynamicPluginTensorDesc const* outputs,
                                           int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t SelectOnePluginV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                         int32_t nbInputs,
                                         nvinfer1::PluginTensorDesc const* outputs,
                                         int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* SelectOnePluginV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t SelectOnePluginV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                                   nvinfer1::PluginTensorDesc const* outputDesc,
                                   void const* const* inputs,
                                   void* const* outputs,
                                   void* workspace,
                                   cudaStream_t stream) noexcept {
  try {
    int input_size = inputDesc[0].dims.d[0];
    auto data_type = inputDesc[0].type;

    switch (data_type) {
      case nvinfer1::DataType::kFLOAT:
        launch_select_one(stream,
                          (float*)outputs[0],
                          (int*)outputs[1],
                          (const float*)inputs[0],
                          input_size,
                          select_num_);
        break;

      case nvinfer1::DataType::kINT32:
        launch_select_one(stream,
                          (int*)outputs[0],
                          (int*)outputs[1],
                          (const int*)inputs[0],
                          input_size,
                          select_num_);
        break;
      default:
        return 1;
    }
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

// Plugin Creator Implementation
SelectOnePluginV3Creator::SelectOnePluginV3Creator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("select_num", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* SelectOnePluginV3Creator::getPluginName() const noexcept {
  return SELECT_ONE_PLUGINV3_NAME;
}

char const* SelectOnePluginV3Creator::getPluginVersion() const noexcept {
  return SELECT_ONE_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const* SelectOnePluginV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* SelectOnePluginV3Creator::createPlugin(
    char const* name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  try {
    int select_num = 0;

    for (int32_t i = 0; i < fc->nbFields; i++) {
      std::string field_name(fc->fields[i].name);
      auto field_data = fc->fields[i].data;
      auto field_len = fc->fields[i].length;

      if (field_name.compare("select_num") == 0) {
        select_num = *static_cast<const int32_t*>(field_data);
      }
    }

    PLUGIN_ASSERT(select_num > 0);

    auto* plugin = new SelectOnePluginV3(select_num);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void SelectOnePluginV3Creator::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* SelectOnePluginV3Creator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer