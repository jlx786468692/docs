#ifndef SELECT_ONE_KERNEL_H
#define SELECT_ONE_KERNEL_H

#include <cuda_runtime.h>

void launch_select_one(cudaStream_t stream,
                       float* output_value,
                       int* output_indice,
                       const float* input,
                       int input_size,
                       int select_num);

void launch_select_one(cudaStream_t stream,
                       int* output_value,
                       int* output_indice,
                       const int* input,
                       int input_size,
                       int select_num);

#endif  // SELECT_ONE_KERNEL_H
