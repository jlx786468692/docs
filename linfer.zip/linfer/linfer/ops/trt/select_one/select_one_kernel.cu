#include <stdio.h>
#include <stdlib.h>

template <typename T>
__global__ void select_one_kernel(T* output_value,
                                  int* output_indice,
                                  const T* input,
                                  int input_size,
                                  int select_num,
                                  int num_thread) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_thread) {
    return;
  }
  extern __shared__ int share_idx[];
  int* one_idx = &share_idx[0];
  int* zero_idx = &share_idx[input_size];
  T one = 1;
  T zero = 0;

  int num_one = 0;
  int num_zero = 0;

  for (int i = 0; i < input_size; i++) {
    if (input[i] == one) {
      one_idx[num_one] = i;
      num_one += 1;
    } else {
      zero_idx[num_zero] = i;
      num_zero += 1;
    }
  }

  if (num_one >= select_num) {
    for (int i = 0; i < select_num; i++) {
      output_indice[i] = one_idx[i];
      output_value[i] = one;
    }
  } else {
    int pad_zero = select_num - num_one;
    for (int i = 0; i < num_one; i++) {
      output_indice[i] = one_idx[i];
      output_value[i] = one;
    }
    for (int i = 0; i < pad_zero; i++) {
      output_indice[num_one + i] = zero_idx[i];
      output_value[num_one + i] = zero;
    }
  }
}

void launch_select_one(cudaStream_t stream,
                       float* output_value,
                       int* output_indice,
                       const float* input,
                       int input_size,
                       int select_num) {
  int block_size = 32;
  int grid_size = 1;
  int num_thread = 1;
  size_t smem_size = 2 * input_size * sizeof(int);
  select_one_kernel<<<grid_size, block_size, smem_size, stream>>>(output_value,
                                                                  output_indice,
                                                                  input,
                                                                  input_size,
                                                                  select_num,
                                                                  num_thread);
}

void launch_select_one(cudaStream_t stream,
                       int* output_value,
                       int* output_indice,
                       const int* input,
                       int input_size,
                       int select_num) {
  int block_size = 32;
  int grid_size = 1;
  int num_thread = 1;
  size_t smem_size = 2 * input_size * sizeof(int);
  select_one_kernel<<<grid_size, block_size, smem_size, stream>>>(output_value,
                                                                  output_indice,
                                                                  input,
                                                                  input_size,
                                                                  select_num,
                                                                  num_thread);
}