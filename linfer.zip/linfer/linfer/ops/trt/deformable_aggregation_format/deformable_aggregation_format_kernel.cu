#include <cuda_fp16.h>
#include <stdio.h>
#include <stdlib.h>

#include "linfer/ops/trt/common/common_types.h"

__global__ void deformable_aggregation_format_float_kernel(const int num_kernels,
                                                           float* output,
                                                           const float* mc_ms_feat0,
                                                           const float* mc_ms_feat1,
                                                           const float* sample_location,
                                                           const float* weights,
                                                           int num_cams,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int h_0,
                                                           int w_0,
                                                           int h_1,
                                                           int w_1,
                                                           int hw_stride0,
                                                           int hw_stride1,
                                                           int pts_stride,
                                                           int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 2;
  int hw[]{h_0, w_0, h_1, w_1};
  int hw_strides[]{hw_stride0, hw_stride1};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  float* share_weights = reinterpret_cast<float*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const float* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value = 0.0f;
  const float* feat[] = {mc_ms_feat0, mc_ms_feat1};

  int channel_index = idx - anchor_index * num_embeds;
  int channel_offset = channel_index / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const float* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index;
      const float* value_ptr = reinterpret_cast<const float*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          float weight = *(share_weights + base_weight_offset);

          float val = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val = fma(interpolate_weights.x, value_ptr[pos.x], val);
          }

          if (interpolate_weights.y > 0.0f) {
            val = fma(interpolate_weights.y, value_ptr[pos.y], val);
          }

          if (interpolate_weights.z > 0.0f) {
            val = fma(interpolate_weights.z, value_ptr[pos.z], val);
          }

          if (interpolate_weights.w > 0.0f) {
            val = fma(interpolate_weights.w, value_ptr[pos.w], val);
          }
          ret_value = fma(val, weight, ret_value);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_half_kernel(const int num_kernels,
                                                          float* output,
                                                          const __half* mc_ms_feat0,
                                                          const __half* mc_ms_feat1,
                                                          const float* sample_location,
                                                          const __half* weights,
                                                          int num_cams,
                                                          int num_embeds,
                                                          int num_scale,
                                                          int num_anchors,
                                                          int num_pts,
                                                          int num_groups,
                                                          int h_0,
                                                          int w_0,
                                                          int h_1,
                                                          int w_1,
                                                          int hw_stride0,
                                                          int hw_stride1,
                                                          int pts_stride,
                                                          int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 2;
  int hw[]{h_0, w_0, h_1, w_1};
  int hw_strides[]{hw_stride0, hw_stride1};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  __half* share_weights = reinterpret_cast<__half*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const __half* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value = 0.0f;
  const __half* feat[] = {mc_ms_feat0, mc_ms_feat1};

  int channel_index = idx - anchor_index * num_embeds;
  int channel_offset = channel_index / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const __half* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index;
      const __half* value_ptr = reinterpret_cast<const __half*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          float weight = *(share_weights + base_weight_offset);

          float val = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val = fma(interpolate_weights.x, __half2float(value_ptr[pos.x]), val);
          }

          if (interpolate_weights.y > 0.0f) {
            val = fma(interpolate_weights.y, __half2float(value_ptr[pos.y]), val);
          }

          if (interpolate_weights.z > 0.0f) {
            val = fma(interpolate_weights.z, __half2float(value_ptr[pos.z]), val);
          }

          if (interpolate_weights.w > 0.0f) {
            val = fma(interpolate_weights.w, __half2float(value_ptr[pos.w]), val);
          }
          ret_value = fma(val, __half2float(weight), ret_value);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_half2_kernel(const int num_kernels,
                                                           float* output,
                                                           const __half* mc_ms_feat0,
                                                           const __half* mc_ms_feat1,
                                                           const float* sample_location,
                                                           const __half* weights,
                                                           int num_cams,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int h_0,
                                                           int w_0,
                                                           int h_1,
                                                           int w_1,
                                                           int hw_stride0,
                                                           int hw_stride1,
                                                           int pts_stride,
                                                           int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 2;
  int hw[]{h_0, w_0, h_1, w_1};
  int hw_strides[]{hw_stride0, hw_stride1};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  __half* share_weights = reinterpret_cast<__half*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const __half* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value1 = 0.0f;
  float ret_value2 = 0.0f;
  const __half* feat[] = {mc_ms_feat0, mc_ms_feat1};

  int channel_index = idx - anchor_index * num_embeds / 2;
  int channel_offset = channel_index * 2 / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const __half* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index * 2;
      const __half* value_ptr = reinterpret_cast<const __half*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          __half weight = *(share_weights + base_weight_offset);

          float val1 = 0.0f, val2 = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val1 = fma(interpolate_weights.x, __half2float(value_ptr[pos.x]), val1);
            val2 = fma(interpolate_weights.x, __half2float(value_ptr[pos.x + 1]), val2);
          }

          if (interpolate_weights.y > 0.0f) {
            val1 = fma(interpolate_weights.y, __half2float(value_ptr[pos.y]), val1);
            val2 = fma(interpolate_weights.y, __half2float(value_ptr[pos.y + 1]), val2);
          }

          if (interpolate_weights.z > 0.0f) {
            val1 = fma(interpolate_weights.z, __half2float(value_ptr[pos.z]), val1);
            val2 = fma(interpolate_weights.z, __half2float(value_ptr[pos.z + 1]), val2);
          }

          if (interpolate_weights.w > 0.0f) {
            val1 = fma(interpolate_weights.w, __half2float(value_ptr[pos.w]), val1);
            val2 = fma(interpolate_weights.w, __half2float(value_ptr[pos.w + 1]), val2);
          }

          ret_value1 = fma(val1, __half2float(weight), ret_value1);
          ret_value2 = fma(val2, __half2float(weight), ret_value2);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index * 2] = ret_value1;
  output[anchor_index * num_embeds + channel_index * 2 + 1] = ret_value2;
}

__global__ void deformable_aggregation_format_float_kernel(const int num_kernels,
                                                           float* output,
                                                           const float* mc_ms_feat0,
                                                           const float* mc_ms_feat1,
                                                           const float* mc_ms_feat2,
                                                           const float* sample_location,
                                                           const float* weights,
                                                           int num_cams,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int h_0,
                                                           int w_0,
                                                           int h_1,
                                                           int w_1,
                                                           int h_2,
                                                           int w_2,
                                                           int hw_stride0,
                                                           int hw_stride1,
                                                           int hw_stride2,
                                                           int pts_stride,
                                                           int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 3;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  float* share_weights = reinterpret_cast<float*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const float* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;
      interpolate_weight[index] = {hh, hw, lh, lw};

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      int pos1 = -1, pos2 = -1, pos3 = -1, pos4 = -1;

      if (h_low >= 0 && w_low >= 0) {
        pos1 = h_low_ptr_offset + w_low_ptr_offset;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        pos2 = h_low_ptr_offset + w_high_ptr_offset;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        pos3 = h_high_ptr_offset + w_low_ptr_offset;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        pos4 = h_high_ptr_offset + w_high_ptr_offset;
      }
      interpolate_pos[index] = {pos1, pos2, pos3, pos4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value = 0.0f;
  const float* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2};

  int channel_index = idx - anchor_index * num_embeds;
  int channel_offset = channel_index / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const float* bottom_data = feat[k];
    int hw_stride = hw_strides[k];
    float level_value = 0.0f;

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index;
      const float* value_ptr = reinterpret_cast<const float*>(bottom_data + value_offset);
      float cam_value = 0.0f;

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          float weight = *(share_weights + base_weight_offset);

          float val = 0.0f;
          if (pos.x >= 0) {
            val = __fmaf_rn(interpolate_weights.x,
                            __fmaf_rn(interpolate_weights.y, value_ptr[pos.x], 0),
                            val);
          }

          if (pos.y >= 0) {
            val = __fmaf_rn(interpolate_weights.x,
                            __fmaf_rn(interpolate_weights.w, value_ptr[pos.y], 0),
                            val);
          }

          if (pos.z >= 0) {
            val = __fmaf_rn(interpolate_weights.z,
                            __fmaf_rn(interpolate_weights.y, value_ptr[pos.z], 0),
                            val);
          }

          if (pos.w >= 0) {
            val = __fmaf_rn(interpolate_weights.z,
                            __fmaf_rn(interpolate_weights.w, value_ptr[pos.w], 0),
                            val);
          }
          cam_value = __fmaf_rn(val, weight, cam_value);
        }
      }
      level_value += cam_value;
    }
    ret_value += level_value;
  }

  output[anchor_index * num_embeds + channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_float2_kernel(const int num_kernels,
                                                            float* output,
                                                            const float* mc_ms_feat0,
                                                            const float* mc_ms_feat1,
                                                            const float* mc_ms_feat2,
                                                            const float* sample_location,
                                                            const float* weights,
                                                            int num_cams,
                                                            int num_embeds,
                                                            int num_scale,
                                                            int num_anchors,
                                                            int num_pts,
                                                            int num_groups,
                                                            int h_0,
                                                            int w_0,
                                                            int h_1,
                                                            int w_1,
                                                            int h_2,
                                                            int w_2,
                                                            int hw_stride0,
                                                            int hw_stride1,
                                                            int hw_stride2,
                                                            int pts_stride,
                                                            int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 3;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  float* share_weights = reinterpret_cast<float*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const float* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;
      interpolate_weight[index] = {hh, hw, lh, lw};

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      int pos1 = -1, pos2 = -1, pos3 = -1, pos4 = -1;

      if (h_low >= 0 && w_low >= 0) {
        pos1 = h_low_ptr_offset + w_low_ptr_offset;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        pos2 = h_low_ptr_offset + w_high_ptr_offset;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        pos3 = h_high_ptr_offset + w_low_ptr_offset;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        pos4 = h_high_ptr_offset + w_high_ptr_offset;
      }
      interpolate_pos[index] = {pos1 >> 1, pos2 >> 1, pos3 >> 1, pos4 >> 1};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value1 = 0.0f;
  float ret_value2 = 0.0f;
  const float* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2};

  int channel_index = idx - anchor_index * num_embeds / 2;
  int channel_offset = channel_index * 2 / (num_embeds / num_groups);
  int index_stride = num_cams * num_pts;

  // 对齐loti精度，按照loti顺序进行累加

  for (int pts_index = 0; pts_index < num_pts; pts_index++) {
    const int weight_base = channel_offset + pts_index * pts_stride;
    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_base = weight_base + cam_index * scale_value * num_groups;
      float* share_weights_base = share_weights + cam_scale_base;
      int index_base = cam_index * num_pts + pts_index;
      for (int k = 0; k < scale_value; k++) {
        const float* bottom_data = feat[k];
        int hw_stride = hw_strides[k];
        const int value_offset = cam_index * hw_stride + channel_index * 2;
        const float2* value_ptr = reinterpret_cast<const float2*>(bottom_data + value_offset);
        int index = index_base + k * index_stride;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];
          float weight = *(share_weights_base + k * num_groups);

          float val1 = (pos.x >= 0)
                           ? (value_ptr[pos.x].x * interpolate_weights.x * interpolate_weights.y)
                           : (0.0f);
          float val2 = (pos.x >= 0)
                           ? (value_ptr[pos.x].y * interpolate_weights.x * interpolate_weights.y)
                           : (0.0f);

          val1 += (pos.y >= 0)
                      ? (value_ptr[pos.y].x * interpolate_weights.x * interpolate_weights.w)
                      : (0.0f);
          val2 += (pos.y >= 0)
                      ? (value_ptr[pos.y].y * interpolate_weights.x * interpolate_weights.w)
                      : (0.0f);

          val1 += (pos.z >= 0)
                      ? (value_ptr[pos.z].x * interpolate_weights.z * interpolate_weights.y)
                      : (0.0f);
          val2 += (pos.z >= 0)
                      ? (value_ptr[pos.z].y * interpolate_weights.z * interpolate_weights.y)
                      : (0.0f);

          val1 += (pos.w >= 0)
                      ? (value_ptr[pos.w].x * interpolate_weights.z * interpolate_weights.w)
                      : (0.0f);
          val2 += (pos.w >= 0)
                      ? (value_ptr[pos.w].y * interpolate_weights.z * interpolate_weights.w)
                      : (0.0f);

          ret_value1 = __fmaf_rn(val1, weight, ret_value1);
          ret_value2 = __fmaf_rn(val2, weight, ret_value2);
        }
      }
    }
  }

  //   for (int k = 0; k < scale_value; k++) {
  //     const float* bottom_data = feat[k];
  //     int hw_stride = hw_strides[k];
  //     float level_value1 = 0.0f;
  //     float level_value2 = 0.0f;

  //     for (int cam_index = 0; cam_index < num_cams; cam_index++) {
  //       int cam_scale_index = cam_index * scale_value + k;
  //       int group_offset = channel_offset + cam_scale_index * num_groups;
  //       const int value_offset = cam_index * hw_stride + channel_index * 2;
  //       const float2* value_ptr = reinterpret_cast<const float2*>(bottom_data + value_offset);
  //       float cam_value1 = 0.0f;
  //       float cam_value2 = 0.0f;
  //       int index = (k * num_cams + cam_index) * num_pts;

  //       for (int pts_index = 0; pts_index < num_pts; pts_index++) {
  //         if (!is_out[index]) {
  //           float4 interpolate_weights = interpolate_weight[index];
  //           int4 pos = interpolate_pos[index];

  //           const int base_weight_offset = group_offset + pts_index * pts_stride;
  //           float weight = *(share_weights + base_weight_offset);

  //           float val1 = 0.0f, val2 = 0.0f;
  //           if (pos.x >= 0) {
  //             float2 value1 = value_ptr[pos.x];
  //             val1 = __fmaf_rn(interpolate_weights.x,
  //                              __fmaf_rn(interpolate_weights.y, value1.x, 0),
  //                              val1);
  //             val2 = __fmaf_rn(interpolate_weights.x,
  //                              __fmaf_rn(interpolate_weights.y, value1.y, 0),
  //                              val2);
  //           }

  //           if (pos.y >= 0) {
  //             float2 value2 = value_ptr[pos.y];
  //             val1 = __fmaf_rn(interpolate_weights.x,
  //                              __fmaf_rn(interpolate_weights.w, value2.x, 0),
  //                              val1);
  //             val2 = __fmaf_rn(interpolate_weights.x,
  //                              __fmaf_rn(interpolate_weights.w, value2.y, 0),
  //                              val2);
  //           }

  //           if (pos.z >= 0) {
  //             float2 value3 = value_ptr[pos.z];
  //             val1 = __fmaf_rn(interpolate_weights.z,
  //                              __fmaf_rn(interpolate_weights.y, value3.x, 0),
  //                              val1);
  //             val2 = __fmaf_rn(interpolate_weights.z,
  //                              __fmaf_rn(interpolate_weights.y, value3.y, 0),
  //                              val2);
  //           }

  //           if (pos.w >= 0) {
  //             float2 value4 = value_ptr[pos.w];
  //             val1 = __fmaf_rn(interpolate_weights.z,
  //                              __fmaf_rn(interpolate_weights.w, value4.x, 0),
  //                              val1);
  //             val2 = __fmaf_rn(interpolate_weights.z,
  //                              __fmaf_rn(interpolate_weights.w, value4.y, 0),
  //                              val2);
  //           }
  //           cam_value1 = __fmaf_rn(val1, weight, cam_value1);
  //           cam_value2 = __fmaf_rn(val2, weight, cam_value2);
  //         }
  //         index += 1;
  //       }
  //       level_value1 += cam_value1;
  //       level_value2 += cam_value2;
  //     }
  //     ret_value1 += level_value1;
  //     ret_value2 += level_value2;
  //   }

  float2 ret_value = make_float2(ret_value1, ret_value2);
  float2* out = reinterpret_cast<float2*>(output + anchor_index * num_embeds);
  out[channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_half_kernel(const int num_kernels,
                                                          float* output,
                                                          const __half* mc_ms_feat0,
                                                          const __half* mc_ms_feat1,
                                                          const __half* mc_ms_feat2,
                                                          const float* sample_location,
                                                          const __half* weights,
                                                          int num_cams,
                                                          int num_embeds,
                                                          int num_scale,
                                                          int num_anchors,
                                                          int num_pts,
                                                          int num_groups,
                                                          int h_0,
                                                          int w_0,
                                                          int h_1,
                                                          int w_1,
                                                          int h_2,
                                                          int w_2,
                                                          int hw_stride0,
                                                          int hw_stride1,
                                                          int hw_stride2,
                                                          int pts_stride,
                                                          int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 3;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  __half* share_weights = reinterpret_cast<__half*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const __half* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value = 0.0f;
  const __half* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2};

  int channel_index = idx - anchor_index * num_embeds;
  int channel_offset = channel_index / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const __half* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index;
      const __half* value_ptr = reinterpret_cast<const __half*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          float weight = *(share_weights + base_weight_offset);

          float val = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val = fma(interpolate_weights.x, __half2float(value_ptr[pos.x]), val);
          }

          if (interpolate_weights.y > 0.0f) {
            val = fma(interpolate_weights.y, __half2float(value_ptr[pos.y]), val);
          }

          if (interpolate_weights.z > 0.0f) {
            val = fma(interpolate_weights.z, __half2float(value_ptr[pos.z]), val);
          }

          if (interpolate_weights.w > 0.0f) {
            val = fma(interpolate_weights.w, __half2float(value_ptr[pos.w]), val);
          }
          ret_value = fma(val, __half2float(weight), ret_value);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_half2_kernel(const int num_kernels,
                                                           float* output,
                                                           const __half* mc_ms_feat0,
                                                           const __half* mc_ms_feat1,
                                                           const __half* mc_ms_feat2,
                                                           const float* sample_location,
                                                           const __half* weights,
                                                           int num_cams,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int h_0,
                                                           int w_0,
                                                           int h_1,
                                                           int w_1,
                                                           int h_2,
                                                           int w_2,
                                                           int hw_stride0,
                                                           int hw_stride1,
                                                           int hw_stride2,
                                                           int pts_stride,
                                                           int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 3;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  half4* interpolate_weight =
      reinterpret_cast<half4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  __half* share_weights = reinterpret_cast<__half*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;
  __half2 half2_zero = __halves2half2(__float2half(0.0f), __float2half(0.0f));

  int tid = threadIdx.x;
  const __half* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {half2_zero, half2_zero};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;
      interpolate_weight[index] = {__halves2half2(__float2half(hh), __float2half(hw)),
                                   __halves2half2(__float2half(lh), __float2half(lw))};

      const int num_embeds_half = num_embeds >> 1;
      const int h_stride = width * num_embeds_half;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds_half;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds_half;

      int pos1 = -1, pos2 = -1, pos3 = -1, pos4 = -1;

      if (h_low >= 0 && w_low >= 0) {
        pos1 = h_low_ptr_offset + w_low_ptr_offset;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        pos2 = h_low_ptr_offset + w_high_ptr_offset;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        pos3 = h_high_ptr_offset + w_low_ptr_offset;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        pos4 = h_high_ptr_offset + w_high_ptr_offset;
      }
      interpolate_pos[index] = {pos1, pos2, pos3, pos4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value1 = 0.0f;
  float ret_value2 = 0.0f;
  const __half* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2};

  int channel_index = idx - anchor_index * num_embeds / 2;
  int channel_offset = channel_index * 2 / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const __half* bottom_data = feat[k];
    int hw_stride = hw_strides[k];
    float level_value1 = 0.0f;
    float level_value2 = 0.0f;

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index * 2;
      const __half2* value_ptr = reinterpret_cast<const __half2*>(bottom_data + value_offset);
      float cam_value1 = 0.0f;
      float cam_value2 = 0.0f;

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          half4 interpolate_weights = interpolate_weight[index];
          __half2 hh = __half2half2(interpolate_weights.left.x);
          __half2 hw = __half2half2(interpolate_weights.left.y);
          __half2 lh = __half2half2(interpolate_weights.right.x);
          __half2 lw = __half2half2(interpolate_weights.right.y);
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          __half weight = *(share_weights + base_weight_offset);

          __half2 val = half2_zero;
          if (pos.x >= 0) {
            val = __hfma2(hh, __hfma2(hw, value_ptr[pos.x], half2_zero), val);
          }

          if (pos.y >= 0) {
            val = __hfma2(hh, __hfma2(lw, value_ptr[pos.y], half2_zero), val);
          }

          if (pos.z >= 0) {
            val = __hfma2(lh, __hfma2(hw, value_ptr[pos.z], half2_zero), val);
          }

          if (pos.w >= 0) {
            val = __hfma2(lh, __hfma2(lw, value_ptr[pos.w], half2_zero), val);
          }

          cam_value1 = __fmaf_rn(__half2float(val.x), __half2float(weight), cam_value1);
          cam_value2 = __fmaf_rn(__half2float(val.y), __half2float(weight), cam_value2);
        }
      }
      level_value1 += cam_value1;
      level_value2 += cam_value2;
    }
    ret_value1 += level_value1;
    ret_value2 += level_value2;
  }

  output[anchor_index * num_embeds + channel_index * 2] = ret_value1;
  output[anchor_index * num_embeds + channel_index * 2 + 1] = ret_value2;
}

__global__ void deformable_aggregation_format_float_kernel(const int num_kernels,
                                                           float* output,
                                                           const float* mc_ms_feat0,
                                                           const float* mc_ms_feat1,
                                                           const float* mc_ms_feat2,
                                                           const float* mc_ms_feat3,
                                                           const float* sample_location,
                                                           const float* weights,
                                                           int num_cams,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int h_0,
                                                           int w_0,
                                                           int h_1,
                                                           int w_1,
                                                           int h_2,
                                                           int w_2,
                                                           int h_3,
                                                           int w_3,
                                                           int hw_stride0,
                                                           int hw_stride1,
                                                           int hw_stride2,
                                                           int hw_stride3,
                                                           int pts_stride,
                                                           int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 4;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2, h_3, w_3};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2, hw_stride3};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  float* share_weights = reinterpret_cast<float*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const float* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value = 0.0f;
  const float* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2, mc_ms_feat3};

  int channel_index = idx - anchor_index * num_embeds;
  int channel_offset = channel_index / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const float* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index;
      const float* value_ptr = reinterpret_cast<const float*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          float weight = *(share_weights + base_weight_offset);

          float val = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val = fma(interpolate_weights.x, value_ptr[pos.x], val);
          }

          if (interpolate_weights.y > 0.0f) {
            val = fma(interpolate_weights.y, value_ptr[pos.y], val);
          }

          if (interpolate_weights.z > 0.0f) {
            val = fma(interpolate_weights.z, value_ptr[pos.z], val);
          }

          if (interpolate_weights.w > 0.0f) {
            val = fma(interpolate_weights.w, value_ptr[pos.w], val);
          }
          ret_value = fma(val, weight, ret_value);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_half_kernel(const int num_kernels,
                                                          float* output,
                                                          const __half* mc_ms_feat0,
                                                          const __half* mc_ms_feat1,
                                                          const __half* mc_ms_feat2,
                                                          const __half* mc_ms_feat3,
                                                          const float* sample_location,
                                                          const __half* weights,
                                                          int num_cams,
                                                          int num_embeds,
                                                          int num_scale,
                                                          int num_anchors,
                                                          int num_pts,
                                                          int num_groups,
                                                          int h_0,
                                                          int w_0,
                                                          int h_1,
                                                          int w_1,
                                                          int h_2,
                                                          int w_2,
                                                          int h_3,
                                                          int w_3,
                                                          int hw_stride0,
                                                          int hw_stride1,
                                                          int hw_stride2,
                                                          int hw_stride3,
                                                          int pts_stride,
                                                          int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 4;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2, h_3, w_3};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2, hw_stride3};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  __half* share_weights = reinterpret_cast<__half*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const __half* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value = 0.0f;
  const __half* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2, mc_ms_feat3};

  int channel_index = idx - anchor_index * num_embeds;
  int channel_offset = channel_index / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const __half* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index;
      const __half* value_ptr = reinterpret_cast<const __half*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          float weight = *(share_weights + base_weight_offset);

          float val = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val = fma(interpolate_weights.x, __half2float(value_ptr[pos.x]), val);
          }

          if (interpolate_weights.y > 0.0f) {
            val = fma(interpolate_weights.y, __half2float(value_ptr[pos.y]), val);
          }

          if (interpolate_weights.z > 0.0f) {
            val = fma(interpolate_weights.z, __half2float(value_ptr[pos.z]), val);
          }

          if (interpolate_weights.w > 0.0f) {
            val = fma(interpolate_weights.w, __half2float(value_ptr[pos.w]), val);
          }
          ret_value = fma(val, __half2float(weight), ret_value);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index] = ret_value;
}

__global__ void deformable_aggregation_format_half2_kernel(const int num_kernels,
                                                           float* output,
                                                           const __half* mc_ms_feat0,
                                                           const __half* mc_ms_feat1,
                                                           const __half* mc_ms_feat2,
                                                           const __half* mc_ms_feat3,
                                                           const float* sample_location,
                                                           const __half* weights,
                                                           int num_cams,
                                                           int num_embeds,
                                                           int num_scale,
                                                           int num_anchors,
                                                           int num_pts,
                                                           int num_groups,
                                                           int h_0,
                                                           int w_0,
                                                           int h_1,
                                                           int w_1,
                                                           int h_2,
                                                           int w_2,
                                                           int h_3,
                                                           int w_3,
                                                           int hw_stride0,
                                                           int hw_stride1,
                                                           int hw_stride2,
                                                           int hw_stride3,
                                                           int pts_stride,
                                                           int num_weight) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= num_kernels) return;
  const int scale_value = 4;
  int hw[]{h_0, w_0, h_1, w_1, h_2, w_2, h_3, w_3};
  int hw_strides[]{hw_stride0, hw_stride1, hw_stride2, hw_stride3};

  int num_point_per_level = num_pts * num_cams;
  int anchor_index = blockIdx.x;
  int anchor_offset = anchor_index * num_point_per_level;
  int num_point = scale_value * num_point_per_level;

  extern __shared__ __align__(16) unsigned char shared_mem[];
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);  // scale_value * num_cams * num_pts
  float4* interpolate_weight =
      reinterpret_cast<float4*>(interpolate_pos + num_point);  // scale_value * num_cams * num_pts
  __half* share_weights = reinterpret_cast<__half*>(
      interpolate_weight + num_point);  // num_pts * num_groups * num_cams * scale_value
  bool* is_out = reinterpret_cast<bool*>(share_weights + num_weight);
  const float one = 1.0f;
  const float zero = 0.0f;
  const float half_one = -0.5f;

  int tid = threadIdx.x;
  const __half* weight_ptr = weights + anchor_index * num_weight;
  for (int i = tid; i < num_weight; i += blockDim.x) {
    share_weights[i] = weight_ptr[i];
  }

  const float2* sample_location_ptr =
      reinterpret_cast<const float2*>(sample_location + anchor_offset * 2);
  for (int index = tid; index < num_point; index += blockDim.x) {
    int level_id = index / num_point_per_level;
    int cam_id = (index / num_pts) % num_cams;
    int point_id = index % num_pts;

    int point_index = point_id * num_cams + cam_id;
    float2 pts = sample_location_ptr[point_index];
    float pts_w = pts.x;
    float pts_h = pts.y;
    interpolate_weight[index] = {0.0f, 0.0f, 0.0f, 0.0f};
    if (pts_w > zero && pts_w < one && pts_h > zero && pts_h < one) {
      is_out[index] = false;
      int height = hw[2 * level_id];
      int width = hw[2 * level_id + 1];
      const float h_im = static_cast<float>(height) * pts.y + half_one;
      const float w_im = static_cast<float>(width) * pts.x + half_one;

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - static_cast<float>(h_low);
      const float lw = w_im - static_cast<float>(w_low);
      const float hh = 1.0f - lh, hw = 1.0f - lw;

      float w1 = 0.0f;
      float w2 = 0.0f;
      float w3 = 0.0f;
      float w4 = 0.0f;

      const int h_stride = width * num_embeds;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * num_embeds;
      const int w_high_ptr_offset = w_low_ptr_offset + num_embeds;

      interpolate_pos[index] = {h_low_ptr_offset + w_low_ptr_offset,
                                h_low_ptr_offset + w_high_ptr_offset,
                                h_high_ptr_offset + w_low_ptr_offset,
                                h_high_ptr_offset + w_high_ptr_offset};

      if (h_low >= 0 && w_low >= 0) {
        w1 = hh * hw;
      }

      if (h_low >= 0 && w_high <= width - 1) {
        w2 = hh * lw;
      }

      if (h_high <= height - 1 && w_low >= 0) {
        w3 = lh * hw;
      }

      if (h_high <= height - 1 && w_high <= width - 1) {
        w4 = lh * lw;
      }
      interpolate_weight[index] = {w1, w2, w3, w4};
    } else {
      is_out[index] = true;
    }
  }
  __syncthreads();

  float ret_value1 = 0.0f;
  float ret_value2 = 0.0f;
  const __half* feat[] = {mc_ms_feat0, mc_ms_feat1, mc_ms_feat2, mc_ms_feat3};

  int channel_index = idx - anchor_index * num_embeds / 2;
  int channel_offset = channel_index * 2 / (num_embeds / num_groups);

  for (int k = 0; k < scale_value; k++) {
    const __half* bottom_data = feat[k];
    int hw_stride = hw_strides[k];

    for (int cam_index = 0; cam_index < num_cams; cam_index++) {
      int cam_scale_index = cam_index * scale_value + k;
      int group_offset = channel_offset + cam_scale_index * num_groups;
      const int value_offset = cam_index * hw_stride + channel_index * 2;
      const __half* value_ptr = reinterpret_cast<const __half*>(bottom_data + value_offset);

      for (int pts_index = 0; pts_index < num_pts; pts_index++) {
        int index = (k * num_cams + cam_index) * num_pts + pts_index;
        if (!is_out[index]) {
          float4 interpolate_weights = interpolate_weight[index];
          int4 pos = interpolate_pos[index];

          const int base_weight_offset = group_offset + pts_index * pts_stride;
          __half weight = *(share_weights + base_weight_offset);

          float val1 = 0.0f, val2 = 0.0f;
          if (interpolate_weights.x > 0.0f) {
            val1 = fma(interpolate_weights.x, __half2float(value_ptr[pos.x]), val1);
            val2 = fma(interpolate_weights.x, __half2float(value_ptr[pos.x + 1]), val2);
          }

          if (interpolate_weights.y > 0.0f) {
            val1 = fma(interpolate_weights.y, __half2float(value_ptr[pos.y]), val1);
            val2 = fma(interpolate_weights.y, __half2float(value_ptr[pos.y + 1]), val2);
          }

          if (interpolate_weights.z > 0.0f) {
            val1 = fma(interpolate_weights.z, __half2float(value_ptr[pos.z]), val1);
            val2 = fma(interpolate_weights.z, __half2float(value_ptr[pos.z + 1]), val2);
          }

          if (interpolate_weights.w > 0.0f) {
            val1 = fma(interpolate_weights.w, __half2float(value_ptr[pos.w]), val1);
            val2 = fma(interpolate_weights.w, __half2float(value_ptr[pos.w + 1]), val2);
          }

          ret_value1 = fma(val1, __half2float(weight), ret_value1);
          ret_value2 = fma(val2, __half2float(weight), ret_value2);
        }
      }
    }
  }

  output[anchor_index * num_embeds + channel_index * 2] = ret_value1;
  output[anchor_index * num_embeds + channel_index * 2 + 1] = ret_value2;
}

/*
    L：多相机多尺度2D特征合并在一起之后的长度
    C：图像特征的Channel数
    K：anchor数量
    P：每个anchor的采样点数量
    N：相机数量
    S：每个相机下的尺度（层次）数量
    G：分组数量

    mc_ms_feat: L x C, 包含多相机多尺度的2D特征，将多相机多尺度的特征合并在一起。
    sample_location: KxPxNx2，在2D图像上的采样点坐标
    weights: KxPxNxSxG，权重
    output: KxC，输出

    分组处理的逻辑：对于同一个anchor、同一个采样点，所对应的同一个相机的同一个尺度下，有C维特征，
    将C维特征分为G组，每组长度为C/G，同组共享相同权重，即：w = weights[k, p, n, s, g]
*/

void deformable_aggregation_format(cudaStream_t stream,
                                   float* output,
                                   const float* mc_ms_feat0,
                                   const float* mc_ms_feat1,
                                   const float* sample_location,
                                   const float* weights,
                                   int num_cams,
                                   int num_embeds,
                                   int num_scale,
                                   int num_anchors,
                                   int num_pts,
                                   int num_groups,
                                   int h_0,
                                   int w_0,
                                   int h_1,
                                   int w_1) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  int hw_stride0 = h_0 * w_0 * num_embeds;
  int hw_stride1 = h_1 * w_1 * num_embeds;
  int num_kernels = num_embeds * num_anchors;
  const int scale_value = 2;
  int pts_stride = num_groups * scale_value * num_cams;
  int num_weight = num_pts * num_groups * num_cams * scale_value;
  unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(float)) +
                           num_weight * sizeof(float) +
                           scale_value * num_cams * num_pts * sizeof(bool);
  deformable_aggregation_format_float_kernel<<<(int)ceil(((double)num_kernels / 256)),
                                               256,
                                               smem_size,
                                               stream>>>(num_kernels,
                                                         output,
                                                         mc_ms_feat0,
                                                         mc_ms_feat1,
                                                         sample_location,
                                                         weights,
                                                         num_cams,
                                                         num_embeds,
                                                         num_scale,
                                                         num_anchors,
                                                         num_pts,
                                                         num_groups,
                                                         h_0,
                                                         w_0,
                                                         h_1,
                                                         w_1,
                                                         hw_stride0,
                                                         hw_stride1,
                                                         pts_stride,
                                                         num_weight);
}

void deformable_aggregation_format(cudaStream_t stream,
                                   float* output,
                                   const float* mc_ms_feat0,
                                   const float* mc_ms_feat1,
                                   const float* mc_ms_feat2,
                                   const float* sample_location,
                                   const float* weights,
                                   int num_cams,
                                   int num_embeds,
                                   int num_scale,
                                   int num_anchors,
                                   int num_pts,
                                   int num_groups,
                                   int h_0,
                                   int w_0,
                                   int h_1,
                                   int w_1,
                                   int h_2,
                                   int w_2) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */
  // 1个thread计算2个channel

  int hw_stride0 = h_0 * w_0 * num_embeds;
  int hw_stride1 = h_1 * w_1 * num_embeds;
  int hw_stride2 = h_2 * w_2 * num_embeds;
  const int scale_value = 3;
  int pts_stride = num_groups * scale_value * num_cams;
  int num_weight = num_pts * num_groups * num_cams * scale_value;
  unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(float)) +
                           num_weight * sizeof(float) +
                           scale_value * num_cams * num_pts * sizeof(bool);
  // 1个thread计算两个channel，可以减少对共享内存访问和插值判断次数
  if (num_embeds % 2 == 0) {
    int num_kernels = num_embeds * num_anchors / 2;
    deformable_aggregation_format_float2_kernel<<<(int)ceil(((double)num_kernels / 128)),
                                                  128,
                                                  smem_size,
                                                  stream>>>(num_kernels,
                                                            output,
                                                            mc_ms_feat0,
                                                            mc_ms_feat1,
                                                            mc_ms_feat2,
                                                            sample_location,
                                                            weights,
                                                            num_cams,
                                                            num_embeds,
                                                            num_scale,
                                                            num_anchors,
                                                            num_pts,
                                                            num_groups,
                                                            h_0,
                                                            w_0,
                                                            h_1,
                                                            w_1,
                                                            h_2,
                                                            w_2,
                                                            hw_stride0,
                                                            hw_stride1,
                                                            hw_stride2,
                                                            pts_stride,
                                                            num_weight);
  } else {
    int num_kernels = num_embeds * num_anchors;
    deformable_aggregation_format_float_kernel<<<(int)ceil(((double)num_kernels / 256)),
                                                 256,
                                                 smem_size,
                                                 stream>>>(num_kernels,
                                                           output,
                                                           mc_ms_feat0,
                                                           mc_ms_feat1,
                                                           mc_ms_feat2,
                                                           sample_location,
                                                           weights,
                                                           num_cams,
                                                           num_embeds,
                                                           num_scale,
                                                           num_anchors,
                                                           num_pts,
                                                           num_groups,
                                                           h_0,
                                                           w_0,
                                                           h_1,
                                                           w_1,
                                                           h_2,
                                                           w_2,
                                                           hw_stride0,
                                                           hw_stride1,
                                                           hw_stride2,
                                                           pts_stride,
                                                           num_weight);
  }
}

void deformable_aggregation_format(cudaStream_t stream,
                                   float* output,
                                   const float* mc_ms_feat0,
                                   const float* mc_ms_feat1,
                                   const float* mc_ms_feat2,
                                   const float* mc_ms_feat3,
                                   const float* sample_location,
                                   const float* weights,
                                   int num_cams,
                                   int num_embeds,
                                   int num_scale,
                                   int num_anchors,
                                   int num_pts,
                                   int num_groups,
                                   int h_0,
                                   int w_0,
                                   int h_1,
                                   int w_1,
                                   int h_2,
                                   int w_2,
                                   int h_3,
                                   int w_3) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  int hw_stride0 = h_0 * w_0 * num_embeds;
  int hw_stride1 = h_1 * w_1 * num_embeds;
  int hw_stride2 = h_2 * w_2 * num_embeds;
  int hw_stride3 = h_3 * w_3 * num_embeds;
  int num_kernels = num_embeds * num_anchors;
  const int scale_value = 4;
  int pts_stride = num_groups * scale_value * num_cams;
  int num_weight = num_pts * num_groups * num_cams * scale_value;
  unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(float)) +
                           num_weight * sizeof(float) +
                           scale_value * num_cams * num_pts * sizeof(bool);
  deformable_aggregation_format_float_kernel<<<(int)ceil(((double)num_kernels / 256)),
                                               256,
                                               smem_size,
                                               stream>>>(num_kernels,
                                                         output,
                                                         mc_ms_feat0,
                                                         mc_ms_feat1,
                                                         mc_ms_feat2,
                                                         mc_ms_feat3,
                                                         sample_location,
                                                         weights,
                                                         num_cams,
                                                         num_embeds,
                                                         num_scale,
                                                         num_anchors,
                                                         num_pts,
                                                         num_groups,
                                                         h_0,
                                                         w_0,
                                                         h_1,
                                                         w_1,
                                                         h_2,
                                                         w_2,
                                                         h_3,
                                                         w_3,
                                                         hw_stride0,
                                                         hw_stride1,
                                                         hw_stride2,
                                                         hw_stride3,
                                                         pts_stride,
                                                         num_weight);
}

void deformable_aggregation_format(cudaStream_t stream,
                                   float* output,
                                   const __half* mc_ms_feat0,
                                   const __half* mc_ms_feat1,
                                   const float* sample_location,
                                   const __half* weights,
                                   int num_cams,
                                   int num_embeds,
                                   int num_scale,
                                   int num_anchors,
                                   int num_pts,
                                   int num_groups,
                                   int h_0,
                                   int w_0,
                                   int h_1,
                                   int w_1) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  int hw_stride0 = h_0 * w_0 * num_embeds;
  int hw_stride1 = h_1 * w_1 * num_embeds;
  const int scale_value = 2;
  int pts_stride = num_groups * scale_value * num_cams;
  int num_weight = num_pts * num_groups * num_cams * scale_value;
  unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(float)) +
                           num_weight * sizeof(__half) +
                           scale_value * num_cams * num_pts * sizeof(bool);

  if (num_embeds % 2 == 0) {
    int num_kernels = num_embeds * num_anchors / 2;
    deformable_aggregation_format_half2_kernel<<<(int)ceil(((double)num_kernels / 128)),
                                                 128,
                                                 smem_size,
                                                 stream>>>(num_kernels,
                                                           output,
                                                           mc_ms_feat0,
                                                           mc_ms_feat1,
                                                           sample_location,
                                                           weights,
                                                           num_cams,
                                                           num_embeds,
                                                           num_scale,
                                                           num_anchors,
                                                           num_pts,
                                                           num_groups,
                                                           h_0,
                                                           w_0,
                                                           h_1,
                                                           w_1,
                                                           hw_stride0,
                                                           hw_stride1,
                                                           pts_stride,
                                                           num_weight);
  } else {
    int num_kernels = num_embeds * num_anchors;
    deformable_aggregation_format_half_kernel<<<(int)ceil(((double)num_kernels / 256)),
                                                256,
                                                smem_size,
                                                stream>>>(num_kernels,
                                                          output,
                                                          mc_ms_feat0,
                                                          mc_ms_feat1,
                                                          sample_location,
                                                          weights,
                                                          num_cams,
                                                          num_embeds,
                                                          num_scale,
                                                          num_anchors,
                                                          num_pts,
                                                          num_groups,
                                                          h_0,
                                                          w_0,
                                                          h_1,
                                                          w_1,
                                                          hw_stride0,
                                                          hw_stride1,
                                                          pts_stride,
                                                          num_weight);
  }
}

void deformable_aggregation_format(cudaStream_t stream,
                                   float* output,
                                   const __half* mc_ms_feat0,
                                   const __half* mc_ms_feat1,
                                   const __half* mc_ms_feat2,
                                   const float* sample_location,
                                   const __half* weights,
                                   int num_cams,
                                   int num_embeds,
                                   int num_scale,
                                   int num_anchors,
                                   int num_pts,
                                   int num_groups,
                                   int h_0,
                                   int w_0,
                                   int h_1,
                                   int w_1,
                                   int h_2,
                                   int w_2) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  int hw_stride0 = h_0 * w_0 * num_embeds;
  int hw_stride1 = h_1 * w_1 * num_embeds;
  int hw_stride2 = h_2 * w_2 * num_embeds;
  const int scale_value = 3;
  int pts_stride = num_groups * scale_value * num_cams;
  int num_weight = num_pts * num_groups * num_cams * scale_value;

  if (num_embeds % 2 == 0) {
    int num_kernels = num_embeds * num_anchors / 2;
    unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(__half)) +
                             num_weight * sizeof(__half) +
                             scale_value * num_cams * num_pts * sizeof(bool);
    deformable_aggregation_format_half2_kernel<<<(int)ceil(((double)num_kernels / 128)),
                                                 128,
                                                 smem_size,
                                                 stream>>>(num_kernels,
                                                           output,
                                                           mc_ms_feat0,
                                                           mc_ms_feat1,
                                                           mc_ms_feat2,
                                                           sample_location,
                                                           weights,
                                                           num_cams,
                                                           num_embeds,
                                                           num_scale,
                                                           num_anchors,
                                                           num_pts,
                                                           num_groups,
                                                           h_0,
                                                           w_0,
                                                           h_1,
                                                           w_1,
                                                           h_2,
                                                           w_2,
                                                           hw_stride0,
                                                           hw_stride1,
                                                           hw_stride2,
                                                           pts_stride,
                                                           num_weight);
  } else {
    int num_kernels = num_embeds * num_anchors;
    unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(float)) +
                             num_weight * sizeof(__half) +
                             scale_value * num_cams * num_pts * sizeof(bool);
    deformable_aggregation_format_half_kernel<<<(int)ceil(((double)num_kernels / 256)),
                                                256,
                                                smem_size,
                                                stream>>>(num_kernels,
                                                          output,
                                                          mc_ms_feat0,
                                                          mc_ms_feat1,
                                                          mc_ms_feat2,
                                                          sample_location,
                                                          weights,
                                                          num_cams,
                                                          num_embeds,
                                                          num_scale,
                                                          num_anchors,
                                                          num_pts,
                                                          num_groups,
                                                          h_0,
                                                          w_0,
                                                          h_1,
                                                          w_1,
                                                          h_2,
                                                          w_2,
                                                          hw_stride0,
                                                          hw_stride1,
                                                          hw_stride2,
                                                          pts_stride,
                                                          num_weight);
  }
}

void deformable_aggregation_format(cudaStream_t stream,
                                   float* output,
                                   const __half* mc_ms_feat0,
                                   const __half* mc_ms_feat1,
                                   const __half* mc_ms_feat2,
                                   const __half* mc_ms_feat3,
                                   const float* sample_location,
                                   const __half* weights,
                                   int num_cams,
                                   int num_embeds,
                                   int num_scale,
                                   int num_anchors,
                                   int num_pts,
                                   int num_groups,
                                   int h_0,
                                   int w_0,
                                   int h_1,
                                   int w_1,
                                   int h_2,
                                   int w_2,
                                   int h_3,
                                   int w_3) {
  /* feat: bs, num_feat, c */
  /* _spatial_shape: cam, scale, 2 */
  /* _scale_start_index: cam, scale */
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  /* kernel: bs, anchor, pts, c */

  int hw_stride0 = h_0 * w_0 * num_embeds;
  int hw_stride1 = h_1 * w_1 * num_embeds;
  int hw_stride2 = h_2 * w_2 * num_embeds;
  int hw_stride3 = h_3 * w_3 * num_embeds;
  const int scale_value = 4;
  int pts_stride = num_groups * scale_value * num_cams;
  int num_weight = num_pts * num_groups * num_cams * scale_value;
  unsigned int smem_size = scale_value * num_cams * num_pts * 4 * (sizeof(int) + sizeof(float)) +
                           num_weight * sizeof(__half) +
                           scale_value * num_cams * num_pts * sizeof(bool);

  if (num_embeds % 2 == 0) {
    int num_kernels = num_embeds * num_anchors / 2;
    deformable_aggregation_format_half2_kernel<<<(int)ceil(((double)num_kernels / 128)),
                                                 128,
                                                 smem_size,
                                                 stream>>>(num_kernels,
                                                           output,
                                                           mc_ms_feat0,
                                                           mc_ms_feat1,
                                                           mc_ms_feat2,
                                                           mc_ms_feat3,
                                                           sample_location,
                                                           weights,
                                                           num_cams,
                                                           num_embeds,
                                                           num_scale,
                                                           num_anchors,
                                                           num_pts,
                                                           num_groups,
                                                           h_0,
                                                           w_0,
                                                           h_1,
                                                           w_1,
                                                           h_2,
                                                           w_2,
                                                           h_3,
                                                           w_3,
                                                           hw_stride0,
                                                           hw_stride1,
                                                           hw_stride2,
                                                           hw_stride3,
                                                           pts_stride,
                                                           num_weight);
  } else {
    int num_kernels = num_embeds * num_anchors;
    deformable_aggregation_format_half_kernel<<<(int)ceil(((double)num_kernels / 256)),
                                                256,
                                                smem_size,
                                                stream>>>(num_kernels,
                                                          output,
                                                          mc_ms_feat0,
                                                          mc_ms_feat1,
                                                          mc_ms_feat2,
                                                          mc_ms_feat3,
                                                          sample_location,
                                                          weights,
                                                          num_cams,
                                                          num_embeds,
                                                          num_scale,
                                                          num_anchors,
                                                          num_pts,
                                                          num_groups,
                                                          h_0,
                                                          w_0,
                                                          h_1,
                                                          w_1,
                                                          h_2,
                                                          w_2,
                                                          h_3,
                                                          w_3,
                                                          hw_stride0,
                                                          hw_stride1,
                                                          hw_stride2,
                                                          hw_stride3,
                                                          pts_stride,
                                                          num_weight);
  }
}
