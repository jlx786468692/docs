#ifndef DEFORMABLE_AGGREGATION_CUDA_H
#define DEFORMABLE_AGGREGATION_CUDA_H

#include <cuda_runtime.h>

void deformable_aggregation_base(cudaStream_t stream,
                                 float* output,
                                 const float* mc_ms_feat,
                                 const int* spatial_shape,
                                 const int* scale_start_index,
                                 const float* sample_location,
                                 const float* weights,
                                 int batch_size,
                                 int num_cams,
                                 int num_feat,
                                 int num_embeds,
                                 int num_scale,
                                 int num_anchors,
                                 int num_pts,
                                 int num_groups);

void deformable_aggregation_grad(cudaStream_t stream,
                                 const float* mc_ms_feat,
                                 const int* spatial_shape,
                                 const int* scale_start_index,
                                 const float* sample_location,
                                 const float* weights,
                                 const float* grad_output,
                                 float* grad_mc_ms_feat,
                                 float* grad_sampling_location,
                                 float* grad_weights,
                                 int batch_size,
                                 int num_cams,
                                 int num_feat,
                                 int num_embeds,
                                 int num_scale,
                                 int num_anchors,
                                 int num_pts,
                                 int num_groups);

#endif  // DEFORMABLE_AGGREGATION_CUDA_H
