#include "deformable_aggregation_format_v3.hpp"

#include <assert.h>
#include <cuda_fp16.h>

#include <chrono>

#include "deformable_aggregation_format_kernel.h"
#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/util/internal/trt/plugin.h"

using linfer::ops::trt::DeformableAggregationFormatV3Creator;
REGISTER_TENSORRT_PLUGIN(DeformableAggregationFormatV3Creator);

namespace linfer {
namespace ops {
namespace trt {

constexpr char const* DFA_PLUGINV3_VERSION{"1"};
constexpr char const* DFA_PLUGINV3_NAME{"LinferDeformableAggregationFormatV3"};

nvinfer1::PluginFieldCollection DeformableAggregationFormatV3Creator::mFC{};
std::vector<nvinfer1::PluginField> DeformableAggregationFormatV3Creator::mPluginAttributes;

DeformableAggregationFormatV3::DeformableAggregationFormatV3(int num_cams) : num_cams_(num_cams) {}

nvinfer1::IPluginCapability* DeformableAggregationFormatV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* DeformableAggregationFormatV3::getPluginName() const noexcept {
  return DFA_PLUGINV3_NAME;
}

char const* DeformableAggregationFormatV3::getPluginVersion() const noexcept {
  return DFA_PLUGINV3_VERSION;
}

int32_t DeformableAggregationFormatV3::getNbOutputs() const noexcept { return 1; }

void DeformableAggregationFormatV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* DeformableAggregationFormatV3::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

nvinfer1::IPluginV3* DeformableAggregationFormatV3::clone() noexcept {
  try {
    auto* plugin = new DeformableAggregationFormatV3(num_cams_);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t DeformableAggregationFormatV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                                          int32_t nbOutputs,
                                                          nvinfer1::DataType const* inputTypes,
                                                          int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as the first input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t DeformableAggregationFormatV3::getOutputShapes(
    nvinfer1::DimsExprs const* inputs,
    int32_t nbInputs,
    nvinfer1::DimsExprs const* shapeInputs,
    int32_t nbShapeInputs,
    nvinfer1::DimsExprs* outputs,
    int32_t nbOutputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    // Output shape: [N, Lq, M, D]
    int sample_pos = nbInputs - 2;
    outputs[0].nbDims = 3;
    outputs[0].d[0] = exprBuilder.constant(1);
    outputs[0].d[1] = inputs[sample_pos].d[1];
    outputs[0].d[2] = inputs[0].d[3];
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool DeformableAggregationFormatV3::supportsFormatCombination(
    int32_t pos,
    nvinfer1::DynamicPluginTensorDesc const* inOut,
    int32_t nbInputs,
    int32_t nbOutputs) noexcept {
  try {
    // Check format
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;
    if (pos == 0) {
      return ((desc.type == nvinfer1::DataType::kFLOAT) &&
              desc.format == nvinfer1::TensorFormat::kLINEAR);
    } else if (pos == 3 || pos == 5)  // sampling_location和output需要使用float保证精度
    {
      return (desc.type == nvinfer1::DataType::kFLOAT &&
              desc.format == nvinfer1::TensorFormat::kLINEAR);
    } else {
      return (desc.type == inOut[0].desc.type && desc.format == nvinfer1::TensorFormat::kLINEAR);
    }

  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t DeformableAggregationFormatV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                                       int32_t nbInputs,
                                                       nvinfer1::DynamicPluginTensorDesc const* out,
                                                       int32_t nbOutputs) noexcept {
  try {
    num_inputs = nbInputs;
    ASSERT(nbOutputs == 1);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const*
DeformableAggregationFormatV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("num_cams", &num_cams_, nvinfer1::PluginFieldType::kINT32, 1));
    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t DeformableAggregationFormatV3::getWorkspaceSize(
    nvinfer1::DynamicPluginTensorDesc const* inputs,
    int32_t nbInputs,
    nvinfer1::DynamicPluginTensorDesc const* outputs,
    int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t DeformableAggregationFormatV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                                     int32_t nbInputs,
                                                     nvinfer1::PluginTensorDesc const* outputs,
                                                     int32_t nbOutputs) noexcept {
  try {
    num_inputs = nbInputs;
    ASSERT(nbOutputs == 1);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* DeformableAggregationFormatV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t DeformableAggregationFormatV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                                               nvinfer1::PluginTensorDesc const* outputDesc,
                                               void const* const* inputs,
                                               void* const* outputs,
                                               void* workspace,
                                               cudaStream_t stream) noexcept {
  try {
    int nbInputs = num_inputs;
    int sample_pos = nbInputs - 2;
    int weight_pos = nbInputs - 1;

    int batch_size = inputDesc[sample_pos].dims.d[0];   // 1
    ASSERT(batch_size == 1);                            // 算子仅支持batch == 1
    int num_embeds = inputDesc[0].dims.d[3];            // 256
    int num_cams = num_cams_;                           // 5
    int num_scale = nbInputs - 2;                       // 3
    int num_anchors = inputDesc[sample_pos].dims.d[1];  // 600
    int num_pts = inputDesc[sample_pos].dims.d[2];      // 13
    int num_groups = inputDesc[weight_pos].dims.d[5];   // 8
    auto data_type = inputDesc[0].type;

    switch (data_type) {
      case nvinfer1::DataType::kFLOAT:
        if (num_scale == 2) {
          int h_0 = inputDesc[0].dims.d[1];
          int w_0 = inputDesc[0].dims.d[2];
          int h_1 = inputDesc[1].dims.d[1];
          int w_1 = inputDesc[1].dims.d[2];

          deformable_aggregation_format(stream,
                                        (float*)outputs[0],
                                        (float*)inputs[0],
                                        (float*)inputs[1],
                                        (float*)inputs[2],
                                        (float*)inputs[3],
                                        num_cams,
                                        num_embeds,
                                        num_scale,
                                        num_anchors,
                                        num_pts,
                                        num_groups,
                                        h_0,
                                        w_0,
                                        h_1,
                                        w_1);
          break;
        }

        if (num_scale == 3) {
          int h_0 = inputDesc[0].dims.d[1];
          int w_0 = inputDesc[0].dims.d[2];
          int h_1 = inputDesc[1].dims.d[1];
          int w_1 = inputDesc[1].dims.d[2];
          int h_2 = inputDesc[2].dims.d[1];
          int w_2 = inputDesc[2].dims.d[2];
          deformable_aggregation_format(stream,
                                        (float*)outputs[0],
                                        (float*)inputs[0],
                                        (float*)inputs[1],
                                        (float*)inputs[2],
                                        (float*)inputs[3],
                                        (float*)inputs[4],
                                        num_cams,
                                        num_embeds,
                                        num_scale,
                                        num_anchors,
                                        num_pts,
                                        num_groups,
                                        h_0,
                                        w_0,
                                        h_1,
                                        w_1,
                                        h_2,
                                        w_2);
          break;
        }

        if (num_scale == 4) {
          int h_0 = inputDesc[0].dims.d[1];
          int w_0 = inputDesc[0].dims.d[2];
          int h_1 = inputDesc[1].dims.d[1];
          int w_1 = inputDesc[1].dims.d[2];
          int h_2 = inputDesc[2].dims.d[1];
          int w_2 = inputDesc[2].dims.d[2];
          int h_3 = inputDesc[3].dims.d[1];
          int w_3 = inputDesc[3].dims.d[2];
          deformable_aggregation_format(stream,
                                        (float*)outputs[0],
                                        (float*)inputs[0],
                                        (float*)inputs[1],
                                        (float*)inputs[2],
                                        (float*)inputs[3],
                                        (float*)inputs[4],
                                        (float*)inputs[5],
                                        num_cams,
                                        num_embeds,
                                        num_scale,
                                        num_anchors,
                                        num_pts,
                                        num_groups,
                                        h_0,
                                        w_0,
                                        h_1,
                                        w_1,
                                        h_2,
                                        w_2,
                                        h_3,
                                        w_3);
          break;
        }

      // case nvinfer1::DataType::kHALF:
      //     if (num_scale == 2) {
      //         int h_0 = inputDesc[0].dims.d[1];
      //         int w_0 = inputDesc[0].dims.d[2];
      //         int h_1 = inputDesc[1].dims.d[1];
      //         int w_1 = inputDesc[1].dims.d[2];

      //         deformable_aggregation_format(stream, (float*)outputs[0], (__half*)inputs[0],
      //         (__half*)inputs[1], (float*)inputs[2], (__half*)inputs[3], num_cams, num_embeds,
      //         num_scale, num_anchors, num_pts, num_groups, h_0, w_0, h_1, w_1); break;
      //     }

      //     if (num_scale == 3) {
      //         int h_0 = inputDesc[0].dims.d[1];
      //         int w_0 = inputDesc[0].dims.d[2];
      //         int h_1 = inputDesc[1].dims.d[1];
      //         int w_1 = inputDesc[1].dims.d[2];
      //         int h_2 = inputDesc[2].dims.d[1];
      //         int w_2 = inputDesc[2].dims.d[2];
      //         deformable_aggregation_format(stream, (float*)outputs[0], (__half*)inputs[0],
      //         (__half*)inputs[1],
      //         (__half*)inputs[2], (float*)inputs[3], (__half*)inputs[4], num_cams, num_embeds,
      //         num_scale, num_anchors, num_pts, num_groups, h_0, w_0, h_1, w_1, h_2, w_2); break;
      //     }

      //     if (num_scale == 4) {
      //         int h_0 = inputDesc[0].dims.d[1];
      //         int w_0 = inputDesc[0].dims.d[2];
      //         int h_1 = inputDesc[1].dims.d[1];
      //         int w_1 = inputDesc[1].dims.d[2];
      //         int h_2 = inputDesc[2].dims.d[1];
      //         int w_2 = inputDesc[2].dims.d[2];
      //         int h_3 = inputDesc[3].dims.d[1];
      //         int w_3 = inputDesc[3].dims.d[2];
      //         deformable_aggregation_format(stream, (float*)outputs[0], (__half*)inputs[0],
      //         (__half*)inputs[1],
      //         (__half*)inputs[2], (__half*)inputs[3], (float*)inputs[4],
      //         (__half*)inputs[5], num_cams, num_embeds, num_scale, num_anchors, num_pts,
      //         num_groups, h_0, w_0, h_1, w_1, h_2, w_2, h_3, w_3); break;
      //     }
      default:
        return 1;
        break;
    }
    return STATUS_SUCCESS;

  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

// Plugin Creator Implementation
DeformableAggregationFormatV3Creator::DeformableAggregationFormatV3Creator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("num_cams", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* DeformableAggregationFormatV3Creator::getPluginName() const noexcept {
  return DFA_PLUGINV3_NAME;
}

char const* DeformableAggregationFormatV3Creator::getPluginVersion() const noexcept {
  return DFA_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const*
DeformableAggregationFormatV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* DeformableAggregationFormatV3Creator::createPlugin(
    char const* name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  try {
    int num_cams;

    for (int32_t i = 0; i < fc->nbFields; i++) {
      std::string field_name(fc->fields[i].name);
      auto field_data = fc->fields[i].data;
      auto field_len = fc->fields[i].length;

      if (field_name.compare("num_cams") == 0) {
        num_cams = *static_cast<const int32_t*>(field_data);
      }
    }

    return new DeformableAggregationFormatV3(num_cams);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void DeformableAggregationFormatV3Creator::setPluginNamespace(
    char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* DeformableAggregationFormatV3Creator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer