#include "deformable_aggregation_format.hpp"

#include <assert.h>

#include <chrono>

#include "deformable_aggregation_format_kernel.h"
#include "linfer/ops/trt/common/trt_plugin_helper.hpp"
#include "linfer/ops/trt/common/trt_serialize.hpp"

namespace linfer {
namespace {
static const char* DFA_PLUGIN_VERSION{"1"};
static const char* DFA_PLUGIN_NAME{"LinferDeformableAggregationFormat"};
}  // namespace

DeformableAggregationFormat::DeformableAggregationFormat(const std::string& name, int num_cams)
    : TRTPluginBase(name), num_cams_(num_cams) {}

DeformableAggregationFormat::DeformableAggregationFormat(const std::string name,
                                                         const void* data,
                                                         size_t length)
    : TRTPluginBase(name) {
  deserialize_value(&data, &length, &num_cams_);
}

nvinfer1::IPluginV2DynamicExt* DeformableAggregationFormat::clone() const TRT_NOEXCEPT {
  DeformableAggregationFormat* plugin = new DeformableAggregationFormat(mLayerName, num_cams_);
  plugin->setPluginNamespace(getPluginNamespace());

  return plugin;
}

nvinfer1::DimsExprs DeformableAggregationFormat::getOutputDimensions(
    int outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) TRT_NOEXCEPT {
  // input[0] == _mc_ms_feat0
  // input[1] == _mc_ms_feat1
  // input[2] == _mc_ms_feat2
  // input[3] == _sampling_location
  // input[4] == _weights
  nvinfer1::DimsExprs ret;
  int sample_pos = nbInputs - 2;
  ret.nbDims = 3;
  // ret.d[0] = inputs[0].d[0];
  // ret.d[1] = inputs[sample_pos].d[1];
  // ret.d[2] = inputs[0].d[4];

  ret.d[0] = exprBuilder.constant(1);
  ret.d[1] = inputs[sample_pos].d[1];
  ret.d[2] = inputs[0].d[3];

  return ret;
}

bool DeformableAggregationFormat::supportsFormatCombination(
    int pos,
    const nvinfer1::PluginTensorDesc* ioDesc,
    int nbInputs,
    int nbOutputs) TRT_NOEXCEPT {
  // input[0] == _mc_ms_feat0->kFLOAT
  // input[1] == _mc_ms_feat1->kFLOAT
  // input[2] == _mc_ms_feat2->kFLOAT
  // input[3] == _sampling_location->kFLOAT
  // input[4] == _weights->kFLOAT
  // output[0] == features->kFLOAT

  if (pos == 0) {
    return ((ioDesc[pos].type == nvinfer1::DataType::kFLOAT) &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else if (pos == 3 || pos == 5)  // sampling_location和output需要使用float保证精度
  {
    return (ioDesc[pos].type == nvinfer1::DataType::kFLOAT &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  } else {
    return (ioDesc[pos].type == ioDesc[0].type &&
            ioDesc[pos].format == nvinfer1::TensorFormat::kLINEAR);
  }
}

void DeformableAggregationFormat::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* inputs,
                                                  int nbInputs,
                                                  const nvinfer1::DynamicPluginTensorDesc* outputs,
                                                  int nbOutputs) TRT_NOEXCEPT {
  // Validate input arguments
  num_inputs = nbInputs;
  ASSERT(nbOutputs == 1);
}

size_t DeformableAggregationFormat::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                                     int nbInputs,
                                                     const nvinfer1::PluginTensorDesc* outputs,
                                                     int nbOutputs) const TRT_NOEXCEPT {
  return 0;
}

int DeformableAggregationFormat::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                         const nvinfer1::PluginTensorDesc* outputDesc,
                                         const void* const* inputs,
                                         void* const* outputs,
                                         void* workSpace,
                                         cudaStream_t stream) TRT_NOEXCEPT {
  /* feat0: num_cams, h, w, c*/
  /* feat0: num_cams, h, w, c*/
  /* feat0: num_cams, h, w, c*/
  /* _sampling_location: bs, anchor, pts, cam, 2 */
  /* _weights: bs, anchor, pts, cam, scale, group */
  /* output: bs, anchor, c */
  int nbInputs = num_inputs;
  int sample_pos = nbInputs - 2;
  int weight_pos = nbInputs - 1;

  int batch_size = inputDesc[sample_pos].dims.d[0];   // 1
  ASSERT(batch_size == 1);                            // 算子仅支持batch == 1
  int num_embeds = inputDesc[0].dims.d[3];            // 256
  int num_cams = num_cams_;                           // 5
  int num_scale = nbInputs - 2;                       // 3
  int num_anchors = inputDesc[sample_pos].dims.d[1];  // 600
  int num_pts = inputDesc[sample_pos].dims.d[2];      // 13
  int num_groups = inputDesc[weight_pos].dims.d[5];   // 8
  auto data_type = inputDesc[0].type;

  switch (data_type) {
    case nvinfer1::DataType::kFLOAT:
      if (num_scale == 2) {
        int h_0 = inputDesc[0].dims.d[1];
        int w_0 = inputDesc[0].dims.d[2];
        int h_1 = inputDesc[1].dims.d[1];
        int w_1 = inputDesc[1].dims.d[2];

        deformable_aggregation_format(stream,
                                      (float*)outputs[0],
                                      (float*)inputs[0],
                                      (float*)inputs[1],
                                      (float*)inputs[2],
                                      (float*)inputs[3],
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1);
        break;
      }

      if (num_scale == 3) {
        int h_0 = inputDesc[0].dims.d[1];
        int w_0 = inputDesc[0].dims.d[2];
        int h_1 = inputDesc[1].dims.d[1];
        int w_1 = inputDesc[1].dims.d[2];
        int h_2 = inputDesc[2].dims.d[1];
        int w_2 = inputDesc[2].dims.d[2];
        deformable_aggregation_format(stream,
                                      (float*)outputs[0],
                                      (float*)inputs[0],
                                      (float*)inputs[1],
                                      (float*)inputs[2],
                                      (float*)inputs[3],
                                      (float*)inputs[4],
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1,
                                      h_2,
                                      w_2);
        break;
      }

      if (num_scale == 4) {
        int h_0 = inputDesc[0].dims.d[1];
        int w_0 = inputDesc[0].dims.d[2];
        int h_1 = inputDesc[1].dims.d[1];
        int w_1 = inputDesc[1].dims.d[2];
        int h_2 = inputDesc[2].dims.d[1];
        int w_2 = inputDesc[2].dims.d[2];
        int h_3 = inputDesc[3].dims.d[1];
        int w_3 = inputDesc[3].dims.d[2];
        deformable_aggregation_format(stream,
                                      (float*)outputs[0],
                                      (float*)inputs[0],
                                      (float*)inputs[1],
                                      (float*)inputs[2],
                                      (float*)inputs[3],
                                      (float*)inputs[4],
                                      (float*)inputs[5],
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1,
                                      h_2,
                                      w_2,
                                      h_3,
                                      w_3);
        break;
      }

    // case nvinfer1::DataType::kHALF:
    //     if (num_scale == 2) {
    //         int h_0 = inputDesc[0].dims.d[1];
    //         int w_0 = inputDesc[0].dims.d[2];
    //         int h_1 = inputDesc[1].dims.d[1];
    //         int w_1 = inputDesc[1].dims.d[2];

    //         deformable_aggregation_format(stream, (float*)outputs[0], (__half*)inputs[0],
    //         (__half*)inputs[1], (float*)inputs[2], (__half*)inputs[3], num_cams, num_embeds,
    //         num_scale, num_anchors, num_pts, num_groups, h_0, w_0, h_1, w_1); break;
    //     }

    //     if (num_scale == 3) {
    //         int h_0 = inputDesc[0].dims.d[1];
    //         int w_0 = inputDesc[0].dims.d[2];
    //         int h_1 = inputDesc[1].dims.d[1];
    //         int w_1 = inputDesc[1].dims.d[2];
    //         int h_2 = inputDesc[2].dims.d[1];
    //         int w_2 = inputDesc[2].dims.d[2];
    //         deformable_aggregation_format(stream, (float*)outputs[0], (__half*)inputs[0],
    //         (__half*)inputs[1],
    //         (__half*)inputs[2], (float*)inputs[3], (__half*)inputs[4], num_cams, num_embeds,
    //         num_scale, num_anchors, num_pts, num_groups, h_0, w_0, h_1, w_1, h_2, w_2); break;
    //     }

    //     if (num_scale == 4) {
    //         int h_0 = inputDesc[0].dims.d[1];
    //         int w_0 = inputDesc[0].dims.d[2];
    //         int h_1 = inputDesc[1].dims.d[1];
    //         int w_1 = inputDesc[1].dims.d[2];
    //         int h_2 = inputDesc[2].dims.d[1];
    //         int w_2 = inputDesc[2].dims.d[2];
    //         int h_3 = inputDesc[3].dims.d[1];
    //         int w_3 = inputDesc[3].dims.d[2];
    //         deformable_aggregation_format(stream, (float*)outputs[0], (__half*)inputs[0],
    //         (__half*)inputs[1],
    //         (__half*)inputs[2], (__half*)inputs[3], (float*)inputs[4],
    //         (__half*)inputs[5], num_cams, num_embeds, num_scale, num_anchors, num_pts,
    //         num_groups, h_0, w_0, h_1, w_1, h_2, w_2, h_3, w_3); break;
    //     }
    default:
      return 1;
      break;
  }

  return 0;
}

nvinfer1::DataType DeformableAggregationFormat::getOutputDataType(
    int index,
    const nvinfer1::DataType* inputTypes,
    int nbInputs) const TRT_NOEXCEPT {
  return inputTypes[0];
}

// IPluginV2 Methods
const char* DeformableAggregationFormat::getPluginType() const TRT_NOEXCEPT {
  return DFA_PLUGIN_NAME;
}

const char* DeformableAggregationFormat::getPluginVersion() const TRT_NOEXCEPT {
  return DFA_PLUGIN_VERSION;
}

int DeformableAggregationFormat::getNbOutputs() const TRT_NOEXCEPT { return 1; }

size_t DeformableAggregationFormat::getSerializationSize() const TRT_NOEXCEPT {
  return sizeof(int);
}

void DeformableAggregationFormat::serialize(void* buffer) const TRT_NOEXCEPT {
  serialize_value(&buffer, num_cams_);
}

////////////////////// creator /////////////////////////////

DeformableAggregationFormatCreator::DeformableAggregationFormatCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("num_cams", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* DeformableAggregationFormatCreator::getPluginName() const TRT_NOEXCEPT {
  return DFA_PLUGIN_NAME;
}

const char* DeformableAggregationFormatCreator::getPluginVersion() const TRT_NOEXCEPT {
  return DFA_PLUGIN_VERSION;
}

nvinfer1::IPluginV2* DeformableAggregationFormatCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) TRT_NOEXCEPT {
  int num_cams;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("num_cams") == 0) {
      num_cams = *static_cast<const int32_t*>(field_data);
    }
  }

  DeformableAggregationFormat* plugin = new DeformableAggregationFormat(name, num_cams);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

nvinfer1::IPluginV2* DeformableAggregationFormatCreator::deserializePlugin(const char* name,
                                                                           const void* serialData,
                                                                           size_t serialLength)
    TRT_NOEXCEPT {
  // This object will be deleted when the network is destroyed, which will
  // call FCPluginDynamic::destroy()
  auto plugin = new DeformableAggregationFormat(name, serialData, serialLength);
  plugin->setPluginNamespace(getPluginNamespace());
  return plugin;
}

REGISTER_TENSORRT_PLUGIN(DeformableAggregationFormatCreator);
}  // namespace linfer
