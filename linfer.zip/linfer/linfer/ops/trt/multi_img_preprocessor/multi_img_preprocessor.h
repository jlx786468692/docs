#pragma once
#include <cuda_runtime.h>

#include <array>
#include <cstdint>
#include <memory>
namespace mip {
enum class InterpolationMode : int32_t {
  kNearest = 0,
  kLinear,
};
class MultiImgPreprocessorKernel final {
 public:
  MultiImgPreprocessorKernel(const std::array<float, 3>& mean_vals,
                             const std::array<float, 3>& std_vals,
                             float scale,
                             bool bgr2rgb,
                             bool is_resize,
                             int dst_width,
                             int dst_height,
                             InterpolationMode interp_mode);
  ~MultiImgPreprocessorKernel();
  void Process(const void* const* imgs,
               int w,
               int h,
               int c,
               void* output,
               cudaStream_t stream,
               int ver = -1) const;

 private:
  class Impl;
  std::unique_ptr<Impl> impl_;
};
}  // namespace mip