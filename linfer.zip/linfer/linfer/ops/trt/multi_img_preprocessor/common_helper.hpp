#pragma once
#include <stdarg.h>

#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include "NvInferPlugin.h"

namespace linfer {
namespace ops {
namespace trt {
#define LIDS_JOIN_OBJ_IMPL2(a, b) a##b
#define LIDS_JOIN_OBJ_IMPL3(a, b, c) a##b##c
#define LIDS_JOIN_OBJ2(a, b) LIDS_JOIN_OBJ_IMPL2(a, b)
#define LIDS_JOIN_OBJ3(a, b, c) LIDS_JOIN_OBJ_IMPL3(a, b, c)
#define LIDS_UNIQUE_ID LIDS_JOIN_OBJ2(LIDS_JOIN_OBJ3(_uid_, __LINE__, _), __COUNTER__)
#define LIDS_UNIQUE_NAME LIDS_UNIQUE_ID
namespace log {

template <typename T, typename U>
inline int64_t GetTickCount() {
  const auto tp = std::chrono::time_point_cast<U>(T::now());
  return std::chrono::duration_cast<U>(tp.time_since_epoch()).count();
}

template <typename T = std::chrono::milliseconds>
inline int64_t GetTickCount() {
  return GetTickCount<std::chrono::steady_clock, T>();
}

inline constexpr auto StringRightChar(const char* str, int ch) {
  const char dst = static_cast<char>(ch);
  const char* start = str;
  while (*str++);
  while (--str != start && *str != dst);
  return *str == dst ? str : nullptr;
}

inline constexpr const char* GetFileNameFromFilePath(const char* filepath) {
  auto tmp = StringRightChar(filepath, '/');
  if (std::is_pointer<decltype(tmp)>::value) {
    return tmp + 1;
  } else {
    return filepath;
  }
}

inline std::string StringFormat(const char* format, ...) {
  if (format == nullptr) {
    throw std::invalid_argument("error: format is nullptr");
  }
  va_list ap1;
  va_start(ap1, format);
  va_list ap2;
  va_copy(ap2, ap1);
  int len = std::vsnprintf(nullptr, 0, format, ap1);
  if (len < 0) {
    throw std::runtime_error("error: internal error.");
  }
  va_end(ap1);
  std::string ret(static_cast<size_t>(len) + 1, '\0');
  len = std::vsnprintf(&ret[0], ret.size(), format, ap2);
  if (len < 0) {
    throw std::runtime_error("error: internal error.");
  }
  ret.resize(static_cast<size_t>(len));
  va_end(ap2);
  return ret;
}

template <typename... Args, typename T>
inline std::string StringFormatWithPrefix(const char* filename,
                                          int lineno,
                                          const T& fmt,
                                          Args&&... args) {
  const std::string& fmt_str =
      linfer::ops::trt::log::StringFormat("[%s:%d]: ", filename, lineno) + fmt;
  return linfer::ops::trt::log::StringFormat(fmt_str.c_str(), std::forward<Args>(args)...);
}

#define STRING_FORMAT_WITH_PREFIX(...)                          \
  linfer::ops::trt::log::StringFormatWithPrefix(                \
      linfer::ops::trt::log::GetFileNameFromFilePath(__FILE__), \
      __LINE__,                                                 \
      __VA_ARGS__)

#define LOGD(...)                                                                        \
  do {                                                                                   \
    const auto _ticks = linfer::ops::trt::log::GetTickCount<std::chrono::nanoseconds>(); \
    const auto _ns_tick = std::div(_ticks, 1'000UL);                                     \
    const auto _mas_tick = std::div(_ns_tick.quot, 1'000UL);                             \
    const auto _mis_tick = std::div(_mas_tick.quot, 1'000UL);                            \
    const auto _s_tick = std::div(_mis_tick.quot, 1'000UL);                              \
    const auto _ks_tick = std::div(_s_tick.quot, 1'000UL);                               \
    std::printf("[%3.3ld'%3.3ld'%3.3ld'%3.3ld][%s:%u][%s]: %s\n",                        \
                _ks_tick.rem,                                                            \
                _s_tick.rem,                                                             \
                _mis_tick.rem,                                                           \
                _mas_tick.rem,                                                           \
                linfer::ops::trt::log::GetFileNameFromFilePath(__FILE__),                \
                __LINE__,                                                                \
                __func__,                                                                \
                linfer::ops::trt::log::StringFormat(__VA_ARGS__).c_str());               \
  } while (false)

}  // namespace log

#if defined(__GNUC__) || defined(__clang__)
#ifndef LIDS_LIKELY
#define LIDS_LIKELY(x) __builtin_expect(!!(x), 1)
#endif
#ifndef LIDS_UNLIKELY
#define LIDS_UNLIKELY(x) __builtin_expect(!!(x), 0)
#endif
#else
#ifndef LIDS_LIKELY
#define LIDS_LIKELY(x) (x)
#endif
#ifndef LIDS_UNLIKELY
#define LIDS_UNLIKELY(x) (x)
#endif
#endif

#define CHECK_CUDA_RESULT(retval)                                                                 \
  linfer::ops::trt::CheckCudaResultImpl(retval,                                                   \
                                        linfer::ops::trt::log::GetFileNameFromFilePath(__FILE__), \
                                        __LINE__)
inline void CheckCudaResultImpl(cudaError_t retval, const char* filename, std::size_t lineno) {
  if (LIDS_UNLIKELY(retval != cudaSuccess)) {
    throw std::runtime_error(linfer::ops::trt::log::StringFormat("[%s:%u] cudaError_t: %d(%s)(%s)",
                                                                 filename,
                                                                 lineno,
                                                                 static_cast<int>(retval),
                                                                 cudaGetErrorName(retval),
                                                                 cudaGetErrorString(retval)));
  }
}

class SerializeHelper {
 public:
  SerializeHelper(void* buffer, size_t bytes = std::numeric_limits<size_t>::max())
      : buffer_(static_cast<uint8_t*>(buffer)), bytes_(bytes), total_bytes_(0) {}

  size_t TotalBytes() const { return total_bytes_; }

  void Push(const void* ptr, size_t sz) {
    if (bytes_ > 0 && sz > bytes_) {
      LOGD("error: no enough memory. %ju,%ju\n", sz, bytes_);
      abort();
    }
    if (buffer_ != nullptr) {
      std::memcpy(buffer_, ptr, sz);
      buffer_ += sz;
      bytes_ -= sz;
    }
    total_bytes_ += sz;
  }

  template <typename T>
  void Push(const T& obj) {
    static_assert(std::is_arithmetic<T>::value || std::is_enum<T>::value || std::is_pod<T>::value,
                  "error: type not support.");
    Push(&obj, sizeof(obj));
  }

  void Push(const char* str, bool with_size = true) {
    const auto sz = std::strlen(str);
    if (with_size) {
      Push(sz);
    }
    Push((const void*)str, sz);
    if (!with_size) {
      Push("\0", 1);
    }
  }

  void Push(const std::string& str) {
    Push(str.size());
    Push((const void*)str.data(), str.size());
  }

  template <typename T, size_t N>
  void Push(const std::array<T, N>& obj) {
    static_assert(std::is_arithmetic<T>::value || std::is_enum<T>::value || std::is_pod<T>::value,
                  "error: type not support.");
    Push(obj.data(), obj.size() * sizeof(obj[0]));
  }

  template <typename T>
  void Push(const std::vector<T>& obj) {
    static_assert(std::is_arithmetic<T>::value || std::is_enum<T>::value || std::is_pod<T>::value,
                  "error: type not support.");
    Push(obj.size());
    Push(obj.data(), obj.size() * sizeof(obj[0]));
  }

 private:
  uint8_t* buffer_;
  size_t bytes_;
  size_t total_bytes_;
};

class DeserializeHelper {
 public:
  DeserializeHelper(const void* buffer, size_t bytes = std::numeric_limits<size_t>::max())
      : buffer_(static_cast<const uint8_t*>(buffer)), bytes_(bytes) {}

  void Pop(void* ptr, size_t sz) {
    if (sz > bytes_) {
      LOGD("error: no enough memory. %ju,%ju\n", sz, bytes_);
      abort();
    }
    std::memcpy(ptr, buffer_, sz);
    buffer_ += sz;
    bytes_ -= sz;
  }

  template <typename T>
  void Pop(T& obj) {
    static_assert(std::is_arithmetic<T>::value || std::is_enum<T>::value || std::is_pod<T>::value,
                  "error: type not support.");
    Pop(&obj, sizeof(obj));
  }

  void Pop(const char*& str) {
    str = (const char*)buffer_;
    const auto sz = std::strlen(str);
    buffer_ += sz;
    if (sz > bytes_) {
      LOGD("error: no enough memory. %ju,%ju\n", sz, bytes_);
      abort();
    }
    bytes_ -= sz;
  }

  void Pop(std::string& str, bool with_size = true) {
    if (!with_size) {
      const char* str_tmp;
      Pop(str_tmp);
      str = str_tmp;
    } else {
      size_t sz;
      Pop(sz);
      str.resize(sz + 1);
      Pop(&str[0], sz);
      str[sz] = '\0';
      str.resize(sz);
    }
  }

  template <typename T, size_t N>
  void Pop(std::array<T, N>& obj) {
    static_assert(std::is_arithmetic<T>::value || std::is_enum<T>::value || std::is_pod<T>::value,
                  "error: type not support.");
    Pop(obj.data(), obj.size() * sizeof(obj[0]));
  }

  template <typename T>
  void Pop(std::vector<T>& obj) {
    static_assert(std::is_arithmetic<T>::value || std::is_enum<T>::value || std::is_pod<T>::value,
                  "error: type not support.");
    typename std::vector<T>::size_type sz;
    Pop(sz);
    obj.resize(sz);
    Pop(obj.data(), obj.size() * sizeof(obj[0]));
  }

 private:
  const uint8_t* buffer_;
  size_t bytes_;
};

template <typename T>
struct AttrPopHelper {
  template <typename DH>
  static void Pop(DH&& dh, T& val) {
    dh.Pop(val);
  }
};

template <>
struct AttrPopHelper<std::string> {
  template <typename DH>
  static void Pop(DH&& dh, std::string& val) {
    dh.Pop(val, false);
  }
};

class AttrHelper {
 public:
  AttrHelper(const nvinfer1::PluginFieldCollection& fc) : fc_(fc) {}

  template <typename T>
  bool GetItem(const char* key, T& val) const {
    if (key != nullptr) {
      for (int i = 0; i < fc_.nbFields; i++) {
        const auto& field = fc_.fields[i];
        if (field.name != nullptr && std::strcmp(field.name, key) == 0) {
          AttrPopHelper<std::remove_cv_t<T>>::Pop(DeserializeHelper(field.data), val);
          return true;
        }
      }
    }
    return false;
  }

 private:
  const nvinfer1::PluginFieldCollection& fc_;
};

template <class T>
constexpr T Clamp(T v, T lo, T hi) {
  return std::max(std::min(v, hi), lo);
}

namespace fp {
/**
 * @brief 比较浮点数是否相等
 * @tparam T 自动推导出的第一个参数的类型
 * @tparam U 自动推导出的第二个参数的类型
 * @param v1 数值
 * @param v2 数值
 * @param epsilon 精度
 * @return int 0：表示v1==v2; 1：表示v1 > v2; -1:表示v1 < v2
 * @attention 不同的类型默认使用不同的精度，也可以调用时候显示给出epsilon
 */
template <typename T, typename U>
inline int Compare(const T& v1,
                   const U& v2,
                   std::remove_cv_t<std::common_type_t<T, U>> epsilon =
                       std::numeric_limits<std::common_type_t<T, U>>::epsilon()) {
  static_assert(std::is_floating_point<std::common_type_t<T, U>>::value,
                "error: At least one parameter type is a floating point type");
  const auto& delta = v1 - v2;
  int ret = 0;
  if (std::abs(delta) > epsilon) {
    ret = ((delta > 0) ? 1 : -1);
  }
  return ret;
}
/**
 * @brief 比较浮点数是否相等
 * @tparam T 自动推导出的第一个参数的类型
 * @tparam U 自动推导出的第二个参数的类型
 * @param v1 数值
 * @param v2 数值
 * @param epsilon 精度
 * @return bool
 * @attention 不同的类型默认使用不同的精度，也可以调用时候显示给出epsilon
 */
template <typename T, typename U>
inline bool CmpEqual(const T& v1,
                     const U& v2,
                     std::remove_cv_t<std::common_type_t<T, U>> epsilon =
                         std::numeric_limits<std::common_type_t<T, U>>::epsilon()) {
  return (Compare<T, U>(v1, v2, epsilon) == 0);
}
/**
 * @brief 比较浮点数是否小于
 * @tparam T 自动推导出的第一个参数的类型
 * @tparam U 自动推导出的第二个参数的类型
 * @param v1 数值
 * @param v2 数值
 * @param epsilon 精度
 * @return boot
 * @attention 不同的类型默认使用不同的精度，也可以调用时候显示给出epsilon
 */
template <typename T, typename U>
inline bool CmpLess(const T& v1,
                    const U& v2,
                    std::remove_cv_t<std::common_type_t<T, U>> epsilon =
                        std::numeric_limits<std::common_type_t<T, U>>::epsilon()) {
  return (Compare<T, U>(v1, v2, epsilon) < 0);
}

/**
 * @brief 比较浮点数是否大于
 * @tparam T 自动推导出的第一个参数的类型
 * @tparam U 自动推导出的第二个参数的类型
 * @param v1 数值
 * @param v2 数值
 * @param epsilon 精度
 * @return boot
 * @attention 不同的类型默认使用不同的精度，也可以调用时候显示给出epsilon
 */
template <typename T, typename U>
inline bool CmpGreater(const T& v1,
                       const U& v2,
                       std::remove_cv_t<std::common_type_t<T, U>> epsilon =
                           std::numeric_limits<std::common_type_t<T, U>>::epsilon()) {
  return (Compare<T, U>(v1, v2, epsilon) > 0);
}

}  // namespace fp

template <typename T>
int RoundToNearestEven(T x) {
  T integer_part;
  T fractional = std::modf(x, &integer_part);
  if (fp::CmpEqual(std::abs(fractional), 0.5)) {
    int int_part = static_cast<int>(integer_part);
    return (int_part % 2 == 0) ? int_part : int_part + (x > 0 ? 1 : -1);
  }
  return static_cast<int>(std::round(x));
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer