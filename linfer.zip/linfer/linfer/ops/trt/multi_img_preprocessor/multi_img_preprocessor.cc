#include "multi_img_preprocessor.h"

#include <NvInferRuntime.h>
// #include <NvInferPluginBase.h>
#include <stdarg.h>

#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <type_traits>
#include <vector>

#include "common_helper.hpp"
#include "linfer/util/internal/trt/plugin.h"

namespace linfer {
namespace ops {
namespace trt {

static const char* kMultiImgPreprocessorPluginVersion = "1";
static const char* kMultiImgPreprocessorPluginName = "LinferMultiImgPreprocessor";

class MultiImgPreprocessor : public nvinfer1::IPluginV2DynamicExt {
 public:
  MultiImgPreprocessor(const std::array<float, 3>& mean_vals,
                       const std::array<float, 3>& std_vals,
                       float scale,
                       int8_t offset,
                       int32_t bgr2rgb,
                       int32_t is_resize,
                       const std::array<int32_t, 2>& dst_hw,
                       mip::InterpolationMode interp_mode)
      : mean_vals_(mean_vals),
        std_vals_(std_vals),
        scale_(scale),
        offset_(offset),
        bgr2rgb_(bgr2rgb),
        is_resize_(is_resize),
        dst_hw_(dst_hw),
        interp_mode_(interp_mode) {
    kernel_ = std::make_unique<mip::MultiImgPreprocessorKernel>(mean_vals_,
                                                                std_vals_,
                                                                scale_,
                                                                bgr2rgb_,
                                                                is_resize_,
                                                                dst_hw_[1],
                                                                dst_hw_[0],
                                                                interp_mode);
  }

  MultiImgPreprocessor(void const* serialData, size_t serialLength) {
    DeserializeHelper helper(serialData, serialLength);
    helper.Pop(mean_vals_);
    helper.Pop(std_vals_);
    helper.Pop(scale_);
    helper.Pop(offset_);
    helper.Pop(bgr2rgb_);
    helper.Pop(is_resize_);
    helper.Pop(dst_hw_);
    helper.Pop(interp_mode_);
    kernel_ = std::make_unique<mip::MultiImgPreprocessorKernel>(mean_vals_,
                                                                std_vals_,
                                                                scale_,
                                                                bgr2rgb_,
                                                                is_resize_,
                                                                dst_hw_[1],
                                                                dst_hw_[0],
                                                                interp_mode_);
  }

  MultiImgPreprocessor(const MultiImgPreprocessor&) = delete;
  MultiImgPreprocessor(MultiImgPreprocessor&&) = delete;
  MultiImgPreprocessor& operator=(const MultiImgPreprocessor&) = delete;
  MultiImgPreprocessor& operator=(MultiImgPreprocessor&&) noexcept = delete;

  ~MultiImgPreprocessor() noexcept override {}

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override {
    return (inOut[pos].type == nvinfer1::DataType::kINT8 &&
            inOut[pos].format == nvinfer1::TensorFormat::kLINEAR);
  }

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* /*in*/,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* /*out*/,
                       int32_t nbOutputs) noexcept override {
    assert(nbInputs == 5 && nbOutputs == 1);
  }

  size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                          int32_t nbInputs,
                          const nvinfer1::PluginTensorDesc* outputs,
                          int32_t nbOutputs) const noexcept override {
    return 0;
  }

  int initialize() noexcept override { return 0; }

  void terminate() noexcept override {}

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override {
    const auto& input_dims = inputDesc[0].dims;
    const auto h = input_dims.d[0];
    const auto w = input_dims.d[1];
    const auto c = input_dims.d[2];
    // const bool bgr2rgb = (bgr2rgb_ == 1);
    // const bool is_resize = (is_resize_ == 1);
    // const int dst_h = dst_hw_[0];
    // const int dst_w = dst_hw_[1];
    auto output = outputs[0];
    kernel_->Process(inputs, w, h, c, output, stream);
    return 0;
  }

  size_t getSerializationSize() const noexcept override {
    SerializeHelper helper(nullptr, 0);
    helper.Push(mean_vals_);
    helper.Push(std_vals_);
    helper.Push(scale_);
    helper.Push(offset_);
    helper.Push(bgr2rgb_);
    helper.Push(is_resize_);
    helper.Push(dst_hw_);
    helper.Push(interp_mode_);
    return helper.TotalBytes();
  }

  void serialize(void* buffer) const noexcept override {
    SerializeHelper helper(buffer);
    helper.Push(mean_vals_);
    helper.Push(std_vals_);
    helper.Push(scale_);
    helper.Push(offset_);
    helper.Push(bgr2rgb_);
    helper.Push(is_resize_);
    helper.Push(dst_hw_);
    helper.Push(interp_mode_);
  }

  const char* getPluginType() const noexcept override { return kMultiImgPreprocessorPluginName; }

  const char* getPluginVersion() const noexcept override {
    return kMultiImgPreprocessorPluginVersion;
  }

  void destroy() noexcept override {}

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override {
    auto plugin = new MultiImgPreprocessor(mean_vals_,
                                           std_vals_,
                                           scale_,
                                           offset_,
                                           bgr2rgb_,
                                           is_resize_,
                                           dst_hw_,
                                           interp_mode_);
    plugin->setPluginNamespace(ns_.c_str());
    return plugin;
  }

  void setPluginNamespace(const char* pluginNamespace) noexcept override { ns_ = pluginNamespace; }

  const char* getPluginNamespace() const noexcept override { return ns_.c_str(); }

  int getNbOutputs() const noexcept override { return 1; }

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override {
    nvinfer1::DimsExprs outputs;
    outputs.nbDims = 4;
    outputs.d[0] = exprBuilder.constant(nbInputs);
    outputs.d[1] = inputs[0].d[2];
    const bool is_resize = (is_resize_ == 1);
    if (is_resize) {
      outputs.d[2] = exprBuilder.constant(dst_hw_[0]);
      outputs.d[3] = exprBuilder.constant(dst_hw_[1]);
    } else {
      outputs.d[2] = inputs[0].d[0];
      outputs.d[3] = inputs[0].d[1];
    }
    return outputs;
  }

  nvinfer1::DataType getOutputDataType(int /*index*/,
                                       const nvinfer1::DataType* /*inputTypes*/,
                                       int /*nbInputs*/) const noexcept override {
    return nvinfer1::DataType::kINT8;
  }

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override {}

  void detachFromContext() noexcept override {}

 private:
  std::string ns_;

 private:
  std::array<float, 3> mean_vals_;
  std::array<float, 3> std_vals_;
  float scale_;
  int8_t offset_;
  int32_t bgr2rgb_;
  int32_t is_resize_;
  std::array<int32_t, 2> dst_hw_;
  mip::InterpolationMode interp_mode_;

  std::unique_ptr<mip::MultiImgPreprocessorKernel> kernel_;
};

class MultiImgPreprocessorPluginCreator : public nvinfer1::IPluginCreator {
 public:
  MultiImgPreprocessorPluginCreator() {
    attrs_.emplace_back("mean");
    attrs_.emplace_back("std");
    attrs_.emplace_back("scale");
    attrs_.emplace_back("offset");
    attrs_.emplace_back("bgr2rgb");
    attrs_.emplace_back("is_resize");
    attrs_.emplace_back("dst_hw");
    attrs_.emplace_back("interp_mode");
    fc_.nbFields = attrs_.size();
    fc_.fields = attrs_.data();
  }

  ~MultiImgPreprocessorPluginCreator() noexcept override {}

  nvinfer1::AsciiChar const* getPluginVersion() const noexcept override {
    return kMultiImgPreprocessorPluginVersion;
  }

  nvinfer1::AsciiChar const* getPluginName() const noexcept override {
    return kMultiImgPreprocessorPluginName;
  }

  nvinfer1::PluginFieldCollection const* getFieldNames() noexcept override { return &fc_; }

  nvinfer1::IPluginV2Ext* createPlugin(
      nvinfer1::AsciiChar const* /*name*/,
      nvinfer1::PluginFieldCollection const* fc) noexcept override {
    std::array<float, 3> mean_vals;
    std::array<float, 3> std_vals;
    float scale = 1;
    int8_t offset = 0;
    int32_t bgr2rgb = 1;
    int32_t is_resize = 1;
    std::array<int32_t, 2> dst_hw;
    mip::InterpolationMode interp_mode = mip::InterpolationMode::kLinear;

    AttrHelper helper(*fc);
    helper.GetItem("mean", mean_vals);
    helper.GetItem("std", std_vals);
    helper.GetItem("scale", scale);
    helper.GetItem("offset", offset);
    helper.GetItem("bgr2rgb", bgr2rgb);
    helper.GetItem("is_resize", is_resize);
    helper.GetItem("dst_hw", dst_hw);
    helper.GetItem("interp_mode", interp_mode);
    auto obj = new MultiImgPreprocessor(mean_vals,
                                        std_vals,
                                        scale,
                                        offset,
                                        bgr2rgb,
                                        is_resize,
                                        dst_hw,
                                        interp_mode);
    obj->setPluginNamespace(ns_.c_str());
    return obj;
  }

  nvinfer1::IPluginV2Ext* deserializePlugin(nvinfer1::AsciiChar const* /*name*/,
                                            void const* serialData,
                                            size_t serialLength) noexcept override {
    auto obj = new MultiImgPreprocessor(serialData, serialLength);
    obj->setPluginNamespace(ns_.c_str());
    return obj;
  }

  void setPluginNamespace(nvinfer1::AsciiChar const* libNamespace) noexcept override {
    if (libNamespace != nullptr) {
      ns_ = libNamespace;
    }
  }

  nvinfer1::AsciiChar const* getPluginNamespace() const noexcept override { return ns_.c_str(); }

 private:
  std::string ns_;
  nvinfer1::PluginFieldCollection fc_;
  std::vector<nvinfer1::PluginField> attrs_;
};

REGISTER_TENSORRT_PLUGIN(MultiImgPreprocessorPluginCreator);

}  // namespace trt
}  // namespace ops
}  // namespace linfer