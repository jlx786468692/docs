#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <stdexcept>
#include <type_traits>

#include "common_helper.hpp"
#include "multi_img_preprocessor.h"

namespace mip {

struct ImgArray {
  const uint8_t* __restrict__ imgs[5];
  __device__ const uint8_t* operator[](size_t i) const { return imgs[i]; }
  __device__ constexpr size_t Size() const { return sizeof(imgs) / sizeof(imgs[0u]); }
};

constexpr std::tuple<std::array<float, 3>, std::array<float, 3>> InitParams(
    const std::array<float, 3>& mean_vals,
    const std::array<float, 3>& std_vals,
    float scale) {
  const float s0 = 1 / (std_vals[0] * scale);
  const float s1 = 1 / (std_vals[1] * scale);
  const float s2 = 1 / (std_vals[2] * scale);
  const float z0 = -mean_vals[0] / (std_vals[0] * scale);
  const float z1 = -mean_vals[1] / (std_vals[1] * scale);
  const float z2 = -mean_vals[2] / (std_vals[2] * scale);
  return std::tuple<std::array<float, 3>, std::array<float, 3>>{std::array<float, 3>{s0, s1, s2},
                                                                std::array<float, 3>{z0, z1, z2}};
}
constexpr std::array<ssize_t, 3> CvtFloatToInt(const std::array<float, 3>& vals, ssize_t factor) {
  return {ssize_t(vals[0] * factor), ssize_t(vals[1] * factor), ssize_t(vals[2] * factor)};
}

bool IsFloatArrayEq(const std::array<float, 3>& src, const float* dst) {
  namespace fp = linfer::ops::trt::fp;
  return fp::CmpEqual(src[0], dst[0]) && fp::CmpEqual(src[1], dst[1]) &&
         fp::CmpEqual(src[2], dst[2]);
}

template <size_t Index, typename... Args>
struct ArgAt;
template <typename TFirst, typename... TRest>
struct ArgAt<0, TFirst, TRest...> {
  using Type = TFirst;
};
template <size_t Index, typename TFirst, typename... TRest>
struct ArgAt<Index, TFirst, TRest...> {
  using Type = typename ArgAt<Index - 1, TRest...>::Type;
};
template <size_t Index, typename... Args>
using ArgTypeAt = typename ArgAt<Index, Args...>::Type;
template <size_t Index, typename TDefault, typename... Args>
__device__ constexpr auto ArgVal(TDefault val) ->
    typename std::enable_if<(sizeof...(Args) == 0), TDefault>::type {
  return val;
}
template <size_t Index, typename TDefault, typename TFirst, typename... TRest>
__device__ constexpr auto ArgVal(TDefault, TFirst&& first, TRest&&... rest) ->
    typename std::enable_if<(Index == 0), TFirst>::type {
  return first;
}
template <size_t Index, typename TDefault, typename TFirst, typename... TRest>
__device__ constexpr auto ArgVal(TDefault val, TFirst&& first, TRest&&... rest) ->
    typename std::enable_if<(Index > 0), ArgTypeAt<Index, TFirst, TRest...>>::type {
  return ArgVal<Index - 1, TDefault>(val, std::forward<TRest>(rest)...);
}

template <int W = 1024, int H = 768, int C = 3>
struct MultiImgPreprocessConfig {
  static constexpr const int width = W;
  static constexpr const int height = H;
  static constexpr const int channels = C;
};

template <bool BGR2RGB = true>
struct FormatConfig {
  static constexpr const bool bgr2rgb = BGR2RGB;
};

template <bool RESIZE = true,
          int DST_W = 704,
          int DST_H = 528,
          mip::InterpolationMode InterpMode = mip::InterpolationMode::kLinear>
struct ResizeConfig {
  static constexpr const bool is_resize = RESIZE;
  static constexpr const int dst_width = DST_W;
  static constexpr const int dst_height = DST_H;
  static constexpr const mip::InterpolationMode interp_mode = InterpMode;
};

template <ssize_t S0 = 1, ssize_t S1 = 1, ssize_t S2 = 1>
struct ScaleConfig {
  static constexpr const ssize_t s0 = S0;
  static constexpr const ssize_t s1 = S1;
  static constexpr const ssize_t s2 = S2;
};

template <ssize_t Z0 = 0, ssize_t Z1 = 0, ssize_t Z2 = 0>
struct ZeroPointConfig {
  static constexpr const ssize_t z0 = Z0;
  static constexpr const ssize_t z1 = Z1;
  static constexpr const ssize_t z2 = Z2;
};

template <ssize_t FACTOR = 1000000>
struct FactorConfig {
  static constexpr const ssize_t factor = FACTOR;
};

template <typename ScaleCfg = ScaleConfig<>,          //
          typename ZeroPointCfg = ZeroPointConfig<>,  //
          typename FactorCfg = FactorConfig<>>        //
struct QuantizeConfig {
  using Scale = ScaleCfg;
  using ZeroPoint = ZeroPointCfg;
  using Factor = FactorCfg;
};

namespace v0 {

template <typename T, size_t N>
struct Pixel {
  T data[N];
  __device__ T& operator[](size_t i) { return data[i]; }
  __device__ const T& operator[](size_t i) const { return data[i]; }

  __device__ Pixel<float, N> operator*(float scalar) const {
    Pixel<float, N> result;
    for (size_t i = 0; i < N; ++i) {
      result[i] = static_cast<float>(float(data[i]) * scalar);
    }
    return result;
  }

  __device__ Pixel<float, N> operator/(float scalar) const {
    Pixel<float, N> result;
    for (size_t i = 0; i < N; ++i) {
      result[i] = static_cast<float>(data[i] / scalar);
    }
    return result;
  }

  __device__ Pixel<float, N> operator+(const Pixel<float, N>& other) const {
    Pixel<float, N> result;
    for (size_t i = 0; i < N; ++i) {
      result[i] = static_cast<float>(float(data[i])) + other[i];
    }
    return result;
  }

  __device__ Pixel<float, N> operator-(const Pixel<float, N>& other) const {
    Pixel<float, N> result;
    for (size_t i = 0; i < N; ++i) {
      result[i] = static_cast<float>(float(data[i])) - other[i];
    }
    return result;
  }
};

__device__ int RoundSafe(float x) {
  float int_part;
  float frac_part = modff(x, &int_part);  // 分离整数和小数部分
  if (frac_part >= 0.5f) {
    return static_cast<int>(int_part) + 1;
  } else if (frac_part <= -0.5f) {
    return static_cast<int>(int_part) - 1;
  } else {
    return static_cast<int>(int_part);
  }
}

template <typename ImgCfg = MultiImgPreprocessConfig<>,  //
          typename ResizeCfg = ResizeConfig<>,           //
          typename FormatCfg = FormatConfig<>,           //
          typename QuantizeCfg = QuantizeConfig<>        //
          >
struct FullConfig {
  using Img = ImgCfg;
  using Resize = ResizeCfg;
  using Format = FormatCfg;
  using Quantize = QuantizeCfg;
};

template <typename Config = FullConfig<>, typename... Args>
__global__ void MultiImgPreprocessImplGeneric(const ImgArray imgs,
                                              int8_t* __restrict__ output,
                                              Args... args) {
  const auto w = ArgVal<0>(Config::Img::width, args...);
  const auto h = ArgVal<1>(Config::Img::height, args...);
  const auto c = ArgVal<2>(Config::Img::channels, args...);
  const auto bgr2rgb = ArgVal<3>(Config::Format::bgr2rgb, args...);
  const auto is_resize = ArgVal<4>(Config::Resize::is_resize, args...);
  auto dst_width = ArgVal<5>(Config::Resize::dst_width, args...);
  auto dst_height = ArgVal<6>(Config::Resize::dst_height, args...);
  const auto interp_mode = ArgVal<7>(Config::Resize::dst_height, args...);
  using cq = typename Config::Quantize;
  const auto s0 = ArgVal<8>(cq::Scale::s0 / float(cq::Factor::factor), args...);
  const auto s1 = ArgVal<9>(cq::Scale::s1 / float(cq::Factor::factor), args...);
  const auto s2 = ArgVal<10>(cq::Scale::s2 / float(cq::Factor::factor), args...);
  const auto z0 = ArgVal<11>(cq::ZeroPoint::z0 / float(cq::Factor::factor), args...);
  const auto z1 = ArgVal<12>(cq::ZeroPoint::z1 / float(cq::Factor::factor), args...);
  const auto z2 = ArgVal<13>(cq::ZeroPoint::z2 / float(cq::Factor::factor), args...);
  (void)interp_mode;
  if (is_resize == false) {
    dst_width = w;
    dst_height = h;
  }
  const auto index = blockIdx.x * blockDim.x + threadIdx.x;
  if (index < dst_width * dst_height) {
    const auto scale_x = float(w) / dst_width;
    const auto scale_y = float(h) / dst_height;
    const auto img_size = dst_width * dst_height * c;
    const auto kPixelCount = 2;
#pragma unroll
    for (unsigned j = 0; j < kPixelCount; j++) {
      const auto indexr = index * kPixelCount + j;
      auto out0 = output + 0 * dst_width * dst_height + indexr;
      auto out1 = output + 1 * dst_width * dst_height + indexr;
      auto out2 = output + 2 * dst_width * dst_height + indexr;
      const int y_dst = indexr / dst_width;
      const int x_dst = indexr - y_dst * dst_width;
      const int y_src = is_resize ? __float2int_rd(y_dst * scale_y) : y_dst;
      const int x_src = is_resize ? __float2int_rd(x_dst * scale_x) : x_dst;
      const auto elem_index = (y_src * w + x_src) * c;
#pragma unroll
      for (unsigned i = 0; i < imgs.Size(); i++) {
        const uint8_t* pt = imgs[i] + elem_index;
        uint8_t b;
        uint8_t g;
        uint8_t r;
        if (bgr2rgb) {
          b = pt[0];
          g = pt[1];
          r = pt[2];
        } else {
          r = pt[0];
          g = pt[1];
          b = pt[2];
        }
        const auto ind = i * img_size;
        out0[ind] = int8_t(max(min(__float2int_rn(fmaf(r, s0, z0)), 127), -128));
        out1[ind] = int8_t(max(min(__float2int_rn(fmaf(g, s1, z1)), 127), -128));
        out2[ind] = int8_t(max(min(__float2int_rn(fmaf(b, s2, z2)), 127), -128));
      }
    }
  }
}

template <typename Config>
__global__ void MultiImgPreprocessImpl(const ImgArray imgs, int8_t* __restrict__ output) {
  constexpr auto w = Config::Img::width;
  constexpr auto h = Config::Img::height;
  constexpr auto c = Config::Img::channels;
  constexpr auto bgr2rgb = Config::Format::bgr2rgb;
  constexpr auto is_resize = Config::Resize::is_resize;
  constexpr auto dst_width = Config::Resize::dst_width;
  constexpr auto dst_height = Config::Resize::dst_height;
  constexpr auto interp_mode = Config::Resize::interp_mode;
  constexpr auto s0 = Config::Quantize::Scale::s0 / float(Config::Quantize::Factor::factor);
  constexpr auto s1 = Config::Quantize::Scale::s1 / float(Config::Quantize::Factor::factor);
  constexpr auto s2 = Config::Quantize::Scale::s2 / float(Config::Quantize::Factor::factor);
  constexpr auto z0 = Config::Quantize::ZeroPoint::z0 / float(Config::Quantize::Factor::factor);
  constexpr auto z1 = Config::Quantize::ZeroPoint::z1 / float(Config::Quantize::Factor::factor);
  constexpr auto z2 = Config::Quantize::ZeroPoint::z2 / float(Config::Quantize::Factor::factor);
  (void)is_resize;
  (void)interp_mode;
  constexpr auto scale_x = float(w) / dst_width;
  constexpr auto scale_y = float(h) / dst_height;
  constexpr auto kDealPixelCount = 2;
  constexpr auto kIndexMax = (dst_width + kDealPixelCount - 1) / kDealPixelCount;
  constexpr auto kIsDivisible = dst_width % kDealPixelCount == 0;
  // using InputType = uint8_t[h][w][c];
  using InputType = Pixel<uint8_t, 3>[h][w];
  using OutputType = int8_t[imgs.Size()][c][dst_height][dst_width];

  const auto x = blockIdx.x * blockDim.x + threadIdx.x;
  const auto y = blockIdx.y * blockDim.y + threadIdx.y;
  if (kIsDivisible ? true : (x < kIndexMax && y < dst_height)) {
    auto& outimg = *(OutputType*)(output);
    const auto y_dst = y;
    //
    const auto y_src = (y_dst + 0.5f) * scale_y - 0.5f;
    const auto y_src_floor = floor(y_src);
    const auto y_src_ceil = ceil(y_src);
    const auto y_src_lerp = y_src - y_src_floor;

    const auto pixel = [&imgs](int idx, int x0, int y0) {
      const auto& img = *(const InputType*)(imgs[idx]);
      x0 = max(min(x0, w - 1), 0);
      y0 = max(min(y0, h - 1), 0);
      return img[y0][x0];
    };

    const auto r = [&pixel, scale_x, y_src_floor, y_src_ceil, y_src_lerp](int idx, int x_dst) {
      const auto x_src = (x_dst + 0.5f) * scale_x - 0.5f;
      const auto x_src_floor = floor(x_src);
      const auto x_src_ceil = ceil(x_src);
      const auto x_src_lerp = x_src - x_src_floor;

      const auto r1 = [&pixel, x_src_lerp, y_src_floor, x_src_floor, x_src_ceil](int idx) {
        const auto x0 = x_src_floor;
        const auto x1 = x_src_ceil;
        const auto y = y_src_floor;
        return pixel(idx, x0, y) * (1 - x_src_lerp) + pixel(idx, x1, y) * x_src_lerp;
      };

      const auto r2 = [&pixel, x_src_lerp, y_src_ceil, x_src_floor, x_src_ceil](int idx) {
        const auto x0 = x_src_floor;
        const auto x1 = x_src_ceil;
        const auto y = y_src_ceil;
        return pixel(idx, x0, y) * (1 - x_src_lerp) + pixel(idx, x1, y) * x_src_lerp;
      };

      auto bgr = r1(idx) * (1 - y_src_lerp) + r2(idx) * y_src_lerp;
      bgr[0] = fmaxf(fminf(roundf(bgr[0]), 255.f), 0.f);
      bgr[1] = fmaxf(fminf(roundf(bgr[1]), 255.f), 0.f);
      bgr[2] = fmaxf(fminf(roundf(bgr[2]), 255.f), 0.f);
      return bgr;
    };

    // const auto r = [&pixel](int idx, int x_dst) {
    //   const auto y_src = __float2uint_rd(y_dst * scale_y);
    //   const auto x_src = __float2uint_rd(x_dst * scale_x);
    //   return pixel(idx, x_src, y_src);
    // };

    for (unsigned j = 0; j < kDealPixelCount; j++) {
      const auto tmp = x * kDealPixelCount + j;
      const auto x_dst = kIsDivisible ? tmp : min(tmp, dst_width - 1);

      for (unsigned i = 0; i < imgs.Size(); i++) {
        const auto& bgr = r(i, x_dst);
        float b;
        float g;
        float r;
        if (bgr2rgb) {
          b = bgr[0];
          g = bgr[1];
          r = bgr[2];
        } else {
          r = bgr[0];
          g = bgr[1];
          b = bgr[2];
        }
        outimg[i][0][y_dst][x_dst] = int8_t(max(min(__float2int_rn(fmaf(r, s0, z0)), 127), -128));
        outimg[i][1][y_dst][x_dst] = int8_t(max(min(__float2int_rn(fmaf(g, s1, z1)), 127), -128));
        outimg[i][2][y_dst][x_dst] = int8_t(max(min(__float2int_rn(fmaf(b, s2, z2)), 127), -128));
      }
    }
  }
}

void MultiImgPreprocess(const void* const* imgs,
                        int w,
                        int h,
                        int c,
                        const float s[3],
                        const float z[3],
                        bool bgr2rgb,
                        bool is_resize,
                        int dst_width,
                        int dst_height,
                        mip::InterpolationMode interp_mode,
                        void* output,
                        cudaStream_t stream) {
  static constexpr const auto kW = 1024;
  static constexpr const auto kH = 768;
  static constexpr const auto kC = 3;
  static constexpr const auto kBgr2rgb = true;
  static constexpr const auto kIsResize = true;
  static constexpr const auto kDstWidth = 704;
  static constexpr const auto kDstHeight = 528;
  static constexpr const auto kInterpMode = mip::InterpolationMode::kLinear;
  static constexpr const std::array<float, 3> kImageMean{123.675f, 116.28f, 103.53f};
  static constexpr const std::array<float, 3> kImageStd{58.395f, 57.12f, 57.375f};
  static constexpr const float kScale = 0.02070588245987892;
  static constexpr const auto kSZ = InitParams(kImageMean, kImageStd, kScale);
  static constexpr const auto kS = std::get<0>(kSZ);
  static constexpr const auto kZ = std::get<1>(kSZ);
  static constexpr const auto kFactor = 1000000l;
  static constexpr const auto kSInt = CvtFloatToInt(kS, kFactor);
  static constexpr const auto kZInt = CvtFloatToInt(kZ, kFactor);
  ImgArray inputs;
  std::memcpy((void*)inputs.imgs, imgs, sizeof(inputs.imgs));
  if (kW == w && kH == h && kC == c && kBgr2rgb == bgr2rgb && kIsResize == is_resize &&
      kDstWidth == dst_width && kDstHeight == dst_height && kInterpMode == interp_mode &&
      IsFloatArrayEq(kS, s) && IsFloatArrayEq(kZ, z)) {
    static constexpr const dim3 kBlockSize(32, 16);
    const dim3 kGridDim((kDstWidth / 2 + kBlockSize.x - 1) / kBlockSize.x,
                        (kDstHeight + kBlockSize.y - 1) / kBlockSize.y);
    using ParamConfig = FullConfig<
        MultiImgPreprocessConfig<kW, kH, kC>,  // 原图宽高
        ResizeConfig<kIsResize,
                     kDstWidth,
                     kDstHeight,
                     kInterpMode>,                                 // 是否resize,以及resize后的宽高
        FormatConfig<kBgr2rgb>,                                    // 是否由bgr转rgb
        QuantizeConfig<ScaleConfig<kSInt[0], kSInt[1], kSInt[2]>,  // 融合后每个通道的scale
                       ZeroPointConfig<kZInt[0], kZInt[1], kZInt[2]>,  // 融合后每个通道的offset
                       FactorConfig<kFactor>  // 融合后通过模板传递时候的缩放倍数
                       >>;
    MultiImgPreprocessImpl<ParamConfig>
        <<<kGridDim, kBlockSize, 0, stream>>>(inputs, (int8_t*)(output));
  } else {
    if (is_resize == false) {
      dst_width = w;
      dst_height = h;
    }
    const auto kBlockSize = 512;
    const auto kGridDim = (dst_width * dst_height / 2 + kBlockSize - 1) / kBlockSize;
    MultiImgPreprocessImplGeneric<><<<kGridDim, kBlockSize, 0, stream>>>(inputs,
                                                                         (int8_t*)(output),
                                                                         w,
                                                                         h,
                                                                         c,
                                                                         bgr2rgb,
                                                                         is_resize,
                                                                         dst_width,
                                                                         dst_height,
                                                                         interp_mode,
                                                                         s[0],
                                                                         s[1],
                                                                         s[2],
                                                                         z[0],
                                                                         z[1],
                                                                         z[2]);
  }
}

}  // namespace v0

// namespace v1 {
// template <typename ImgCfg = MultiImgPreprocessConfig<>,  //
//           typename ResizeCfg = ResizeConfig<>,           //
//           typename FormatCfg = FormatConfig<>            //
//           >
// struct FullConfig {
//   using Img = ImgCfg;
//   using Resize = ResizeCfg;
//   using Format = FormatCfg;
// };
// template <typename Config = FullConfig<>, typename... Args>
// __global__ void MultiImgPreprocessImpl(const ImgArray imgs,
//                                        const int8_t* __restrict__ table,
//                                        int8_t* __restrict__ output,
//                                        Args... args) {
//   const auto w = ArgVal<0>(Config::Img::width, args...);
//   const auto h = ArgVal<1>(Config::Img::height, args...);
//   const auto c = ArgVal<2>(Config::Img::channels, args...);
//   const auto bgr2rgb = ArgVal<3>(Config::Format::bgr2rgb, args...);
//   const auto is_resize = ArgVal<4>(Config::Resize::is_resize, args...);
//   const auto dst_width = ArgVal<5>(Config::Resize::dst_width, args...);
//   const auto dst_height = ArgVal<6>(Config::Resize::dst_height, args...);
//   (void)is_resize;
//   const auto index = blockIdx.x * blockDim.x + threadIdx.x;
//   if (index < dst_width * dst_height) {
//     const auto scale_x = float(w) / dst_width;
//     const auto scale_y = float(h) / dst_height;
//     const auto img_size = dst_width * dst_height * c;
//     const auto t0 = (const int8_t*)table + 0 * 256;
//     const auto t1 = (const int8_t*)table + 1 * 256;
//     const auto t2 = (const int8_t*)table + 2 * 256;
//     const auto kPixelCount = 2;
// #pragma unroll
//     for (unsigned j = 0; j < kPixelCount; j++) {
//       const auto indexr = index * kPixelCount + j;
//       const int y_dst = indexr / dst_width;
//       const int x_dst = indexr - y_dst * dst_width;
//       const int x_src = __float2int_rd(x_dst * scale_x);
//       const int y_src = __float2int_rd(y_dst * scale_y);
//       const auto elem_index = (y_src * w + x_src) * c;
// #pragma unroll
//       for (unsigned i = 0; i < imgs.Size(); i++) {
//         const uint8_t* pt = imgs[i] + elem_index;
//         uint8_t b;
//         uint8_t r;
//         uint8_t g;
//         if (bgr2rgb) {
//           b = pt[0];
//           g = pt[1];
//           r = pt[2];
//         } else {
//           r = pt[0];
//           g = pt[1];
//           b = pt[2];
//         }
//         int8_t* out_base = output + indexr + i * img_size;
//         out_base[0 * dst_width * dst_height] = t0[r];
//         out_base[1 * dst_width * dst_height] = t1[g];
//         out_base[2 * dst_width * dst_height] = t2[b];
//       }
//     }
//   }
// }

// void MultiImgPreprocess(const void* const* imgs,
//                         int w,
//                         int h,
//                         int c,
//                         const int8_t* table,
//                         bool bgr2rgb,
//                         bool is_resize,
//                         int dst_width,
//                         int dst_height,
//                         mip::InterpolationMode interp_mode,
//                         void* output,
//                         cudaStream_t stream) {
//   static constexpr const auto kW = 1024;
//   static constexpr const auto kH = 768;
//   static constexpr const auto kC = 3;
//   static constexpr const auto kBgr2rgb = true;
//   static constexpr const auto kIsResize = true;
//   static constexpr const auto kDstWidth = 704;
//   static constexpr const auto kDstHeight = 528;

//   const auto kBlockSize = 512;
//   const auto kGridDim = (dst_width * dst_height + (kBlockSize * 2) - 1) / (kBlockSize * 2);
//   ImgArray inputs;
//   std::memcpy((void*)inputs.imgs, imgs, sizeof(inputs.imgs));
//   if (kW == w && kH == h && kC == c && kBgr2rgb == bgr2rgb && kIsResize == is_resize &&
//       kDstWidth == dst_width && kDstHeight == dst_height) {
//     using ParamConfig = FullConfig<MultiImgPreprocessConfig<kW, kH, kC>,  // 原图宽高
//                                    ResizeConfig<kIsResize,
//                                                 kDstWidth,
//                                                 kDstHeight>,  // 是否resize,以及resize后的宽高
//                                    FormatConfig<kBgr2rgb>     // 是否由bgr转rgb
//                                    >;
//     MultiImgPreprocessImpl<ParamConfig>
//         <<<kGridDim, kBlockSize, 0, stream>>>(inputs, table, (int8_t*)(output));
//   } else {
//     MultiImgPreprocessImpl<><<<kGridDim, kBlockSize, 0, stream>>>(inputs,
//                                                                   table,
//                                                                   (int8_t*)(output),
//                                                                   w,
//                                                                   h,
//                                                                   c,
//                                                                   bgr2rgb,
//                                                                   is_resize,
//                                                                   dst_width,
//                                                                   dst_height);
//   }
// }
// }  // namespace v1

// namespace v2 {

// __global__ void MultiImgPreprocessImpl(const uint8_t* __restrict__ img0,
//                                        const uint8_t* __restrict__ img1,
//                                        const uint8_t* __restrict__ img2,
//                                        const uint8_t* __restrict__ img3,
//                                        const uint8_t* __restrict__ img4,
//                                        int w,
//                                        int h,
//                                        int c,
//                                        const int8_t* __restrict__ table,
//                                        bool bgr2rgb,
//                                        bool is_resize,
//                                        int dst_width,
//                                        int dst_height,
//                                        int8_t* __restrict__ output) {
//   int x = blockIdx.x * blockDim.x + threadIdx.x;
//   int y = blockIdx.y * blockDim.y + threadIdx.y;
//   if (x < 5 && y < dst_width * dst_height) {
//     const auto t0 = (const int8_t*)table + 0 * 256;
//     const auto t1 = (const int8_t*)table + 1 * 256;
//     const auto t2 = (const int8_t*)table + 2 * 256;
//     const auto kImgSize = c * dst_width * dst_height;
//     const auto k0Hw = 0 * dst_width * dst_height;
//     const auto k1Hw = 1 * dst_width * dst_height;
//     const auto k2Hw = 2 * dst_width * dst_height;

//     const uint8_t* imgs[]{img0, img1, img2, img3, img4};

//     const auto scale_x = float(w) / dst_width;
//     const auto scale_y = float(h) / dst_height;
//     int y_dst = y / dst_width;
//     int x_dst = y % dst_width;
//     int x_src = min(__float2int_rd(x_dst * scale_x), w - 1);
//     int y_src = min(__float2int_rd(y_dst * scale_y), h - 1);
//     const uint8_t* pt = imgs[x] + (y_src * w + x_src) * c;

//     const uint8_t r = (bgr2rgb ? pt[2] : pt[0]);
//     const uint8_t g = pt[1];
//     const uint8_t b = (bgr2rgb ? pt[0] : pt[2]);

//     const auto kxImgSize = x * kImgSize + y;
//     output[kxImgSize + k0Hw] = t0[r];
//     output[kxImgSize + k1Hw] = t1[g];
//     output[kxImgSize + k2Hw] = t2[b];
//   }
// }

// void MultiImgPreprocess(const void* const* imgs,
//                         int w,
//                         int h,
//                         int c,
//                         const int8_t* table,
//                         bool bgr2rgb,
//                         bool is_resize,
//                         int dst_width,
//                         int dst_height,
//                         mip::InterpolationMode interp_mode,
//                         void* output,
//                         cudaStream_t stream) {
//   const auto img0 = (const uint8_t*)(imgs[0]);
//   const auto img1 = (const uint8_t*)(imgs[1]);
//   const auto img2 = (const uint8_t*)(imgs[2]);
//   const auto img3 = (const uint8_t*)(imgs[3]);
//   const auto img4 = (const uint8_t*)(imgs[4]);
//   auto outimg = (int8_t*)(output);
//   const dim3 kBlockSize(1, 1024);
//   const dim3 kGridDim(5, dst_width * dst_height / 1024);
//   MultiImgPreprocessImpl<<<kGridDim, kBlockSize, 0, stream>>>(img0,
//                                                               img1,
//                                                               img2,
//                                                               img3,
//                                                               img4,
//                                                               w,
//                                                               h,
//                                                               c,
//                                                               table,
//                                                               bgr2rgb,
//                                                               is_resize,
//                                                               dst_width,
//                                                               dst_height,
//                                                               outimg);
// }
// }  // namespace v2

// namespace v3 {

// __global__ void MultiImgPreprocessImpl(const uint8_t* __restrict__ img0,
//                                        const uint8_t* __restrict__ img1,
//                                        const uint8_t* __restrict__ img2,
//                                        const uint8_t* __restrict__ img3,
//                                        const uint8_t* __restrict__ img4,
//                                        int w,
//                                        int h,
//                                        int c,
//                                        const int8_t* __restrict__ table,
//                                        bool bgr2rgb,
//                                        bool is_resize,
//                                        int dst_width,
//                                        int dst_height,
//                                        int8_t* __restrict__ output) {
//   int x = blockIdx.x * blockDim.x + threadIdx.x;
//   int y = blockIdx.y * blockDim.y + threadIdx.y;
//   // __shared__ int8_t shared_table[kTableSize];
//   // const auto tid = threadIdx.y;
//   // if (tid < kTableSize / 16) {
//   //     auto srcptr = (const uint32_t*)table;
//   //     auto dstptr = (uint32_t*)shared_table;
//   //     dstptr[tid * 4 + 0] = srcptr[tid * 4 + 0];
//   //     dstptr[tid * 4 + 1] = srcptr[tid * 4 + 1];
//   //     dstptr[tid * 4 + 2] = srcptr[tid * 4 + 2];
//   //     dstptr[tid * 4 + 3] = srcptr[tid * 4 + 3];
//   // }
//   // __syncthreads();
//   // table = (const int8_t*)shared_table;

//   const uint8_t* const imgs[]{img0, img1, img2, img3, img4};
//   const auto t0 = (const int8_t*)table + 0 * 256;
//   const auto t1 = (const int8_t*)table + 1 * 256;
//   const auto t2 = (const int8_t*)table + 2 * 256;
//   const auto out0 = output + x * c * dst_width * dst_height + 0 * dst_width * dst_height;
//   const auto out1 = output + x * c * dst_width * dst_height + 1 * dst_width * dst_height;
//   const auto out2 = output + x * c * dst_width * dst_height + 2 * dst_width * dst_height;
//   const auto scale_x = float(w) / dst_width;
//   const auto scale_y = float(h) / dst_height;
//   const auto img = imgs[x];
// #pragma unroll
//   for (int i = 0; i < 5; i++) {
//     auto yr = y * 5 + i;
//     if (yr < dst_width * dst_height) {
//       int y_dst = yr / dst_width;
//       int x_dst = yr % dst_width;
//       int x_src = min(__float2int_rd(x_dst * scale_x), w - 1);
//       int y_src = min(__float2int_rd(y_dst * scale_y), h - 1);
//       const uint8_t* pt = img + (y_src * w + x_src) * c;

//       const uint8_t r = (bgr2rgb ? pt[2] : pt[0]);
//       const uint8_t g = pt[1];
//       const uint8_t b = (bgr2rgb ? pt[0] : pt[2]);

//       // const auto v0 = tex1Dfetch<int8_t>(table, r + 0 * 256);
//       // const auto v1 = tex1Dfetch<int8_t>(table, g + 1 * 256);
//       // const auto v2 = tex1Dfetch<int8_t>(table, b + 2 * 256);

//       out0[yr] = t0[r];
//       out1[yr] = t1[g];
//       out2[yr] = t2[b];
//     }
//   }
// }

// void MultiImgPreprocess(const void* const* imgs,
//                         int w,
//                         int h,
//                         int c,
//                         const int8_t* table,
//                         bool bgr2rgb,
//                         bool is_resize,
//                         int dst_width,
//                         int dst_height,
//                         mip::InterpolationMode interp_mode,
//                         void* output,
//                         cudaStream_t stream) {
//   const auto img0 = (const uint8_t*)(imgs[0]);
//   const auto img1 = (const uint8_t*)(imgs[1]);
//   const auto img2 = (const uint8_t*)(imgs[2]);
//   const auto img3 = (const uint8_t*)(imgs[3]);
//   const auto img4 = (const uint8_t*)(imgs[4]);
//   auto outimg = (int8_t*)(output);
//   static const dim3 kBlockSize(1, 1024);
//   static const dim3 kGridDim(5, dst_width * dst_height / 1024 / 5 + 1);
//   MultiImgPreprocessImpl<<<kGridDim, kBlockSize, 0, stream>>>(img0,
//                                                               img1,
//                                                               img2,
//                                                               img3,
//                                                               img4,
//                                                               w,
//                                                               h,
//                                                               c,
//                                                               table,
//                                                               bgr2rgb,
//                                                               is_resize,
//                                                               dst_width,
//                                                               dst_height,
//                                                               outimg);
// }
// }  // namespace v3

class MultiImgPreprocessorKernel::Impl final {
 public:
  Impl(const std::array<float, 3>& mean_vals,
       const std::array<float, 3>& std_vals,
       float scale,
       bool bgr2rgb,
       bool is_resize,
       int dst_width,
       int dst_height,
       mip::InterpolationMode interp_mode)
      : bgr2rgb_(bgr2rgb),
        is_resize_(is_resize),
        dst_width_(dst_width),
        dst_height_(dst_height),
        interp_mode_(interp_mode) {
    InitParams(mean_vals, std_vals, scale, s_, z_);
    dtable_ = GenerateTable(true);
    // ttable_ = CreateTextureObj(dtable_.get());
  }
  ~Impl() {
    // DestroyTextureObj(ttable_);
    dtable_ = nullptr;
  }
  void Process(const void* const* imgs,
               int w,
               int h,
               int c,
               void* output,
               cudaStream_t stream,
               int ver) const {
    // switch (ver) {
    //   case 0:
    //     v0::MultiImgPreprocess(imgs,
    //                            w,
    //                            h,
    //                            c,
    //                            s_,
    //                            z_,
    //                            bgr2rgb_,
    //                            is_resize_,
    //                            dst_width_,
    //                            dst_height_,
    //                            interp_mode_,
    //                            output,
    //                            stream);
    //     break;
    //   case 1:
    //     v1::MultiImgPreprocess(imgs,
    //                            w,
    //                            h,
    //                            c,
    //                            dtable_.get(),
    //                            bgr2rgb_,
    //                            is_resize_,
    //                            dst_width_,
    //                            dst_height_,
    //                            interp_mode_,
    //                            output,
    //                            stream);
    //     break;
    //   case 2:
    //     v2::MultiImgPreprocess(imgs,
    //                            w,
    //                            h,
    //                            c,
    //                            dtable_.get(),
    //                            bgr2rgb_,
    //                            is_resize_,
    //                            dst_width_,
    //                            dst_height_,
    //                            interp_mode_,
    //                            output,
    //                            stream);
    //     break;
    //   case 3:
    //     v3::MultiImgPreprocess(imgs,
    //                            w,
    //                            h,
    //                            c,
    //                            dtable_.get(),
    //                            bgr2rgb_,
    //                            is_resize_,
    //                            dst_width_,
    //                            dst_height_,
    //                            interp_mode_,
    //                            output,
    //                            stream);
    //     break;
    //   default:
    v0::MultiImgPreprocess(imgs,
                           w,
                           h,
                           c,
                           s_,
                           z_,
                           bgr2rgb_,
                           is_resize_,
                           dst_width_,
                           dst_height_,
                           interp_mode_,
                           output,
                           stream);
    //     break;
    // }
  }

 private:
  void InitParams(const std::array<float, 3>& mean_vals,
                  const std::array<float, 3>& std_vals,
                  float scale,
                  float* s,
                  float* z) {
    s[0] = 1 / (std_vals[0] * scale);
    s[1] = 1 / (std_vals[1] * scale);
    s[2] = 1 / (std_vals[2] * scale);
    z[0] = -mean_vals[0] / (std_vals[0] * scale);
    z[1] = -mean_vals[1] / (std_vals[1] * scale);
    z[2] = -mean_vals[2] / (std_vals[2] * scale);
  }

  std::shared_ptr<int8_t> GenerateTable(bool on_device) {
    const float* s = s_;
    const float* z = z_;
    std::shared_ptr<int8_t> hptr((int8_t*)malloc(kTableSize), [](int8_t* ptr) { free(ptr); });
    int8_t* table = hptr.get();
    namespace hp = linfer::ops::trt;
    for (unsigned i = 0; i < 256; i++) {
      for (unsigned j = 0; j < 3; j++) {
        const auto fval = i * s[j] + z[j];
        table[j * 256 + i] = int8_t(hp::Clamp(hp::RoundToNearestEven(fval), -128, 127));
      }
    }
    if (on_device) {
      void* dptr = nullptr;
      CHECK_CUDA_RESULT(cudaMalloc(&dptr, kTableSize));
      CHECK_CUDA_RESULT(
          cudaMemcpy(dptr, table, kTableSize, cudaMemcpyKind::cudaMemcpyHostToDevice));
      return std::shared_ptr<int8_t>((int8_t*)dptr, [](int8_t* dptr) { cudaFree(dptr); });
    } else {
      return hptr;
    }
  }
  cudaTextureObject_t CreateTextureObj(int8_t* dptr) {
    cudaResourceDesc res_desc;
    std::memset(&res_desc, 0, sizeof(res_desc));
    res_desc.resType = cudaResourceTypeLinear;
    res_desc.res.linear.devPtr = dptr;
    res_desc.res.linear.desc.f = cudaChannelFormatKindSigned;
    res_desc.res.linear.desc.x = 8;
    res_desc.res.linear.sizeInBytes = kPageElemTotal * kChannelCount;

    cudaTextureDesc tex_desc;
    std::memset(&tex_desc, 0, sizeof(tex_desc));
    tex_desc.addressMode[0] = cudaAddressModeClamp;
    tex_desc.filterMode = cudaFilterModePoint;
    tex_desc.readMode = cudaReadModeElementType;
    tex_desc.normalizedCoords = 0;
    cudaTextureObject_t ttable;
    CHECK_CUDA_RESULT(cudaCreateTextureObject(&ttable, &res_desc, &tex_desc, nullptr));
    return ttable;
  }

  void DestroyTextureObj(cudaTextureObject_t obj) {
    CHECK_CUDA_RESULT(cudaDestroyTextureObject(obj));
  }

 private:
  static const size_t kChannelCount = 3;
  static const size_t kPageElemTotal = 256;
  static const size_t kTableSize = kPageElemTotal * kChannelCount;
  float s_[3];
  float z_[3];
  bool bgr2rgb_;
  bool is_resize_;
  int dst_width_;
  int dst_height_;
  mip::InterpolationMode interp_mode_;
  std::shared_ptr<int8_t> dtable_;
  // cudaTextureObject_t ttable_;
};

MultiImgPreprocessorKernel::MultiImgPreprocessorKernel(const std::array<float, 3>& mean_vals,
                                                       const std::array<float, 3>& std_vals,
                                                       float scale,
                                                       bool bgr2rgb,
                                                       bool is_resize,
                                                       int dst_width,
                                                       int dst_height,
                                                       mip::InterpolationMode interp_mode) {
  impl_ = std::make_unique<Impl>(mean_vals,
                                 std_vals,
                                 scale,
                                 bgr2rgb,
                                 is_resize,
                                 dst_width,
                                 dst_height,
                                 interp_mode);
}
MultiImgPreprocessorKernel::~MultiImgPreprocessorKernel() = default;
void MultiImgPreprocessorKernel::Process(const void* const* imgs,
                                         int w,
                                         int h,
                                         int c,
                                         void* output,
                                         cudaStream_t stream,
                                         int ver) const {
  impl_->Process(imgs, w, h, c, output, stream, ver);
}
}  // namespace mip