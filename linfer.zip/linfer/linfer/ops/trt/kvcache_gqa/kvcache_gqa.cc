#if defined(LIDS_PLATFORM_THOR) || defined(LIDS_PLATFORM_X86)
// #include "linfer/ops/trt/kvcache_gqa/kvcache_gqa.h"

#include "kvcache_gqa.cuh"

#include <NvInferRuntime.h>
#include <cublas_v2.h>
#include <cudnn.h>
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

#include "helpers/helper.h"
#include "linfer/util/internal/trt/plugin.h"

// #if NV_TENSORRT_MAJOR >= 10

namespace linfer {
namespace ops {
namespace trt {
static const char* LinferKVCacheGQA_PLUGIN_VERSION{"1"};
static const char* LinferKVCacheGQA_PLUGIN_NAME{"LinferKVCacheGQA"};

enum InOutPos {
  kKeyCache = 0,
  kValueCache,
  kQuery,
  kKey,
  kValue,
  kSeqIdx,
  kOutputMin,
  kOutputEmbeddingBaseInput = kOutputMin,
  kOutputMax,
  kOutputEmbedding = kOutputEmbeddingBaseInput - kOutputMin,
};

class LinferKVCacheGQA : public nvinfer1::IPluginV2DynamicExt {
 public:
  LinferKVCacheGQA(unsigned int max_seq_len) : max_seq_len_(max_seq_len) {}

  ~LinferKVCacheGQA() override = default;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override {
    ASSERT(pos <= InOutPos::kOutputMax);
    ASSERT(nbInputs == InOutPos::kOutputMin);
    ASSERT(nbOutputs == (InOutPos::kOutputMax - InOutPos::kOutputMin));
    auto dtype = inOut[pos].type;
    auto dformat = inOut[pos].format;

    switch (pos) {
      case InOutPos::kKeyCache:
        return dtype == nvinfer1::DataType::kBF16 && dformat == nvinfer1::TensorFormat::kLINEAR;
      case InOutPos::kValueCache:
        return dtype == inOut[InOutPos::kKeyCache].type &&
               dformat == inOut[InOutPos::kKeyCache].format;
      case InOutPos::kQuery:
        return dtype == inOut[InOutPos::kKeyCache].type &&
               dformat == inOut[InOutPos::kKeyCache].format;
      case InOutPos::kKey:
        return dtype == inOut[InOutPos::kKeyCache].type &&
               dformat == inOut[InOutPos::kKeyCache].format;
      case InOutPos::kValue:
        return dtype == inOut[InOutPos::kKeyCache].type &&
               dformat == inOut[InOutPos::kKeyCache].format;
      case InOutPos::kSeqIdx:
        return dtype == nvinfer1::DataType::kINT32 && dformat == nvinfer1::TensorFormat::kLINEAR;
      case InOutPos::kOutputEmbeddingBaseInput:
        return dtype == inOut[InOutPos::kKeyCache].type &&
               dformat == inOut[InOutPos::kKeyCache].format;
      default:
        return false;
    }
  }

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override {}

  size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                          int32_t nbInputs,
                          const nvinfer1::PluginTensorDesc* outputs,
                          int32_t nbOutputs) const noexcept override {
    LASSERT(4 == inputs[InOutPos::kQuery].dims.nbDims);
    LASSERT(1 == outputs[InOutPos::kOutputEmbedding].dims.d[0]);  // batch size is 1
    unsigned int num_q_heads = inputs[InOutPos::kQuery].dims.d[1];
    return num_q_heads * max_seq_len_ * sizeof(float);
  }

  int initialize() noexcept override { return 0; }

  void terminate() noexcept override {}

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override {
    unsigned int head_dim = inputDesc[InOutPos::kQuery].dims.d[3];
    unsigned int num_q_heads = inputDesc[InOutPos::kQuery].dims.d[1];
    unsigned int num_kv_heads = inputDesc[InOutPos::kKey].dims.d[1];

    // printf("max_seq_len_: %lu, head_dim: %lu, num_q_heads: %lu, num_kv_heads: %lu\n",
    // max_seq_len_, head_dim, num_q_heads, num_kv_heads);

    auto seq_idx = static_cast<const int32_t* const>(inputs[InOutPos::kSeqIdx]);
    // copy new kKey to kKey cache and copy new kValue feature to kValue cache
    // kKey: [batch, num_kv_heads, 1, head_dim]
    // kKey cache: [batch, num_kv_heads, max_seq_len, head_dim]
    // new kValue: [batch, num_kv_heads, 1, head_dim]
    // kValue cache: [batch, num_kv_heads, max_seq_len, head_dim]
    auto key_cache =
        reinterpret_cast<__nv_bfloat16*>(const_cast<void*>(inputs[InOutPos::kKeyCache]));
    auto key = reinterpret_cast<const __nv_bfloat16*>(inputs[InOutPos::kKey]);
    auto value_cache =
        reinterpret_cast<__nv_bfloat16*>(const_cast<void*>(inputs[InOutPos::kValueCache]));
    auto value = reinterpret_cast<const __nv_bfloat16*>(inputs[InOutPos::kValue]);
    auto query = reinterpret_cast<const __nv_bfloat16*>(inputs[InOutPos::kQuery]);

    auto output_emb = reinterpret_cast<__nv_bfloat16*>(outputs[InOutPos::kOutputEmbedding]);
    auto attn_score = reinterpret_cast<float*>(workspace);

    const auto qk_bytes = num_q_heads * max_seq_len_ * sizeof(float);
    void* qk_result = nullptr;  // for debug only
    // cudaMalloc(&qk_result, qk_bytes);

    LaunchAttnWithGqa(output_emb,
                      attn_score,
                      key_cache,
                      value_cache,
                      query,
                      key,
                      value,
                      seq_idx,
                      max_seq_len_,
                      head_dim,
                      num_q_heads,
                      num_kv_heads,
                      (float*)qk_result,
                      stream);

    // auto all_tensors = lad::CvtIOToTensors(inputDesc, inputs, 6, outputDesc, outputs, 1);
    // lad::Tensor qk_r;
    // qk_r.dtype = (int)nvinfer1::DataType::kFLOAT;
    // qk_r.dims = {1, int(num_q_heads * max_seq_len_)};
    // qk_r.hdata.resize(qk_bytes);
    // cudaMemcpy(qk_r.hdata.data(), qk_result, qk_r.hdata.size(), cudaMemcpyDeviceToHost);
    // all_tensors.insert(all_tensors.end(), qk_r);
    // const auto& tbuf = lad::SerializeTensors(all_tensors);
    // const auto filename =
    //     "/home/eric/sunxing/sunxing/hermes/modules/linfer/linfer/ops/trt/kvcache_gqa/"
    //     "inoutframe.json";
    // lad::WriteToBinaryFile(filename, tbuf);
    // cudaFree(qk_result);

    return 0;
  }

  size_t getSerializationSize() const noexcept override { return sizeof(max_seq_len_); }

  void serialize(void* buffer) const noexcept override {
    char* buf = reinterpret_cast<char*>(buffer);
    char* start = buf;
    write<unsigned int>(buf, max_seq_len_);
    LASSERT_MSG(buf, start + getSerializationSize());
  }

  const char* getPluginType() const noexcept override { return LinferKVCacheGQA_PLUGIN_NAME; }

  const char* getPluginVersion() const noexcept override { return LinferKVCacheGQA_PLUGIN_VERSION; }

  void destroy() noexcept override { delete this; }

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override {
    LinferKVCacheGQA* plugin = new LinferKVCacheGQA(max_seq_len_);
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  }

  void setPluginNamespace(const char* pluginNamespace) noexcept override {
    mPluginNamespace = pluginNamespace;
  }

  const char* getPluginNamespace() const noexcept override { return mPluginNamespace.c_str(); }

  int getNbOutputs() const noexcept override { return InOutPos::kOutputMax - InOutPos::kOutputMin; }

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override {
    return inputs[InOutPos::kQuery];
  }
  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override {
    ASSERT(index == 0);
    return inputTypes[InOutPos::kQuery];
  }

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override {
    return;
  }

  void detachFromContext() noexcept override {}

 private:
  std::string mPluginNamespace;
  unsigned int max_seq_len_;
};

class LinferKVCacheGQACreator : public BaseCreator {
 public:
  LinferKVCacheGQACreator() {
    attrs_.clear();
    attrs_.emplace_back("max_seq_len", nullptr, nvinfer1::PluginFieldType::kINT32, 1);
    fc_.nbFields = attrs_.size();
    fc_.fields = attrs_.data();
  }

  ~LinferKVCacheGQACreator() override = default;

  const char* getPluginName() const noexcept override { return LinferKVCacheGQA_PLUGIN_NAME; }

  const char* getPluginVersion() const noexcept override { return LinferKVCacheGQA_PLUGIN_VERSION; }

  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override { return &fc_; }

  nvinfer1::IPluginV2Ext* createPlugin(
      const char* name,
      const nvinfer1::PluginFieldCollection* fc) noexcept override {
    unsigned int max_seq_len, head_dim, num_q_heads, num_kv_heads;

    LASSERT_MSG(fc->nbFields == 1, "must have 1 fields");
    for (int32_t i = 0; i < fc->nbFields; i++) {
      std::string field_name(fc->fields[i].name);
      auto field_data = fc->fields[i].data;
      auto field_len = fc->fields[i].length;

      if (field_name.compare("max_seq_len") == 0) {
        max_seq_len = static_cast<unsigned int>(*static_cast<const int32_t*>(field_data));
      } else {
        LASSERT_MSG(false, "unexpected field_name: " + field_name);
      }
    }

    LinferKVCacheGQA* obj = new LinferKVCacheGQA(max_seq_len);
    obj->setPluginNamespace(mNamespace.c_str());
    return obj;
  }

  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept override {
    unsigned int max_seq_len;
    auto buf = reinterpret_cast<const char*>(serialData);
    auto buf_start = buf;
    max_seq_len = read<unsigned int>(buf);
    LinferKVCacheGQA* obj = new LinferKVCacheGQA(max_seq_len);
    obj->setPluginNamespace(mNamespace.c_str());

    LASSERT_MSG((buf - buf_start) == serialLength, "serialize and deserialize mismatch!");
    return obj;
  }

 private:
  nvinfer1::PluginFieldCollection fc_;
  std::vector<nvinfer1::PluginField> attrs_;
};

REGISTER_TENSORRT_PLUGIN(LinferKVCacheGQACreator);

}  // namespace trt
}  // namespace ops
}  // namespace linfer

#endif
