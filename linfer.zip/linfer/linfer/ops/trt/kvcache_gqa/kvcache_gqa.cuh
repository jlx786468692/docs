#pragma once
#if defined(LIDS_PLATFORM_THOR) || defined(LIDS_PLATFORM_X86)

#include <cuda_bf16.h>
#include <cuda_runtime.h>

#include <cstdint>

#include "NvInferVersion.h"

namespace linfer {
namespace ops {
namespace trt {

void LaunchAttnWithGqa(__nv_bfloat16* output_emb,
                       float* attn_score,
                       __nv_bfloat16* key_cache,
                       __nv_bfloat16* value_cache,
                       const __nv_bfloat16* query,
                       const __nv_bfloat16* key,
                       const __nv_bfloat16* value,
                       const int32_t* seq_idx,
                       unsigned int max_seq_len,
                       unsigned int head_dim,
                       unsigned int num_q_heads,
                       unsigned int num_kv_heads,
                       float* qk_result,  // for debug only
                       cudaStream_t stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer

#endif