
// #if defined(__CUDA_ARCH__) && (__CUDA_ARCH__ >= 860)
#if defined(LIDS_PLATFORM_THOR)

#include <cooperative_groups.h>
#include <cuda.h>
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <math_constants.h>
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

#include <algorithm>
#include <fstream>
#include <sstream>

#include "NvInferVersion.h"
#include "linfer/ops/trt/kvcache_gqa/kvcache_gqa.cuh"
#include "linfer/ops/trt/multi_img_preprocessor/common_helper.hpp"
#include "linfer/util/internal/cuda/util.h"

namespace linfer {
namespace ops {
namespace trt {

namespace cg = cooperative_groups;

template <typename T>
__host__ __device__ __forceinline__ T AlignUp(T Align, T val) {
  return (val + Align - 1) & ~(Align - 1);
}

template <uint32_t Align, typename T>
__host__ __device__ __forceinline__ T AlignUp(T val) {
  return (val + Align - 1) & ~(Align - 1);
}

template <uint32_t Align, uint32_t val>
__host__ __device__ __forceinline__ constexpr uint32_t AlignUp() {
  return (val + Align - 1) & ~(Align - 1);
}

__host__ __device__ __forceinline__ uint32_t Ceil(uint32_t a, uint32_t b) {
  return (a + b - 1) / b;
}

template <uint32_t a, uint32_t b>
__host__ __device__ __forceinline__ constexpr uint32_t Ceil() {
  return (a + b - 1) / b;
}

__forceinline__ __device__ int SemFetch(volatile int* lock, bool pred) {
  int state{};
  if (pred) {
    asm volatile("ld.global.acquire.gpu.b32 %0, [%1];\n" : "=r"(state) : "l"(lock));
  }
  return state;
}

__forceinline__ __device__ void SemWait(volatile int* lock, int status, bool pred) {
  int state = 0;
  while (__syncthreads_and(state != status)) {
    state = SemFetch(lock, pred);
  }
  __syncthreads();
}

__forceinline__ __device__ void SemWaitMany(volatile int* lock, int count, bool pred) {
  int state = 0;
  while (__syncthreads_count(state) != count) {
    state = SemFetch(lock, pred);
  }
  __syncthreads();
}

__forceinline__ __device__ void SemPost(volatile int* lock, int status, bool pred) {
  __syncthreads();
  if (pred) {
    asm volatile("st.global.release.gpu.b32 [%0], %1;\n" : : "l"(lock), "r"(status));
  }
}

enum class SharedMemFillMode { kFillZero, kNoFill };

enum class PrefetchMode { kNoPrefetch, kPrefetch };

__device__ __forceinline__ void CommitGroup() { asm volatile("cp.async.commit_group;\n" ::); }

template <int N>
__device__ __forceinline__ void WaitGroup() {
  asm volatile("cp.async.wait_group %0;\n" ::"n"(N));
}

template <PrefetchMode prefetch_mode, typename T>
__device__ __forceinline__ void Load16Bytes(T* smem_ptr, const T* gmem_ptr) {
  auto smem_int_ptr = __cvta_generic_to_shared(smem_ptr);
  if (prefetch_mode == PrefetchMode::kPrefetch) {
    asm volatile("cp.async.cg.shared.global.L2::128B [%0], [%1], %2, %3;\n" ::"l"(smem_int_ptr),
                 "l"(gmem_ptr),
                 "n"(16),
                 "r"(16));
  } else {
    asm volatile("cp.async.cg.shared.global [%0], [%1], %2, %3;\n" ::"l"(smem_int_ptr),
                 "l"(gmem_ptr),
                 "n"(16),
                 "r"(16));
  }
}

template <PrefetchMode prefetch_mode, SharedMemFillMode fill_mode, typename T>
__device__ __forceinline__ void Load16BytesWithPred(T* smem_ptr,
                                                    const T* gmem_ptr,
                                                    bool predicate) {
  // if (predicate) {
  //   *((uint4 *)smem_ptr) = *((uint4 *)gmem_ptr);
  // } else {
  //   if constexpr (fill_mode == SharedMemFillMode::kFillZero) {
  //     *((uint4 *)smem_ptr) = make_uint4(0, 0, 0, 0);
  //   }
  // }

  auto smem_int_ptr = __cvta_generic_to_shared(smem_ptr);
  if (fill_mode == SharedMemFillMode::kFillZero) {
    int src_in_bytes = predicate ? 16 : 0;
    if (prefetch_mode == PrefetchMode::kPrefetch) {
      asm volatile("cp.async.cg.shared.global.L2::128B [%0], [%1], %2, %3;\n" ::"l"(smem_int_ptr),
                   "l"(gmem_ptr),
                   "n"(16),
                   "r"(src_in_bytes));
    } else {
      asm volatile("cp.async.cg.shared.global [%0], [%1], %2, %3;\n" ::"l"(smem_int_ptr),
                   "l"(gmem_ptr),
                   "n"(16),
                   "r"(src_in_bytes));
    }
  } else {
    if (prefetch_mode == PrefetchMode::kPrefetch) {
      asm volatile(
          "{\n"
          " .reg .pred p;\n"
          " setp.ne.b32 p, %0, 0;\n"
          " @p cp.async.cg.shared.global.L2::128B [%1], [%2], %3;\n"
          "}\n" ::"r"((int)predicate),
          "l"(smem_int_ptr),
          "l"(gmem_ptr),
          "n"(16));
    } else {
      asm volatile(
          "{\n"
          " .reg .pred p;\n"
          " setp.ne.b32 p, %0, 0;\n"
          " @p cp.async.cg.shared.global [%1], [%2], %3;\n"
          "}\n" ::"r"((int)predicate),
          "l"(smem_int_ptr),
          "l"(gmem_ptr),
          "n"(16));
    }
  }
}

// A generic Swizzle functor
/* 0bxxxxxxxxxxxxxxxYYYxxxxxxxZZZxxxx
 *                               ^--^ MBase is the number of least-sig bits to keep constant
 *                  ^-^       ^-^     BBits is the number of bits in the mask
 *                    ^---------^     SShift is the distance to shift the YYY mask
 *                                       (pos shifts YYY to the right, neg shifts YYY to the left)
 *
 * e.g. Given
 * 0bxxxxxxxxxxxxxxxxYYxxxxxxxxxZZxxx
 * the result is
 * 0bxxxxxxxxxxxxxxxxYYxxxxxxxxxAAxxx where AA = ZZ xor YY
 */
template <int BBits, int MBase, int SShift = BBits>
struct Swizzle {
  static constexpr int num_bits = BBits;
  static constexpr int num_base = MBase;
  static constexpr int num_shft = SShift;

  static_assert(num_base >= 0, "MBase must be positive.");
  static_assert(num_bits >= 0, "BBits must be positive.");
  static_assert(abs(num_shft) >= num_bits, "abs(SShift) must be more than BBits.");

  // using 'int' type here to avoid unintentially casting to unsigned... unsure.
  static constexpr int bit_msk = (1 << num_bits) - 1;
  static constexpr int yyy_msk = bit_msk << (num_base + (0 > num_shft ? 0 : num_shft));
  static constexpr int zzz_msk = bit_msk << (num_base - (0 > num_shft ? num_shft : 0));
  static constexpr int msk_sft = num_shft;

  template <class Offset>
  __device__ __forceinline__ constexpr static auto Apply(Offset offset) {
    return offset ^ ShiftR(offset & yyy_msk, msk_sft);  // ZZZ ^= YYY
  }

  template <class T>
  __device__ __forceinline__ constexpr static auto ShiftR(T x, int s) {
    return s >= 0 ? (x >> s) : (x << -s);
  }
};

struct Identity {
  template <class Offset>
  __device__ __forceinline__ static auto Apply(Offset offset) {
    return offset;
  }
};

struct Offset {
  __device__ __forceinline__ explicit Offset(uint32_t value) : value_{value} {}
  __device__ __forceinline__ uint32_t& operator()() { return value_; }
  __device__ __forceinline__ const uint32_t& operator()() const { return value_; }
  uint32_t value_;
};

enum class LayoutOrder { kRowMajor, kColMajor };

template <typename T, LayoutOrder Order, uint32_t Strid, typename SwizzleT = Identity>
struct SwizzleLayout {
  __device__ __forceinline__ constexpr static uint32_t ToLinear(uint32_t row, uint32_t col) {
    if (Order == LayoutOrder::kRowMajor) {
      return row * Strid + col;
    } else {
      return col * Strid + row;
    }
  }

  __device__ __forceinline__ constexpr static uint32_t Apply(uint32_t row, uint32_t col) {
    uint32_t linear = ToLinear(row, col);
    return SwizzleT::Apply(linear * sizeof(T)) / sizeof(T);
  }
};

using QTileLayout = SwizzleLayout<__nv_bfloat16, LayoutOrder::kRowMajor, 16, Swizzle<3, 4, 5>
                                  //
                                  >;

#ifdef LIDS_PLATFORM_THOR
using KTileLayout = SwizzleLayout<__nv_bfloat16, LayoutOrder::kColMajor, 64, Swizzle<3, 4, 3>
                                  //
                                  >;
using VTileLayout = SwizzleLayout<__nv_bfloat16, LayoutOrder::kRowMajor, 64, Swizzle<3, 4, 3>
                                  //
                                  >;

#else
using KTileLayout = SwizzleLayout<__nv_bfloat16, LayoutOrder::kColMajor, 16, Swizzle<3, 4, 3>
                                  //
                                  >;
using VTileLayout = SwizzleLayout<__nv_bfloat16, LayoutOrder::kRowMajor, 8
                                  // , Swizzle<3, 3, 3>
                                  //
                                  >;
#endif
template <typename T, int Len>
struct Array {
  __host__ __device__ __forceinline__ T& operator[](int idx) noexcept { return data[idx]; }
  __host__ __device__ __forceinline__ const T& operator[](int idx) const noexcept {
    return data[idx];
  }

  T data[Len];
};

template <typename T, int M, int N, bool RowMajor>
struct Tile2D;
template <typename T, int M, int N>
struct Tile2D<T, M, N, true> {
  __host__ __device__ __forceinline__ T& operator()(int r, int c) noexcept { return data[r][c]; }
  __host__ __device__ __forceinline__ const T& operator()(int r, int c) const noexcept {
    return data[r][c];
  }
  T data[M][N];
};

template <typename T, int M, int N>
struct Tile2D<T, M, N, false> {
  __host__ __device__ __forceinline__ T& operator()(int r, int c) noexcept { return data[c][r]; }
  __host__ __device__ __forceinline__ const T& operator()(int r, int c) const noexcept {
    return data[c][r];
  }
  T data[N][M];
};

struct MMA_M16N8K16RowCol {
  static const unsigned int M = 16;
  static const unsigned int N = 8;
  static const unsigned int K = 16;

  static const unsigned int WarpSize = 32;

  using ADataType = __nv_bfloat16;
  using BDataType = __nv_bfloat16;
  using CDataType = float;
  using DDataType = float;
  using ARegType = Array<ADataType, M * K / WarpSize>;
  using BRegType = Array<BDataType, K * N / WarpSize>;
  using CRegType = Array<CDataType, M * N / WarpSize>;
  using DRegType = Array<DDataType, M * N / WarpSize>;
  using ATileType = Tile2D<ADataType, M, K, true>;           // M x K
  using BTileTypeColMajor = Tile2D<BDataType, K, N, false>;  // K x N
  using BTileTypeRowMajor = Tile2D<BDataType, K, N, true>;   // K x N
  using CTileType = Tile2D<CDataType, M, N, true>;
  using DTileType = Tile2D<DDataType, M, N, true>;

  __forceinline__ __device__ static void LoadFragA(int lane_id,
                                                   ARegType& a,
                                                   const ADataType* smem_a) {
    const int row = lane_id >> 2;
    if (row == 0) {
      const int col = (lane_id & 0x3) * 2;
      // const auto sptr = reinterpret_cast<const uint32_t *>(smem_a + col);
      const auto sptr = reinterpret_cast<const uint32_t*>(smem_a + QTileLayout::Apply(0, col));
      auto rega = reinterpret_cast<uint32_t*>(&a);
      rega[0] = sptr[0];
      // rega[1] = 0;
      rega[2] = sptr[4];
      // rega[3] = 0;
    }
  }

  // __forceinline__ __device__ static void LoadFragA(int lane_id, ARegType &a, const ADataType
  // *smem_a) {
  //   int row = lane_id % 16;
  //   int col = lane_id / 16 * 8;

  //   const auto s_a = smem_a + row * 16 + col;
  //   auto smem_int_ptr = __cvta_generic_to_shared(s_a);
  //   asm volatile(
  //       "ldmatrix.sync.aligned.m8n8.x4.shared.b16 "
  //       "{%0,%1,%2,%3}, [%4];\n"
  //       : "=r"(a[0]), "=r"(a[1]), "=r"(a[2]), "=r"(a[3])
  //       : "l"(smem_int_ptr));
  // }
  // __forceinline__ __device__ static void LoadFragAStd(int lane_id, ARegType &a, const ADataType
  // *smem_a) {
  //   int row = lane_id / 2;
  //   int col = (lane_id & 1) * 8;

  //   const auto s_a = smem_a + row * 16 + col;
  //   auto smem_int_ptr = __cvta_generic_to_shared(s_a);
  //   asm volatile(
  //       "ldmatrix.sync.aligned.m8n8.x4.shared.b16 "
  //       "{%0,%1,%2,%3}, [%4];\n"
  //       : "=r"(a[0]), "=r"(a[1]), "=r"(a[2]), "=r"(a[3])
  //       : "l"(smem_int_ptr));
  // }

  // __forceinline__ __device__ static void LoadFragA(int lane_id, ARegType &a, const ATileType &A)
  // {
  //   LoadFragA(lane_id, a, &A(0, 0));
  // }
  // __forceinline__ __device__ static void LoadFragAStd(int lane_id, ARegType &a, const ATileType
  // &A) {
  //   LoadFragAStd(lane_id, a, &A(0, 0));
  // }
  __forceinline__ __device__ static void LoadFragBColMajor(int lane_id,
                                                           BRegType& reg_b,
                                                           const BDataType* smem_b) {
    int row = lane_id / 8 % 2 * 8;  // 0,0,0,0,0,0,0,0, 8,8,8,8,8,8,8,8 ...
    int col = lane_id % 8;          // 0,1,2,3,4,5,6,7, 0,1,2,3,4,5,6,7 ...
    const auto share_b = smem_b + KTileLayout::Apply(row, col);
    // const auto share_b = smem_b + col * 16 + row;
    auto smem_int_ptr = __cvta_generic_to_shared(share_b);
    auto regb = reinterpret_cast<uint32_t*>(&reg_b);
    asm volatile(
        "ldmatrix.sync.aligned.m8n8.x2.shared.b16 "
        "{%0, %1}, [%2];\n"
        : "=r"(regb[0]), "=r"(regb[1])
        : "l"(smem_int_ptr));
  }

  __forceinline__ __device__ static void LoadFragBColMajorCol(int lane_id,
                                                              BRegType& reg_b,
                                                              const BDataType* smem_b,
                                                              int col_idx) {
    int row = lane_id / 8 % 2 * 8;  // 0,0,0,0,0,0,0,0, 8,8,8,8,8,8,8,8 ...
    int col = lane_id % 8;          // 0,1,2,3,4,5,6,7, 0,1,2,3,4,5,6,7 ...
    const auto share_b = smem_b + KTileLayout::Apply(row + col_idx * 16, col);
    // const auto share_b = smem_b + col * 16 + row;
    auto smem_int_ptr = __cvta_generic_to_shared(share_b);
    auto regb = reinterpret_cast<uint32_t*>(&reg_b);
    asm volatile(
        "ldmatrix.sync.aligned.m8n8.x2.shared.b16 "
        "{%0, %1}, [%2];\n"
        : "=r"(regb[0]), "=r"(regb[1])
        : "l"(smem_int_ptr));
  }
  // __forceinline__ __device__ static void LoadFragBColMajorStd(int lane_id, BRegType &b, const
  // BDataType *smem_b) {
  //   lane_id = lane_id & 15;
  //   int row = (lane_id & 1) * 8;
  //   int col = lane_id / 2;

  //   const auto s_b = smem_b + col * 16 + row;
  //   auto smem_int_ptr = __cvta_generic_to_shared(s_b);
  //   asm volatile(
  //       "ldmatrix.sync.aligned.m8n8.x2.shared.b16 "
  //       "{%0, %1}, [%2];\n"
  //       : "=r"(b[0]), "=r"(b[1])
  //       : "l"(smem_int_ptr));
  // }

  __forceinline__ __device__ static void LoadFragBRowMajorRow(int lane_id,
                                                              BRegType& reg_b,
                                                              const BDataType* smem_b,
                                                              int row_idx,
                                                              int col_indx) {
    const int row = lane_id % 16;
    constexpr int col = 0;

    const auto share_b = smem_b + VTileLayout::Apply(row + row_idx * 16, col + col_indx * 8);
    // const auto share_b = smem_b + row * 64 + col;
    auto smem_int_ptr = __cvta_generic_to_shared(share_b);
    auto regb = reinterpret_cast<uint32_t*>(&reg_b);
    asm volatile(
        "ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 "
        "{%0, %1}, [%2];\n"
        : "=r"(regb[0]), "=r"(regb[1])
        : "l"(smem_int_ptr));
  }

  __forceinline__ __device__ static void LoadFragBRowMajor(int lane_id,
                                                           BRegType& reg_b,
                                                           const BDataType* smem_b) {
    const int row = lane_id % 16;
    constexpr int col = 0;

    const auto share_b = smem_b + VTileLayout::Apply(row, col);

    // const auto share_b = smem_b + row * 8 + col;
    auto smem_int_ptr = __cvta_generic_to_shared(share_b);
    auto regb = reinterpret_cast<uint32_t*>(&reg_b);
    asm volatile(
        "ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 "
        "{%0, %1}, [%2];\n"
        : "=r"(regb[0]), "=r"(regb[1])
        : "l"(smem_int_ptr));
  }

  // __forceinline__ __device__ static void LoadFragB(int lane_id, BRegType &b, const BDataType *B)
  // {
  //   const int row = (lane_id & 0x3) * 2;
  //   const int col = lane_id >> 2;
  //   b[0] = *reinterpret_cast<const uint32_t *>(B + col * 16 + row);
  //   b[1] = *reinterpret_cast<const uint32_t *>(B + col * 16 + row + 8);
  // }

  // __forceinline__ __device__ static void LoadFragBStd(int lane_id, BRegType &b, const
  // BTileTypeColMajor &B) {
  //   LoadFragBColMajorStd(lane_id, b, &B(0, 0));
  // }

  __forceinline__ __device__ static void LoadFragB(int lane_id,
                                                   BRegType& reg_b,
                                                   const BTileTypeColMajor& smem_b) {
    LoadFragBColMajor(lane_id, reg_b, &smem_b(0, 0));
  }
  __forceinline__ __device__ static void LoadFragB(int lane_id,
                                                   BRegType& reg_b,
                                                   const BTileTypeRowMajor& smem_b) {
    LoadFragBRowMajor(lane_id, reg_b, &smem_b(0, 0));
  }

  // __forceinline__ __device__ static void LoadFragBRow(int lane_id, BRegType &reg_b, const
  // BTileTypeRowMajor &smem_b)
  // {
  //   LoadFragBRowMajorRow(lane_id, reg_b, &smem_b(0, 0));
  // }
  // __forceinline__ __device__ static void LoadFragC(int lane_id, CRegType &c, const CDataType *C)
  // {
  //   const int row = lane_id >> 2;
  //   const int col = (lane_id & 0x3) * 2;
  //   c[0] = C[(row + 0) * 8 + col + 0];
  //   c[1] = C[(row + 0) * 8 + col + 1];
  //   c[2] = C[(row + 8) * 8 + col + 0];
  //   c[3] = C[(row + 8) * 8 + col + 1];
  // }

  // __forceinline__ __device__ static void LoadFragC(int lane_id, CRegType &c, const CTileType &C)
  // {
  //   LoadFragC(lane_id, c, &C(0, 0));
  // }

  // __forceinline__ __device__ static void LoadFragRawC(int lane_id, CRegType &c, const CRegType
  // &C) {
  //   c[0] = C[0];
  //   c[1] = C[1];
  //   c[2] = C[2];
  //   c[3] = C[3];
  // }

  // __forceinline__ __device__ static void StoreFragD(int lane_id, DDataType *D, const DRegType &d)
  // {
  //   StoreFragD(lane_id, D, d, 8);
  // }
  // __forceinline__ __device__ static void StoreFragD(int lane_id,
  //                                                   DDataType *D,
  //                                                   const DRegType &d,
  //                                                   int row_step) {
  //   const int row = lane_id >> 2;
  //   const int col = (lane_id & 0x3) * 2;
  //   D[(row + 0) * row_step + col + 0] = d[0];
  //   D[(row + 0) * row_step + col + 1] = d[1];
  //   D[(row + 8) * row_step + col + 0] = d[2];
  //   D[(row + 8) * row_step + col + 1] = d[3];
  // }
  // __forceinline__ __device__ static void StoreFragD(int lane_id, DTileType &D, const DRegType &d)
  // {
  //   StoreFragD(lane_id, &D(0, 0), d);
  // }

  __forceinline__ __device__ static void Fma(DRegType& d,
                                             const ARegType& a,
                                             const BRegType& b,
                                             const CRegType& c) {
    auto A = reinterpret_cast<const uint32_t*>(&a);
    auto B = reinterpret_cast<const uint32_t*>(&b);
    auto C = reinterpret_cast<const float*>(&c);
    auto D = reinterpret_cast<float*>(&d);
    asm volatile(
        "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32  {%0,%1,%2,%3}, "
        "{%4,%5,%6,%7}, {%8,%9}, {%10,%11,%12,%13};\n"
        : "=f"(D[0]), "=f"(D[1]), "=f"(D[2]), "=f"(D[3])
        : "r"(A[0]),
          "r"(A[1]),
          "r"(A[2]),
          "r"(A[3]),
          "r"(B[0]),
          "r"(B[1]),
          "f"(C[0]),
          "f"(C[1]),
          "f"(C[2]),
          "f"(C[3])
        : "memory");
  }
};

struct MMA_M16N8K16RowColTile {
  using Frag = MMA_M16N8K16RowCol;

  static const auto M = Frag::M;
  static const auto N = Frag::N;
  static const auto K = Frag::K;

  using ADataType = Frag::ADataType;
  using BDataType = Frag::BDataType;
  using CDataType = Frag::CDataType;
  using DDataType = Frag::DDataType;

  using ARegType = Frag::ARegType;
  using BRegType = Frag::BRegType;
  using CRegType = Frag::CRegType;
  using DRegType = Frag::DRegType;

  using ATileType = Frag::ATileType;
  using BTileTypeColMajor = Frag::BTileTypeColMajor;
  using BTileTypeRowMajor = Frag::BTileTypeRowMajor;
  using CTileType = Frag::CTileType;
  using DTileType = Frag::DTileType;

  ARegType a;
  BRegType b;

  __forceinline__ __device__ MMA_M16N8K16RowColTile() {
    for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++) {
      a[i] = 0;
    }
  }

  template <typename T>
  __forceinline__ __device__ void Load(int lane_id, const ADataType* share_a, const T& share_b) {
    Frag::LoadFragA(lane_id, a, share_a);
    Frag::LoadFragB(lane_id, b, share_b);
  }

  template <typename T>
  __forceinline__ __device__ void LoadRow(int lane_id,
                                          const ADataType* share_a,
                                          const T& share_b,
                                          int row_idx,
                                          int col_indx) {
    Frag::LoadFragA(lane_id, a, share_a);
    Frag::LoadFragBRowMajorRow(lane_id, b, share_b, row_idx, col_indx);
  }

  template <typename T>
  __forceinline__ __device__ void LoadCol(int lane_id,
                                          const ADataType* share_a,
                                          const T& share_b,
                                          int col_idx) {
    Frag::LoadFragA(lane_id, a, share_a);
    Frag::LoadFragBColMajorCol(lane_id, b, share_b, col_idx);
  }

  __forceinline__ __device__ void Fma(DRegType& d, const CRegType& c) const {
    Frag::Fma(d, a, b, c);
  }
};

struct Tensor2DView {
  __host__ __device__ __forceinline__ Tensor2DView() : row(-1), col(-1), rstep(-1), cstep(-1) {}
  __host__ __device__ __forceinline__ Tensor2DView(int r, int c)
      : row(r), col(c), rstep(c), cstep(1) {}
  __host__ __device__ __forceinline__ Tensor2DView(int r, int c, int rs, int cs)
      : row(r), col(c), rstep(rs), cstep(cs) {}

  __host__ __device__ __forceinline__ int RangeElemTotal() const noexcept {
    return (row - 1) * rstep + (col - 1) * cstep + 1;
  }
  __host__ __device__ __forceinline__ bool operator==(const Tensor2DView& other) const noexcept {
    return (row == other.row) && (col == other.col) && (rstep == other.rstep) &&
           (cstep == other.cstep);
  }

  __host__ __device__ __forceinline__ bool operator!=(const Tensor2DView& other) const noexcept {
    return !(*this == other);
  }
  int row = -1;
  int col = -1;
  int rstep = -1;
  int cstep = -1;
};

struct Tensor1DView {
  __host__ __device__ __forceinline__ Tensor1DView() : len(-1), step(-1) {}
  __host__ __device__ __forceinline__ Tensor1DView(int _len, int _step) : len(_len), step(_step) {}

  __host__ __device__ __forceinline__ int RangeElemTotal() const noexcept {
    return (len - 1) * step + 1;
  }

  __host__ __device__ __forceinline__ bool operator==(const Tensor1DView& other) const noexcept {
    return (len == other.len) && (step == other.step);
  }

  __host__ __device__ __forceinline__ bool operator!=(const Tensor1DView& other) const noexcept {
    return !(*this == other);
  }

  int len = -1;
  int step = -1;
};

enum class MemType {
  kHost,
  kDevice,
};

template <typename T>
struct Tensor2D {
  __host__ __device__ __forceinline__ Tensor2D() : data(nullptr) {}
  __host__ __device__ __forceinline__ Tensor2D(T* d, MemType type, const Tensor2DView& tv)
      : data(d), mem_type(type), view(tv) {}

  __host__ __device__ __forceinline__ Tensor2D(const T* d, MemType type, const Tensor2DView& tv)
      : data(const_cast<T*>(d)), mem_type(type), view(tv) {}

  __host__ __device__ __forceinline__ T& operator()(int r, int c) noexcept {
    return data[r * view.rstep + c * view.cstep];
  }

  __host__ __device__ __forceinline__ const T& operator()(int r, int c) const noexcept {
    return data[r * view.rstep + c * view.cstep];
  }

  T* data = nullptr;
  MemType mem_type;
  Tensor2DView view;
};

template <typename T>
struct Tensor1D {
  __host__ __device__ __forceinline__ Tensor1D() : data(nullptr) {}
  __host__ __device__ __forceinline__ Tensor1D(T* d, MemType type, const Tensor1DView& tv)
      : data(d), mem_type(type), view(tv) {}

  __host__ __device__ __forceinline__ Tensor1D(const T* d, MemType type, const Tensor1DView& tv)
      : Tensor1D(const_cast<T*>(d), type, tv) {}

  __host__ __device__ __forceinline__ T& operator()(int idx) noexcept {
    return data[idx * view.step];
  }

  __host__ __device__ __forceinline__ const T& operator()(int idx) const noexcept {
    return data[idx * view.step];
  }

  T* data = nullptr;
  MemType mem_type;
  Tensor1DView view;
};

#define LOGP(...) Print(__LINE__, __VA_ARGS__)

template <typename... Args>
__host__ __device__ void Print(int lineno, const char* fmt, Args... args) {
  // printf("ln:%d ", lineno);
  printf(fmt, args...);
  // printf("\n");
}

template <typename T>
__host__ __device__ void Print(int lineno, const Tensor2D<T>& tensor) {
  const auto print_view = [lineno](const auto& tv) {
    printf("ln:%d row=%d,col=%d,rstep=%d,cstep=%d\n", lineno, tv.row, tv.col, tv.rstep, tv.cstep);
  };
  print_view(tensor.view);

  const Tensor2D<T>* tptr = nullptr;
#ifdef __CUDA_ARCH__
  tptr = &tensor;
#else
  std::vector<T> mem;
  Tensor2D<T> res;
  if (tensor.mem_type != MemType::kHost) {
    const auto& tv = tensor.view;
    mem.resize(tv.RangeElemTotal());
    CHECK_CUDA_RESULT(
        cudaMemcpy(mem.data(), tensor.data, mem.size() * sizeof(T), cudaMemcpyDeviceToHost));
    res.data = mem.data();
    res.mem_type = MemType::kHost;
    res.view = tensor.view;
    tptr = &res;
  } else {
    tptr = &tensor;
  }
#endif

  const auto get_val = [tptr](int r, int c) { return (*tptr)(r, c); };

  const auto M = tensor.view.row;
  const auto N = tensor.view.col;
  const auto print1 = [](const auto& post, auto val) {
    if (std::is_same<T, __nv_bfloat16>::value) {
      printf("%.6f", __bfloat162float(float(val)));
    } else if (std::is_same<T, float>::value) {
      printf("%.6f", (float)val);
    } else if (std::is_same<T, int>::value) {
      printf("%d", (int)val);
    } else {
      printf("unknown");
    }
    printf("%s", post);
  };
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      const auto v = get_val(i, j);
      if (i == 0 && j == 0) {
        printf("[");
      }
      if (j == 0) {
        printf("[");
      }
      if (j == N - 1) {
        if (i == M - 1) {
          print1("]]", v);
        } else {
          print1("],", v);
        }
      } else {
        print1(", ", v);
      }
    }
    printf("\n");
  }
  printf("\n");
}

template <typename T>
__host__ void AssertClose(const Tensor2D<T>& actual,
                          const Tensor2D<T>& expected,
                          double rtol = 1e-6,
                          double atol = 1e-6,
                          const std::string& msg = "") {
  if (actual.view != expected.view) {
    throw std::runtime_error(msg + " tensor view mismatch");
  }

  const Tensor2D<T>* aptr = nullptr;
  const Tensor2D<T>* eptr = nullptr;
#ifdef __CUDA_ARCH__
  aptr = &actual;
  eptr = &expected;
#else
  std::vector<T> amem;
  Tensor2D<T> ares;
  if (actual.mem_type != MemType::kHost) {
    const auto& tv = actual.view;
    amem.resize(tv.RangeElemTotal());
    CHECK_CUDA_RESULT(
        cudaMemcpy(amem.data(), actual.data, amem.size() * sizeof(T), cudaMemcpyDeviceToHost));
    ares.data = amem.data();
    ares.mem_type = MemType::kHost;
    ares.view = actual.view;
    aptr = &ares;
  } else {
    aptr = &actual;
  }

  std::vector<T> emem;
  Tensor2D<T> eres;
  if (expected.mem_type != MemType::kHost) {
    const auto& tv = expected.view;
    emem.resize(tv.RangeElemTotal());
    CHECK_CUDA_RESULT(
        cudaMemcpy(emem.data(), expected.data, emem.size() * sizeof(T), cudaMemcpyDeviceToHost));
    eres.data = emem.data();
    eres.mem_type = MemType::kHost;
    eres.view = expected.view;
    eptr = &eres;
  } else {
    eptr = &expected;
  }
#endif

  const auto get_val = [](auto v) {
    if (std::is_same<T, __nv_bfloat16>::value) {
      return __bfloat162float(v);
    }
    return float(v);
  };

  auto mismatch_count = 0;
  std::string error_msg;
  const auto& tv = expected.view;
  char buf[8 * 1024];
  for (auto r = 0; r < tv.row; ++r) {
    for (auto c = 0; c < tv.col; ++c) {
      const auto a = get_val((*aptr)(r, c));
      const auto e = get_val((*eptr)(r, c));
      const float abs_error = std::abs(a - e);
      const float tolerance = atol + rtol * std::abs(e);

      if (abs_error > tolerance || std::isinf(a) || std::isinf(e) || std::isnan(a) ||
          std::isnan(e)) {
        if (mismatch_count < 8) {
          snprintf(buf,
                   sizeof(buf),
                   "Index (%d,%d): actual=%s, expected=%s, abs error=%f, tolerance=%f\n",
                   r,
                   c,
                   std::to_string(a).c_str(),
                   std::to_string(e).c_str(),
                   abs_error,
                   tolerance);
          error_msg += (const char*)(buf);
        }
        mismatch_count++;
      }
    }
  }
  if (mismatch_count > 0) {
    const auto rate = mismatch_count * 100.f / (tv.row * tv.col);
    snprintf(buf,
             sizeof(buf),
             " [%d,%d] %d/%d(%.3f%%) elements mismatch\n",
             tv.row,
             tv.col,
             mismatch_count,
             tv.row * tv.col,
             rate);
    throw std::runtime_error(msg + std::string(buf) + error_msg);
  }
}

class DeviceTimer final {
 public:
  __device__ DeviceTimer(const char* msg) : msg_(msg) { start_ = clock64(); }
  __device__ ~DeviceTimer() {
    const auto elapsed_cycles = clock64() - start_;
#if defined(__arm__) || defined(__aarch64__)
    const auto freq = 1.53;  // GHz
#else
    const auto freq = 2.1;  // GHz
#endif
    const auto elapsed_us = elapsed_cycles / freq / 1000;
    if (blockIdx.x == 0 && blockIdx.y == 0 && threadIdx.x == 0 && threadIdx.y == 0) {
      printf("==========[%s]========= elapsed = %lu us\n", msg_, (uint64_t)elapsed_us);
    }
  }

 private:
  const char* msg_;
  uint64_t start_;
};

template <typename DstDataType>
__host__ __device__ void GemmCpuRowCol(Tensor2D<DstDataType>& D,
                                       const Tensor2D<__nv_bfloat16>& A,
                                       const Tensor2D<__nv_bfloat16>& B,
                                       float scale) {
  assert(A.view.col == B.view.row);
  assert(D.view.row == A.view.row && D.view.col == B.view.col);
#ifdef __CUDA_ARCH__
  if (
      // blockIdx.x != 0 ||
      threadIdx.x != 0 || threadIdx.y != 0) {
    return;
  }
#endif
  const int M = A.view.row;
  const int N = B.view.col;
  const int K = A.view.col;
  for (int m = 0; m < M; ++m) {
    for (int n = 0; n < N; ++n) {
      float sum = 0;
      for (int k = 0; k < K; ++k) {
        sum += __bfloat162float(A(m, k)) * __bfloat162float(B(k, n)) * scale;
      }
      if (std::is_same<DstDataType, __nv_bfloat16>::value) {
        D(m, n) = __float2bfloat16(sum);
      } else {
        D(m, n) = sum;
      }
    }
  }
}

// __forceinline__ __device__ void LoadTileA(typename MMA_M16N8K16RowColTile::ATileType &a_tile, int
// lane_id,
//                                           int m_tile, int k_tile,
//                                           const Tensor2D<MMA_M16N8K16RowColTile::ADataType> &A) {
//   using Tile = MMA_M16N8K16RowColTile;
//   constexpr int TM = Tile::M;
//   constexpr int TK = Tile::K;

//   const int row = (lane_id >> 1);          // 0 ~ 15
//   const int col = ((lane_id & 0x1) << 3);  // 0, 8, 0, 8 ...
//   const int g_row = m_tile * TM + row;
//   const int g_col = k_tile * TK + col;

// #pragma unroll 8
//   for (int i = 0; i < 8; ++i) {
//     int g_k = g_col + i;
//     const auto valid = g_row < A.view.row && g_k < A.view.col;
//     a_tile(row, col + i) = (valid ? A(g_row, g_k) : Tile::ADataType(0));
//   }
// }

// __forceinline__ __device__ void LoadTileB(typename MMA_M16N8K16RowColTile::BTileTypeColMajor
// &b_tile, int lane_id,
//                                           int k_tile, int n_tile,
//                                           const Tensor2D<MMA_M16N8K16RowColTile::BDataType> &B) {
//   using Tile = MMA_M16N8K16RowColTile;
//   constexpr int TN = Tile::N;
//   constexpr int TK = Tile::K;

//   int row = ((lane_id & 0x3) << 2);  // 0、4、8、12
//   int col = (lane_id >> 2);          // 0 ~ 7
//   int g_n = n_tile * TN + col;
//   int g_k_start = k_tile * TK + row;

//   const auto k_total = B.view.row / TK;
//   const auto n_total = B.view.col / TN;

//   if (n_tile < n_total && k_tile < k_total && sizeof(uint4) / sizeof(Tile::BDataType) == TN) {
//     *(uint2 *)(&b_tile(row, col)) = *(const uint2 *)(&B(g_k_start, g_n));
//   } else {
// #pragma unroll 4
//     for (int i = 0; i < 4; ++i) {
//       const int g_k = g_k_start + i;
//       const auto valid = g_k < B.view.row && g_n < B.view.col;
//       b_tile(row + i, col) = (valid ? B(g_k, g_n) : Tile::BDataType(0));
//     }
//   }
// }

// __forceinline__ __device__ void LoadTileB(typename MMA_M16N8K16RowColTile::BTileTypeRowMajor
// &b_tile, int lane_id,
//                                           int k_tile, int n_tile,
//                                           const Tensor2D<MMA_M16N8K16RowColTile::BDataType> &B) {
//   using Tile = MMA_M16N8K16RowColTile;
//   constexpr int TN = Tile::N;
//   constexpr int TK = Tile::K;

//   const int row = (lane_id >> 1);          // 0 ～ 15
//   const int col = ((lane_id & 0x1) << 2);  // 0 4
//   const int g_k = k_tile * TK + row;
//   const int g_n_start = n_tile * TN;

//   const auto k_total = B.view.row / TK;
//   const auto n_total = B.view.col / TN;

//   if (n_tile < n_total && k_tile < k_total && sizeof(uint4) / sizeof(Tile::BDataType) == TN) {
//     *(uint2 *)(&b_tile(row, col)) = *(const uint2 *)(&B(g_k, g_n_start + col));
//   } else {
// #pragma unroll 8
//     for (int i = 0; i < TN; ++i) {
//       int g_n = g_n_start + i;
//       const auto valid = (g_k < B.view.row && g_n < B.view.col);
//       b_tile(row, i) = (valid ? B(g_k, g_n) : Tile::BDataType(0));
//     }
//   }
// }

// =====================================================================================================================
template <int MaxSeqLen, int HeadDim, int NbQHeads, int NbKVHeads, int SMemSize>
struct AttnConfig {
  static const constexpr int kMaxSeqLen = MaxSeqLen;
  static const constexpr int kHeadDim = HeadDim;
  static const constexpr int kNbQHeads = NbQHeads;
  static const constexpr int kNbKVHeads = NbKVHeads;
  static const constexpr int kSMemSize = SMemSize;
};

template <typename Config>
struct AttnFusionType {
  using DataType = __nv_bfloat16;
  using Tile = MMA_M16N8K16RowColTile;
  static const constexpr auto kWarpSize = 32;

  struct ParamIn {
    const DataType* key_cache = nullptr;    //
    const DataType* value_cache = nullptr;  //
    const DataType* query = nullptr;        //
    const DataType* key = nullptr;          //
    const DataType* value = nullptr;        //
    const int32_t* seq_idx = nullptr;       //
  };

  struct ParamOut {
    DataType* output_emb = nullptr;  //
    uint8_t* hbm_cache = nullptr;    //
    float* qk_result = nullptr;      //
  };

  template <typename DType, int HeadDim>
  struct ReduceType {
    DType data[HeadDim];
    float m;
    float l;
    int lck;
    int unused;
  };

  // template <int MaxSeqLen = 3072, int MaxQSplitCount = 7, int kHeadDim = 128>
  // struct ShareMemStorage {
  //   static const constexpr auto kSeqLenS = AlignUp<4>(Ceil<MaxSeqLen, MaxQSplitCount>());
  //   static const constexpr auto kSeqLenP = AlignUp<8>(Ceil<MaxSeqLen, MaxQSplitCount>());
  //   union {
  //     float s[kSeqLenS];
  //     DataType o[kHeadDim];
  //   };
  //   DataType p[kSeqLenP];
  //   DataType v[8 * 1024];
  // };

  template <typename T>
  struct BufferView {
    __host__ __device__ BufferView(T* ptr, int elem_sz) : data(ptr), count(elem_sz) {}
    __host__ __device__ T* GetEndPtr() const { return data + count; }
    __host__ __device__ int GetBytes() const { return sizeof(T) * count; }
    T* data;
    int count;  //
  };

  template <int kHeadDim = 128>
  struct ShareMemStorageRt {
    using Tile = MMA_M16N8K16RowColTile;
    __host__ __device__ __forceinline__
    ShareMemStorageRt(DataType* mem, int bytes, int seqlen, int splitcnt)
        : smem(mem), nbytes(bytes), seq_len_blk(seqlen), split_cnt(splitcnt) {}

    __host__ __device__ __forceinline__ BufferView<float> GetS() {
      // auto eptr = reinterpret_cast<float *>(AlignUp<1024U>(reinterpret_cast<uintptr_t>(smem)));
      constexpr auto kAlignVal = (Tile::K > Tile::N ? Tile::K : Tile::N);
      auto ptr = (float*)(smem);
      auto count = (int)AlignUp<kAlignVal>((uint32_t)seq_len_blk);
      return {ptr, count};
    }

    __host__ __device__ __forceinline__ BufferView<DataType> GetO() {
      const auto ptr = (DataType*)(GetS().data);
      return {ptr, kHeadDim};
    }

    __host__ __device__ __forceinline__ BufferView<float> GetMCache() {
      const auto& s = GetS();
      const auto& o = GetO();
      auto ptr = s.GetBytes() > o.GetBytes() ? s.GetEndPtr() : (float*)o.GetEndPtr();
      auto count = (int)AlignUp<Tile::K>(Ceil(seq_len_blk, Tile::N));
      return {ptr, count};
    }
    __host__ __device__ __forceinline__ BufferView<float> GetLCache() {
      auto ptr = (float*)GetMCache().GetEndPtr();
      auto count = (int)AlignUp<Tile::K>(Ceil(seq_len_blk, Tile::N));
      return {ptr, count};
    }
    __host__ __device__ __forceinline__ BufferView<DataType> GetQ() {
      auto ptr = (DataType*)(GetLCache().GetEndPtr());
      constexpr auto count = AlignUp<Tile::K, kHeadDim>();
      return {ptr, count};
    }
    __host__ __device__ __forceinline__ BufferView<DataType> GetK() {
      auto ptr = (DataType*)(GetQ().GetEndPtr());
      ptr = (DataType*)AlignUp<128>(reinterpret_cast<uintptr_t>(ptr));
      int count = (GetRealEndPtr() - (uint8_t*)ptr) / sizeof(DataType);
      return {ptr, count};
    }
    __host__ __device__ __forceinline__ BufferView<DataType> GetP() {
      auto ptr = GetQ().data;
      auto count = GetS().count;
      return {ptr, count};
    }

    __host__ __device__ __forceinline__ BufferView<DataType> GetV() {
      auto ptr = GetP().GetEndPtr();
      int count = (GetRealEndPtr() - (uint8_t*)ptr) / sizeof(DataType);
      return {ptr, count};
    }
    //
    __host__ __device__ __forceinline__ BufferView<float> GetIntroBlockReduceCache() {
      const auto warp_total = (blockDim.x * blockDim.y + kWarpSize - 1) / kWarpSize;
      auto ptr = (float*)GetLCache().GetEndPtr();
      auto count = (int)AlignUp<sizeof(float)>(warp_total * 2);  // m and l
      return {ptr, count};
    }
    __host__ __device__ __forceinline__ BufferView<ReduceType<DataType, Config::kHeadDim>>
    GetCrossBlockReduceCache() {
      auto ptr = (ReduceType<DataType, Config::kHeadDim>*)(GetQ().data);
      return {ptr, split_cnt};
    }

    __host__ __device__ __forceinline__ uint8_t* GetRealEndPtr() const {
      return (uint8_t*)smem + nbytes;
    }

    DataType* smem;  //
    const int nbytes;
    const int seq_len_blk;
    const int split_cnt;
  };

  __device__ __forceinline__ static void CopyKVToCache(const ParamIn& param,
                                                       int seq_blk_total,
                                                       int seq_val) {
    if (blockIdx.y == seq_blk_total - 1 && blockIdx.x < Config::kNbKVHeads) {
      constexpr auto kNbKVHeads = Config::kNbKVHeads;
      constexpr auto kHeadDim = Config::kHeadDim;
      constexpr auto kMaxSeqLen = Config::kMaxSeqLen;

      const int tid = threadIdx.x + threadIdx.y * blockDim.x;

      const auto thread_total = blockDim.y * blockDim.x;
      constexpr auto group = kHeadDim / (sizeof(uint4) / sizeof(DataType));
      constexpr auto rem = kHeadDim % (sizeof(uint4) / sizeof(DataType));
      const auto src_offset = blockIdx.x * kHeadDim;
      const auto dst_offset = blockIdx.x * kMaxSeqLen * kHeadDim + seq_val * kHeadDim;
      const auto key_ptr = param.key + src_offset;
      const auto value_ptr = param.value + src_offset;
      auto key_cache_ptr = const_cast<DataType*>(param.key_cache + dst_offset);
      auto value_cache_ptr = const_cast<DataType*>(param.value_cache + dst_offset);
      if (group <= thread_total) {
        if (tid < group) {
          ((uint4*)key_cache_ptr)[tid] = ((uint4*)key_ptr)[tid];
          ((uint4*)value_cache_ptr)[tid] = ((uint4*)value_ptr)[tid];
        }
        if (rem != 0) {
          if (tid == 0) {
            const auto idx_base = group * (sizeof(uint4) / sizeof(DataType));
            for (int i = 0; i < rem; i++) {
              key_cache_ptr[idx_base + i] = key_ptr[idx_base + i];
              value_cache_ptr[idx_base + i] = value_ptr[idx_base + i];
            }
          }
        }
      } else {
        if (tid == 0) {
          for (int i = 0; i < kHeadDim; i++) {
            key_cache_ptr[i] = key_ptr[i];
            value_cache_ptr[i] = value_ptr[i];
          }
        }
      }
      __syncthreads();
    }
  }

  __device__ __forceinline__ static void SplitBlock(int& seq_blk_total,
                                                    int& seq_len_per_blk,
                                                    int& seq_idx_start,
                                                    int seq_val) {
    const int warp_total = (blockDim.x * blockDim.y + kWarpSize - 1) / kWarpSize;
    seq_val++;
    seq_blk_total = min(Ceil(seq_val, Tile::N * warp_total), gridDim.y);
    auto tmp = seq_val / seq_blk_total;
    const auto rem = seq_val % seq_blk_total;
    seq_idx_start = blockIdx.y * tmp + min(blockIdx.y, rem);
    if (blockIdx.y < rem) {
      tmp++;
    }
    seq_len_per_blk = tmp;
  }

  __device__ __forceinline__ static const Tensor2D<DataType> GetK(const DataType* key_cache,
                                                                  int seq_idx_start,
                                                                  int seq_len_per_blk) {
    constexpr auto kNbKVHeads = Config::kNbKVHeads;
    constexpr auto kHeadDim = Config::kHeadDim;
    constexpr auto kMaxSeqLen = Config::kMaxSeqLen;
    constexpr auto kNbQHeads = Config::kNbQHeads;
    const auto key_head_idx = blockIdx.x / (kNbQHeads / kNbKVHeads);
    const auto key_cache_start = key_cache + key_head_idx * kMaxSeqLen * kHeadDim;
    auto key_blk_start = key_cache_start + seq_idx_start * kHeadDim;
    return Tensor2D<DataType>(key_blk_start,
                              MemType::kDevice,
                              {kHeadDim, seq_len_per_blk, 1, kHeadDim});
  }

  __device__ __forceinline__ static const Tensor2D<DataType> GetQ(const DataType* query) {
    constexpr auto kHeadDim = Config::kHeadDim;
    const auto query_start = query + blockIdx.x * kHeadDim;
    return Tensor2D<DataType>(query_start, MemType::kDevice, {1, kHeadDim, kHeadDim, 1});
  }

  __device__ __forceinline__ static const Tensor2D<DataType> GetV(const DataType* value_cache,
                                                                  int seq_idx_start,
                                                                  int seq_len_per_blk) {
    constexpr auto kNbKVHeads = Config::kNbKVHeads;
    constexpr auto kHeadDim = Config::kHeadDim;
    constexpr auto kMaxSeqLen = Config::kMaxSeqLen;
    constexpr auto kNbQHeads = Config::kNbQHeads;
    const auto value_head_idx = blockIdx.x / (kNbQHeads / kNbKVHeads);
    const auto value_start = value_cache + value_head_idx * kMaxSeqLen * kHeadDim;
    const auto value_blk_start = value_start + seq_idx_start * kHeadDim;
    return Tensor2D<DataType>(value_blk_start,
                              MemType::kDevice,
                              {seq_len_per_blk, kHeadDim, kHeadDim, 1});
  }

  // __device__ __forceinline__ static void PreloadQ(Tile::ATileType *qtiles, const
  // Tensor2D<DataType> &q, int warp_total,
  //                                                 int warp_id, int lane_id) {
  //   constexpr auto kHeadDim = Config::kHeadDim;
  //   constexpr auto kTileTotal = Ceil<kHeadDim, Tile::K>();
  //   using QTileArray = Tile::ATileType[kTileTotal];
  //   auto tiles_per_warp = (kTileTotal + warp_total - 1) / warp_total;
  //   for (int i = 0; i < tiles_per_warp; i++) {
  //     auto tile_idx = warp_id * tiles_per_warp + i;
  //     if (tile_idx < kTileTotal) {
  //       auto base = &qtiles[tile_idx](0, 0);
  //       for (int j = lane_id * Tile::K / 2; j < lane_id * Tile::K / 2 + Tile::K / 2; j++) {
  //         base[j] = (lane_id < 2) ? q(0, tile_idx * Tile::K + j) : DataType(0);
  //       }
  //     }
  //   }
  // }

  __device__ __forceinline__ static void PrefetchQ(Tile::ADataType* qtiles,
                                                   const Tensor2D<DataType>& qobj,
                                                   int warp_id,
                                                   int lane_id) {
    constexpr auto kHeadDim = Config::kHeadDim;
    static_assert(kHeadDim * sizeof(Tile::ADataType) % 16 == 0,
                  "error: kHeadDim * sizeof(Tile::ADataType) % 16 == 0");
    auto tid = warp_id * kWarpSize + lane_id;
    if (tid < kHeadDim * sizeof(Tile::ADataType) / 16) {  // 一次加载16个字节，一共是128*2个字节
      const auto col = tid * 8;                           // 16个字节也就是8个元素
      auto src = &qobj(0, 0) + col;
      auto dst = qtiles + col;
      Load16Bytes<PrefetchMode::kPrefetch>(dst, src);
    }
    CommitGroup();
  }

  // __forceinline__ __device__ static void PrefetchQ(Tile::ATileType &qtile, int lane_id, int
  // /*m_tile*/, int k_tile,
  //                                                  const Tensor2D<Tile::ADataType> &qsrc) {
  //   const int row = (lane_id >> 1);  // 0, 0, 1, 1, 2, 2
  //   if (row == 0) {
  //     constexpr int TK = Tile::K;
  //     constexpr auto kHeadDim = Config::kHeadDim;
  //     static_assert(kHeadDim % TK == 0, "error: kHeadDim % TK != 0");
  //     const int col = ((lane_id & 0x1) << 3);  // 0, 8, 0, 8 ...
  //     const int g_col = k_tile * TK + col;

  //     auto src = &qsrc(0, g_col);
  //     // auto dst = &qtile(0, col);
  //     auto dst = &qtile(0, 0) + QTileLayout::Apply(0, col) / 2;
  //     Load16Bytes<PrefetchMode::kPrefetch>(dst, src);  // st 600
  //   }
  //   CommitGroup();
  // }

  __forceinline__ __device__ static void PrefetchK(Tile::BTileTypeColMajor& btile,
                                                   int lane_id,
                                                   int k_tile,
                                                   int n_tile,
                                                   const Tensor2D<Tile::BDataType>& kobj) {
    if (lane_id < 16) {
      constexpr int TN = Tile::N;
      constexpr int TK = Tile::K;
      constexpr auto kHeadDim = Config::kHeadDim;
      static_assert(kHeadDim % TK == 0, "error: kHeadDim % TK != 0");
      const auto row = lane_id % 2 * 8;  // 0,8,0,8,0,8,0,8,...
      const auto col = lane_id / 2;      // 0,0,1,1,2,2,3,3,...7,7
      const auto g_col = n_tile * TN + col;
      const auto g_row = k_tile * TK + row;

      const auto pred = (g_col < kobj.view.col);
      const auto src = &kobj(g_row, g_col);
      // auto dst = &btile(row, col);
      auto dst = &btile(0, 0) + KTileLayout::Apply(row, col);
      Load16BytesWithPred<PrefetchMode::kPrefetch, SharedMemFillMode::kFillZero>(dst, src, pred);
    }
    CommitGroup();
  }

  __forceinline__ __device__ static void PrefetchKCol(Tile::BDataType* btiles,
                                                      int lane_id,
                                                      int k_tile,
                                                      int n_tile,
                                                      const Tensor2D<Tile::BDataType>& kobj) {
    constexpr int TN = Tile::N;
    constexpr int TK = Tile::K;
    constexpr auto kHeadDim = Config::kHeadDim;
    static_assert(kHeadDim % (TK * 4) == 0, "error: kHeadDim % (TK*4) != 0");
    const auto row =
        lane_id % 8 * 8;  // 0,8,16,24,32,40,48,56, 0,8,16,24,32,40,48,56 ... 0,8,16,24,32,40,48,56
    const auto col =
        lane_id / 8 * 2;  // 0,0, 0, 0, 0, 0, 0, 0, 2,2, 2, 2, 2, 2, 2, 2 ... 6,6, 6, 6, 6, 6, 6, 6
    const auto g_col = n_tile * TN + col;
    const auto g_row = k_tile * TK + row;
    const auto total_col = kobj.view.col;
    {
      const auto pred = (g_col < total_col);
      const auto src = &kobj(g_row, g_col);
      auto dst = btiles + KTileLayout::Apply(row, col);
      Load16BytesWithPred<PrefetchMode::kPrefetch, SharedMemFillMode::kFillZero>(dst, src, pred);
    }
    {
      const auto pred = (g_col + 1 < total_col);
      const auto src = &kobj(g_row, g_col + 1);
      auto dst = btiles + KTileLayout::Apply(row, col + 1);
      Load16BytesWithPred<PrefetchMode::kPrefetch, SharedMemFillMode::kFillZero>(dst, src, pred);
    }
    CommitGroup();
  }

  __forceinline__ __device__ static void PrefetchV(Tile::BTileTypeRowMajor& btile,
                                                   int lane_id,
                                                   int k_tile,
                                                   int n_tile,
                                                   const Tensor2D<Tile::BDataType>& vobj) {
    constexpr int TK = Tile::K;
    if (lane_id < TK) {
      constexpr auto kHeadDim = Config::kHeadDim;
      static_assert(kHeadDim % TK == 0, "error: kHeadDim % TK != 0");
      constexpr int TN = Tile::N;
      const auto row = lane_id;  // 0,1,2,...15
      constexpr auto col = 0;    // 0
      const int g_col = n_tile * TN + col;
      const int g_row = k_tile * TK + row;

      const auto pred = (g_row < vobj.view.row);
      const auto src = &vobj(g_row, g_col);
      // auto dst = &btile(row, col);

      auto dst = &btile(0, 0) + VTileLayout::Apply(row, col);

      Load16BytesWithPred<PrefetchMode::kNoPrefetch, SharedMemFillMode::kFillZero>(
          dst,
          src,
          pred);  // st 2400
    }
    CommitGroup();
  }

  __forceinline__ __device__ static void PrefetchVRow(DataType* btile,
                                                      int lane_id,
                                                      int k_tile,
                                                      int n_tile,
                                                      const Tensor2D<Tile::BDataType>& vobj) {
    constexpr int TK = Tile::K;
    constexpr int TN = Tile::N;
    constexpr auto kHeadDim = Config::kHeadDim;
    static_assert(kHeadDim % TK == 0, "error: kHeadDim % TK != 0");

    const auto row = lane_id / 8;  // 0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,...3,3,3,3,3,3,3,3
    const auto col = lane_id % 8;  // 0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7,...0,1,2,3,4,5,6,7
    const auto total_row = vobj.view.row;
    const auto koffset = k_tile * TK;
    const auto noffset = n_tile * TN;
    for (int kk = 0; kk < 8; kk++) {
      const auto cache_row = kk * 4 + row;
      const auto cache_col = col * 8;
      const auto g_row = koffset + cache_row;
      const auto g_col = noffset + cache_col;
      const auto pred = (g_row < total_row);
      const auto src = &vobj(g_row, g_col);
      auto dst = btile + VTileLayout::Apply(cache_row, cache_col);
      Load16BytesWithPred<PrefetchMode::kPrefetch, SharedMemFillMode::kFillZero>(dst, src, pred);
    }

    // const auto row = lane_id;
    // for (int col = 0; col < 64; col += 8) {
    //   const int g_col = n_tile * TN + col;
    //   const int g_row = k_tile * TK + row;

    //   const auto pred = (g_row < vobj.view.row);
    //   const auto src = &vobj(g_row, g_col);
    //   auto dst = btile + VTileLayout::Apply(row, col);

    //   Load16BytesWithPred<PrefetchMode::kPrefetch, SharedMemFillMode::kFillZero>(dst, src, pred);
    // }
    CommitGroup();
  }

  __device__ __forceinline__ static void TileSafeSoftmax(float* out0,
                                                         float* out1,
                                                         float* m,
                                                         float* l,
                                                         int lane_id,
                                                         float frag0,
                                                         float frag1,
                                                         bool pred0,
                                                         bool pred1,
                                                         bool is_active) {
    float local_max = -__FLT_MAX__;
    if (is_active) {
      if (pred0) {
        local_max = frag0;
      }
      if (pred1) {
        local_max = fmaxf(local_max, frag1);
      }
    }

#pragma unroll
    for (int mask = 4; mask > 0; mask >>= 1) {
      float neighbor_max = __shfl_xor_sync(0xFFFFFFFF, local_max, mask);
      local_max = fmaxf(local_max, neighbor_max);
    }

    float exp0 = 0.0f;
    float exp1 = 0.0f;
    if (is_active) {
      if (pred0) {
        exp0 = expf(frag0 - local_max);
      }
      if (pred1) {
        exp1 = expf(frag1 - local_max);
      }
    }

    float local_sum = exp0 + exp1;
#pragma unroll
    for (int mask = 4; mask > 0; mask >>= 1) {
      local_sum += __shfl_xor_sync(0xFFFFFFFF, local_sum, mask);
    }

    if (is_active) {
      constexpr float eps = 1e-10f;
      const float inv_sum = 1.0f / (local_sum + eps);
      *out0 = pred0 ? (exp0 * inv_sum) : 0.0f;
      *out1 = pred1 ? (exp1 * inv_sum) : 0.0f;
      if (lane_id == 0) {
        *m = local_max;
        *l = local_sum;
      }
    }
  }

  __device__ static void WarpReduceML(float& global_max_m,
                                      float& global_sum_l,
                                      int warp_id,
                                      int lane_id,
                                      int n_tiles_total,
                                      const float* m_array,
                                      const float* l_array) {
    const int idx = warp_id * kWarpSize + lane_id;

    const float m = (idx < n_tiles_total) ? m_array[idx] : -__FLT_MAX__;
    float warp_max = m;
#pragma unroll
    for (int offset = 16; offset >= 1; offset >>= 1) {
      warp_max = fmaxf(warp_max, __shfl_xor_sync(0xFFFFFFFF, warp_max, offset));
    }

    // const float l = (idx < n_tiles_total) ? l_array[idx] : 0.0f;
    float warp_sum = (idx < n_tiles_total) ? (l_array[idx] * __expf(m - warp_max)) : 0.f;
#pragma unroll
    for (int offset = 16; offset >= 1; offset >>= 1) {
      warp_sum += __shfl_xor_sync(0xFFFFFFFF, warp_sum, offset);
    }

    if (lane_id == 0) {
      global_max_m = warp_max;
      global_sum_l = warp_sum;
    }
  }

  __device__ static void BlockReduceML(float& g_m,
                                       float& g_l,
                                       int warp_id,
                                       int lane_id,
                                       int N,
                                       const float* m_array,
                                       const float* l_array,
                                       float* smem) {
    const auto n_tiles_total = (N + Tile::N - 1) / Tile::N;
    const int warp_count_needed = Ceil(n_tiles_total, kWarpSize);
    __shared__ float m_share;
    __shared__ float l_share;
    if (warp_count_needed == 1) {
      if (warp_id < 1) {
        float local_m = -__FLT_MAX__;
        float local_l = 0.f;
        WarpReduceML(local_m, local_l, warp_id, lane_id, n_tiles_total, m_array, l_array);
        if (lane_id == 0) {
          m_share = local_m;
          l_share = local_l;
        }
      }
      __syncthreads();
      g_m = m_share;
      g_l = l_share;
    } else {
      float* m_warp_array = smem;
      float* l_warp_array = m_warp_array + AlignUp<4>(warp_count_needed);
      if (warp_id < warp_count_needed) {
        WarpReduceML(m_warp_array[warp_id],
                     l_warp_array[warp_id],
                     warp_id,
                     lane_id,
                     n_tiles_total,
                     m_array,
                     l_array);
      }
      __syncthreads();

      if (warp_id == 0 && lane_id == 0) {
        float local_m = -__FLT_MAX__;
        float local_l = 0.f;
        switch (warp_count_needed) {
          case 2: {
            float2 m_tmp = *reinterpret_cast<float2*>(m_warp_array);
            local_m = max(m_tmp.x, m_tmp.y);

            float2 l_tmp = *reinterpret_cast<float2*>(l_warp_array);
            local_l = l_tmp.x * expf(m_tmp.x - local_m) + l_tmp.y * expf(m_tmp.y - local_m);
            break;
          }
          case 3: {
            float3 m_tmp = *reinterpret_cast<float3*>(m_warp_array);
            local_m = max(max(m_tmp.x, m_tmp.y), m_tmp.z);

            float3 l_tmp = *reinterpret_cast<float3*>(l_warp_array);
            local_l = l_tmp.x * expf(m_tmp.x - local_m) + l_tmp.y * expf(m_tmp.y - local_m) +
                      l_tmp.z * expf(m_tmp.z - local_m);
            break;
          }
          default: {
            for (int i = 0; i < warp_count_needed; ++i) {
              local_m = max(local_m, m_warp_array[i]);
            }
            for (int i = 0; i < warp_count_needed; ++i) {
              local_l += l_warp_array[i] * expf(m_warp_array[i] - local_m);
            }
          }
        }

        m_share = local_m;
        l_share = local_l;
      }
      __syncthreads();
      g_m = m_share;
      g_l = l_share;
    }
  }

  template <typename DstType>
  __device__ static void CorrectWithBlockML(Tensor2D<DstType>& dst,
                                            Tensor2D<float>& score,
                                            int seq_len_per_blk,
                                            int warp_total,
                                            int warp_id,
                                            int lane_id,
                                            const float* m_array,
                                            const float* l_array,
                                            float g_m,
                                            float g_l) {
    constexpr int TN = Tile::N;
    const auto thread_total = warp_total * kWarpSize;
    const int size_per_thread = (seq_len_per_blk + thread_total - 1) / thread_total;
    const int tid = warp_id * kWarpSize + lane_id;
    constexpr float eps = 1e-10f;
    const float inv_g_l = 1.0f / (g_l + eps);

    auto idx_start = tid * size_per_thread;
    auto idx_end = min(seq_len_per_blk, idx_start + size_per_thread);

    for (int idx = idx_start; idx < idx_end; idx++) {
      const int local_idx = idx / TN;
      const float local_m = m_array[local_idx];
      const float local_l = l_array[local_idx];
      const float val = score(0, idx) * local_l * expf(local_m - g_m) * inv_g_l;
      if (std::is_same<DstType, __nv_bfloat16>::value) {
        dst(0, idx) = __float2bfloat16(val);
      } else {
        dst(0, idx) = val;
      }
    }
  }

  __device__ static void CrossBlockReduce(ReduceType<DataType, Config::kHeadDim>* smem_cache,
                                          ReduceType<DataType, Config::kHeadDim>* hbm_cache,
                                          int& idx_start,
                                          int& len,
                                          const Tensor2D<DataType>& out,
                                          float b_m,
                                          float b_l,
                                          int seq_blk_total,
                                          int seq_len_per_blk,
                                          int warp_id,
                                          int lane_id) {
    if (seq_blk_total > 1 && blockIdx.y < seq_blk_total) {
      auto tid = warp_id * kWarpSize + lane_id;
      auto& bulk = hbm_cache[blockIdx.y];
      if (tid < Config::kHeadDim) {
        bulk.data[tid] = out(0, tid);
      } else if (tid == Config::kHeadDim) {
        bulk.m = b_m;
        bulk.l = b_l;
      }
      __threadfence();
      SemPost(&bulk.lck, 1, (tid == 0));
      SemWaitMany(&hbm_cache[tid].lck, seq_blk_total, (tid < seq_blk_total));
      const auto split = [](auto& idx_start, auto& len, auto blk_total, auto elem_count) {
        len = elem_count / blk_total;
        const auto rem = elem_count % blk_total;
        const auto bidx = blockIdx.y;
        idx_start = bidx * len + min(bidx, rem);
        if (bidx < rem) {
          len++;
        }
      };

      split(idx_start, len, seq_blk_total, Config::kHeadDim);

      if (tid < len * seq_blk_total) {
        const auto didx = tid % len;
        const auto bidx = tid / len % seq_blk_total;
        smem_cache[bidx].data[didx] = hbm_cache[bidx].data[idx_start + didx];
        smem_cache[bidx].m = hbm_cache[bidx].m;
        smem_cache[bidx].l = hbm_cache[bidx].l;
      }

      __syncthreads();
    }
  }

  __device__ static void CalcQK(Tensor2D<float>& sobj,
                                float* marray,
                                float* larray,
                                const Tensor2D<DataType>& qobj,
                                const Tensor2D<DataType>& kobj,
                                ShareMemStorageRt<Config::kHeadDim>& smgr,
                                cg::thread_block& block,
                                cg::thread_block_tile<kWarpSize, cg::thread_block>& warp) {
    constexpr int TN = Tile::N;
    constexpr int TK = Tile::K;

    const auto warp_total = warp.meta_group_size();
    const auto warp_id = warp.meta_group_rank();
    const auto lane_id = warp.thread_rank();

    const auto N = kobj.view.col;

    const int n_tiles_total = (N + TN - 1) / TN;
    const int seq_group = (n_tiles_total + warp_total - 1) / warp_total;
    const int start_n_tile = warp_id * seq_group;
    const int end_n_tile = min(n_tiles_total, start_n_tile + seq_group);

    using ATileRow = Array<Tile::ADataType, Tile::K>;
    auto atiles = reinterpret_cast<ATileRow*>(smgr.GetQ().data);
    PrefetchQ((DataType*)atiles, qobj, warp_id, lane_id);
    WaitGroup<0>();
    block.sync();
    if (start_n_tile < end_n_tile) {
      constexpr auto kHeadDim = Config::kHeadDim;
      constexpr auto K = kHeadDim;
      constexpr int kTilesTotal = (K + TK - 1) / TK;
      auto btiles = reinterpret_cast<Tile::BTileTypeColMajor*>(smgr.GetK().data);
      PrefetchK(btiles[warp_id * 2 + 0], lane_id, 0, start_n_tile, kobj);

      Tile tile;
      Tile::DRegType d_frag;
      const float scale = 1.f / sqrtf(static_cast<float>(kHeadDim));
      int idx = 0;

      for (int n_tile = start_n_tile; n_tile < end_n_tile; ++n_tile) {
        for (int di = 0; di < sizeof(d_frag) / sizeof(d_frag[0]); di++) {
          d_frag[di] = 0.f;
        }
        for (int k_tile = 1; k_tile < kTilesTotal; ++k_tile) {
          idx++;
          const auto current = (idx & 1);
          const auto prev = (current ^ 1);
          PrefetchK(btiles[warp_id * 2 + current], lane_id, k_tile, n_tile, kobj);
          WaitGroup<1>();
          warp.sync();
          tile.Load(lane_id, &atiles[k_tile - 1][0], btiles[warp_id * 2 + prev]);
          tile.Fma(d_frag, d_frag);
        }

        if (n_tile + 1 < end_n_tile) {
          idx++;
          const auto current = (idx & 1);
          PrefetchK(btiles[warp_id * 2 + current], lane_id, 0, n_tile + 1, kobj);
          WaitGroup<1>();
        } else {
          idx++;
          WaitGroup<0>();
        }
        const auto current = ((idx - 1) & 1);
        warp.sync();
        tile.Load(lane_id, (DataType*)(&atiles[kTilesTotal - 1]), btiles[warp_id * 2 + current]);
        tile.Fma(d_frag, d_frag);

        const int row = (lane_id >> 2);
        const int col = ((lane_id & 0x3) << 1);
        const int g_n0 = n_tile * TN + col;
        const int g_n1 = g_n0 + 1;
        TileSafeSoftmax(&sobj(0, g_n0),
                        &sobj(0, g_n1),
                        &marray[n_tile],
                        &larray[n_tile],
                        lane_id,
                        (d_frag[0] * scale),
                        (d_frag[1] * scale),
                        (g_n0 < N),
                        (g_n1 < N),
                        (row == 0));
      }
    }
  }

  __device__ static void CalcQKCol(Tensor2D<float>& sobj,
                                   float* marray,
                                   float* larray,
                                   const Tensor2D<DataType>& qobj,
                                   const Tensor2D<DataType>& kobj,
                                   ShareMemStorageRt<Config::kHeadDim>& smgr,
                                   cg::thread_block& block,
                                   cg::thread_block_tile<kWarpSize, cg::thread_block>& warp) {
    constexpr int TN = Tile::N;
    constexpr int TK = Tile::K;

    const auto warp_total = warp.meta_group_size();
    const auto warp_id = warp.meta_group_rank();
    const auto lane_id = warp.thread_rank();

    const auto N = kobj.view.col;

    const int n_tiles_total = (N + TN - 1) / TN;
    const int seq_group = (n_tiles_total + warp_total - 1) / warp_total;
    const int start_n_tile = warp_id * seq_group;
    const int end_n_tile = min(n_tiles_total, start_n_tile + seq_group);

    using ATileRow = Array<Tile::ADataType, Tile::K>;
    auto atiles = reinterpret_cast<ATileRow*>(smgr.GetQ().data);
    PrefetchQ((DataType*)atiles, qobj, warp_id, lane_id);
    WaitGroup<0>();
    block.sync();
    if (start_n_tile < end_n_tile) {
      constexpr auto kHeadDim = Config::kHeadDim;
      constexpr auto K = kHeadDim;
      constexpr int kTilesTotal = (K + TK - 1) / TK;
      using BTileCol = Array<Tile::BDataType, 64 * TN>;
      auto btiles = reinterpret_cast<BTileCol*>(smgr.GetK().data);
      PrefetchKCol(&btiles[warp_id * 2 + 0][0], lane_id, 0, start_n_tile, kobj);

      Tile tile;
      Tile::DRegType d_frag;
      const float scale = 1.f / sqrtf(static_cast<float>(kHeadDim));
      int idx = 0;

      for (int n_tile = start_n_tile; n_tile < end_n_tile; ++n_tile) {
        for (int di = 0; di < sizeof(d_frag) / sizeof(d_frag[0]); di++) {
          d_frag[di] = 0.f;
        }
        for (int k_tile = 4; k_tile < kTilesTotal; k_tile += 4) {
          idx++;
          const auto current = (idx & 1);
          const auto prev = (current ^ 1);
          PrefetchKCol(&btiles[warp_id * 2 + current][0], lane_id, k_tile, n_tile, kobj);
          WaitGroup<1>();
          warp.sync();
          for (int i = 0; i < 4; ++i) {
            const int k_tile_idx = k_tile - 4 + i;
            if (k_tile_idx < kTilesTotal) {
              tile.LoadCol(lane_id, &atiles[k_tile_idx][0], &btiles[warp_id * 2 + prev][0], i);
              tile.Fma(d_frag, d_frag);
            }
          }
        }

        if (n_tile + 1 < end_n_tile) {
          idx++;
          const auto current = (idx & 1);
          PrefetchKCol(&btiles[warp_id * 2 + current][0], lane_id, 0, n_tile + 1, kobj);
          WaitGroup<1>();
        } else {
          idx++;
          WaitGroup<0>();
        }
        warp.sync();
        for (int i = 0; i < 4; ++i) {
          const int k_tile_idx = kTilesTotal - 4 + i;
          if (k_tile_idx < kTilesTotal) {
            const auto current = ((idx - 1) & 1);
            tile.LoadCol(lane_id, &atiles[k_tile_idx][0], &btiles[warp_id * 2 + current][0], i);
            tile.Fma(d_frag, d_frag);
          }
        }

        const int row = (lane_id >> 2);
        const int col = ((lane_id & 0x3) << 1);
        const int g_n0 = n_tile * TN + col;
        const int g_n1 = g_n0 + 1;
        TileSafeSoftmax(&sobj(0, g_n0),
                        &sobj(0, g_n1),
                        &marray[n_tile],
                        &larray[n_tile],
                        lane_id,
                        (d_frag[0] * scale),
                        (d_frag[1] * scale),
                        (g_n0 < N),
                        (g_n1 < N),
                        (row == 0));
      }
    }
  }

  __device__ static void CalcPV(Tensor2D<DataType>& out,
                                const Tensor2D<DataType>& pobj,
                                const Tensor2D<DataType>& vobj,
                                ShareMemStorageRt<Config::kHeadDim>& smgr,
                                cg::thread_block& block,
                                cg::thread_block_tile<kWarpSize, cg::thread_block>& warp) {
    const auto warp_total = warp.meta_group_size();
    const auto warp_id = warp.meta_group_rank();

    constexpr auto N = Config::kHeadDim;
    constexpr int TN = Tile::N;
    constexpr int TK = Tile::K;

    constexpr int nTilesTotal = (N + TN - 1) / TN;

    const int seq_group = (nTilesTotal + warp_total - 1) / warp_total;

    const int start_n_tile = warp_id * seq_group;
    if (start_n_tile < nTilesTotal) {
      const auto lane_id = warp.thread_rank();
      const auto K = pobj.view.col;
      const int k_tiles_total = (K + TK - 1) / TK;
      const int end_n_tile = min(nTilesTotal, start_n_tile + seq_group);

      Tile tile;
      Tile::DRegType d_frag;
      auto btiles = reinterpret_cast<Tile::BTileTypeRowMajor*>(smgr.GetV().data);
      auto obase = &out(0, 0);
      auto pbase = &pobj(0, 0);

      PrefetchV(btiles[warp_id * 2 + 0], lane_id, 0, start_n_tile, vobj);
      int idx = 0;
      for (int n_tile = start_n_tile; n_tile < end_n_tile; ++n_tile) {
        for (int di = 0; di < sizeof(d_frag) / sizeof(d_frag[0]); di++) {
          d_frag[di] = 0.f;
        }

        for (int k_tile = 1; k_tile < k_tiles_total; ++k_tile) {
          idx++;
          const auto current = (idx & 1);
          const auto prev = (current ^ 1);
          PrefetchV(btiles[warp_id * 2 + current], lane_id, k_tile, n_tile, vobj);
          WaitGroup<1>();
          warp.sync();
          tile.Load(lane_id, &pbase[(k_tile - 1) * TK], btiles[warp_id * 2 + prev]);
          tile.Fma(d_frag, d_frag);
        }
        if (n_tile + 1 < end_n_tile) {
          idx++;
          const auto current = (idx & 1);
          PrefetchV(btiles[warp_id * 2 + current], lane_id, 0, n_tile + 1, vobj);
          WaitGroup<1>();
        } else {
          idx++;
          WaitGroup<0>();
        }

        warp.sync();
        const auto current = ((idx - 1) & 1);
        tile.Load(lane_id, &pbase[(k_tiles_total - 1) * TK], btiles[warp_id * 2 + current]);
        tile.Fma(d_frag, d_frag);

        const int row = (lane_id >> 2);
        if (row == 0) {
          const int col = (lane_id & 0x3) << 1;
          const int g_n0 = n_tile * TN + col;
          // const int g_n1 = g_n0 + 1;
          DataType regdata[2];
          regdata[0] = __float2bfloat16(d_frag[0]);
          regdata[1] = __float2bfloat16(d_frag[1]);
          *reinterpret_cast<uint32_t*>(&obase[g_n0]) = *reinterpret_cast<uint32_t*>(&regdata[0]);
        }
      }
    }
  }

  __device__ static void CalcPVRow(Tensor2D<DataType>& out,
                                   const Tensor2D<DataType>& pobj,
                                   const Tensor2D<DataType>& vobj,
                                   ShareMemStorageRt<Config::kHeadDim>& smgr,
                                   cg::thread_block& block,
                                   cg::thread_block_tile<kWarpSize, cg::thread_block>& warp) {
    const auto warp_total = warp.meta_group_size();
    const auto warp_id = warp.meta_group_rank();
    const auto lane_id = warp.thread_rank();

    constexpr int N = Config::kHeadDim;
    constexpr int TN = Tile::N;
    constexpr int TK = Tile::K;
    const int K = pobj.view.col;

    static_assert(N % TN == 0, "error: N % TN != 0");

    // constexpr int n_tiles_total = N / TN;
    const int k_tiles_total = (K + TK - 1) / TK;
    using CacheType = Array<DataType, 64 * 32>;
    auto caches = reinterpret_cast<CacheType*>(smgr.GetV().data);
    auto vbase = reinterpret_cast<const CacheType*>(&vobj(0, 0));
    auto obase = &out(0, 0);
    auto pbase = &pobj(0, 0);
    auto otmp = reinterpret_cast<float*>(caches + 4);

    auto tid = warp_id * kWarpSize + lane_id;
    if (tid < N) {
      otmp[tid] = 0.f;
    }
    block.sync();

    if (warp_id < 2) {
      Tile tile;
      Tile::DRegType d_frag;
      int cnt = 0;
      auto wcache = caches + warp_id * 2;
      PrefetchVRow(&wcache[cnt & 1][0], lane_id, 0, warp_id * 8, vobj);

      const int row = (lane_id >> 2);          // 0,0,0,0,1,1,1,1,...3,3,3,3
      const int col = ((lane_id & 0x3) << 1);  // 0,2,4,6,0,2,4,6,...0,2,4,6
      for (int k = 0; k < k_tiles_total; k += 2) {
        if (k + 2 < k_tiles_total) {
          cnt++;
          PrefetchVRow(&wcache[cnt & 1][0], lane_id, k + 2, warp_id * 8, vobj);
          WaitGroup<1>();
        } else {
          cnt++;
          WaitGroup<0>();
        }

        for (int nn = 0; nn < 8; nn++) {
          const int g_n0 = (warp_id * 8 + nn) * TN + col;
          // const int g_n1 = g_n0 + 1;
          if (row == 0) {
            *reinterpret_cast<float2*>(&d_frag[0]) = *reinterpret_cast<float2*>(&otmp[g_n0]);
          }
          warp.sync();
          for (int kk = 0; kk < 2; kk++) {
            tile.LoadRow(lane_id, &pbase[(k + kk) * TK], &wcache[(cnt - 1) & 1][0], kk, nn);
            tile.Fma(d_frag, d_frag);
          }
          if (row == 0) {
            *reinterpret_cast<float2*>(&otmp[g_n0]) = *reinterpret_cast<float2*>(&d_frag[0]);
          }
        }
      }
    }
    block.sync();
    if (tid < N) {
      obase[tid] = __float2bfloat16(otmp[tid]);
    }
  }

  __device__ static void WriteOut(DataType* emb_start, const Tensor2D<DataType>& out) {
    const int tid = threadIdx.x + threadIdx.y * blockDim.x;
    if (tid < Config::kHeadDim) {
      emb_start[tid] = out(0, tid);
    }
  }

  __device__ static void WriteOut(DataType* emb_start,
                                  const ReduceType<DataType, Config::kHeadDim>* smem_cache,
                                  int idx_start,
                                  int len,
                                  int seq_blk_total) {
    __shared__ float share_m;
    __shared__ float share_inv_l;
    const int tid = threadIdx.x + threadIdx.y * blockDim.x;
    if (tid == 0) {
      float g_m = -__FLT_MAX__;
      for (int i = 0; i < seq_blk_total; i++) {
        g_m = max(smem_cache[i].m, g_m);
      }
      float g_l = 0.f;
      for (int i = 0; i < seq_blk_total; i++) {
        g_l += smem_cache[i].l * expf(smem_cache[i].m - g_m);
      }
      share_m = g_m;
      share_inv_l = 1.0f / (g_l + 1e-10f);
    }
    __syncthreads();
    if (tid < len) {
      const auto out_start = emb_start + idx_start;
      const float gm = share_m;
      const float inv_gl = share_inv_l;
      float sum = 0.f;
      for (int j = 0; j < seq_blk_total; j++) {
        const auto& bulk = smem_cache[j];
        sum += __bfloat162float(bulk.data[tid]) * bulk.l * expf(bulk.m - gm) * inv_gl;
      }
      out_start[tid] = __float2bfloat16(sum);
    }
  }

  __device__ __forceinline__ static void AttnFusionImpl(ParamOut& param_out,
                                                        const ParamIn& param_in) {
    constexpr auto kNbKVHeads = Config::kNbKVHeads;
    constexpr auto kHeadDim = Config::kHeadDim;
    constexpr auto kMaxSeqLen = Config::kMaxSeqLen;
    constexpr auto kSMemSize = Config::kSMemSize;
    const int seq_val = param_in.seq_idx[0];

    if (seq_val >= kMaxSeqLen) {
      return;
    }

    int seq_blk_total;
    int seq_len_per_blk;
    int seq_idx_start;
    SplitBlock(seq_blk_total, seq_len_per_blk, seq_idx_start, seq_val);

    if (blockIdx.y >= seq_blk_total) {
      return;
    }

    CopyKVToCache(param_in, seq_blk_total, seq_val);

    auto block = cg::this_thread_block();
    // const dim3 block_idx = block.group_index();  // blockIdx
    // const dim3 block_dims = block.group_dim();
    auto warp = cg::tiled_partition<kWarpSize>(block);
    const auto warp_total = warp.meta_group_size();
    const auto warp_id = warp.meta_group_rank();
    const auto lane_id = warp.thread_rank();

    auto emb_start = param_out.output_emb + blockIdx.x * kHeadDim;
    auto hbm_start =
        (ReduceType<DataType, Config::kHeadDim>*)(param_out.hbm_cache) + blockIdx.x * seq_blk_total;

    extern __shared__ DataType smem[];
    auto smgr = ShareMemStorageRt<kHeadDim>(smem, kSMemSize, seq_len_per_blk, seq_blk_total);
    auto s = Tensor2D<float>(smgr.GetS().data,
                             MemType::kDevice,
                             {1, seq_len_per_blk, seq_len_per_blk, 1});
    auto marray = smgr.GetMCache().data;
    auto larray = smgr.GetLCache().data;

    const auto& q = GetQ(param_in.query);
    const auto& k = GetK(param_in.key_cache, seq_idx_start, seq_len_per_blk);

#ifdef LIDS_PLATFORM_THOR
    CalcQKCol(s, marray, larray, q, k, smgr, block, warp);  // Thor
#else
    CalcQK(s, marray, larray, q, k, smgr, block, warp);
#endif

    block.sync();

    float b_m = -__FLT_MAX__;
    float b_l = 0.f;
    auto cache = smgr.GetIntroBlockReduceCache().data;
    BlockReduceML(b_m, b_l, warp_id, lane_id, seq_len_per_blk, marray, larray, cache);

    auto p = Tensor2D<DataType>(smgr.GetP().data, s.mem_type, s.view);
    CorrectWithBlockML(p,
                       s,
                       seq_len_per_blk,
                       warp_total,
                       warp_id,
                       lane_id,
                       marray,
                       larray,
                       b_m,
                       b_l);

    // set paddings to 0
    const auto tid = warp_id * kWarpSize + lane_id;
    if (tid < AlignUp<Tile::K>(p.view.col) - p.view.col) {
      auto idx = p.view.col + tid;
      p(0, idx) = DataType(0);
    }
    block.sync();

    const auto& v = GetV(param_in.value_cache, seq_idx_start, seq_len_per_blk);
    auto out = Tensor2D<DataType>(smgr.GetO().data, MemType::kDevice, {1, kHeadDim, kHeadDim, 1});

#ifdef LIDS_PLATFORM_THOR
    CalcPVRow(out, p, v, smgr, block, warp);
#else
    CalcPV(out, p, v, smgr, block, warp);
#endif
    block.sync();

    if (seq_blk_total > 1) {
      auto g_out = smgr.GetCrossBlockReduceCache().data;
      int idx_start = 0;
      int len = kHeadDim;
      CrossBlockReduce(g_out,
                       hbm_start,
                       idx_start,
                       len,
                       out,
                       b_m,
                       b_l,
                       seq_blk_total,
                       seq_len_per_blk,
                       warp_id,
                       lane_id);
      WriteOut(emb_start, g_out, idx_start, len, seq_blk_total);
    } else {
      WriteOut(emb_start, out);
    }
  }
};

template <typename Config>
__global__ void __launch_bounds__(32 * 6, 8)
    AttnFusion_simple(typename AttnFusionType<Config>::ParamOut param_out,
                      const typename AttnFusionType<Config>::ParamIn param_in) {
  // auto start = clock64();
  AttnFusionType<Config>::AttnFusionImpl(param_out, param_in);
  // for debug only
  // __syncthreads();
  // if (blockIdx.x == 0 && blockIdx.y == 0 && threadIdx.x == 0 && threadIdx.y == 0) {
  //   const auto elapsed_us = (clock64() - start) / 1.53f / 1000;
  //   param_out.qk_result[0] = elapsed_us;
  // }
}

void LaunchAttnWithGqa(__nv_bfloat16* output_emb,
                       float* hbm_cache,
                       __nv_bfloat16* key_cache,
                       __nv_bfloat16* value_cache,
                       const __nv_bfloat16* query,
                       const __nv_bfloat16* key,
                       const __nv_bfloat16* value,
                       const int32_t* seq_idx,
                       unsigned int max_seq_len,
                       unsigned int head_dim,
                       unsigned int num_q_heads,
                       unsigned int num_kv_heads,
                       float* qk_result,
                       cudaStream_t stream) {
  dim3 block(32 * 6);
  dim3 grid(16, 7);  // 16*7 == 14*8, 每个sm有8个block，Thor上共14个sm
#ifdef LIDS_PLATFORM_THOR
  constexpr size_t smem = 26 * 1024;  // Thor
#else
  constexpr size_t smem = 10 * 1024;
#endif
  // LOGD("head_dim=%d, num_q_heads=%d, num_kv_heads=%d", head_dim, num_q_heads, num_kv_heads);
  if (max_seq_len != 3072 || head_dim != 128 || num_q_heads != 16 || num_kv_heads != 2) {
    throw std::runtime_error("error: not support.");
  }

  using Config = AttnConfig<3072, 128, 16, 2, smem>;
  using AttnType = AttnFusionType<Config>;
  using ReduceType = AttnType::ReduceType<AttnType::DataType, Config::kHeadDim>;

  CHECK_CUDA_RESULT(cudaMemset(hbm_cache, 0, sizeof(ReduceType) * grid.y * grid.x));

  const auto kernel_func = &AttnFusion_simple<Config>;

  CHECK_CUDA_RESULT(
      cudaFuncSetAttribute(kernel_func, cudaFuncAttributeMaxDynamicSharedMemorySize, smem));
  int num_blocks_per_sm = -1;
  CHECK_CUDA_RESULT(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&num_blocks_per_sm,
                                                                  kernel_func,
                                                                  block.x,
                                                                  smem));
  // LOGD("num_blocks_per_sm = %d", num_blocks_per_sm);
  if (num_blocks_per_sm != 8) {
    throw std::runtime_error("error: num_blocks_per_sm != 8.\t" +
                             std::to_string(num_blocks_per_sm));
  }

  AttnType::ParamIn inp;
  inp.key_cache = key_cache;
  inp.value_cache = value_cache;
  inp.query = query;
  inp.key = key;
  inp.value = value;
  inp.seq_idx = seq_idx;

  AttnType::ParamOut outp;
  outp.output_emb = output_emb;
  outp.hbm_cache = (uint8_t*)hbm_cache;
  outp.qk_result = qk_result;

  kernel_func<<<grid, block, smem, stream>>>(outp, inp);

  CHECK_CUDA_RESULT(cudaGetLastError());
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer

#elif defined(LIDS_PLATFORM_X86)

#include <cuda_bf16.h>
#include <cuda_runtime_api.h>
#include <math_constants.h>

#include <algorithm>

#include "NvInferVersion.h"
#include "linfer/ops/trt/kvcache_gqa/kvcache_gqa.cuh"
#include "linfer/util/internal/cuda/util.h"
namespace linfer {
namespace ops {
namespace trt {
__global__ void kv_copy_kernel_simple(__nv_bfloat16* const key_cache,
                                      __nv_bfloat16* const value_cache,
                                      const __nv_bfloat16* const key_new,
                                      const __nv_bfloat16* const value_new,
                                      const int32_t* const seq_idx,
                                      unsigned int max_seq_len,
                                      unsigned int head_dim,
                                      unsigned int num_kv_heads) {
  unsigned int seq_idx_val = static_cast<unsigned int>(*seq_idx);
  if (threadIdx.x >= head_dim || seq_idx_val >= max_seq_len) {
    return;
  }

  __nv_bfloat16* dest_ptr = nullptr;
  const __nv_bfloat16* src_ptr = nullptr;

  if (blockIdx.x < num_kv_heads) {
    auto head_idx_key = blockIdx.x;
    dest_ptr =
        key_cache + head_idx_key * max_seq_len * head_dim + seq_idx_val * head_dim + threadIdx.x;
    src_ptr = key_new + head_idx_key * head_dim + threadIdx.x;
  } else {
    auto head_idx_value = blockIdx.x - num_kv_heads;
    dest_ptr = value_cache + head_idx_value * max_seq_len * head_dim + seq_idx_val * head_dim +
               threadIdx.x;
    src_ptr = value_new + head_idx_value * head_dim + threadIdx.x;
  }

  *dest_ptr = *src_ptr;
}

// copy new key to key cache and copy new value feature to value cache
// new key: [batch, num_kv_heads, 1, head_dim]
// key_cache: [batch, num_kv_heads, max_seq_len, head_dim]
// new value: [batch, num_kv_heads, 1, head_dim]
// value_cache: [batch, num_kv_heads, max_seq_len, head_dim]
void launch_kv_copy_kernel(__nv_bfloat16* const key_cache,
                           __nv_bfloat16* const value_cache,
                           const __nv_bfloat16* const key_new,
                           const __nv_bfloat16* const value_new,
                           const int32_t* const seq_idx,
                           unsigned int max_seq_len,
                           unsigned int head_dim,
                           unsigned int num_kv_heads,
                           cudaStream_t stream) {
  size_t thread_size = head_dim;
  size_t block_size = num_kv_heads * 2;  // 2 means for key and value
  kv_copy_kernel_simple<<<block_size, thread_size, 0, stream>>>(key_cache,
                                                                value_cache,
                                                                key_new,
                                                                value_new,
                                                                seq_idx,
                                                                max_seq_len,
                                                                head_dim,
                                                                num_kv_heads);
  CHECK_CUDA_STATUS("check cuda kernel: kv_copy_kernel");
}

__global__ void qk_kernel_simple(__nv_bfloat16* const attn_score,
                                 const __nv_bfloat16* const query,
                                 const __nv_bfloat16* const key_cache,
                                 const int32_t* const seq_idx,
                                 unsigned int max_seq_len,
                                 unsigned int head_dim,
                                 unsigned int num_q_heads,
                                 unsigned int num_kv_heads) {
  // blockDim.x: 256
  // gridDim.x: block num for seq
  // gridDim.y: num_q_heads
  unsigned int seq_idx_val = static_cast<unsigned int>(*seq_idx);
  unsigned int target_seq_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (target_seq_idx > seq_idx_val || seq_idx_val >= max_seq_len) {
    // attn_score[output_idx] = -CUDART_INF_F;
    return;
  }

  unsigned int output_idx = blockIdx.y * max_seq_len + target_seq_idx;
  float scale_factor = 1.f / sqrtf(static_cast<float>(head_dim));
  float acc = 0.0f;

  const __nv_bfloat16* query_start = query + blockIdx.y * head_dim;
  unsigned int key_head_idx = blockIdx.y / (num_q_heads / num_kv_heads);
  const __nv_bfloat16* key_cache_start =
      key_cache + (key_head_idx * max_seq_len + target_seq_idx) * head_dim;

  for (int i = 0; i < head_dim; ++i) {
    // TODO: optimize this code use __hmul2
    acc += scale_factor * __bfloat162float(query_start[i]) * __bfloat162float(key_cache_start[i]);
  }

  attn_score[output_idx] = __float2bfloat16(acc);
}

void launch_qk_kernel(__nv_bfloat16* const attn_score,
                      const __nv_bfloat16* const query,
                      const __nv_bfloat16* const key_cache,
                      const int32_t* const seq_idx,
                      unsigned int max_seq_len,
                      unsigned int head_dim,
                      unsigned int num_q_heads,
                      unsigned int num_kv_heads,
                      cudaStream_t stream) {
  size_t thread_size = 256;
  size_t block_for_seq = (max_seq_len + thread_size - 1) / thread_size;
  dim3 block_size(block_for_seq, num_q_heads);

  // auto query_bf2 = reinterpret_cast<const __nv_bfloat162* const>(query);
  // auto key_cache_bf2 = reinterpret_cast<const __nv_bfloat162* const>(key_cache);
  // qk_kernel_simple<<<block_size, thread_size, 0, stream>>>(attn_score, query_bf2, key_cache_bf2,
  qk_kernel_simple<<<block_size, thread_size, 0, stream>>>(attn_score,
                                                           query,
                                                           key_cache,
                                                           seq_idx,
                                                           max_seq_len,
                                                           head_dim,
                                                           num_q_heads,
                                                           num_kv_heads);
  CHECK_CUDA_STATUS("check cuda kernel: qk_kernel_simple");
}

__global__ void softmax_kernel_simple(__nv_bfloat16* const attn_score,
                                      const int32_t* const seq_idx,
                                      unsigned int max_seq_len) {
  // blockDim.x: 1
  // gridDim.x: num_q_heads

  unsigned int seq_idx_val = static_cast<unsigned int>(*seq_idx);
  if (threadIdx.x != 0 || seq_idx_val >= max_seq_len) {
    return;
  }

  size_t index_base = (blockIdx.x * blockDim.x + threadIdx.x) * max_seq_len;
  float max_val = __bfloat162float(attn_score[index_base]);

  for (unsigned i = 1; i <= seq_idx_val; ++i) {
    // TODO use __hmax2
    auto cur_val = __bfloat162float(attn_score[index_base + i]);
    if (cur_val > max_val) {
      max_val = cur_val;
    }
  }

  float sum = 0.f;
  for (unsigned i = 0; i <= seq_idx_val; ++i) {
    // TODO use hexp2, __bfloat1622float2
    auto cur_val = __bfloat162float(attn_score[index_base + i]);
    sum += expf(cur_val - max_val);
  }

  for (unsigned i = 0; i <= seq_idx_val; ++i) {
    // TODO use hexp2, __bfloat1622float2, __float22bfloat16
    auto cur_val = __bfloat162float(attn_score[index_base + i]);
    auto result = expf(cur_val - max_val) / sum;
    attn_score[index_base + i] = __float2bfloat16(result);
  }
}

// attn_score: [batch, num_q_heads, max_seq_len]
void launch_softmax_kernel(__nv_bfloat16* const attn_score,
                           const int32_t* const seq_idx,
                           unsigned int max_seq_len,
                           unsigned int num_q_heads,
                           cudaStream_t stream) {
  size_t thread_size = 1;
  size_t block_size = num_q_heads;
  softmax_kernel_simple<<<block_size, thread_size, 0, stream>>>(attn_score, seq_idx, max_seq_len);
  CHECK_CUDA_STATUS("check cuda kernel: softmax_kernel_simple");
}

__global__ void attn_kernel_simple(__nv_bfloat16* const output_emb,
                                   const __nv_bfloat16* const attn_score,
                                   const __nv_bfloat16* const value_cache,
                                   const int32_t* const seq_idx,
                                   unsigned int max_seq_len,
                                   unsigned int num_kv_heads) {
  // blockDim.x: head_dim
  // gridDim.x: num_q_heads
  unsigned int seq_idx_val = static_cast<unsigned int>(*seq_idx);
  if (seq_idx_val >= max_seq_len) {
    return;
  }

  unsigned int output_idx = blockIdx.x * blockDim.x + threadIdx.x;
  float acc = 0.0f;

  auto attn_score_start = attn_score + blockIdx.x * max_seq_len;
  auto value_head_idx = blockIdx.x / (gridDim.x / num_kv_heads);
  auto value_cache_start = value_cache + value_head_idx * max_seq_len * blockDim.x + threadIdx.x;
  for (unsigned i = 0; i <= seq_idx_val; ++i) {
    auto score = __bfloat162float(attn_score_start[i]);
    auto val = __bfloat162float(value_cache_start[i * blockDim.x]);
    acc = fmaf(score, val, acc);
  }

  output_emb[output_idx] = __float2bfloat16(acc);
}

// output_emb: [batch, num_q_heads, 1, head_dim]
// attn_score: [batch, num_q_heads, max_seq_len]
// value_cache: [batch, num_kv_heads, max_seq_len, head_dim]
void launch_attn_kernel(__nv_bfloat16* const output_emb,
                        const __nv_bfloat16* const attn_score,
                        const __nv_bfloat16* const value_cache,
                        const int32_t* const seq_idx,
                        unsigned int max_seq_len,
                        unsigned int head_dim,
                        unsigned int num_q_heads,
                        unsigned int num_kv_heads,
                        cudaStream_t stream) {
  size_t thread_size = head_dim;
  size_t block_size = num_q_heads;
  attn_kernel_simple<<<block_size, thread_size, 0, stream>>>(output_emb,
                                                             attn_score,
                                                             value_cache,
                                                             seq_idx,
                                                             max_seq_len,
                                                             num_kv_heads);
  CHECK_CUDA_STATUS("check cuda kernel: attn_kernel_simple");
}

void LaunchAttnWithGqa(__nv_bfloat16* output_emb,
                       float* hbm_cache,
                       __nv_bfloat16* key_cache,
                       __nv_bfloat16* value_cache,
                       const __nv_bfloat16* query,
                       const __nv_bfloat16* key,
                       const __nv_bfloat16* value,
                       const int32_t* seq_idx,
                       unsigned int max_seq_len,
                       unsigned int head_dim,
                       unsigned int num_q_heads,
                       unsigned int num_kv_heads,
                       float* qk_result,
                       cudaStream_t stream) {
  launch_kv_copy_kernel(key_cache,
                        value_cache,
                        key,
                        value,
                        seq_idx,
                        max_seq_len,
                        head_dim,
                        num_kv_heads,
                        stream);

  auto attn_score = reinterpret_cast<__nv_bfloat16*>(hbm_cache);
  launch_qk_kernel(attn_score,
                   query,
                   key_cache,
                   seq_idx,
                   max_seq_len,
                   head_dim,
                   num_q_heads,
                   num_kv_heads,
                   stream);

  launch_softmax_kernel(attn_score, seq_idx, max_seq_len, num_q_heads, stream);

  launch_attn_kernel(output_emb,
                     attn_score,
                     value_cache,
                     seq_idx,
                     max_seq_len,
                     head_dim,
                     num_q_heads,
                     num_kv_heads,
                     stream);
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer

#endif