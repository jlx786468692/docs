#if defined(LIDS_PLATFORM_THOR) || defined(LIDS_PLATFORM_X86)
#include "helper.h"

#include <nvtx3/nvToolsExt.h>
#include <stdlib.h>

#include <string>
#include <vector>

#include "nlohmann/json.hpp"

namespace lad {
static const bool is_enable_nvtx = [] {
  const char* nvtx_env = std::getenv("LINFER_NVTX");
  return (nvtx_env != nullptr && std::string(nvtx_env) == "ON");
}();

static void NvtxRangePush(const std::string& name) {
  nvtxEventAttributes_t attr = {0};
  attr.messageType = NVTX_MESSAGE_TYPE_REGISTERED;
  attr.message.registered = nvtxDomainRegisterStringA(nullptr, name.c_str());
  attr.payloadType = NVTX_PAYLOAD_TYPE_INT32;
  attr.payload.iValue = 0;
  nvtxRangePushEx(&attr);
}

static void NvtxRangePop() { nvtxRangePop(); }

HostNvtxScope::HostNvtxScope(const std::string& name) {
  if (is_enable_nvtx) {
    NvtxRangePush(name);
  }
}

HostNvtxScope::~HostNvtxScope() {
  if (is_enable_nvtx) {
    NvtxRangePop();
  }
}

bool WriteToBinaryFile(const std::string& filename, const std::vector<uint8_t>& content) {
  std::ofstream fout(filename, std::ios::binary);
  if (!fout.is_open()) {
    return false;
  }
  fout.write(reinterpret_cast<const char*>(content.data()), content.size());
  return fout.good();
}

std::vector<uint8_t> ReadBinaryFile(const std::string& filename) {
  std::vector<uint8_t> content;
  std::ifstream fin(filename, std::ios::binary);
  if (!fin.is_open()) {
    return content;
  }

  fin.seekg(0, std::ios::end);
  const size_t file_size = static_cast<size_t>(fin.tellg());
  fin.seekg(0, std::ios::beg);

  content.resize(file_size);
  fin.read(reinterpret_cast<char*>(content.data()), file_size);

  if (!fin.good()) {
    content.clear();
  }

  return content;
}

std::vector<uint8_t> SerializeTensors(const std::vector<Tensor>& tensors) {
  std::vector<uint8_t> tdata;
  const auto get_tensor_range = [&tdata](const auto& v) {
    const auto sz = tdata.size();
    const auto len = v.size();
    tdata.insert(tdata.end(), v.begin(), v.end());
    return std::vector<std::size_t>{sz, len};
  };

  nlohmann::json j = nlohmann::json::array();
  for (int i = 0; i < tensors.size(); ++i) {
    nlohmann::json jt;
    jt["dims"] = tensors[i].dims;
    jt["type"] = tensors[i].dtype;
    jt["data"] = get_tensor_range(tensors[i].hdata);
    j.push_back(jt);
  }

  const auto& hdr = j.dump();
  const auto hdr_sz = int32_t(hdr.size());
  std::vector<uint8_t> result(sizeof(hdr_sz) + hdr.size() + tdata.size());
  std::memcpy(result.data(), &hdr_sz, sizeof(hdr_sz));
  std::memcpy(result.data() + sizeof(hdr_sz), hdr.data(), hdr.size());
  std::memcpy(result.data() + sizeof(hdr_sz) + hdr.size(), tdata.data(), tdata.size());
  return result;
}

std::vector<Tensor> DeserializeTensors(const std::vector<uint8_t>& buffer) {
  int32_t hdr_sz = 0;
  std::memcpy(&hdr_sz, buffer.data(), sizeof(hdr_sz));
  const char* hdr_start = (const char*)buffer.data() + sizeof(hdr_sz);
  const auto j = nlohmann::json::parse(hdr_start, hdr_start + hdr_sz);
  auto tensor_start = hdr_start + hdr_sz;

  std::vector<Tensor> result;
  for (const auto& jt : j) {
    Tensor tensor;
    tensor.dtype = jt["type"].get<int>();
    tensor.dims = jt["dims"].get<std::vector<int>>();
    const auto& items = jt["data"].get<std::pair<std::size_t, std::size_t>>();
    const auto start = items.first;
    const auto size = items.second;
    tensor.hdata.resize(size);
    std::memcpy(tensor.hdata.data(), tensor_start + start, size);
    result.emplace_back(std::move(tensor));
  }
  return result;
}

static int GetDataTypeSize(nvinfer1::DataType dtype) {
  switch (dtype) {
    case nvinfer1::DataType::kFLOAT:
      return 4;
    case nvinfer1::DataType::kHALF:
      return 2;
    case nvinfer1::DataType::kINT8:
      return 1;
    case nvinfer1::DataType::kINT32:
      return 4;
    case nvinfer1::DataType::kBF16:
      return 2;
    default:
      throw std::runtime_error("error: unsupport datatype.");
  }
}
static int GetElemCount(const nvinfer1::Dims& dims) {
  int num_elements = 1;
  for (int d = 0; d < dims.nbDims; ++d) {
    num_elements *= dims.d[d];
  }
  return num_elements;
}
std::vector<Tensor> CvtToTensors(const nvinfer1::PluginTensorDesc* descs,
                                 const void* const* tensors,
                                 const int32_t total) {
  std::vector<Tensor> result;
  for (int i = 0; i < total; i++) {
    const auto& desc = descs[i];
    const auto& tensor = tensors[i];
    Tensor t;
    t.dtype = (int)desc.type;
    t.dims = std::vector<int>(desc.dims.d, desc.dims.d + desc.dims.nbDims);
    t.hdata.resize(GetElemCount(desc.dims) * GetDataTypeSize(desc.type));
    cudaError_t err = cudaMemcpy(t.hdata.data(), tensor, t.hdata.size(), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
      throw std::runtime_error("Failed to copy data from device to host: " +
                               std::string(cudaGetErrorString(err)));
    }
    result.emplace_back(std::move(t));
  }
  return result;
}

std::vector<Tensor> CvtIOToTensors(const nvinfer1::PluginTensorDesc* input_descs,
                                   const void* const* input_tensors,
                                   const int32_t input_total,
                                   const nvinfer1::PluginTensorDesc* output_descs,
                                   const void* const* output_tensors,
                                   const int32_t output_total) {
  auto in_tensors = lad::CvtToTensors(input_descs, input_tensors, input_total);
  const auto& out_tensors = lad::CvtToTensors(output_descs, output_tensors, output_total);
  in_tensors.insert(in_tensors.end(), out_tensors.begin(), out_tensors.end());
  return in_tensors;
}

}  // namespace lad

#endif
