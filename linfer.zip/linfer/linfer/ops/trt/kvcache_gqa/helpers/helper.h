#if defined(LIDS_PLATFORM_THOR) || defined(LIDS_PLATFORM_X86)
#pragma once
#include <fstream>
#include <string>
#include <vector>

#include "NvInferPlugin.h"

namespace lad {
struct HostNvtxScope final {
  explicit HostNvtxScope(const std::string& name);
  ~HostNvtxScope();
};

struct Tensor {
  int dtype;
  std::vector<int> dims;
  std::vector<std::uint8_t> hdata;
};

std::vector<Tensor> CvtToTensors(const nvinfer1::PluginTensorDesc* descs,
                                 const void* const* tensors,
                                 const int32_t total);

std::vector<Tensor> CvtIOToTensors(const nvinfer1::PluginTensorDesc* input_descs,
                                   const void* const* input_tensors,
                                   const int32_t input_total,
                                   const nvinfer1::PluginTensorDesc* output_descs,
                                   const void* const* output_tensors,
                                   const int32_t output_total);

std::vector<uint8_t> SerializeTensors(const std::vector<Tensor>& tensors);

std::vector<Tensor> DeserializeTensors(const std::vector<uint8_t>& buffer);

bool WriteToBinaryFile(const std::string& filename, const std::vector<uint8_t>& content);

std::vector<uint8_t> ReadBinaryFile(const std::string& filename);

}  // namespace lad

#endif