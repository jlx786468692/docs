#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime_api.h>
#include <stdint.h>

#include <algorithm>

#include "NvInferVersion.h"
#include "linfer/ops/trt/debug/common.h"
#include "linfer/util/internal/cuda/util.h"

namespace linfer {
namespace ops {
namespace trt {

// static inline __device__ float atomicMax(float* addr, float val) {
//     unsigned int old = __float_as_uint(*addr), assumed;
//     do {
//         assumed = old;
//         if (__uint_as_float(old) >= val) {
//             break;
//         }
//         old = atomicCAS((unsigned int*)addr, assumed, __float_as_uint(val));
//     } while (assumed != old);

//     return __uint_as_float(old);
// }

static inline __device__ float atomic_set_max_err_and_offset(uint64_t* addr,
                                                             float val,
                                                             uint32_t offset) {
  uint64_t offset_err = *addr, assumed;
  do {
    assumed = offset_err;
    if (__uint_as_float((uint32_t)offset_err) >= val) {
      break;
    }
    uint64_t val_with_offset = __float_as_uint(val) | ((uint64_t)offset) << 32;
    offset_err = atomicCAS((unsigned long long*)addr, assumed, val_with_offset);
  } while (assumed != offset_err);

  return __uint_as_float((uint32_t)offset_err);
}

template <class T>
__device__ inline float abs_val(T x) {
  return fabsf((float)(x));
}
template <>
__device__ inline float abs_val<__half>(__half x) {
  return fabsf(__half2float(x));
}
template <>
__device__ inline float abs_val<__nv_bfloat16>(__nv_bfloat16 x) {
  return fabsf(__bfloat162float(x));
}

template <typename T>
__global__ void check_kernel(const T* const expect,
                             const T* const actual,
                             size_t part_num,
                             size_t max_offset,
                             const uint32_t* match_result,
                             float abs_tol,
                             float rel_tol) {
  size_t thread_idx = blockIdx.x * blockDim.x + threadIdx.x;
  size_t start = thread_idx * part_num;
  size_t end = umin(max_offset, (thread_idx + 1) * part_num);
  for (size_t idx = start; idx < end; ++idx) {
    bool is_abs_mismatch = false, is_rel_mismatch = false;
    float abs_err = abs_val<T>(expect[idx] - actual[idx]);
    if (isnan(abs_err)) {
      abs_err = nanf("");
    }
    if (abs_err > abs_tol || isnan(abs_err)) {
      is_abs_mismatch = true;
      atomicAdd((uint32_t*)(match_result + CKPT_ABS_MISMATCH_NUM), 1);
      float* ptr_max_error = (float*)(match_result + CKPT_ABS_MAX_ERROR);
      atomic_set_max_err_and_offset((uint64_t*)ptr_max_error, abs_err, idx);
    }

    float rel_err = abs_err - rel_tol * abs_val<T>(expect[idx]);
    if (isnan(rel_err)) {
      rel_err = nanf("");
    }
    if (rel_err > 0 || isnan(rel_err)) {
      is_rel_mismatch = true;
      atomicAdd((uint32_t*)(match_result + CKPT_REL_MISMATCH_NUM), 1);
      float* ptr_max_error = (float*)(match_result + CKPT_REL_MAX_ERROR);
      float err = abs_err / abs_val<T>(expect[idx]);
      atomic_set_max_err_and_offset((uint64_t*)ptr_max_error, err, idx);
    }

    if (is_abs_mismatch && is_rel_mismatch) {
      atomicAdd((uint32_t*)(match_result + CKPT_ABS_AND_REL_MISMATCH_NUM), 1);
    }
  }
}

template <typename T>
void launch_check_kernel_(const T* expect,
                          const T* actual,
                          size_t len,
                          const uint32_t* match_result,
                          float abs_tol,
                          float rel_tol,
                          cudaStream_t stream) {
  size_t thread_size = 512;
  size_t block_size = std::max(1UL, len / thread_size);
  size_t part_num = std::max(1UL, (len / block_size) / thread_size);
  check_kernel<<<block_size, thread_size, 0, stream>>>(expect,
                                                       actual,
                                                       part_num,
                                                       len,
                                                       match_result,
                                                       abs_tol,
                                                       rel_tol);
  CHECK_CUDA_STATUS("check_kernel");
}

void launch_check_kernel(const float* const expect,
                         const float* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream) {
  launch_check_kernel_(expect, actual, len, match_result, abs_tol, rel_tol, stream);
}

void launch_check_kernel(const int32_t* const expect,
                         const int32_t* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream) {
  launch_check_kernel_(expect, actual, len, match_result, abs_tol, rel_tol, stream);
}

// float16
void launch_check_kernel(const __half* const expect,
                         const __half* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream) {
  launch_check_kernel_(expect, actual, len, match_result, abs_tol, rel_tol, stream);
}

#if NV_TENSORRT_MAJOR >= 10
// bfloat16
void launch_check_kernel(const __nv_bfloat16* const expect,
                         const __nv_bfloat16* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream) {
  launch_check_kernel_(expect, actual, len, match_result, abs_tol, rel_tol, stream);
}
#endif

}  // namespace trt
}  // namespace ops
}  // namespace linfer
