#pragma once

#include <cstdint>

#include "NvInferVersion.h"

namespace linfer {
namespace ops {
namespace trt {

void launch_check_kernel(const float* const expect,
                         const float* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream);

void launch_check_kernel(const int32_t* const expect,
                         const int32_t* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream);

void launch_check_kernel(const __half* const expect,
                         const __half* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream);

#if NV_TENSORRT_MAJOR >= 10
void launch_check_kernel(const __nv_bfloat16* const expect,
                         const __nv_bfloat16* const actual,
                         size_t len,
                         const uint32_t* match_result,
                         float abs_tol,
                         float rel_tol,
                         cudaStream_t stream);
#endif

}  // namespace trt
}  // namespace ops
}  // namespace linfer
