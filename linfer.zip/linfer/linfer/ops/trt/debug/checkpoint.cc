
#include "linfer/ops/trt/debug/checkpoint.h"

#include <NvInfer.h>
#include <NvInferRuntime.h>
#include <cublas_v2.h>

#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

#include "NvInferVersion.h"
#include "linfer/ops/trt/debug/checkpoint.cuh"
#include "linfer/ops/trt/debug/common.h"
#include "linfer/util/cuda/util.h"
#include "linfer/util/datatype.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/numpy.h"
#include "linfer/util/tensor.h"
#include "linfer/util/util.h"

using linfer::ops::trt::CheckpointLayer;
using linfer::ops::trt::CheckpointLayerCreator;

REGISTER_TENSORRT_PLUGIN(CheckpointLayerCreator);

namespace {
const char* CheckpointLayer_PLUGIN_VERSION{"1"};
const char* CheckpointLayer_PLUGIN_NAME{"LinferCheckpoint"};
}  // namespace

namespace linfer {
namespace ops {
namespace trt {
enum INOUT_POS {
  x = 0,
  expect_x,
};

static size_t get_element_size(nvinfer1::DataType dataType) {
  switch (dataType) {
    case nvinfer1::DataType::kFLOAT:
    case nvinfer1::DataType::kINT32:
      return 4;
    case nvinfer1::DataType::kHALF:
#if NV_TENSORRT_MAJOR >= 10
    case nvinfer1::DataType::kBF16:
#endif
      return 2;
    default:
      std::cerr << "Unsupported data type." << std::endl;
      return 0;
  }
}

std::vector<uint32_t> get_coord_by_offset(uint32_t offset, nvinfer1::Dims& dims) {
  std::vector<uint32_t> coord(dims.nbDims, 0);
  for (int idx = dims.nbDims - 1; idx >= 0; idx -= 1) {
    coord[idx] = offset % dims.d[idx];
    offset /= dims.d[idx];
  }
  return coord;
}

std::string get_coord_str(uint32_t offset, nvinfer1::Dims& dims) {
  auto coor = get_coord_by_offset(offset, dims);
  std::stringstream s;
  s << "(";
  int idx = 0;
  for (; idx < coor.size() - 1; ++idx) {
    s << std::to_string(coor[idx]) << ",";
  }
  s << std::to_string(coor[idx]) << ")";
  return s.str();
}

nvinfer1::PluginFieldCollection CheckpointLayerCreator::mFC{};
std::vector<nvinfer1::PluginField> CheckpointLayerCreator::mPluginAttributes;

CheckpointLayer::CheckpointLayer(const std::string& desc,
                                 bool vis_meta,
                                 int vis_data_len,
                                 float atol,
                                 float rtol,
                                 bool replay,
                                 const std::string& save_path)
    : desc_(desc),
      vis_meta_(vis_meta),
      vis_data_len_(vis_data_len),
      atol_(atol),
      rtol_(rtol),
      replay_(replay),
      save_path_(save_path),
      match_result_(CKPT_ELEMENT_SIZE, 0) {
  expect_data_.resize(vis_data_len_);
  actual_data_.resize(vis_data_len_);
}

int CheckpointLayer::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType CheckpointLayer::getOutputDataType(int index,
                                                      const nvinfer1::DataType* inputTypes,
                                                      int nbInputs) const noexcept {
  ASSERT(index == 0);
  return inputTypes[actual_val_idx_];
}

nvinfer1::DimsExprs CheckpointLayer::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[actual_val_idx_];
}

int CheckpointLayer::initialize() noexcept { return 0; }

void CheckpointLayer::terminate() noexcept {}

bool CheckpointLayer::supportsFormatCombination(int32_t pos,
                                                const nvinfer1::PluginTensorDesc* inOut,
                                                int32_t nbInputs,
                                                int32_t nbOutputs) noexcept {
  ASSERT(pos <= 2);
  ASSERT(nbInputs == 2);
  ASSERT(nbOutputs == 1);

  auto dtype = inOut[pos].type;
  auto x_dtype = inOut[INOUT_POS::x].type;
  auto dformat = inOut[pos].format;

  return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kINT32 ||
#if NV_TENSORRT_MAJOR >= 10
          dtype == nvinfer1::DataType::kBF16 ||
#endif
          dtype == nvinfer1::DataType::kHALF) &&
         x_dtype == dtype && dformat == nvinfer1::TensorFormat::kLINEAR;
}

void CheckpointLayer::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                      int32_t nbInputs,
                                      const nvinfer1::DynamicPluginTensorDesc* out,
                                      int32_t nbOutputs) noexcept {}

size_t CheckpointLayer::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                         int32_t nbInputs,
                                         const nvinfer1::PluginTensorDesc* outputs,
                                         int32_t nbOutputs) const noexcept {
  return CKPT_WORKSPACE_SIZE;
}

void CheckpointLayer::print_info(void) {
  uint32_t abs_mismatch_num = match_result_[CKPT_ABS_MISMATCH_NUM];
  uint32_t rel_mismatch_num = match_result_[CKPT_REL_MISMATCH_NUM];
  uint32_t abs_and_reld_mismatch_num = match_result_[CKPT_ABS_AND_REL_MISMATCH_NUM];
  bool match = (0 == abs_mismatch_num) && (0 == rel_mismatch_num);

  auto dims = input_desc_.dims;
  size_t total_len = linfer::util::volume(dims);
  auto vis_data_len = std::min(vis_data_len_, (int32_t)total_len);

  bool vis_meta = vis_meta_ || (!match);
  if (vis_meta) {
    std::cout << "Desc:" << desc_ << std::endl;
    printf("\n-------------------------------\n");
    printf("Desc: %s.\nMetaInfo:\n", desc_.c_str());
    printf("atol: %.6f, rtol: %.6f, vis_len: %d, replay: %d\n",
           atol_,
           rtol_,
           vis_data_len,
           replay_);
    linfer::util::print_nv_tensor_desc(input_desc_, "actual and expect");
  }

  if (match) {
    printf("All is matched!\n");
  } else {
    printf("ABS MISMATCH: %u/%lu = %.2f%%. ",
           abs_mismatch_num,
           total_len,
           (100.0 * abs_mismatch_num) / total_len);
    if (abs_mismatch_num > 0) {
      printf("MaxError: %.6f, MaxErrorIndex: %s.",
             *reinterpret_cast<float*>(match_result_.data() + CKPT_ABS_MAX_ERROR),
             get_coord_str(match_result_[CKPT_ABS_MAX_ERROR_OFFSET], dims).c_str());
    }

    printf("\nREL MISMATCH: %u/%lu = %.2f%%. ",
           rel_mismatch_num,
           total_len,
           (100.0 * rel_mismatch_num) / total_len);
    if (rel_mismatch_num > 0) {
      printf("MaxError: %.6f, MaxErrorIndex: %s.",
             *reinterpret_cast<float*>(match_result_.data() + CKPT_REL_MAX_ERROR),
             get_coord_str(match_result_[CKPT_REL_MAX_ERROR_OFFSET], dims).c_str());
    }

    printf("\nABS and REL MISMATCH: %u/%lu = %.2f%%. ",
           abs_and_reld_mismatch_num,
           total_len,
           (100.0 * abs_and_reld_mismatch_num) / total_len);
    printf("\n");

    if (input_desc_.type == nvinfer1::DataType::kFLOAT) {
      linfer::util::print_n_data<float>(reinterpret_cast<float*>(actual_data_.data()),
                                        vis_data_len,
                                        "actual");
      linfer::util::print_n_data<float>(reinterpret_cast<float*>(expect_data_.data()),
                                        vis_data_len,
                                        "expect");
    } else if (input_desc_.type == nvinfer1::DataType::kINT32) {
      linfer::util::print_n_data<int>(reinterpret_cast<int*>(actual_data_.data()),
                                      vis_data_len,
                                      "actual");
      linfer::util::print_n_data<int>(reinterpret_cast<int*>(expect_data_.data()),
                                      vis_data_len,
                                      "expect");
#if NV_TENSORRT_MAJOR >= 10
    } else if (input_desc_.type == nvinfer1::DataType::kBF16) {
      linfer::util::print_n_data<linfer::util::BFloat16>(
          reinterpret_cast<linfer::util::BFloat16*>(actual_data_.data()),
          vis_data_len,
          "actual");
      linfer::util::print_n_data<linfer::util::BFloat16>(
          reinterpret_cast<linfer::util::BFloat16*>(expect_data_.data()),
          vis_data_len,
          "expect");
#endif
    } else if (input_desc_.type == nvinfer1::DataType::kHALF) {
      linfer::util::print_n_data<linfer::util::Float16>(
          reinterpret_cast<linfer::util::Float16*>(actual_data_.data()),
          vis_data_len,
          "actual");
      linfer::util::print_n_data<linfer::util::Float16>(
          reinterpret_cast<linfer::util::Float16*>(expect_data_.data()),
          vis_data_len,
          "expect");
    } else {
      LCHECK_MSG(false,
                 "unsupported datatype: " + linfer::util::get_nvdatatype_name(input_desc_.type));
    }
  }

  if (vis_meta) {
    printf("----------------------------------------------------------------------------------\n");
  }
}

void print_info_graph_node(void* ptr) {
  auto ckpt_ptr = static_cast<CheckpointLayer*>(ptr);
  ckpt_ptr->print_info();
}

int32_t CheckpointLayer::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                 const nvinfer1::PluginTensorDesc* outputDesc,
                                 const void* const* inputs,
                                 void* const* outputs,
                                 void* workspace,
                                 cudaStream_t stream) noexcept {
  auto ws = (void*)((uint64_t)workspace & (~0x3FULL));  // align to 64bit
  input_desc_ = inputDesc[actual_val_idx_];
  nvinfer1::DataType input_type = input_desc_.type;
  CHECK_CUDA(cudaMemsetAsync(ws, 0, CKPT_VALID_SIZE, stream));

  auto dims = inputDesc[actual_val_idx_].dims;
  size_t total_len = linfer::util::volume(dims);

  if (input_type == nvinfer1::DataType::kFLOAT) {
    launch_check_kernel((float*)inputs[expect_val_idx_],
                        (float*)inputs[actual_val_idx_],
                        total_len,
                        (const uint32_t*)ws,
                        atol_,
                        rtol_,
                        stream);
  } else if (input_type == nvinfer1::DataType::kINT32) {
    launch_check_kernel((int32_t*)inputs[expect_val_idx_],
                        (int32_t*)inputs[actual_val_idx_],
                        total_len,
                        (const uint32_t*)ws,
                        atol_,
                        rtol_,
                        stream);
  } else if (input_type == nvinfer1::DataType::kHALF) {
    launch_check_kernel((__half*)inputs[expect_val_idx_],
                        (__half*)inputs[actual_val_idx_],
                        total_len,
                        (const uint32_t*)ws,
                        atol_,
                        rtol_,
                        stream);
#if NV_TENSORRT_MAJOR >= 10
  } else if (input_type == nvinfer1::DataType::kBF16) {
    launch_check_kernel((__nv_bfloat16*)inputs[expect_val_idx_],
                        (__nv_bfloat16*)inputs[actual_val_idx_],
                        total_len,
                        (const uint32_t*)ws,
                        atol_,
                        rtol_,
                        stream);
#endif
  }

  if (save_path_.size() > 1) {
    std::vector<size_t> shape(dims.nbDims, 0);
    for (size_t i = 0; i < dims.nbDims; ++i) {
      shape[i] = static_cast<size_t>(dims.d[i]);
    }

    void* ptr;
    CHECK_CUDA(cudaMallocHost(&ptr, total_len * get_element_size(input_type)));
    CHECK_CUDA(cudaMemcpy(ptr,
                          inputs[actual_val_idx_],
                          total_len * get_element_size(input_type),
                          cudaMemcpyDeviceToHost));

    if (input_type == nvinfer1::DataType::kFLOAT) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "trt_actual_value",
                                             (float*)ptr,
                                             util::DataType::kFLOAT,
                                             shape,
                                             save_path_);
    } else if (input_type == nvinfer1::DataType::kINT32) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "trt_actual_value",
                                             (int32_t*)ptr,
                                             util::DataType::kINT32,
                                             shape,
                                             save_path_);
#if NV_TENSORRT_MAJOR >= 10
    } else if (input_type == nvinfer1::DataType::kBF16) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "trt_actual_value",
                                             (__nv_bfloat16*)ptr,
                                             util::DataType::kBF16,
                                             shape,
                                             save_path_);
#endif
    } else if (input_type == nvinfer1::DataType::kHALF) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "trt_actual_value",
                                             (__half*)ptr,
                                             util::DataType::kHALF,
                                             shape,
                                             save_path_);
    }

    CHECK_CUDA(cudaFreeHost(ptr));
  }

  int vis_len = std::min(vis_data_len_, static_cast<int>(total_len)) * get_element_size(input_type);
  cudaEvent_t event;
  CHECK_CUDA((cudaEventCreate(&event)));
  CHECK_CUDA(
      cudaMemcpyAsync(match_result_.data(), ws, CKPT_VALID_SIZE, cudaMemcpyDeviceToHost, stream));
  CHECK_CUDA(cudaMemcpyAsync(actual_data_.data(),
                             inputs[actual_val_idx_],
                             vis_len,
                             cudaMemcpyDeviceToHost,
                             stream));
  CHECK_CUDA(cudaMemcpyAsync(expect_data_.data(),
                             inputs[expect_val_idx_],
                             vis_len,
                             cudaMemcpyDeviceToHost,
                             stream));
  CHECK_CUDA(cudaEventRecord(event, stream));
  CHECK_CUDA(cudaStreamWaitEvent(stream, event, 0));

  // if on graph mode, insert HostNode for print checkpoint info.
  cudaStreamCaptureStatus capture_status;
  CHECK_CUDA(cudaStreamIsCapturing(stream, &capture_status));
  if (cudaStreamCaptureStatusActive == capture_status) {
    cudaGraph_t capturing_graph;
    const cudaGraphNode_t* deps;
    size_t dep_count;
    CHECK_CUDA(cudaStreamGetCaptureInfo_v2(stream,
                                           &capture_status,
                                           nullptr,
                                           &capturing_graph,
                                           &deps,
                                           &dep_count));

    cudaGraphNode_t kernelNode;
    cudaHostNodeParams kernelNodeParams{};
    kernelNodeParams.fn = print_info_graph_node;
    kernelNodeParams.userData = this;

    CHECK_CUDA(
        cudaGraphAddHostNode(&kernelNode, capturing_graph, deps, dep_count, &kernelNodeParams));
    CHECK_CUDA(cudaStreamUpdateCaptureDependencies(stream, &kernelNode, 1, 1));
  } else {
    CHECK_CUDA(cudaStreamSynchronize(stream));
    print_info();
  }

  // copy input to output according if replay.
  int val_idx = replay_ ? expect_val_idx_ : actual_val_idx_;
  auto byte_num = linfer::util::getNvTensorLenInByte(inputDesc[val_idx]);
  cudaMemcpyAsync(outputs[0], inputs[val_idx], byte_num, cudaMemcpyDeviceToDevice, stream);
  CHECK_CUDA_STATUS("CheckpointLayer::enqueue");
  return 0;
}

size_t CheckpointLayer::getSerializationSize() const noexcept {
  // len(desc) + desc_ + vis_meta_ + vis_data_len_ + atol_ + rtol_ + replay_
  // NOTE: not use sizeof(vis_meta_), sizeof(bool) is NOT definitely on different
  // platform.
  return sizeof(size_t) + desc_.size() + sizeof(int8_t) + sizeof(vis_data_len_) + sizeof(atol_) +
         sizeof(rtol_) + sizeof(int8_t) + sizeof(size_t) + save_path_.size();
}

void CheckpointLayer::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<size_t>(buf, desc_.size());
  memcpy(buf, desc_.data(), desc_.size());
  buf += desc_.size();
  write<int8_t>(buf, static_cast<int8_t>(vis_meta_));
  write<int32_t>(buf, vis_data_len_);
  write<float>(buf, atol_);
  write<float>(buf, rtol_);
  write<int8_t>(buf, replay_);
  write<size_t>(buf, save_path_.size());
  memcpy(buf, save_path_.data(), save_path_.size());
  LASSERT_MSG(buf, start + getSerializationSize());
}

void CheckpointLayer::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* CheckpointLayer::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

// Attach the plugin object to an execution context and grant the plugin the access to
// some context resource.
void CheckpointLayer::attachToContext(cudnnContext* cudnn,
                                      cublasContext* cublas,
                                      nvinfer1::IGpuAllocator* gpuAllocator) noexcept {
  return;
}

// Detach the plugin object from its execution context.
void CheckpointLayer::detachFromContext() noexcept {}

const char* CheckpointLayer::getPluginType() const noexcept { return CheckpointLayer_PLUGIN_NAME; }

const char* CheckpointLayer::getPluginVersion() const noexcept {
  return CheckpointLayer_PLUGIN_VERSION;
}

void CheckpointLayer::destroy() noexcept { delete this; }

nvinfer1::IPluginV2DynamicExt* CheckpointLayer::clone() const noexcept {
  CheckpointLayer* plugin =
      new CheckpointLayer(desc_, vis_meta_, vis_data_len_, atol_, rtol_, replay_, save_path_);
  plugin->setPluginNamespace(mPluginNamespace.c_str());
  return plugin;
}

CheckpointLayerCreator::CheckpointLayerCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("desc", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("vis_meta", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("vis_data_len", nullptr, nvinfer1::PluginFieldType::kINT32, 4));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("atol", nullptr, nvinfer1::PluginFieldType::kFLOAT32, 4));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("rtol", nullptr, nvinfer1::PluginFieldType::kFLOAT32, 4));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("replay", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("save_path", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* CheckpointLayerCreator::getPluginName() const noexcept {
  return CheckpointLayer_PLUGIN_NAME;
}

const char* CheckpointLayerCreator::getPluginVersion() const noexcept {
  return CheckpointLayer_PLUGIN_VERSION;
}

const nvinfer1::PluginFieldCollection* CheckpointLayerCreator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV2Ext* CheckpointLayerCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  std::string desc, save_path;
  bool vis_meta, replay;
  int32_t vis_data_len;
  float atol, rtol;

  LASSERT_MSG(fc->nbFields == 7, "must have 7 fields");
  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("desc") == 0) {
      desc = std::string(static_cast<const char*>(field_data), field_len);
    } else if (field_name.compare("vis_meta") == 0) {
      vis_meta = static_cast<bool>(*static_cast<const int8_t*>(field_data));
    } else if (field_name.compare("vis_data_len") == 0) {
      vis_data_len = *static_cast<const int32_t*>(field_data);
    } else if (field_name.compare("atol") == 0) {
      atol = *static_cast<const float*>(field_data);
    } else if (field_name.compare("rtol") == 0) {
      rtol = *static_cast<const float*>(field_data);
    } else if (field_name.compare("replay") == 0) {
      replay = static_cast<bool>(*static_cast<const int8_t*>(field_data));
    } else if (field_name.compare("save_path") == 0) {
      save_path = std::string(static_cast<const char*>(field_data), field_len);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }

  CheckpointLayer* obj =
      new CheckpointLayer(desc, vis_meta, vis_data_len, atol, rtol, replay, save_path);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* CheckpointLayerCreator::deserializePlugin(const char* name,
                                                                  const void* serialData,
                                                                  size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;
  auto len = read<size_t>(buf);
  std::string desc(buf, len);
  buf += len;

  bool vis_meta = static_cast<bool>(read<int8_t>(buf));
  int32_t vis_data_len = read<int32_t>(buf);
  float atol = read<float>(buf);
  float rtol = read<float>(buf);
  bool replay = static_cast<bool>(read<int8_t>(buf));

  len = read<size_t>(buf);
  std::string save_path(buf, len);
  buf += len;

  CheckpointLayer* obj =
      new CheckpointLayer(desc, vis_meta, vis_data_len, atol, rtol, replay, save_path);
  obj->setPluginNamespace(mNamespace.c_str());

  LASSERT_MSG((buf - buf_start) == serialLength, "serialize and deserialize mismatch!");
  return obj;
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
