
#include "linfer/ops/trt/debug/observing_point.h"

#include <NvInfer.h>
#include <cublas_v2.h>

#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/numpy.h"
#include "linfer/util/print.h"

using linfer::ops::trt::ObservingPointLayer;
using linfer::ops::trt::ObservingPointLayerCreator;

REGISTER_TENSORRT_PLUGIN(ObservingPointLayerCreator);

namespace {
const char* ObservingPointLayer_PLUGIN_VERSION{"1"};
const char* ObservingPointLayer_PLUGIN_NAME{"LinferObservingPoint"};
}  // namespace

namespace linfer {
namespace ops {
namespace trt {

nvinfer1::PluginFieldCollection ObservingPointLayerCreator::mFC{};
std::vector<nvinfer1::PluginField> ObservingPointLayerCreator::mPluginAttributes;

ObservingPointLayer::ObservingPointLayer(const std::string& filepath_torch,
                                         const std::string& filepath_trt,
                                         bool replay,
                                         float scale)
    : filepath_torch_(filepath_torch),
      filepath_trt_(filepath_trt),
      replay_(replay),
      scale_(scale) {}

int ObservingPointLayer::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType ObservingPointLayer::getOutputDataType(int index,
                                                          const nvinfer1::DataType* inputTypes,
                                                          int nbInputs) const noexcept {
  ASSERT(index == 0);
  return inputTypes[actual_val_idx_];
}

nvinfer1::DimsExprs ObservingPointLayer::getOutputDimensions(
    int32_t outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int32_t nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  return inputs[actual_val_idx_];
}

int ObservingPointLayer::initialize() noexcept { return 0; }

void ObservingPointLayer::terminate() noexcept {}

bool ObservingPointLayer::supportsFormatCombination(int32_t pos,
                                                    const nvinfer1::PluginTensorDesc* inOut,
                                                    int32_t nbInputs,
                                                    int32_t nbOutputs) noexcept {
  ASSERT(pos <= 1);
  ASSERT(nbInputs == 1);
  ASSERT(nbOutputs == 1);
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  return (desc.type == nvinfer1::DataType::kFLOAT || desc.type == nvinfer1::DataType::kINT32) &&
         desc.format == nvinfer1::TensorFormat::kLINEAR;
}

void ObservingPointLayer::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                          int32_t nbInputs,
                                          const nvinfer1::DynamicPluginTensorDesc* out,
                                          int32_t nbOutputs) noexcept {}

size_t ObservingPointLayer::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                             int32_t nbInputs,
                                             const nvinfer1::PluginTensorDesc* outputs,
                                             int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t ObservingPointLayer::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                                     const nvinfer1::PluginTensorDesc* outputDesc,
                                     const void* const* inputs,
                                     void* const* outputs,
                                     void* workspace,
                                     cudaStream_t stream) noexcept {
  auto dims = inputDesc[actual_val_idx_].dims;
  std::vector<size_t> shape(dims.nbDims, 0);
  for (size_t i = 0; i < dims.nbDims; ++i) {
    shape[i] = static_cast<size_t>(dims.d[i]);
  }
  size_t len_ele = linfer::util::volume(dims);
  size_t len_byte = 4 * len_ele;

  // // scale
  // if (inputDesc[actual_val_idx_].type == nvinfer1::DataType::kFLOAT) {
  //     launch_scale_kernel((float*)inputs[actual_val_idx_], len_ele, scale_,
  //     stream);
  // } else {
  //     launch_scale_kernel((int32_t*)inputs[actual_val_idx_], len_ele, scale_,
  //     stream);
  // }

  // save actual data(input) as numpy format on disk
  std::vector<uint32_t> data(len_ele, 0);
  CHECK_CUDA(cudaMemcpy(data.data(), inputs[actual_val_idx_], len_byte, cudaMemcpyDeviceToHost));
  bool fortran_order = false;

  if (inputDesc[actual_val_idx_].type == nvinfer1::DataType::kFLOAT) {
    linfer::util::numpy_save(filepath_trt_, shape, (float*)data.data(), fortran_order);
  } else {
    linfer::util::numpy_save(filepath_trt_, shape, (int32_t*)data.data(), fortran_order);
  }

  if (replay_) {
    // load expect data and then copy to output
    if (inputDesc[actual_val_idx_].type == nvinfer1::DataType::kFLOAT) {
      std::vector<float> data_expect(len_ele, 0);
      linfer::util::numpy_load(filepath_torch_, shape, data_expect, fortran_order);
      cudaMemcpyAsync(outputs[0], data_expect.data(), len_byte, cudaMemcpyHostToDevice, stream);
    } else {
      std::vector<int32_t> data_expect(len_ele, 0);
      linfer::util::numpy_load(filepath_torch_, shape, data_expect, fortran_order);
      cudaMemcpyAsync(outputs[0], data_expect.data(), len_byte, cudaMemcpyHostToDevice, stream);
    }
  } else {
    cudaMemcpyAsync(outputs[0], inputs[0], len_byte, cudaMemcpyHostToDevice, stream);
  }

  return 0;
}

size_t ObservingPointLayer::getSerializationSize() const noexcept {
  // sizeof(size_t) + len(filepath_actual_) + sizeof(size_t) + len(filepath_expect_) +
  // sizeof(replay_) + sizeof(float)
  return sizeof(size_t) + filepath_torch_.size() + sizeof(size_t) + filepath_trt_.size() +
         sizeof(int8_t) + sizeof(float);
}

void ObservingPointLayer::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;

  write<size_t>(buf, filepath_torch_.size());
  memcpy(buf, filepath_torch_.data(), filepath_torch_.size());
  buf += filepath_torch_.size();

  write<size_t>(buf, filepath_trt_.size());
  memcpy(buf, filepath_trt_.data(), filepath_trt_.size());
  buf += filepath_trt_.size();

  write<int8_t>(buf, replay_);
  LASSERT_MSG(buf, start + getSerializationSize());

  write<float>(buf, scale_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

void ObservingPointLayer::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* ObservingPointLayer::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

void ObservingPointLayer::attachToContext(cudnnContext* cudnn,
                                          cublasContext* cublas,
                                          nvinfer1::IGpuAllocator* gpuAllocator) noexcept {
  return;
}

void ObservingPointLayer::detachFromContext() noexcept {}

const char* ObservingPointLayer::getPluginType() const noexcept {
  return ObservingPointLayer_PLUGIN_NAME;
}

const char* ObservingPointLayer::getPluginVersion() const noexcept {
  return ObservingPointLayer_PLUGIN_VERSION;
}

void ObservingPointLayer::destroy() noexcept { delete this; }

nvinfer1::IPluginV2DynamicExt* ObservingPointLayer::clone() const noexcept {
  ObservingPointLayer* plugin =
      new ObservingPointLayer(filepath_torch_, filepath_trt_, replay_, scale_);
  plugin->setPluginNamespace(mPluginNamespace.c_str());
  return plugin;
}

ObservingPointLayerCreator::ObservingPointLayerCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("filepath_torch_data", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("filepath_trt_data", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("replay", nullptr, nvinfer1::PluginFieldType::kINT8, 1));
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("scale", nullptr, nvinfer1::PluginFieldType::kFLOAT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* ObservingPointLayerCreator::getPluginName() const noexcept {
  return ObservingPointLayer_PLUGIN_NAME;
}

const char* ObservingPointLayerCreator::getPluginVersion() const noexcept {
  return ObservingPointLayer_PLUGIN_VERSION;
}

const nvinfer1::PluginFieldCollection* ObservingPointLayerCreator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV2Ext* ObservingPointLayerCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  std::string filepath_torch, filepath_trt;
  bool replay = false;
  float scale = 1.0;

  LASSERT_MSG(fc->nbFields == 4, "must have 4 fields");
  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("filepath_torch_data") == 0) {
      filepath_torch = std::string(static_cast<const char*>(field_data), field_len);
    } else if (field_name.compare("filepath_trt_data") == 0) {
      filepath_trt = std::string(static_cast<const char*>(field_data), field_len);
    } else if (field_name.compare("replay") == 0) {
      replay = static_cast<bool>(*static_cast<const int8_t*>(field_data));
    } else if (field_name.compare("scale") == 0) {
      scale = *static_cast<const float*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }

  ObservingPointLayer* obj = new ObservingPointLayer(filepath_torch, filepath_trt, replay, scale);
  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* ObservingPointLayerCreator::deserializePlugin(
    const char* name,
    const void* serialData,
    size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;

  auto len = read<size_t>(buf);
  std::string filepath_torch(buf, len);
  buf += len;

  len = read<size_t>(buf);
  std::string filepath_trt(buf, len);
  buf += len;

  bool replay = static_cast<bool>(read<int8_t>(buf));
  float scale = read<float>(buf);

  ObservingPointLayer* obj = new ObservingPointLayer(filepath_torch, filepath_trt, replay, scale);
  obj->setPluginNamespace(mNamespace.c_str());

  LASSERT_MSG((buf - buf_start) == serialLength, "serialize and deserialize mismatch!");
  return obj;
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
