#pragma once

#include <cstddef>

constexpr size_t CKPT_ABS_MISMATCH_NUM = 0;
constexpr size_t CKPT_REL_MISMATCH_NUM = 1;
constexpr size_t CKPT_ABS_MAX_ERROR = 2;
constexpr size_t CKPT_ABS_MAX_ERROR_OFFSET = 3;
constexpr size_t CKPT_REL_MAX_ERROR = 4;
constexpr size_t CKPT_REL_MAX_ERROR_OFFSET = 5;
constexpr size_t CKPT_ABS_AND_REL_MISMATCH_NUM = 6;
constexpr size_t CKPT_ELEMENT_SIZE = 7;
constexpr size_t CKPT_WORKSPACE_SIZE = (CKPT_ELEMENT_SIZE + 1) * 4;  // one for 64bit align
constexpr size_t CKPT_VALID_SIZE = CKPT_ELEMENT_SIZE * 4;

static_assert(1 == (CKPT_ABS_MAX_ERROR_OFFSET - CKPT_ABS_MAX_ERROR),
              "This two elements must be one after the other");
static_assert(1 == (CKPT_REL_MAX_ERROR_OFFSET - CKPT_REL_MAX_ERROR),
              "This two elements must be one after the other");