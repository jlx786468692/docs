#include "atan2_v3.h"

#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "../common/trt_serialize.hpp"
#include "atan2_kernel.h"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"

using linfer::ops::trt::Atan2PluginV3Creator;
REGISTER_TENSORRT_PLUGIN(Atan2PluginV3Creator);

namespace linfer {
namespace ops {
namespace trt {

constexpr char const* ATAN2_PLUGINV3_VERSION{"1"};
constexpr char const* ATAN2_PLUGINV3_NAME{"LinferAtan2V3"};

nvinfer1::PluginFieldCollection Atan2PluginV3Creator::mFC{};
std::vector<nvinfer1::PluginField> Atan2PluginV3Creator::mPluginAttributes;

Atan2PluginV3::Atan2PluginV3(int num) : num_(num) {}

nvinfer1::IPluginCapability* Atan2PluginV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* Atan2PluginV3::getPluginName() const noexcept { return ATAN2_PLUGINV3_NAME; }

char const* Atan2PluginV3::getPluginVersion() const noexcept { return ATAN2_PLUGINV3_VERSION; }

int32_t Atan2PluginV3::getNbOutputs() const noexcept { return 1; }

void Atan2PluginV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* Atan2PluginV3::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

nvinfer1::IPluginV3* Atan2PluginV3::clone() noexcept {
  try {
    auto* plugin = new Atan2PluginV3(num_);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t Atan2PluginV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                          int32_t nbOutputs,
                                          nvinfer1::DataType const* inputTypes,
                                          int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t Atan2PluginV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                       int32_t nbInputs,
                                       nvinfer1::DimsExprs const* shapeInputs,
                                       int32_t nbShapeInputs,
                                       nvinfer1::DimsExprs* outputs,
                                       int32_t nbOutputs,
                                       nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    // Output shape is the same as input shape
    nvinfer1::DimsExprs output_dims = inputs[0];
    outputs[0] = output_dims;
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool Atan2PluginV3::supportsFormatCombination(int32_t pos,
                                              nvinfer1::DynamicPluginTensorDesc const* inOut,
                                              int32_t nbInputs,
                                              int32_t nbOutputs) noexcept {
  try {
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;

    auto dtype = desc.type;
    auto dformat = desc.format;
    int32_t dim_num_0 = inOut[0].desc.dims.nbDims;
    auto Dim_0 = inOut[0].desc.dims;

    switch (pos) {
      case 0:  // First input
        return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
               (dformat == nvinfer1::TensorFormat::kLINEAR ||
                dformat == nvinfer1::TensorFormat::kCHW32);
      case 1: {  // Second input
        bool flag = true;
        for (int i = 0; i < dim_num_0; i++) {
          if (inOut[pos].desc.dims.d[i] != Dim_0.d[i]) {
            flag = false;
            break;
          }
        }
        return (dtype == inOut[0].desc.type && dformat == inOut[0].desc.format && flag);
      }
      case 2: {  // Output
        bool flag = true;
        for (int i = 0; i < dim_num_0; i++) {
          if (inOut[pos].desc.dims.d[i] != Dim_0.d[i]) {
            flag = false;
            break;
          }
        }
        return (dtype == inOut[0].desc.type && dformat == inOut[0].desc.format && flag);
      }
      default:
        return false;
    }
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t Atan2PluginV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                       int32_t nbInputs,
                                       nvinfer1::DynamicPluginTensorDesc const* out,
                                       int32_t nbOutputs) noexcept {
  try {
    // Validate input arguments
    PLUGIN_ASSERT(nbInputs == 2 && nbOutputs == 1);
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const* Atan2PluginV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("num", &num_, nvinfer1::PluginFieldType::kINT32, 1));

    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t Atan2PluginV3::getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                                       int32_t nbInputs,
                                       nvinfer1::DynamicPluginTensorDesc const* outputs,
                                       int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t Atan2PluginV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                     int32_t nbInputs,
                                     nvinfer1::PluginTensorDesc const* outputs,
                                     int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* Atan2PluginV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t Atan2PluginV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                               nvinfer1::PluginTensorDesc const* outputDesc,
                               void const* const* inputs,
                               void* const* outputs,
                               void* workspace,
                               cudaStream_t stream) noexcept {
  try {
    const void* input_ptr0 = inputs[0];
    const void* input_ptr1 = inputs[1];
    void* output_ptr0 = outputs[0];

    bool use_float16 = (inputDesc[0].type == nvinfer1::DataType::kHALF);
    if (use_float16) {
      launch_atan2_kernel((const __half*)input_ptr0,
                          (const __half*)input_ptr1,
                          (__half*)output_ptr0,
                          num_,
                          stream);
    } else {  // use float32
      launch_atan2_kernel((const float*)input_ptr0,
                          (const float*)input_ptr1,
                          (float*)output_ptr0,
                          num_,
                          stream);
    }
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

// Plugin Creator Implementation
Atan2PluginV3Creator::Atan2PluginV3Creator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("num", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* Atan2PluginV3Creator::getPluginName() const noexcept { return ATAN2_PLUGINV3_NAME; }

char const* Atan2PluginV3Creator::getPluginVersion() const noexcept {
  return ATAN2_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const* Atan2PluginV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* Atan2PluginV3Creator::createPlugin(char const* name,
                                                        nvinfer1::PluginFieldCollection const* fc,
                                                        nvinfer1::TensorRTPhase phase) noexcept {
  try {
    int num = 0;

    for (int32_t i = 0; i < fc->nbFields; i++) {
      std::string field_name(fc->fields[i].name);
      auto field_data = fc->fields[i].data;
      auto field_len = fc->fields[i].length;

      if (field_name.compare("num") == 0) {
        num = *static_cast<const int32_t*>(field_data);
      } else {
        PLUGIN_ASSERT(false && "unexpected field_name");
      }
    }

    PLUGIN_ASSERT(num > 0);

    auto* plugin = new Atan2PluginV3(num);
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void Atan2PluginV3Creator::setPluginNamespace(char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* Atan2PluginV3Creator::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer