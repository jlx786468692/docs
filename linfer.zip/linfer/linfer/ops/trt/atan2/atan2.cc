#include "atan2.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "atan2_kernel.h"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"

using linfer::ops::trt::Atan2PluginCreator;
REGISTER_TENSORRT_PLUGIN(Atan2PluginCreator);

namespace linfer {
namespace ops {
namespace trt {

static size_t getElementSize(nvinfer1::DataType dataType) {
  switch (dataType) {
    case nvinfer1::DataType::kFLOAT:
      return sizeof(float);
    case nvinfer1::DataType::kHALF:
      return 2;
    case nvinfer1::DataType::kINT8:
      return sizeof(int8_t);
    case nvinfer1::DataType::kINT32:
      return sizeof(int32_t);
    default:
      std::cerr << "Unsupported data type." << std::endl;
      return 0;
  }
}

enum INOUT_POS {
  input = 0,
  output_base = 1,
  output_base_input = output_base,
  output = output_base_input - output_base,
};
const char* Atan2_PLUGIN_VERSION{"1"};
static const char* Atan2_PLUGIN_NAME{"LinferAtan2"};

nvinfer1::PluginFieldCollection Atan2PluginCreator::mFC{};

Atan2::Atan2(int num) : num_(num) {}

Atan2::~Atan2() {}

int Atan2::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType Atan2::getOutputDataType(int index,
                                            const nvinfer1::DataType* inputTypes,
                                            int nbInputs) const noexcept {
  return inputTypes[0];
}

nvinfer1::DimsExprs Atan2::getOutputDimensions(int32_t outputIndex,
                                               const nvinfer1::DimsExprs* inputs,
                                               int32_t nbInputs,
                                               nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs output_dims = inputs[0];
  return output_dims;
}

bool Atan2::supportsFormatCombination(int32_t pos,
                                      const nvinfer1::PluginTensorDesc* inOut,
                                      int32_t nbInputs,
                                      int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];

  auto dtype = desc.type;
  auto dformat = desc.format;
  int32_t dim_num_0 = inOut[0].dims.nbDims;
  auto Dim_0 = inOut[0].dims;

  switch (pos) {
    case 0:
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
             (dformat == nvinfer1::PluginFormat::kLINEAR ||
              dformat == nvinfer1::PluginFormat::kCHW32);
    case 1: {
      bool flag = true;
      for (int i = 0; i < dim_num_0; i++) {
        if (inOut[pos].dims.d[i] != Dim_0.d[i]) {
          flag = false;
          break;
        }
      }
      return (dtype == inOut[0].type && dformat == inOut[0].format && flag);
    }
    case 2: {
      bool flag = true;
      for (int i = 0; i < dim_num_0; i++) {
        if (inOut[pos].dims.d[i] != Dim_0.d[i]) {
          flag = false;
          break;
        }
      }
      return (dtype == inOut[0].type && dformat == inOut[0].format && flag);
    }
    default:
      return false;
  }

  return true;
}

void Atan2::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                            int32_t nbInputs,
                            const nvinfer1::DynamicPluginTensorDesc* out,
                            int32_t nbOutputs) noexcept {
  ASSERT(nbInputs == 2 && nbOutputs == 1);
  // for (int i = 0; i < )
  // for (int index = 0; index < nbInputs; index++)
  // {
  //     ASSERT(out[index].desc.dims.d[0] == in[0].desc.dims.d[0]);
  // }
}

size_t Atan2::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                               int32_t nbInputs,
                               const nvinfer1::PluginTensorDesc* outputs,
                               int32_t nbOutputs) const noexcept {
  return 0;
}

int Atan2::initialize() noexcept { return 0; }

void Atan2::terminate() noexcept {}

int32_t Atan2::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                       const nvinfer1::PluginTensorDesc* outputDesc,
                       const void* const* inputs,
                       void* const* outputs,
                       void* workspace,
                       cudaStream_t stream) noexcept {
  const void* input_ptr0 = inputs[0];
  const void* input_ptr1 = inputs[1];
  void* output_ptr0 = outputs[0];

  bool use_float16 = (inputDesc[0].type == nvinfer1::DataType::kHALF);
  if (use_float16) {
    launch_atan2_kernel((const __half*)input_ptr0,
                        (const __half*)input_ptr1,
                        (__half*)output_ptr0,
                        num_,
                        stream);
  } else {  // use float32
    launch_atan2_kernel((const float*)input_ptr0,
                        (const float*)input_ptr1,
                        (float*)output_ptr0,
                        num_,
                        stream);
  }
  return 0;
}

size_t Atan2::getSerializationSize() const noexcept { return sizeof(int); }

void Atan2::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int>(buf, num_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* Atan2::getPluginType() const noexcept { return Atan2_PLUGIN_NAME; }

const char* Atan2::getPluginVersion() const noexcept { return Atan2_PLUGIN_VERSION; }

void Atan2::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* Atan2::clone() const noexcept {
  auto plugin = new Atan2(num_);
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void Atan2::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* Atan2::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void Atan2::attachToContext(cudnnContext* cudnnContext,
                            cublasContext* cublasContext,
                            nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void Atan2::detachFromContext() noexcept {}

Atan2PluginCreator::Atan2PluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("num", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  pluginName_ = Atan2_PLUGIN_NAME;
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* Atan2PluginCreator::getPluginVersion() const noexcept { return Atan2_PLUGIN_VERSION; }
const char* Atan2PluginCreator::getPluginName() const noexcept { return pluginName_.c_str(); }
const nvinfer1::PluginFieldCollection* Atan2PluginCreator::getFieldNames() noexcept {
  return &Atan2PluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* Atan2PluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int num = 0;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("num") == 0) {
      num = *static_cast<const int32_t*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }
  LINFO_FMT("num: %d. \n", num);

  Atan2* obj = new Atan2(num);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* Atan2PluginCreator::deserializePlugin(const char* plugin_name,
                                                              const void* serialData,
                                                              size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto num = read<int>(buf);
  LINFO_FMT("num: %d. \n", num);
  auto obj = new Atan2(num);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void Atan2PluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* Atan2PluginCreator::getPluginNamespace() const noexcept { return namespace_.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
