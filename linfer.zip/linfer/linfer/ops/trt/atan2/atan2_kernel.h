#pragma once

#include <cuda_fp16.h>
#include <cuda_runtime.h>

namespace linfer {
namespace ops {
namespace trt {
void launch_atan2_kernel(const float* input,
                         const float* other,
                         float* result,
                         int num,
                         cudaStream_t stream);
void launch_atan2_kernel(const __half* input,
                         const __half* other,
                         __half* result,
                         int num,
                         cudaStream_t stream);
}  // namespace trt
}  // namespace ops
}  // namespace linfer