#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <math.h>

#include <chrono>
#include <ctime>
#include <type_traits>

#include "atan2_kernel.h"
#include "linfer/util/log.h"

#define DEBUG_LOG_ATAN2_LOCAL 0

namespace linfer {
namespace ops {
namespace trt {

__global__ void atan2_cuda_kernel_(const float* input,
                                   const float* other,
                                   float* result,
                                   size_t size) {
  size_t idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < size) {
    result[idx] = atan2f(input[idx], other[idx]);
  }
}

__global__ void atan2_cuda_kernel_(const __half* input,
                                   const __half* other,
                                   __half* result,
                                   size_t size) {
  size_t idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx < size) {
    result[idx] = __float2half(atan2f(__half2float(input[idx]), __half2float(other[idx])));
  }
}

void launch_atan2_kernel(const float* input,
                         const float* other,
                         float* result,
                         int num,
                         cudaStream_t stream) {
#if DEBUG_LOG_ATAN2_LOCAL
  cudaEvent_t start_event, stop_event;
  cudaEventCreate(&start_event);
  cudaEventCreate(&stop_event);
  cudaEventRecord(start_event);
#endif

  int threadsPerBlock = 256;
  int blocksPerGrid = (num + threadsPerBlock - 1) / threadsPerBlock;
  atan2_cuda_kernel_<<<blocksPerGrid, threadsPerBlock, 0, stream>>>(input, other, result, num);

#if DEBUG_LOG_ATAN2_LOCAL
  cudaEventRecord(stop_event);
  cudaEventSynchronize(stop_event);
  float time;
  cudaEventElapsedTime(&time, start_event, stop_event);
  printf("launch_atan2_kernel 程序运行fp32耗时: %f 毫秒\n",
         time);  // << " 毫秒" << std::endl;
  cudaEventDestroy(start_event);
  cudaEventDestroy(stop_event);
#endif
}

void launch_atan2_kernel(const __half* input,
                         const __half* other,
                         __half* result,
                         int num,
                         cudaStream_t stream) {
#if DEBUG_LOG_ATAN2_LOCAL
  cudaEvent_t start_event, stop_event;
  cudaEventCreate(&start_event);
  cudaEventCreate(&stop_event);
  cudaEventRecord(start_event);
#endif

  int threadsPerBlock = 256;
  int blocksPerGrid = (num + threadsPerBlock - 1) / threadsPerBlock;
  atan2_cuda_kernel_<<<blocksPerGrid, threadsPerBlock, 0, stream>>>(input, other, result, num);

#if DEBUG_LOG_ATAN2_LOCAL
  cudaEventRecord(stop_event);
  cudaEventSynchronize(stop_event);
  float time;
  cudaEventElapsedTime(&time, start_event, stop_event);
  printf("launch_atan2_kernel 程序运行fp16耗时: %f 毫秒\n",
         time);  // << " 毫秒" << std::endl;
  cudaEventDestroy(start_event);
  cudaEventDestroy(stop_event);
#endif
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer