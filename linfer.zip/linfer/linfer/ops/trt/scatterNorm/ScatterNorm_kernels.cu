// Copyright [2022] <Lotus Robotics>
#include <cuda_fp16.h>
#include <cuda_runtime_api.h>

#include <iostream>

#include "ScatterNorm_kernels.h"

__global__ void ScatterNorm_kernel(const float* pillar_features_data,
                                   const unsigned int* coords_data,
                                   const unsigned int* params_data,
                                   unsigned int featureX,
                                   unsigned int featureY,
                                   float* spatial_feature_data,
                                   const size_t max_pillar_size,
                                   const size_t max_points_size,
                                   const size_t max_feat_size) {
  int pillar_idx = blockIdx.x * max_feat_size + threadIdx.x;
  int valid_pillars_inBlock = max_feat_size;

  const int num_pillars = params_data[0];
  // printf("num_pillars: %d\n", num_pillars);
  if ((blockIdx.x * max_feat_size) > num_pillars) return;
  int valid_blocks = (num_pillars + max_feat_size - 1) / max_feat_size;
  if (blockIdx.x >= valid_blocks) return;

  if (blockIdx.x == (valid_blocks - 1)) {
    valid_pillars_inBlock = num_pillars % max_feat_size;
  }

  valid_pillars_inBlock = (valid_pillars_inBlock == 0) ? max_feat_size : valid_pillars_inBlock;

  extern __shared__ float pillarSM[];  // pillar*64

  for (int i = 0; i < valid_pillars_inBlock; i++) {
    pillarSM[i * max_feat_size + threadIdx.x] =
        pillar_features_data[(blockIdx.x * max_feat_size + i) * max_feat_size + threadIdx.x];
  }

  __syncthreads();

  if (pillar_idx >= num_pillars) return;

  uint4 coord = ((const uint4*)coords_data)[pillar_idx];

  unsigned int x = coord.w;
  unsigned int y = coord.z;
  // printf("x: %d, y: %d, feat: pillarSM:%.3f %.3f %.3f\n", x, y,
  // pillarSM[threadIdx.x][0], pillarSM[threadIdx.x][1],
  // pillarSM[threadIdx.x][2]);
  for (int i = 0; i < max_feat_size; i++) {
    spatial_feature_data[i * featureY * featureX + y * featureX + x] =
        pillarSM[threadIdx.x * max_feat_size + i];
  }
}

__global__ void ScatterNorm_kernel_half(const half* pillar_features_data,
                                        const unsigned int* coords_data,
                                        const unsigned int* params_data,
                                        unsigned int featureX,
                                        unsigned int featureY,
                                        half* spatial_feature_data,
                                        const size_t max_pillar_size,
                                        const size_t max_points_size,
                                        const size_t max_feat_size) {
  int pillar_idx = blockIdx.x * max_feat_size + threadIdx.x;
  int valid_pillars_inBlock = max_feat_size;
  const int num_pillars = params_data[0];
  int valid_blocks = (num_pillars + max_feat_size - 1) / max_feat_size;
  if (blockIdx.x >= valid_blocks) return;
  if (blockIdx.x == (valid_blocks - 1)) {
    valid_pillars_inBlock = num_pillars % max_feat_size;
  }
  valid_pillars_inBlock = (valid_pillars_inBlock == 0) ? max_feat_size : valid_pillars_inBlock;
  extern __shared__ half half_pillarSM[];  // pillar*64
  for (int i = 0; i < valid_pillars_inBlock; i++) {
    // half_pillarSM[i][threadIdx.x] = pillar_features_data[(blockIdx.x * max_feat_size + i) *
    // max_feat_size + threadIdx.x];
    half_pillarSM[i * max_feat_size + threadIdx.x] =
        pillar_features_data[(blockIdx.x * max_feat_size + i) * max_feat_size + threadIdx.x];
  }
  __syncthreads();
  if (pillar_idx >= num_pillars) return;
  uint4 coord = ((const uint4*)coords_data)[pillar_idx];
  unsigned int x = coord.w;
  unsigned int y = coord.z;
  // Output tensor format : kHWC8, [N][H][W][(C+7)/8*8]
  int C_stride = (max_feat_size + 7) / 8 * 8;
  for (int i = 0; i < max_feat_size; i++) {
    spatial_feature_data[y * featureX * C_stride + x * C_stride + i] =
        half_pillarSM[threadIdx.x * max_feat_size + i];
  }
}

__global__ void BatchNorm_float_kernel(const float* pillar_features_data,
                                       const unsigned int* params_data,
                                       const float* scale,
                                       const float* shift,
                                       const size_t max_pillar_size,
                                       const size_t max_points_size,
                                       const size_t max_feat_size,
                                       float* output) {
  if (blockIdx.x >= params_data[0]) return;
  const float temp_scale = scale[threadIdx.x];
  const float temp_shift = shift[threadIdx.x];

  unsigned int pos = blockIdx.x * max_points_size * max_feat_size + threadIdx.x;
  for (size_t i = 0; i < max_points_size; i++) {
    pos += max_feat_size;
    output[pos] = pillar_features_data[pos] * temp_scale + temp_shift;
  }
  return;
}

__global__ void BatchNorm_half_kernel(const half* pillar_features_data,
                                      const unsigned int* params_data,
                                      const half* scale,
                                      const half* shift,
                                      const size_t max_pillar_size,
                                      const size_t max_points_size,
                                      const size_t max_feat_size,
                                      half* output) {
  // printf("in size:%d\n", params_data[0]);
  if (blockIdx.x >= params_data[0]) return;
  const half temp_scale = scale[threadIdx.x];
  const half temp_shift = shift[threadIdx.x];
  // printf("temp_scale:%f, temp_shift:%f, threadid:%d \n",
  //        __half2float(temp_scale), __half2float(temp_shift), threadIdx.x);
  unsigned int stride = max_points_size * max_feat_size;
  for (size_t i = 0; i < max_points_size; i++) {
    unsigned int pos = blockIdx.x * stride + i * max_feat_size + threadIdx.x;
    output[pos] = pillar_features_data[pos] * temp_scale + temp_shift;
  }
  return;
}

cudaError_t BatchNorm_float_launcher(const float* pillar_features_data,
                                     const unsigned int* params_data,
                                     const float* scale,
                                     const float* shift,
                                     float* output,
                                     const size_t max_pillar_size,
                                     const size_t max_points_size,
                                     const size_t max_feat_size,
                                     cudaStream_t stream) {
  dim3 blocks(max_pillar_size);
  dim3 threads(max_feat_size);
  BatchNorm_float_kernel<<<blocks, threads, 0, stream>>>(pillar_features_data,
                                                         params_data,
                                                         scale,
                                                         shift,
                                                         max_pillar_size,
                                                         max_points_size,
                                                         max_feat_size,
                                                         output);
  return cudaGetLastError();
}

cudaError_t BatchNorm_half_launcher(const half* pillar_features_data,
                                    const unsigned int* params_data,
                                    const half* scale,
                                    const half* shift,
                                    half* output,
                                    const size_t max_pillar_size,
                                    const size_t max_points_size,
                                    const size_t max_feat_size,
                                    cudaStream_t stream) {
  dim3 blocks(max_pillar_size);
  dim3 threads(max_feat_size);
  BatchNorm_half_kernel<<<blocks, threads, 0, stream>>>(pillar_features_data,
                                                        params_data,
                                                        scale,
                                                        shift,
                                                        max_pillar_size,
                                                        max_points_size,
                                                        max_feat_size,
                                                        output);
  return cudaGetLastError();
}

cudaError_t ScatterNorm_kernel_launcher(const float* pillar_features_data,
                                        const unsigned int* coords_data,
                                        const unsigned int* params_data,
                                        unsigned int featureX,
                                        unsigned int featureY,
                                        float* spatial_feature_data,
                                        const size_t max_pillar_size,
                                        const size_t max_points_size,
                                        const size_t max_feat_size,
                                        cudaStream_t stream) {
  dim3 blocks((featureX * featureY + max_feat_size - 1) / max_feat_size);
  dim3 threads(max_feat_size);

  ScatterNorm_kernel<<<blocks, threads, max_feat_size * max_feat_size * sizeof(float), stream>>>(
      pillar_features_data,
      coords_data,
      params_data,
      featureX,
      featureY,
      spatial_feature_data,
      max_pillar_size,
      max_points_size,
      max_feat_size);

  return cudaGetLastError();
}

cudaError_t ScatterNorm_kernel_half_launcher(const half* pillar_features_data,
                                             const unsigned int* coords_data,
                                             const unsigned int* params_data,
                                             unsigned int featureX,
                                             unsigned int featureY,
                                             half* spatial_feature_data,
                                             const size_t max_pillar_size,
                                             const size_t max_points_size,
                                             const size_t max_feat_size,
                                             cudaStream_t stream) {
  dim3 blocks((featureX * featureY + max_feat_size - 1) / max_feat_size);
  dim3 threads(max_feat_size);
  ScatterNorm_kernel_half<<<blocks,
                            threads,
                            max_feat_size * max_feat_size * sizeof(half),
                            stream>>>(pillar_features_data,
                                      coords_data,
                                      params_data,
                                      featureX,
                                      featureY,
                                      spatial_feature_data,
                                      max_pillar_size,
                                      max_points_size,
                                      max_feat_size);
  return cudaGetLastError();
}

__global__ void SN_reduceMax_kernel(const float* in,
                                    float* out,
                                    const unsigned int* pillarCount,
                                    const size_t max_pillar_size,
                                    const size_t max_points_size,
                                    const size_t max_feat_size) {
  int pillar_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (pillar_idx >= pillarCount[0]) return;

  int feat_idx = threadIdx.y;

  unsigned int indexIn = pillar_idx * max_points_size * max_feat_size + feat_idx * 2;
  float2 outFeature = *((float2*)(in + indexIn));
  for (int i = 1; i < max_points_size; i++) {
    indexIn = pillar_idx * max_points_size * max_feat_size + i * max_feat_size + feat_idx * 2;
    float2 maxFeature = *((float2*)(in + indexIn));
    outFeature.x = max(outFeature.x, maxFeature.x);
    outFeature.y = max(outFeature.y, maxFeature.y);
  }
  unsigned int indexOut = pillar_idx * max_feat_size + feat_idx * 2;
  outFeature.x = max(outFeature.x, 0.0);
  outFeature.y = max(outFeature.y, 0.0);
  *((float2*)(out + indexOut)) = outFeature;
}

__global__ void SN_reduceMax_kernel_half(const half* in,
                                         half* out,
                                         const unsigned int* pillarCount,
                                         const size_t max_pillar_size,
                                         const size_t max_points_size,
                                         const size_t max_feat_size) {
  // int pillar_idx = (blockIdx.x * blockDim.x +
  // threadIdx.x)/POINTS_PER_PILLAR;
  int pillar_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (pillar_idx >= pillarCount[0]) return;

  int feat_idx = threadIdx.y;

  unsigned int indexIn = pillar_idx * max_points_size * max_feat_size + feat_idx * 2;
  // #if __CUDA_ARCH__ >= 800
  half2 outFeature = *((half2*)(in + indexIn));
  // #else
  // float2 outFeature = __half22float2(*((half2*)(in + indexIn)));
  // #endif
  for (int i = 1; i < max_points_size; i++) {
    indexIn = pillar_idx * max_points_size * max_feat_size + i * max_feat_size + feat_idx * 2;
    half2 maxFeature = *((half2*)(in + indexIn));
#if __CUDA_ARCH__ >= 800
    outFeature = __hmax2(outFeature, maxFeature);
#else
    if (__hge(maxFeature.x, outFeature.x)) outFeature.x = maxFeature.x;
    if (__hge(maxFeature.y, outFeature.y)) outFeature.y = maxFeature.y;
#endif
  }
  unsigned int indexOut = pillar_idx * max_feat_size + feat_idx * 2;
#if __CUDA_ARCH__ >= 800
  outFeature.x = __hmax(outFeature.x, 0.0);
  outFeature.y = __hmax(outFeature.y, 0.0);
#else
  if (__hge(0.0, outFeature.x)) outFeature.x = 0.0;
  if (__hge(0.0, outFeature.y)) outFeature.y = 0.0;
// outFeature.x = max(outFeature.x, 0.0);
// outFeature.y = max(outFeature.y, 0.0);
// printf("out feat x:%f, y:%f\n", __half2float((*((half2*)(out +
// indexOut))).x),
//   __half2float((*((half2*)(out + indexOut))).y));
#endif
  *((half2*)(out + indexOut)) = outFeature;
}

cudaError_t SN_reduceMax_kernel_launcher(const float* in,
                                         float* out,
                                         const unsigned int* pillarCount,
                                         unsigned int featureX,
                                         unsigned int featureY,
                                         const size_t max_pillar_size,
                                         const size_t max_points_size,
                                         const size_t max_feat_size,
                                         cudaStream_t stream) {
  // dim3 threads(4*POINTS_PER_PILLAR);
  // dim3 blocks((pillarCount*POINTS_PER_PILLAR+threads.x-1) / threads.x);
  dim3 threads(4, max_feat_size / 2);
  dim3 blocks((featureX * featureY + 4 - 1) / 4);
  SN_reduceMax_kernel<<<blocks, threads, 0, stream>>>(in,
                                                      out,
                                                      pillarCount,
                                                      max_pillar_size,
                                                      max_points_size,
                                                      max_feat_size);

  return cudaGetLastError();
}

cudaError_t SN_reduceMax_kernel_half_launcher(const half* in,
                                              half* out,
                                              const unsigned int* pillarCount,
                                              unsigned int featureX,
                                              unsigned int featureY,
                                              const size_t max_pillar_size,
                                              const size_t max_points_size,
                                              const size_t max_feat_size,
                                              cudaStream_t stream) {
  // dim3 threads(4*POINTS_PER_PILLAR);
  // dim3 blocks((pillarCount*POINTS_PER_PILLAR+threads.x-1) / threads.x);
  dim3 threads(4, max_feat_size / 2);
  // dim3 blocks((pillarCount + 4 -1)/4);
  dim3 blocks((featureX * featureY + 4 - 1) / 4);
  SN_reduceMax_kernel_half<<<blocks, threads, 0, stream>>>(in,
                                                           out,
                                                           pillarCount,
                                                           max_pillar_size,
                                                           max_points_size,
                                                           max_feat_size);

  return cudaGetLastError();
}