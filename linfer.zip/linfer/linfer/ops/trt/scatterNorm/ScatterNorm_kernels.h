// Copyright [2022] <Lotus Robotics>
#pragma once
#include <cuda_fp16.h>
// #define PILLARS_PER_BLOCK 64
// one thread deals with one pillar and a block has PILLARS_PER_BLOCK threads
// #define FEATURE_SIZE 64  // feature count for one pillar depands on "params.h"
// #define MAX_PILLAR_SIZE 48000
// #define STRIDE (POINTS_PER_PILLAR * FEATURE_SIZE)
// #include "kernel.h"

cudaError_t BatchNorm_float_launcher(const float* pillar_features_data,
                                     const unsigned int* params_data,
                                     const float* scale,
                                     const float* shift,
                                     float* output,
                                     const size_t max_pillar_size,
                                     const size_t max_points_size,
                                     const size_t max_feat_size,
                                     cudaStream_t stream = 0);

cudaError_t BatchNorm_half_launcher(const half* pillar_features_data,
                                    const unsigned int* params_data,
                                    const half* scale,
                                    const half* shift,
                                    half* output,
                                    const size_t max_pillar_size,
                                    const size_t max_points_size,
                                    const size_t max_feat_size,
                                    cudaStream_t stream = 0);

cudaError_t ScatterNorm_kernel_launcher(const float* pillar_features_data,
                                        const unsigned int* coords_data,
                                        const unsigned int* params_data,
                                        unsigned int featureX,
                                        unsigned int featureY,
                                        float* spatial_feature_data,
                                        const size_t max_pillar_size,
                                        const size_t max_points_size,
                                        const size_t max_feat_size,
                                        cudaStream_t stream = 0);
cudaError_t ScatterNorm_kernel_half_launcher(const half* pillar_features_data,
                                             const unsigned int* coords_data,
                                             const unsigned int* params_data,
                                             unsigned int featureX,
                                             unsigned int featureY,
                                             half* spatial_feature_data,
                                             const size_t max_pillar_size,
                                             const size_t max_points_size,
                                             const size_t max_feat_size,
                                             cudaStream_t stream = 0);
// for N*32*64
cudaError_t SN_reduceMax_kernel_launcher(const float* in,
                                         float* out,
                                         const unsigned int* pillarCount,
                                         unsigned int featureX,
                                         unsigned int featureY,
                                         const size_t max_pillar_size,
                                         const size_t max_points_size,
                                         const size_t max_feat_size,
                                         cudaStream_t stream = 0);
cudaError_t SN_reduceMax_kernel_half_launcher(const half* in,
                                              half* out,
                                              const unsigned int* pillarCount,
                                              unsigned int featureX,
                                              unsigned int featureY,
                                              const size_t max_pillar_size,
                                              const size_t max_points_size,
                                              const size_t max_feat_size,
                                              cudaStream_t stream = 0);