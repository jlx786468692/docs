/*
 * SPDX-FileCopyrightText: Copyright (c) 2021 NVIDIA CORPORATION & AFFILIATES.
 * All rights reserved. SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "linfer/ops/trt/scatterNorm/ScatterNorm.h"

#include <unistd.h>

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>

#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/scatterNorm/ScatterNorm_kernels.h"
/**
 * For the usage of those member function, please refer to the
 * offical api doc.
 * https://docs.nvidia.com/deeplearning/tensorrt/api/c_api/classnvinfer1_1_1_i_plugin_v2_ext.html
 */

#ifndef CUTEDEBUG
#define CUTEDEBUG 0  // set debug mode, if you want to see the api call, set it to 1
#endif

#if CUTEDEBUG
#define cutelog(...)                                                                             \
  {                                                                                              \
    char str[100];                                                                               \
    snprintf(str, __VA_ARGS__);                                                                  \
    std::cout << " (๑¯◡¯๑) noexcept CUSTOM PLUGIN TRACE----> call "                              \
              << "[" << __FILE__ << "][" << __FUNCTION__ << "][Line " << __LINE__ << "] " << str \
              << std::endl;                                                                      \
  }
#else
#define cutelog(...)
#endif

using nvinfer1::plugin::ScatterNormPlugin;
using nvinfer1::plugin::ScatterNormPluginCreator;

static const char* PLUGIN_VERSION{"1"};
static const char* PLUGIN_NAME{"ScatterNorm"};

// Static class fields initialization
nvinfer1::PluginFieldCollection ScatterNormPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> ScatterNormPluginCreator::mPluginAttributes;

// Helper function for serializing plugin
template <typename T>
void writeToBuffer(char*& buffer, const T& val) {
  *reinterpret_cast<T*>(buffer) = val;
  buffer += sizeof(T);
}

// Helper function for deserializing plugin
template <typename T>
T readFromBuffer(const char*& buffer) {
  T val = *reinterpret_cast<const T*>(buffer);
  buffer += sizeof(T);
  return val;
}

ScatterNormPlugin::ScatterNormPlugin() { cutelog("wow I run to here now"); }

ScatterNormPlugin::ScatterNormPlugin(size_t feat_num,
                                     size_t h,
                                     size_t w,
                                     std::vector<float> scale,
                                     std::vector<float> shift)
    : featureNum_(feat_num), feature_y_size_(h), feature_x_size_(w) {
  scale_.resize(feat_num);
  shift_.resize(feat_num);
  half_scale_ = new __half[feat_num];
  half_shift_ = new __half[feat_num];
  for (size_t i = 0; i < feat_num; i++) {
    scale_[i] = scale[i];
    shift_[i] = shift[i];
    half_scale_[i] = __float2half(scale_[i]);
    half_shift_[i] = __float2half(shift_[i]);
    // printf("temp_scale:%f, temp_shift:%f", scale_[i], shift_[i]);
  }
  devMemMalloc();
  cudaCheckError();
  cutelog("wow I run to here now");
}

ScatterNormPlugin::ScatterNormPlugin(const void* data, size_t length) {
  const char* d = reinterpret_cast<const char*>(data);
  featureNum_ = readFromBuffer<size_t>(d);
  feature_y_size_ = readFromBuffer<size_t>(d);
  feature_x_size_ = readFromBuffer<size_t>(d);
  scale_.resize(featureNum_);
  shift_.resize(featureNum_);
  half_scale_ = new __half[featureNum_];
  half_shift_ = new __half[featureNum_];
  for (size_t i = 0; i < featureNum_; i++) {
    scale_[i] = readFromBuffer<float>(d);
    half_scale_[i] = __float2half(scale_[i]);
  }
  for (size_t i = 0; i < featureNum_; i++) {
    shift_[i] = readFromBuffer<float>(d);
    half_shift_[i] = __float2half(shift_[i]);
  }
  devMemMalloc();
  cudaCheckError();
}

bool ScatterNormPlugin::devMemMalloc() {
  cudaMalloc(reinterpret_cast<void**>(&dev_scale_), sizeof(float) * featureNum_);
  cudaMalloc(reinterpret_cast<void**>(&dev_shift_), sizeof(float) * featureNum_);
  cudaMalloc(reinterpret_cast<void**>(&dev_half_scale_), sizeof(__half) * featureNum_);
  cudaMalloc(reinterpret_cast<void**>(&dev_half_shift_), sizeof(__half) * featureNum_);

  cudaMemcpy(dev_scale_, &scale_[0], sizeof(float) * featureNum_, cudaMemcpyHostToDevice);
  cudaMemcpy(dev_shift_, &shift_[0], sizeof(float) * featureNum_, cudaMemcpyHostToDevice);
  cudaMemcpy(dev_half_scale_, half_scale_, sizeof(__half) * featureNum_, cudaMemcpyHostToDevice);
  cudaMemcpy(dev_half_shift_, half_shift_, sizeof(__half) * featureNum_, cudaMemcpyHostToDevice);
  return true;
}

// IPluginV2DynamicExt Methods
nvinfer1::IPluginV2DynamicExt* ScatterNormPlugin::clone() const noexcept {
  cutelog("wow I run to here now");
  auto* plugin =
      new ScatterNormPlugin(featureNum_, feature_y_size_, feature_x_size_, scale_, shift_);
  plugin->setPluginNamespace(mNamespace.c_str());
  return plugin;
}

nvinfer1::DimsExprs ScatterNormPlugin::getOutputDimensions(
    int outputIndex,
    const nvinfer1::DimsExprs* inputs,
    int nbInputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  cutelog("wow I run to here now");
  assert(outputIndex == 0);
  // for(int i=0;i<nbInputs;i++) {
  //     printf("input[%d]: ", i);
  //     for(int j=0;j<inputs[i].nbDims;j++) {
  //         printf("%d ", inputs[i].d[j]->getConstantValue());
  //     }
  //     printf("\n");
  // }
  nvinfer1::DimsExprs output;
  output.nbDims = 4;
  output.d[0] = exprBuilder.constant(1);
  output.d[1] = exprBuilder.constant(featureNum_);
  output.d[2] = exprBuilder.constant(feature_y_size_);
  output.d[3] = exprBuilder.constant(feature_x_size_);

  return output;
}

bool ScatterNormPlugin::supportsFormatCombination(int pos,
                                                  const nvinfer1::PluginTensorDesc* inOut,
                                                  int nbInputs,
                                                  int nbOutputs) noexcept {
  assert(nbInputs == 3);
  assert(nbOutputs == 1);
  const PluginTensorDesc& in = inOut[pos];
  if (pos == 0) {
    return (in.type == nvinfer1::DataType::kFLOAT || in.type == nvinfer1::DataType::kHALF) &&
           (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 1) {
    return (in.type == nvinfer1::DataType::kINT32) && (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 2) {
    return (in.type == nvinfer1::DataType::kINT32) && (in.format == TensorFormat::kLINEAR);
  }
  if (pos == 3) {
    return (inOut[0].type == nvinfer1::DataType::kFLOAT && in.type == nvinfer1::DataType::kFLOAT &&
            in.format == TensorFormat::kLINEAR) ||
           (inOut[0].type == nvinfer1::DataType::kHALF && in.type == nvinfer1::DataType::kHALF &&
            in.format == TensorFormat::kHWC8);
  }
  return false;
}

void ScatterNormPlugin::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                                        int nbInputs,
                                        const nvinfer1::DynamicPluginTensorDesc* out,
                                        int nbOutputs) noexcept {
  cutelog("wow I run to here now");
}

size_t ScatterNormPlugin::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                           int nbInputs,
                                           const nvinfer1::PluginTensorDesc* outputs,
                                           int nbOutputs) const noexcept {
  cutelog("wow I run to here now");
  unsigned int cacheBEVSize = inputs[0].dims.d[0] * inputs[0].dims.d[2] * sizeof(float);
  cacheBEVSize += (featureNum_ * inputs[0].dims.d[1] * inputs[0].dims.d[0]) * sizeof(float);
  return cacheBEVSize;
}

int ScatterNormPlugin::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                               const nvinfer1::PluginTensorDesc* outputDesc,
                               const void* const* inputs,
                               void* const* outputs,
                               void* workspace,
                               cudaStream_t stream) noexcept {
  unsigned int batch = 1;
  unsigned int featureNum = featureNum_;
  unsigned int featureY = feature_y_size_;
  unsigned int featureX = feature_x_size_;
  size_t max_pillar_size = inputDesc[0].dims.d[0];
  size_t max_points_size = inputDesc[0].dims.d[1];
  size_t max_feat_size = inputDesc[0].dims.d[2];
  nvinfer1::DataType inputType = inputDesc[0].type;

  auto coords_data = reinterpret_cast<const unsigned int*>(inputs[1]);
  auto params_data = reinterpret_cast<const unsigned int*>(inputs[2]);
  // unsigned int count = 0;
  // cudaMemcpyAsync(&count, params_data, sizeof(unsigned int),
  //                 cudaMemcpyDeviceToHost, stream);
  // cudaStreamSynchronize(stream);
  // std::cout << "count:" << count << std::endl;
  if (inputType == nvinfer1::DataType::kHALF) {
    auto in = reinterpret_cast<const half*>(inputs[0]);
    auto spatial_feature_data = reinterpret_cast<half*>(outputs[0]);
    cacheBEV_ = workspace;
    half* cache_output = reinterpret_cast<half*>(
        (char*)workspace + inputDesc[0].dims.d[0] * inputDesc[0].dims.d[2] * sizeof(float));
    BatchNorm_half_launcher(in,
                            params_data,
                            dev_half_scale_,
                            dev_half_shift_,
                            cache_output,
                            max_pillar_size,
                            max_points_size,
                            max_feat_size,
                            stream);

    half* pillar_features_data = reinterpret_cast<half*>(cacheBEV_);
    cudaMemsetAsync(spatial_feature_data,
                    0,
                    batch * featureNum * featureY * featureX * sizeof(half),
                    stream);
    SN_reduceMax_kernel_half_launcher(cache_output,
                                      pillar_features_data,
                                      params_data,
                                      featureX,
                                      featureY,
                                      max_pillar_size,
                                      max_points_size,
                                      max_feat_size,
                                      stream);
    ScatterNorm_kernel_half_launcher(pillar_features_data,
                                     coords_data,
                                     params_data,
                                     featureX,
                                     featureY,
                                     spatial_feature_data,
                                     max_pillar_size,
                                     max_points_size,
                                     max_feat_size,
                                     stream);
    cudaCheckError();
  } else if (inputType == nvinfer1::DataType::kFLOAT) {
    auto in = reinterpret_cast<const float*>(inputs[0]);
    float* spatial_feature_data = reinterpret_cast<float*>(outputs[0]);

    cacheBEV_ = workspace;
    float* cache_output = reinterpret_cast<float*>(
        (char*)workspace + inputDesc[0].dims.d[0] * inputDesc[0].dims.d[2] * sizeof(float));
    BatchNorm_float_launcher(in,
                             params_data,
                             dev_scale_,
                             dev_shift_,
                             cache_output,
                             max_pillar_size,
                             max_points_size,
                             max_feat_size,
                             stream);
    float* pillar_features_data = reinterpret_cast<float*>(cacheBEV_);
    cudaMemsetAsync(spatial_feature_data,
                    0,
                    batch * featureNum * featureY * featureX * sizeof(float),
                    stream);
    SN_reduceMax_kernel_launcher(cache_output,
                                 pillar_features_data,
                                 params_data,
                                 featureX,
                                 featureY,
                                 max_pillar_size,
                                 max_points_size,
                                 max_feat_size,
                                 stream);

    ScatterNorm_kernel_launcher(pillar_features_data,
                                coords_data,
                                params_data,
                                featureX,
                                featureY,
                                spatial_feature_data,
                                max_pillar_size,
                                max_points_size,
                                max_feat_size,
                                stream);
    cudaCheckError();
  } else {
    assert(0);
  }

  return 0;
}

// IPluginV2Ext Methods
nvinfer1::DataType ScatterNormPlugin::getOutputDataType(int index,
                                                        const nvinfer1::DataType* inputTypes,
                                                        int nbInputs) const noexcept {
  cutelog("wow I run to here now");
  return inputTypes[0];
}

ScatterNormPlugin::~ScatterNormPlugin() {
  if (half_scale_ != nullptr) {
    delete[] half_scale_;
    delete[] half_shift_;
  }
  if (dev_scale_ != nullptr) {
    cudaFree(dev_scale_);
    cudaFree(dev_shift_);
    cudaFree(dev_half_scale_);
    cudaFree(dev_half_shift_);
  }
}

// IPluginV2 Methods

const char* ScatterNormPlugin::getPluginType() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_NAME;
}

const char* ScatterNormPlugin::getPluginVersion() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_VERSION;
}

int ScatterNormPlugin::getNbOutputs() const noexcept {
  cutelog("wow I run to here now");
  return 1;
}

int ScatterNormPlugin::initialize() noexcept {
  cutelog("wow I run to here now");
  return 0;
}

void ScatterNormPlugin::terminate() noexcept { cutelog("wow I run to here now"); }

size_t ScatterNormPlugin::getSerializationSize() const noexcept {
  cutelog("wow I run to here now");
  return (4 + 2 * featureNum_) * sizeof(size_t);
}

void ScatterNormPlugin::serialize(void* buffer) const noexcept {
  cutelog("wow I run to here now");
  char* d = reinterpret_cast<char*>(buffer);
  writeToBuffer<size_t>(d, featureNum_);
  writeToBuffer<size_t>(d, feature_y_size_);
  writeToBuffer<size_t>(d, feature_x_size_);
  for (size_t i = 0; i < featureNum_; i++) {
    writeToBuffer<float>(d, scale_[i]);
  }
  for (size_t i = 0; i < featureNum_; i++) {
    writeToBuffer<float>(d, shift_[i]);
  }
}

void ScatterNormPlugin::destroy() noexcept {
  cutelog("wow I run to here now");
  delete this;
}

void ScatterNormPlugin::setPluginNamespace(const char* libNamespace) noexcept {
  cutelog("wow I run to here now");
  mNamespace = libNamespace;
}

const char* ScatterNormPlugin::getPluginNamespace() const noexcept {
  cutelog("wow I run to here now");
  return mNamespace.c_str();
}

///////////////

ScatterNormPluginCreator::ScatterNormPluginCreator() {
  cutelog("wow I run to here now");
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      PluginField("dense_shape", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("scale", nullptr, nvinfer1::PluginFieldType::kFLOAT32, 1));
  mPluginAttributes.emplace_back(
      PluginField("shift", nullptr, nvinfer1::PluginFieldType::kFLOAT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

const char* ScatterNormPluginCreator::getPluginName() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_NAME;
}

const char* ScatterNormPluginCreator::getPluginVersion() const noexcept {
  cutelog("wow I run to here now");
  return PLUGIN_VERSION;
}

const nvinfer1::PluginFieldCollection* ScatterNormPluginCreator::getFieldNames() noexcept {
  cutelog("wow I run to here now");
  return &mFC;
}

nvinfer1::IPluginV2* ScatterNormPluginCreator::createPlugin(
    const char* name,
    const PluginFieldCollection* fc) noexcept {
  const PluginField* fields = fc->fields;
  int nbFields = fc->nbFields;
  int target_featnum = 0;
  int target_h = 0;
  int target_w = 0;
  std::vector<float> scale;
  std::vector<float> shift;
  for (int i = 0; i < nbFields; ++i) {
    const char* attr_name = fields[i].name;
    if (!strcmp(attr_name, "dense_shape")) {
      const int* ts = static_cast<const int*>(fields[i].data);
      target_featnum = ts[1];
      target_h = ts[2];
      target_w = ts[3];
    } else if (!strcmp(attr_name, "scale")) {
      int size = fields[i].length;
      scale.reserve(size);
      const auto* w = static_cast<const float*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        scale.push_back(*w);
        w++;
      }
    } else if (!strcmp(attr_name, "shift")) {
      int size = fields[i].length;
      shift.reserve(size);
      const auto* w = static_cast<const float*>(fields[i].data);
      for (int j = 0; j < size; j++) {
        shift.push_back(*w);
        w++;
      }
    }
  }
  nvinfer1::IPluginV2* plugin =
      new ScatterNormPlugin(target_featnum, target_h, target_w, scale, shift);
  return plugin;
}

nvinfer1::IPluginV2* ScatterNormPluginCreator::deserializePlugin(const char* name,
                                                                 const void* serialData,
                                                                 size_t serialLength) noexcept {
  cutelog("wow I run to here now");
  return new ScatterNormPlugin(serialData, serialLength);
}

void ScatterNormPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  cutelog("wow I run to here now");
  mNamespace = libNamespace;
}

const char* ScatterNormPluginCreator::getPluginNamespace() const noexcept {
  cutelog("wow I run to here now");
  return mNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(ScatterNormPluginCreator);