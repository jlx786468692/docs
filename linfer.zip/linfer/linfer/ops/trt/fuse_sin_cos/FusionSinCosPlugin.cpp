#include "FusionSinCosPlugin.h"

#include <NvInfer.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace nvinfer1 {
namespace plugin {

PluginFieldCollection FusionSinCosCreator::mFC{};
std::vector<PluginField> FusionSinCosCreator::mPluginAttributes;

FusionSinCos::FusionSinCos() {}

FusionSinCos::FusionSinCos(const void* serialData, size_t serialLength) {}

char const* FusionSinCos::getPluginType() const noexcept { return FUSION_SIN_COS_NAME; }

char const* FusionSinCos::getPluginVersion() const noexcept { return FUSION_SIN_COS_VERSION; }

int32_t FusionSinCos::getNbOutputs() const noexcept { return 1; }

DimsExprs FusionSinCos::getOutputDimensions(int32_t outputIndex,
                                            DimsExprs const* inputs,
                                            int32_t nbInputs,
                                            IExprBuilder& exprBuilder) noexcept {
  DimsExprs output;
  output.nbDims = 4;
  output.d[0] = exprBuilder.constant(1);    // Batch size
  output.d[1] = exprBuilder.constant(100);  // Channels
  output.d[2] = exprBuilder.constant(20);   // Height
  output.d[3] = exprBuilder.constant(256);  // Width

  return output;
}

bool FusionSinCos::supportsFormatCombination(int32_t pos,
                                             PluginTensorDesc const* inOut,
                                             int32_t nbInputs,
                                             int32_t nbOutputs) noexcept {
  // 2 input and 1 output
  ASSERT(0 <= pos && pos < 3);
  ASSERT(nbInputs == 2);
  ASSERT(nbOutputs == 1);
  ASSERT(pos < (nbInputs + nbOutputs));
  ASSERT(inOut != nullptr);

  // make sure all tensor use linear data format
  bool isFormatOK = (inOut[pos].format == nvinfer1::TensorFormat::kLINEAR);

  // check data type
  if (pos == 0 || pos == 1) {
    // input tensors data type must be either float or half
    isFormatOK &= (inOut[pos].type == nvinfer1::DataType::kFLOAT ||
                   inOut[pos].type == nvinfer1::DataType::kHALF);

    // make tensor 0 and tensor 1 have the same data type
    if (pos == 1) {
      isFormatOK &= (inOut[1].type == inOut[0].type);
    }
  } else {
    // make sure output tensor data type is the same as input tensor 0
    isFormatOK &= (inOut[2].type == inOut[0].type);
  }

  return isFormatOK;
}

void FusionSinCos::configurePlugin(DynamicPluginTensorDesc const* in,
                                   int32_t nbInputs,
                                   DynamicPluginTensorDesc const* out,
                                   int32_t nbOutputs) noexcept {
  // check output tensor data type
  mOutputDtype = (in[0].desc.type == nvinfer1::DataType::kHALF) ? 1 : 0;
}

size_t FusionSinCos::getWorkspaceSize(PluginTensorDesc const* inputs,
                                      int32_t nbInputs,
                                      PluginTensorDesc const* outputs,
                                      int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t FusionSinCos::enqueue(PluginTensorDesc const* inputDesc,
                              PluginTensorDesc const* outputDesc,
                              void const* const* inputs,
                              void* const* outputs,
                              void* workspace,
                              cudaStream_t stream) noexcept {
  try {
    const int batch_size = inputDesc[0].dims.d[0];
    const int seq_len = inputDesc[0].dims.d[1];
    const int feature_dim = inputDesc[0].dims.d[2];
    FusionSinCosLaunch(inputs[0],
                       inputs[1],
                       outputs[0],
                       batch_size,
                       seq_len,
                       feature_dim,
                       mOutputDtype,
                       stream);
    return cudaPeekAtLastError();
  } catch (std::exception const& e) {
    caughtError(e);
    return -1;
  }
}

size_t FusionSinCos::getSerializationSize() const noexcept { return 0; }

void FusionSinCos::serialize(void* buffer) const noexcept {}

void FusionSinCos::destroy() noexcept { delete this; }

int32_t FusionSinCos::initialize() noexcept { return 0; }

void FusionSinCos::terminate() noexcept {}

void FusionSinCos::setPluginNamespace(char const* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

char const* FusionSinCos::getPluginNamespace() const noexcept { return mPluginNamespace.c_str(); }

DataType FusionSinCos::getOutputDataType(int32_t index,
                                         nvinfer1::DataType const* inputTypes,
                                         int32_t nbInputs) const noexcept {
  return inputTypes[0];
}

IPluginV2DynamicExt* FusionSinCos::clone() const noexcept {
  try {
    auto* plugin = new FusionSinCos();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

// Plugin creator
FusionSinCosCreator::FusionSinCosCreator() {}

IPluginV2DynamicExt* FusionSinCosCreator::createPlugin(char const* name,
                                                       PluginFieldCollection const* fc) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new FusionSinCos();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

IPluginV2DynamicExt* FusionSinCosCreator::deserializePlugin(char const* name,
                                                            void const* serialData,
                                                            size_t serialLength) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new FusionSinCos(serialData, serialLength);
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

const char* FusionSinCosCreator::getPluginName() const noexcept { return FUSION_SIN_COS_NAME; }

const char* FusionSinCosCreator::getPluginVersion() const noexcept {
  return FUSION_SIN_COS_VERSION;
}

const PluginFieldCollection* FusionSinCosCreator::getFieldNames() noexcept { return &mFC; }

void FusionSinCosCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mPluginNamespace = libNamespace;
}

const char* FusionSinCosCreator::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(FusionSinCosCreator);

}  // namespace plugin
}  // namespace nvinfer1