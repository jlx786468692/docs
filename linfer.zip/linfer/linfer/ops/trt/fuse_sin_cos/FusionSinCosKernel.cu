#include <NvInfer.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <iostream>
#include <type_traits>

namespace nvinfer1 {
namespace plugin {

__global__ void fuse_sin_cos_kernel_fp32(const float* input,
                                         const float* div_bias,
                                         float* output,
                                         const int batch_size,
                                         const int seq_len,
                                         const int feature_dim) {
  // define constants
  const int freq_dim = 128;
  const int output_height = 100;
  const int output_width = 20;

  // calc thread index and stride
  const int tid = blockIdx.x * blockDim.x + threadIdx.x;
  const int stride = blockDim.x * gridDim.x;
  const int total_elements = batch_size * seq_len * feature_dim * freq_dim;

// every thread processes multiple elements to increase compute intensity
#pragma unroll 4
  for (int idx = tid; idx < total_elements; idx += stride) {
    // use bitwise operations to optimize index calculation (while freq_dim is a power of 2 = 128)
    const int freq_idx = idx & 127;     // same as idx % 128
    int temp_idx = idx >> 7;            // same as idx / 128
    const int feat_idx = temp_idx & 1;  // same as temp_idx % 2 (feature_dim=2)
    temp_idx = temp_idx >> 1;           // same as temp_idx / 2

    // calculate sequence and batch index (using division since seq_len is not necessarily a power
    // of 2)
    const int seq_idx = temp_idx % seq_len;
    const int batch_idx = temp_idx / seq_len;

    // calculate input index and read input value
    const int input_idx = (batch_idx * seq_len + seq_idx) * feature_dim + feat_idx;
    // use __ldg to read global memory
    const float input_value = __ldg(&input[input_idx]);
    const float scaled_val = input_value * 6.28318548f;
    const float div_value = __ldg(&div_bias[freq_idx]);
    const float phase = scaled_val / div_value;

    // check if frequency index is even or odd
    const bool is_even = !(freq_idx & 1);
    const float result = is_even ? __sinf(phase) : __cosf(phase);

    // optimize output position calculation
    const int output_seq_h = seq_idx / output_width;
    const int output_seq_w = seq_idx % output_width;

    // swap feature dimension (0->1, 1->0) using bitwise XOR
    const int swapped_feat_idx = feat_idx ^ 1;

    // ensure sin/cos values alternate
    int final_d;
    if (is_even) {
      // even frequency indices use sin - placed in even output positions
      final_d = (freq_idx >> 1) << 1;  // (freq_idx/2)*2 = 偶数位置
    } else {
      // odd frequency indices use cos - placed in odd output positions
      final_d = ((freq_idx >> 1) << 1) + 1;  // (freq_idx/2)*2+1 = 奇数位置
    }

    // calculating final output index
    const int output_idx =
        ((batch_idx * output_height + output_seq_h) * output_width + output_seq_w) *
            (feature_dim * freq_dim) +
        swapped_feat_idx * freq_dim + final_d;
    output[output_idx] = result;
  }
}

__global__ void fuse_sin_cos_kernel_fp16(const half* input,
                                         const half* div_bias,
                                         half* output,
                                         const int batch_size,
                                         const int seq_len,
                                         const int feature_dim) {
  const int freq_dim = 128;
  const int output_height = 100;
  const int output_width = 20;

  const int tid = blockIdx.x * blockDim.x + threadIdx.x;
  const int stride = blockDim.x * gridDim.x;
  const int total_elements = batch_size * seq_len * feature_dim * freq_dim;

#pragma unroll 4
  for (int idx = tid; idx < total_elements; idx += stride) {
    const int freq_idx = idx & 127;     // same as idx % 128
    int temp_idx = idx >> 7;            // same as idx / 128
    const int feat_idx = temp_idx & 1;  // same as temp_idx % 2 (feature_dim=2)
    temp_idx = temp_idx >> 1;           // same as temp_idx / 2

    const int seq_idx = temp_idx % seq_len;
    const int batch_idx = temp_idx / seq_len;

    const int input_idx = (batch_idx * seq_len + seq_idx) * feature_dim + feat_idx;
    const half input_value = __ldg(&input[input_idx]);
    // use half may case precision problem, so convert to float for calculation
    const float input_float = __half2float(input_value);
    const float scaled_val = input_float * 6.28318548f;
    const float div_value = __half2float(__ldg(&div_bias[freq_idx]));
    const float phase = scaled_val / div_value;
    const bool is_even = !(freq_idx & 1);
    const float result_float = is_even ? __sinf(phase) : __cosf(phase);
    const half result = __float2half(result_float);
    const int output_seq_h = seq_idx / output_width;
    const int output_seq_w = seq_idx % output_width;
    const int swapped_feat_idx = feat_idx ^ 1;
    int final_d;
    if (is_even) {
      final_d = (freq_idx >> 1) << 1;
    } else {
      final_d = ((freq_idx >> 1) << 1) + 1;
    }
    const int output_idx =
        ((batch_idx * output_height + output_seq_h) * output_width + output_seq_w) *
            (feature_dim * freq_dim) +
        swapped_feat_idx * freq_dim + final_d;
    output[output_idx] = result;
  }
}

int FusionSinCosLaunch(const void* input0,
                       const void* input1,
                       void* outputs,
                       const int batch_size,
                       const int seq_len,
                       const int feature_dim,
                       const int mOutputDtype,
                       cudaStream_t stream) {
  const int freq_dim = 128;  // Example frequency dimension, adjust as needed
  int total_threads = batch_size * seq_len * feature_dim * freq_dim;
  const int threadPerBlock = 256;

  // every SM at least 4 blocks, usually total blocks is 2-4 times of device SM count for better
  // efficiency
  int blocksPerGrid = (total_threads + threadPerBlock * 4 - 1) / (threadPerBlock * 4);
  // limit blocksPerGrid to a maximum of 1024
  blocksPerGrid = min(blocksPerGrid, 1024);

  if (mOutputDtype == 0) {
    // do fp32 infer
    fuse_sin_cos_kernel_fp32<<<blocksPerGrid, threadPerBlock, 0, stream>>>(
        static_cast<const float*>(input0),
        static_cast<const float*>(input1),
        static_cast<float*>(outputs),
        batch_size,
        seq_len,
        feature_dim);

    // Check for kernel launch errors
    cudaError_t error = cudaGetLastError();
    if (error != cudaSuccess) {
      printf("CUDA error: %s\n", cudaGetErrorString(error));
    }

  } else {
    // do fp16 infer
    fuse_sin_cos_kernel_fp16<<<blocksPerGrid, threadPerBlock, 0, stream>>>(
        static_cast<const half*>(input0),
        static_cast<const half*>(input1),
        static_cast<half*>(outputs),
        batch_size,
        seq_len,
        feature_dim);

    // Check for kernel launch errors
    cudaError_t error = cudaGetLastError();
    if (error != cudaSuccess) {
      printf("CUDA error: %s\n", cudaGetErrorString(error));
    }
  }

  return 0;
}

}  // namespace plugin
}  // namespace nvinfer1