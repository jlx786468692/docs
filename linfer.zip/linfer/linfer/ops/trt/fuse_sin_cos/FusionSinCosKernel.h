#ifndef FUSION_SIN_COS_KERNEL_H
#define FUSION_SIN_COS_KERNEL_H

#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cstdint>
#include <vector>

#include "NvInferRuntimeCommon.h"

namespace nvinfer1 {
namespace plugin {

#ifdef __CUDA_ARCH__
#define ASSERT(condition) __assert_fail(condition, __FILE__, __LINE__, __func__)
#else
#define ASSERT(condition) assert(condition)
#endif
int32_t FusionSinCosLaunch(const void* input0,
                           const void* input1,
                           void* outputs,
                           const int batch_size,
                           const int seq_len,
                           const int feature_dim,
                           const int mOutputDtype,
                           cudaStream_t stream);

}  // namespace plugin
}  // namespace nvinfer1

#endif  // FUSION_SIN_COS_KERNEL_H