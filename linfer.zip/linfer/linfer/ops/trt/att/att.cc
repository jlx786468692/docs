
#include "linfer/ops/trt/att/att.h"

#include <chrono>
#include <fstream>
#include <iomanip>
#include <memory>
#include <string>
#include <vector>

#include "cuda_fp16.h"
#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"

#define NONZERO_LEN 8192

pluginStatus_t Nonzero_op(cudaStream_t stream,
                          int agts_r_size,
                          int agts_c_size,
                          int ctx_r_size,
                          int ctx_c_size,
                          int agt_ctrs_size,
                          int ctx_ctrs_size,
                          int sizeOfElementInBytes,
                          const void* agts,
                          const void* ctx,
                          const void* agt_ctrs,
                          const void* ctx_ctrs,
                          const float dist_th,
                          void* output,
                          int* ret_len,
                          void* workspace);

pluginStatus_t Index_add_op(cudaStream_t stream,
                            int agts_r_size,
                            int agts_c_size,
                            int ctx_r_size,
                            int ctx_c_size,
                            int agt_ctrs_size,
                            int ctx_ctrs_size,
                            int sizeOfElementInBytes,
                            int ret_len,
                            void* new_ctx,
                            void* output,
                            void* workspace);

namespace linfer {
namespace ops {
namespace trt {

const char* ATT_PLUGIN_VERSION{"1"};

static int32_t get_row_size(const nvinfer1::Dims& input) { return input.d[0]; }

static int32_t get_col_size(const nvinfer1::Dims& input) { return input.d[1]; }

std::mutex Att::trt_eng_mutex_;
std::shared_ptr<linfer::util::TrtModelInferEngine> Att::trt_eng_(nullptr);
cudaStream_t Att::stream_att_;

Att::Att(const std::string& name,
         float dist_th,
         const std::vector<int>& idx_map_table,
         bool use_fp16)
    : plugin_name_(name), dist_th_(dist_th), idx_map_table_(idx_map_table), use_fp16_(use_fp16) {
  std::lock_guard<std::mutex> guard(trt_eng_mutex_);
  CHECK_CUDA(cudaStreamCreate(&stream_att_));
  if (nullptr == trt_eng_.get()) {
    const char* att_plugin_engin_path = std::getenv("TRT_PLUGIN_ENGINE_PATH");
    if (nullptr != att_plugin_engin_path) {
      trt_eng_ =
          std::make_shared<linfer::util::TrtModelInferEngine>(std::string(att_plugin_engin_path));
    }
  }
}

inline int Att::get_idx(int idx) const {
  if (0 == idx_map_table_.size()) {
    return idx;
  }
  LASSERT_MSG(idx < idx_map_table_.size(), "");
  return idx_map_table_[idx];
}

bool Att::supportsFormatCombination(int32_t pos,
                                    const nvinfer1::PluginTensorDesc* inOut,
                                    int32_t nbInputs,
                                    int32_t nbOutputs) noexcept {
  const nvinfer1::PluginTensorDesc& desc = inOut[pos];
  printf("%s index %d input precision is %u \n", plugin_name_.c_str(), pos, (int)desc.type);
  if (use_fp16_) {
    switch (pos) {
      case Att::agts_idx_:
        if (desc.type != nvinfer1::DataType::kHALF) {
          printf("precision setting wrongly attr is fp32 but use fp16\n");
          // ASSERT(false);
        }
    }
    // switch (pos) {
    //     case Att::ctx_ctrs_idx_:
    //     case Att::agts_idx_:
    //     case Att::ctx_idx_:
    //         // printf("input %d is %d \n", pos, (desc.type ==
    //         inOut[agt_ctrs_idx_].type)); return (desc.type ==
    //         inOut[agt_ctrs_idx_].type);
    // }
    // printf("input %d is %d %d\n", pos, desc.type, (desc.type ==
    // inOut[agt_ctrs_idx_].type));
    return ((desc.type == nvinfer1::DataType::kHALF || desc.type == nvinfer1::DataType::kINT32) &&
            desc.format == nvinfer1::TensorFormat::kLINEAR);
  }
  switch (pos) {
    case Att::agts_idx_:
      if (desc.type != nvinfer1::DataType::kFLOAT) {
        printf("precision setting wrongly attr is fp16 but use fp32\n");
        // ASSERT(false);
      }

      return (
          (desc.type == nvinfer1::DataType::kFLOAT || desc.type == nvinfer1::DataType::kINT32) &&
          desc.format == nvinfer1::TensorFormat::kLINEAR);
  }
  return false;
}

void Att::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                          int32_t nbInputs,
                          const nvinfer1::DynamicPluginTensorDesc* out,
                          int32_t nbOutputs) noexcept {
  if (in[0].desc.type == nvinfer1::DataType::kHALF) {
    ASSERT(use_fp16_);
    return;
  }
  ASSERT(!use_fp16_);
}

size_t Att::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                             int32_t nbInputs,
                             const nvinfer1::PluginTensorDesc* outputs,
                             int32_t nbOutputs) const noexcept {
  int32_t agt_r_size = get_row_size(inputs[get_idx(agt_ctrs_idx_)].dims);
  int32_t ctx_r_size = get_row_size(inputs[get_idx(ctx_ctrs_idx_)].dims);
  // transformCoeffs + transformed indices
  if (use_fp16_)
    return (agt_r_size * ctx_r_size * 2) * sizeof(__half) +
           (NONZERO_LEN + NONZERO_LEN + 1) * sizeof(int);
  return (agt_r_size * ctx_r_size * 2 + NONZERO_LEN + NONZERO_LEN + 1) * sizeof(float);
}

int Att::initialize() noexcept { return 0; }

void Att::terminate() noexcept { return; }

static std::shared_ptr<linfer::util::Tensor> make_input(const nvinfer1::PluginTensorDesc desc,
                                                        const void* ptr) {
  linfer::util::Dims dims;
  linfer::util::NvDims2TensorDims(desc.dims, dims);
  auto dtype = linfer::util::NvDataType2DataType(desc.type);
  // printf("the dtype is %d\n", dtype);
  return std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                  dtype,
                                                  const_cast<void*>(ptr),
                                                  dims);
}

int32_t Att::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                     const nvinfer1::PluginTensorDesc* outputDesc,
                     const void* const* inputs,
                     void* const* outputs,
                     void* workspace,
                     cudaStream_t stream_lanegcn) noexcept {
  // printf("start %s\n", plugin_name_.c_str());

  if (!trt_eng_) {
    printf(
        "trt engine in Att plugin is NOT inititialized. \
Please set TRT_PLUGIN_ENGINE_PATH or init TrtModelInferEngine with pred_plugin_engine param");
    return 1;
  }
  // cudaEventRecord(start, NULL);

  // do self-define ops
  int agt_ctrs_idx = get_idx(agt_ctrs_idx_);
  int ctx_ctrs_idx = get_idx(ctx_ctrs_idx_);
  int agts_idx = get_idx(agts_idx_);
  int ctx_idx = get_idx(ctx_idx_);

  nvinfer1::Dims agt_ctrs_Dims = inputDesc[agt_ctrs_idx].dims;
  nvinfer1::Dims ctx_ctrs_Dims = inputDesc[ctx_ctrs_idx].dims;
  nvinfer1::Dims agts_Dims = inputDesc[agts_idx].dims;
  nvinfer1::Dims ctx_Dims = inputDesc[ctx_idx].dims;
  int32_t agt_ctrs_r_size = get_row_size(agt_ctrs_Dims);
  int32_t agt_ctrs_c_size = get_col_size(agt_ctrs_Dims);
  int32_t ctx_ctrs_r_size = get_row_size(ctx_ctrs_Dims);
  int32_t ctx_ctrs_c_size = get_col_size(ctx_ctrs_Dims);
  int32_t agts_r_size = get_row_size(agts_Dims);
  int32_t agts_c_size = get_col_size(agts_Dims);
  int32_t ctx_r_size = get_row_size(ctx_Dims);
  int32_t ctx_c_size = get_col_size(ctx_Dims);
  int32_t elementSizeInBytes = linfer::util::getElementSize(inputDesc[agt_ctrs_idx].type);
  int32_t nonzero_len = NONZERO_LEN;

  Nonzero_op(stream_lanegcn,
             agts_r_size,
             agts_c_size,
             ctx_r_size,
             ctx_c_size,
             agt_ctrs_r_size,
             ctx_ctrs_r_size,
             elementSizeInBytes,
             inputs[agts_idx],
             inputs[ctx_idx],
             inputs[agt_ctrs_idx],
             inputs[ctx_ctrs_idx],
             dist_th_,
             outputs[0],
             &nonzero_len,
             workspace);

  if (nonzero_len == 0) {
    printf("direct return\n");
    cudaMemcpyAsync(outputs[0],
                    inputs[agts_idx],
                    agts_r_size * agts_c_size * elementSizeInBytes,
                    cudaMemcpyDeviceToDevice,
                    stream_lanegcn);
    return 0;
  }

  if (elementSizeInBytes == 4) {
    if (use_fp16_) {
      printf("the data type is wrong\n");
      ASSERT(false);
    }
    float* dist_buff = (float*)workspace;
    int* hi_buff = (int*)&dist_buff[agt_ctrs_r_size * ctx_ctrs_r_size * 2];
    int* wi_buff = (int*)&dist_buff[agt_ctrs_r_size * ctx_ctrs_r_size * 2 + NONZERO_LEN];
    float* new_ctx;

    linfer::util::Dims dist_dim, hi_dim, wi_dim, ctx_dim, agts_dim;
    dist_dim.nbDims = 2;
    dist_dim.d[0] = nonzero_len;
    dist_dim.d[1] = 2;
    hi_dim.nbDims = 1;
    hi_dim.d[0] = nonzero_len;
    wi_dim.nbDims = 1;
    wi_dim.d[0] = nonzero_len;
    ctx_dim.nbDims = 2;
    ctx_dim.d[0] = ctx_r_size;
    ctx_dim.d[1] = ctx_c_size;
    agts_dim.nbDims = 2;
    agts_dim.d[0] = agts_r_size;
    agts_dim.d[1] = agts_c_size;

    /* Att1
    0: graph_ctrs
    1: actors_ctrs
    2: a2m.att.0.dist.0.weight
    3: a2m.att.0.dist.0.bias
    4: 3973
    5: a2m.att.0.dist.2.norm.weight
    6: a2m.att.0.dist.2.norm.bias
    7: 1893
    8: 3974
    9: a2m.att.0.query.norm.weight
    10: a2m.att.0.query.norm.bias
    11: 708
    12: 3975
    13: a2m.att.0.ctx.0.norm.weight
    14: a2m.att.0.ctx.0.norm.bias
    15: 3976
    16: 3977

    0, actors_ctrs, float32[22,2]       0
    ---- 0 ----                         1
    1, a2a.att.0.dist.0.weight          2
    2, a2a.att.0.dist.0.bias            3
    3, 4061                             4
    4, a2a.att.0.dist.2.norm.weight     5
    5, a2a.att.0.dist.2.norm.bias       6
    6, 3473, float32[22,128]            7
    7, 4062                             8
    8, a2a.att.0.query.norm.weight      9
    9, a2a.att.0.query.norm.bias        10
    ---- 6 ---                          11
    10, 4063                            12
    11, a2a.att.0.ctx.0.norm.weight     13
    12, a2a.att.0.ctx.0.norm.bias       14
    13, 4064                            15
    14, 4065                            16
    */

    /* Att1 without nonzero
    0, 1913, float32[?,2]:                              ??? dist_buff
    1, a2m.att.0.dist.0.weight, float32[128,2]:         2
    2, a2m.att.0.dist.0.bias, float32[128]:             3
    3, 3973, float32[128,128]:                          4
    4, a2m.att.0.dist.2.norm.weight, float32[128]       5
    5, a2m.att.0.dist.2.norm.bias, float32[128]         6
    6, 1893, float32[3276,128]                          7
    7, 1908, int64[?]                                   ??? hi_buff
    8, 3974, float32[128,128]                           8
    9, a2m.att.0.query.norm.weight, float32[128]        9
    10, a2m.att.0.query.norm.bias,  float32[128]        10
    11, 708, float32[22,128]                            11
    12, 1910, int64[?]                                  ??? wi_buff
    13, 3975, float32[384,128]                          12
    14, a2m.att.0.ctx.0.norm.weight,  float32[128]      13
    15, a2m.att.0.ctx.0.norm.bias, float32[128]         14
    16, 3976, float32[128,128]                          15
    17, 3977, float32[128,128]                          16
    */

    /*  Att5
     0, actors_ctrs, float32[22,2]
     1, a2a.att.0.dist.0.weight
     2, a2a.att.0.dist.0.bias
     3, 4061
     4, a2a.att.0.dist.2.norm.weight
     5, a2a.att.0.dist.2.norm.bias
     6, 3473, float32[22,128]
     7, 4062
     8, a2a.att.0.query.norm.weight
     9, a2a.att.0.query.norm.bias
     10, 4063
     11, a2a.att.0.ctx.0.norm.weight
     12, a2a.att.0.ctx.0.norm.bias
     13, 4064
     14, 4065
     ---------------------

     Att5 without nonzero:
     3493, 3493, float32[?,2]                                                    ???
     a2a.att.0.dist.0.weight, a2a.att.0.dist.0.weight, float32[128,2]            1
     a2a.att.0.dist.0.bias, a2a.att.0.dist.0.bias, float32[128]                  2
     4061, 4061, float32[128,128]                                                3
     a2a.att.0.dist.2.norm.weight, a2a.att.0.dist.2.norm.weight, float32[128]    4
     a2a.att.0.dist.2.norm.bias, a2a.att.0.dist.2.norm.bias, float32[128]        5
     3473, 3473, float32[22,128]                                                 6
     3488, 3488, int64[?]                                                        ???
     4062, 4062, float32[128,128]                                                7
     a2a.att.0.query.norm.weight, a2a.att.0.query.norm.weight, float32[128]      8
     a2a.att.0.query.norm.bias, a2a.att.0.query.norm.bias, float32[128]          9
     ####place_holder##### (3473)                                                6
     3490, 3490, int64[?]                                                        ???
     4063, 4063, float32[384,128]                                                10
     a2a.att.0.ctx.0.norm.weight, a2a.att.0.ctx.0.norm.weight, float32[128]      11
     a2a.att.0.ctx.0.norm.bias, a2a.att.0.ctx.0.norm.bias, float32[128]          12
     4064, 4064, float32[128,128]                                                13
     4065, 4065, float32[128,128]                                                14
    */

    std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> trt_inputs;
    trt_inputs["0"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                               linfer::util::DataType::kFLOAT,
                                                               dist_buff,
                                                               dist_dim);
    trt_inputs["1"] = make_input(inputDesc[get_idx(2)], inputs[get_idx(2)]);
    trt_inputs["2"] = make_input(inputDesc[get_idx(3)], inputs[get_idx(3)]);
    trt_inputs["3"] = make_input(inputDesc[get_idx(4)], inputs[get_idx(4)]);
    trt_inputs["4"] = make_input(inputDesc[get_idx(5)], inputs[get_idx(5)]);
    trt_inputs["5"] = make_input(inputDesc[get_idx(6)], inputs[get_idx(6)]);
    trt_inputs["6"] = make_input(inputDesc[get_idx(7)], inputs[get_idx(7)]);
    trt_inputs["7"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                               linfer::util::DataType::kINT32,
                                                               hi_buff,
                                                               hi_dim);
    trt_inputs["8"] = make_input(inputDesc[get_idx(8)], inputs[get_idx(8)]);
    trt_inputs["9"] = make_input(inputDesc[get_idx(9)], inputs[get_idx(9)]);
    trt_inputs["10"] = make_input(inputDesc[get_idx(10)], inputs[get_idx(10)]);

    trt_inputs["11"] = make_input(inputDesc[get_idx(11)], inputs[get_idx(11)]);
    trt_inputs["12"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                                linfer::util::DataType::kINT32,
                                                                wi_buff,
                                                                wi_dim);
    trt_inputs["13"] = make_input(inputDesc[get_idx(12)], inputs[get_idx(12)]);
    trt_inputs["14"] = make_input(inputDesc[get_idx(13)], inputs[get_idx(13)]);
    trt_inputs["15"] = make_input(inputDesc[get_idx(14)], inputs[get_idx(14)]);
    trt_inputs["16"] = make_input(inputDesc[get_idx(15)], inputs[get_idx(15)]);
    trt_inputs["17"] = make_input(inputDesc[get_idx(16)], inputs[get_idx(16)]);

    trt_eng_->set_stream(stream_lanegcn);
    trt_eng_->infer(trt_inputs);

    /*
        agts: trt_outputs[0]
        hi: trt_outputs[1]
        ctx: trt_outputs[2]
    */
    auto trt_outputs = trt_eng_->get_output_vector(linfer::util::DeviceType::GPU);
    auto trt_agts_output = trt_outputs[0];
    cudaMemcpyAsync(outputs[0],
                    trt_agts_output->get_gpu_buf(),
                    trt_agts_output->get_len_in_byte(),
                    cudaMemcpyDeviceToDevice,
                    stream_lanegcn);
    new_ctx = static_cast<float*>(trt_outputs[2]->get_gpu_buf());
    // do self-define ops
    Index_add_op(stream_lanegcn,
                 agts_r_size,
                 agts_c_size,
                 ctx_r_size,
                 ctx_c_size,
                 agt_ctrs_r_size,
                 ctx_ctrs_r_size,
                 elementSizeInBytes,
                 nonzero_len,
                 (void*)new_ctx,
                 outputs[0],
                 workspace);

    cudaEvent_t event_wait_data;
    cudaEventCreate(&event_wait_data);
    cudaEventRecord(event_wait_data, stream_lanegcn);
    cudaStreamWaitEvent(stream_lanegcn, event_wait_data);

    return 0;

  } else {
    if (!use_fp16_) {
      printf("the data type is wrong\n");
      ASSERT(false);
    }
    __half* dist_buff = (__half*)workspace;
    int* hi_buff = (int*)&dist_buff[agt_ctrs_r_size * ctx_ctrs_r_size * 2];
    int* wi_buff = (int*)&dist_buff[agt_ctrs_r_size * ctx_ctrs_r_size * 2 + NONZERO_LEN];
    // printf("the dist is %d %d\n", (char*)hi_buff - (char*)dist_buff,
    // (char*)wi_buff - (char*)hi_buff);
    __half* new_ctx;

    linfer::util::Dims dist_dim, hi_dim, wi_dim, ctx_dim, agts_dim;
    dist_dim.nbDims = 2;
    dist_dim.d[0] = nonzero_len;
    dist_dim.d[1] = 2;
    hi_dim.nbDims = 1;
    hi_dim.d[0] = nonzero_len;
    wi_dim.nbDims = 1;
    wi_dim.d[0] = nonzero_len;
    ctx_dim.nbDims = 2;
    ctx_dim.d[0] = ctx_r_size;
    ctx_dim.d[1] = ctx_c_size;
    agts_dim.nbDims = 2;
    agts_dim.d[0] = agts_r_size;
    agts_dim.d[1] = agts_c_size;

    std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> trt_inputs;
    trt_inputs["0"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                               linfer::util::DataType::kHALF,
                                                               dist_buff,
                                                               dist_dim);
    trt_inputs["1"] = make_input(inputDesc[get_idx(2)], inputs[get_idx(2)]);
    trt_inputs["2"] = make_input(inputDesc[get_idx(3)], inputs[get_idx(3)]);
    trt_inputs["3"] = make_input(inputDesc[get_idx(4)], inputs[get_idx(4)]);
    trt_inputs["4"] = make_input(inputDesc[get_idx(5)], inputs[get_idx(5)]);
    trt_inputs["5"] = make_input(inputDesc[get_idx(6)], inputs[get_idx(6)]);
    trt_inputs["6"] = make_input(inputDesc[get_idx(7)], inputs[get_idx(7)]);
    trt_inputs["7"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                               linfer::util::DataType::kINT32,
                                                               hi_buff,
                                                               hi_dim);
    trt_inputs["8"] = make_input(inputDesc[get_idx(8)], inputs[get_idx(8)]);
    trt_inputs["9"] = make_input(inputDesc[get_idx(9)], inputs[get_idx(9)]);
    trt_inputs["10"] = make_input(inputDesc[get_idx(10)], inputs[get_idx(10)]);

    trt_inputs["11"] = make_input(inputDesc[get_idx(11)], inputs[get_idx(11)]);
    trt_inputs["12"] = std::make_shared<linfer::util::TensorXD>(linfer::util::DeviceType::GPU,
                                                                linfer::util::DataType::kINT32,
                                                                wi_buff,
                                                                wi_dim);
    trt_inputs["13"] = make_input(inputDesc[get_idx(12)], inputs[get_idx(12)]);
    trt_inputs["14"] = make_input(inputDesc[get_idx(13)], inputs[get_idx(13)]);
    trt_inputs["15"] = make_input(inputDesc[get_idx(14)], inputs[get_idx(14)]);
    trt_inputs["16"] = make_input(inputDesc[get_idx(15)], inputs[get_idx(15)]);
    trt_inputs["17"] = make_input(inputDesc[get_idx(16)], inputs[get_idx(16)]);

    trt_eng_->set_stream(stream_lanegcn);
    trt_eng_->infer(trt_inputs);

    auto trt_outputs = trt_eng_->get_output_vector(linfer::util::DeviceType::GPU);
    auto trt_agts_output = trt_outputs[0];

    cudaMemcpyAsync(outputs[0],
                    trt_agts_output->get_gpu_buf(),
                    trt_agts_output->get_len_in_byte(),
                    cudaMemcpyDeviceToDevice,
                    stream_lanegcn);
    new_ctx = static_cast<__half*>(trt_outputs[2]->get_gpu_buf());

    // do self-define ops
    Index_add_op(stream_lanegcn,
                 agts_r_size,
                 agts_c_size,
                 ctx_r_size,
                 ctx_c_size,
                 agt_ctrs_r_size,
                 ctx_ctrs_r_size,
                 elementSizeInBytes,
                 nonzero_len,
                 (void*)new_ctx,
                 outputs[0],
                 workspace);
    return 0;
  }
}

size_t Att::getSerializationSize() const noexcept { return sizeof(use_fp16_); }

void Att::serialize(void* buffer) const noexcept { serialize_value(&buffer, use_fp16_); }

const char* Att::getPluginType() const noexcept { return plugin_name_.c_str(); }

const char* Att::getPluginVersion() const noexcept { return ATT_PLUGIN_VERSION; }

void Att::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* Att::clone() const noexcept {
  printf("clone plugin: %s\n", plugin_name_.c_str());
  auto att = new Att(plugin_name_, dist_th_, idx_map_table_, use_fp16_);
  att->setPluginNamespace(mPluginNamespace.c_str());
  return att;
}

void Att::setPluginNamespace(const char* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

const char* Att::getPluginNamespace() const noexcept { return mPluginNamespace.c_str(); }

int Att::getNbOutputs() const noexcept { return 1; }

nvinfer1::DimsExprs Att::getOutputDimensions(int32_t outputIndex,
                                             const nvinfer1::DimsExprs* inputs,
                                             int32_t nbInputs,
                                             nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs ret = inputs[get_idx(agts_idx_)];
  return ret;
}

nvinfer1::DataType Att::getOutputDataType(int index,
                                          const nvinfer1::DataType* inputTypes,
                                          int nbInputs) const noexcept {
  if (use_fp16_) return nvinfer1::DataType::kHALF;
  return nvinfer1::DataType::kFLOAT;
  // printf("the output format is %d\n", nvinfer1::DataType::kFLOAT);
  // return nvinfer1::DataType::kFLOAT;
}

void Att::attachToContext(cudnnContext* cudnnContext,
                          cublasContext* cublasContext,
                          nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void Att::detachFromContext() noexcept {}

nvinfer1::PluginFieldCollection AttPluginCreator::mFC{};
AttPluginCreator::AttPluginCreator(const std::string& name,
                                   float dist_th,
                                   const std::vector<int>& idx_map_table)
    : plugin_name_(name), dist_th_(dist_th), idx_map_table_(idx_map_table) {
  mPluginAttributes_.emplace_back(nvinfer1::PluginField("use_fp16"));
}
const char* AttPluginCreator::getPluginVersion() const noexcept { return ATT_PLUGIN_VERSION; }
const char* AttPluginCreator::getPluginName() const noexcept { return plugin_name_.c_str(); }
const nvinfer1::PluginFieldCollection* AttPluginCreator::getFieldNames() noexcept {
  return &AttPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* AttPluginCreator::createPlugin(
    const char* name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  bool use_fp16 = false;
  for (int i = 0; i < fc->nbFields; i++) {
    if (fc->fields[i].data == nullptr) {
      continue;
    }
    std::string field_name(fc->fields[i].name);

    if (field_name.compare("use_fp16") == 0) {
      int use_fp16_int = static_cast<const int*>(fc->fields[i].data)[0];
      use_fp16 = use_fp16_int != 0;
    }
  }
  printf("createPlugin: %s\n", name);
  return new Att(plugin_name_, dist_th_, idx_map_table_, use_fp16);
}

nvinfer1::IPluginV2Ext* AttPluginCreator::deserializePlugin(const char* name,
                                                            const void* serialData,
                                                            size_t serialLength) noexcept {
  printf("deserializePlugin: %s\n", name);
  bool use_fp16_ = false;
  // deserialize_value(&serialData, &serialLength, &use_fp16_); FIX ME
  if (use_fp16_) {
    printf("%s use fp16\n", name);
  } else {
    printf("%s use fp32\n", name);
  }
  auto obj = new Att(plugin_name_, dist_th_, idx_map_table_, use_fp16_);

  obj->setPluginNamespace(mNamespace.c_str());
  return obj;
}

void AttPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mNamespace = libNamespace;
}

const char* AttPluginCreator::getPluginNamespace() const noexcept { return mNamespace.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
