
#include <thrust/extrema.h>
#include <unistd.h>

#include <string>
#include <vector>

#include "cuda_fp16.h"
#include "linfer/ops/cuda/index_add/index_add.cuh"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

#define NONZERO_LEN 8192

#define CUBLAS_CHECK(condition)                                                           \
  do {                                                                                    \
    cublasStatus_t status = condition;                                                    \
    if (status != CUBLAS_STATUS_SUCCESS) {                                                \
      printf("%s %d CUBLAS FAIL %s\n", __FILE__, __LINE__, cublasGetErrorString(status)); \
    }                                                                                     \
  } while (0)

__global__ void index_add_(float* agts, const int* index, const float* ctx, size_t col_size) {
  register int offset = threadIdx.x;
  register int agts_row = index[blockIdx.x];
  register int hi_row = blockIdx.x;

  atomicAdd(agts + agts_row * col_size + offset, ctx[hi_row * col_size + offset]);
}

template <typename T>
__global__ void matrix_element_diff_and_sqrt(T* ret,
                                             const T* m1,
                                             const T* m2,
                                             float dist_th,
                                             int* len,
                                             int* hi,
                                             int* wi,
                                             size_t n,
                                             size_t part) {
  register int offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register const T* ptr_m1 = m1 + blockIdx.x * part;
  register const T* ptr_m2 = m2 + threadIdx.x * part;
  register T tmp = .0;

  for (; offset < end; offset++) {
    register int relative_offset = part - (end - offset);
    register T base_value = *(ptr_m1 + relative_offset) - *(ptr_m2 + relative_offset);
    // *(ret + blockIdx.x * n + offset) = *(ptr_m1 + relative_offset) - *(ptr_m2 +
    // relative_offset) ;
    tmp += base_value * base_value;
  }
  if (sqrtf(tmp) <= dist_th) {
    int32_t ret_offset = atomicAdd(len, part);
    if (ret_offset < NONZERO_LEN) {
      for (int i = 0; i < part; i++) {
        ret[ret_offset + i] = m1[blockIdx.x * part + i] - m2[threadIdx.x * part + i];
      }
      hi[ret_offset / 2] = blockIdx.x;
      wi[ret_offset / 2] = threadIdx.x;
    }
  }

  return;
}

template <typename T>
__global__ void matrix_element_diff_and_sqrt1(T* ret,
                                              const T* m1,
                                              const T* m2,
                                              float dist_th,
                                              int* len,
                                              int* hi,
                                              int* wi,
                                              size_t n,
                                              size_t part) {
  register int mat_1_part_size = 2;
  register int mat_2_part_size = part;
  register int offset = threadIdx.x * mat_2_part_size;
  size_t part_end = offset + mat_2_part_size;
  register size_t end = (n < part_end) ? n : part_end;
  register const T* ptr_m1 = m1 + blockIdx.x * mat_1_part_size;
  register const T* ptr_m2 = m2 + threadIdx.x * mat_2_part_size;

  for (int block_num = 0; offset < end; offset += 2) {
    register T tmp = .0;
    for (int i = 0; i < 2; i++) {
      register int mat1_relative_offset = i;
      // register int mat2_relative_offset = mat_2_part_size - (end - offset - i);
      register int mat2_relative_offset = mat_2_part_size - (end - offset) + i;
      register T base_value = *(ptr_m1 + mat1_relative_offset) - *(ptr_m2 + mat2_relative_offset);
      // *(ret + blockIdx.x * n + offset + i) = base_value ;
      tmp += base_value * base_value;
    }
    if (sqrtf(tmp) <= dist_th) {
      int32_t ret_offset = atomicAdd(len, mat_1_part_size);
      if (ret_offset < NONZERO_LEN) {
        for (int i = 0; i < mat_1_part_size; i++) {
          ret[ret_offset + i] =
              m1[blockIdx.x * mat_1_part_size + i] -
              m2[threadIdx.x * mat_2_part_size + mat_2_part_size - (end - offset) + i];
        }
        hi[ret_offset / 2] = blockIdx.x;
        wi[ret_offset / 2] = threadIdx.x * part / mat_1_part_size + block_num;
      }
    }
    block_num++;
  }
}

__global__ void cumemset(int* ret,
                         const int max_index,
                         const int len,
                         const int per_block,
                         const int per_thread) {
  register int idx = blockIdx.x * per_block + threadIdx.x * per_thread;
  for (int i = 0; i < per_thread; i++) {
    if (idx + i < len) {
      ret[idx + i] = max_index;
    }
  }
}

pluginStatus_t Nonzero_op(cudaStream_t stream,
                          int agts_r_size,
                          int agts_c_size,
                          int ctx_r_size,
                          int ctx_c_size,
                          int agt_ctrs_size,
                          int ctx_ctrs_size,
                          int sizeOfElementInBytes,
                          const void* agts,
                          const void* ctx,
                          const void* agt_ctrs,
                          const void* ctx_ctrs,
                          const float dist_th,
                          void* output,
                          int* ret_len,
                          void* workspace) {
  if (sizeOfElementInBytes == 4) {
    // printf("get into float\n");
    float* dist_buff = (float*)workspace;
    int* hi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2];
    int* wi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2 + NONZERO_LEN];
    int* cuda_ret_len = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2 + NONZERO_LEN * 2];
    cudaMemsetAsync(hi_buff, -1, sizeof(int) * NONZERO_LEN, stream);
    cudaMemsetAsync(wi_buff, -1, sizeof(int) * NONZERO_LEN, stream);
    cudaMemsetAsync(cuda_ret_len, 0, sizeof(int), stream);

    if (ctx_ctrs_size <= 1024) {
      const size_t thread_size = ctx_ctrs_size;
      size_t part = 2;
      matrix_element_diff_and_sqrt<<<agt_ctrs_size, thread_size, 0, stream>>>((float*)dist_buff,
                                                                              (float*)agt_ctrs,
                                                                              (float*)ctx_ctrs,
                                                                              dist_th,
                                                                              (int*)cuda_ret_len,
                                                                              (int*)hi_buff,
                                                                              (int*)wi_buff,
                                                                              ctx_ctrs_size * 2,
                                                                              part);
      CHECK_CUDA_STATUS("matrix_element_diff_and_sqrt");
    } else {
      // printf("the thread_size is not enough\n");
      const size_t thread_size = 1024;
      size_t part = (ctx_ctrs_size + thread_size - 1) / thread_size * 2;
      matrix_element_diff_and_sqrt1<<<agt_ctrs_size, thread_size, 0, stream>>>((float*)dist_buff,
                                                                               (float*)agt_ctrs,
                                                                               (float*)ctx_ctrs,
                                                                               dist_th,
                                                                               (int*)cuda_ret_len,
                                                                               (int*)hi_buff,
                                                                               (int*)wi_buff,
                                                                               ctx_ctrs_size * 2,
                                                                               part);
      CHECK_CUDA_STATUS("matrix_element_diff_and_sqrt1");
    }

    return STATUS_SUCCESS;
  } else {
    __half* dist_buff = (__half*)workspace;
    int* hi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2];
    int* wi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2 + NONZERO_LEN];
    int* cuda_ret_len = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2 + 2 * NONZERO_LEN];
    cudaMemsetAsync(cuda_ret_len, 0, sizeof(int), stream);

    if (ctx_ctrs_size <= 1024) {
      const size_t thread_size = ctx_ctrs_size;
      size_t part = 2;
      matrix_element_diff_and_sqrt<<<agt_ctrs_size, thread_size, 0, stream>>>((__half*)dist_buff,
                                                                              (__half*)agt_ctrs,
                                                                              (__half*)ctx_ctrs,
                                                                              dist_th,
                                                                              (int*)cuda_ret_len,
                                                                              (int*)hi_buff,
                                                                              (int*)wi_buff,
                                                                              ctx_ctrs_size * 2,
                                                                              part);
      CHECK_CUDA_STATUS("matrix_element_diff_and_sqrt");
    } else {
      const size_t thread_size = 1024;
      size_t part = (ctx_ctrs_size + thread_size - 1) / thread_size * 2;
      matrix_element_diff_and_sqrt1<<<agt_ctrs_size, thread_size, 0, stream>>>((__half*)dist_buff,
                                                                               (__half*)agt_ctrs,
                                                                               (__half*)ctx_ctrs,
                                                                               dist_th,
                                                                               (int*)cuda_ret_len,
                                                                               (int*)hi_buff,
                                                                               (int*)wi_buff,
                                                                               ctx_ctrs_size * 2,
                                                                               part);
      CHECK_CUDA_STATUS("matrix_element_diff_and_sqrt1");
    }
    return STATUS_SUCCESS;
  }
}

pluginStatus_t Index_add_op(cudaStream_t stream,
                            int agts_r_size,
                            int agts_c_size,
                            int ctx_r_size,
                            int ctx_c_size,
                            int agt_ctrs_size,
                            int ctx_ctrs_size,
                            int sizeOfElementInBytes,
                            int ret_len,
                            void* new_ctx,
                            void* output,
                            void* workspace) {
  // printf("the ret_len is %d the agts_c_size is %d\n", ret_len, agts_c_size);
  if (sizeOfElementInBytes == 4) {
    float* dist_buff = (float*)workspace;
    int* hi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2];

    index_add_wrapper((float*)output,
                      (const int*)hi_buff,
                      (const float*)new_ctx,
                      agts_r_size,
                      ret_len,
                      agts_c_size,
                      stream);

    return STATUS_SUCCESS;
  } else {
    __half* dist_buff = (__half*)workspace;
    int* hi_buff = (int*)&dist_buff[agt_ctrs_size * ctx_ctrs_size * 2];

    index_add_wrapper((__half*)output,
                      (const int*)hi_buff,
                      (const __half*)new_ctx,
                      agts_r_size,
                      ret_len,
                      agts_c_size,
                      stream);

    return STATUS_SUCCESS;
  }
}