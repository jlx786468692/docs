#pragma once

#include <NvInfer.h>
#include <cublas_v2.h>

#include <mutex>
#include <string>
#include <vector>

#include "linfer/util/trt/model.h"

namespace linfer {
namespace ops {
namespace trt {

class Att : public nvinfer1::IPluginV2DynamicExt {
 public:
  Att(const std::string& name, float dist_th, const std::vector<int>& idx_map_table, bool use_fp16);
  Att(const std::string name, const void* data, size_t length);
  ~Att() override = default;

  bool supportsFormatCombination(int32_t pos,
                                 const nvinfer1::PluginTensorDesc* inOut,
                                 int32_t nbInputs,
                                 int32_t nbOutputs) noexcept override;

  void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                       int32_t nbInputs,
                       const nvinfer1::DynamicPluginTensorDesc* out,
                       int32_t nbOutputs) noexcept override;

  virtual size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                  int32_t nbInputs,
                                  const nvinfer1::PluginTensorDesc* outputs,
                                  int32_t nbOutputs) const noexcept override;

  int initialize() noexcept override;

  void terminate() noexcept override;

  int32_t enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                  const nvinfer1::PluginTensorDesc* outputDesc,
                  const void* const* inputs,
                  void* const* outputs,
                  void* workspace,
                  cudaStream_t stream) noexcept override;

  size_t getSerializationSize() const noexcept override;

  void serialize(void* buffer) const noexcept override;

  const char* getPluginType() const noexcept override;

  const char* getPluginVersion() const noexcept override;

  void destroy() noexcept override;

  nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;

  void setPluginNamespace(const char* pluginNamespace) noexcept override;

  const char* getPluginNamespace() const noexcept override;

  int getNbOutputs() const noexcept override;

  nvinfer1::DimsExprs getOutputDimensions(int32_t outputIndex,
                                          const nvinfer1::DimsExprs* inputs,
                                          int32_t nbInputs,
                                          nvinfer1::IExprBuilder& exprBuilder) noexcept override;

  nvinfer1::DataType getOutputDataType(int index,
                                       const nvinfer1::DataType* inputTypes,
                                       int nbInputs) const noexcept override;

  void attachToContext(cudnnContext* cudnnContext,
                       cublasContext* cublasContext,
                       nvinfer1::IGpuAllocator* gpuAllocator) noexcept override;

  void detachFromContext() noexcept override;

  static inline void set_trt_eng(std::shared_ptr<linfer::util::TrtModelInferEngine> eng) {
    trt_eng_ = eng;
  }

  static inline std::shared_ptr<linfer::util::TrtModelInferEngine> get_trt_eng(void) {
    return trt_eng_;
  }

 private:
  inline int get_idx(int virtual_idx) const;

  static std::mutex trt_eng_mutex_;
  static std::shared_ptr<linfer::util::TrtModelInferEngine> trt_eng_;
  static cudaStream_t stream_att_;
  static int idx_;
  static const int agt_ctrs_idx_ = 0;
  static const int ctx_ctrs_idx_ = 1;
  static const int agts_idx_ = 7;
  static const int ctx_idx_ = 11;
  int iter = 0;
  int use_fp16_ = false;
  float record_time_1 = 0.0f;
  float record_time_2 = 0.0f;
  float record_time_3 = 0.0f;
  std::string mPluginNamespace;
  std::string plugin_name_;
  float dist_th_;
  std::vector<int> idx_map_table_;
};

class AttPluginCreator : public nvinfer1::IPluginCreator {
 private:
  static nvinfer1::PluginFieldCollection mFC;
  std::string plugin_name_;
  float dist_th_;
  std::vector<int> idx_map_table_;
  std::vector<nvinfer1::PluginField> mPluginAttributes_;

 protected:
  std::string mNamespace;

 public:
  AttPluginCreator(const std::string& name, float dist_th, const std::vector<int>& idx_map_table);
  ~AttPluginCreator() override = default;
  const char* getPluginVersion() const noexcept override;
  const char* getPluginName() const noexcept override;
  const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;
  nvinfer1::IPluginV2Ext* createPlugin(const char* name,
                                       const nvinfer1::PluginFieldCollection* fc) noexcept;
  nvinfer1::IPluginV2Ext* deserializePlugin(const char* name,
                                            const void* serialData,
                                            size_t serialLength) noexcept;
  void setPluginNamespace(const char* libNamespace) noexcept;
  const char* getPluginNamespace() const noexcept;
};

class Att1PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att1PluginCreator() : AttPluginCreator("Att1", 7.0, {}) {}
};

class Att2PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att2PluginCreator() : AttPluginCreator("Att2", 7.0, {}) {}
};

class Att3PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att3PluginCreator() : AttPluginCreator("Att3", 6.0, {}) {}
};

class Att4PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att4PluginCreator() : AttPluginCreator("Att4", 6.0, {}) {}
};

class Att5PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att5PluginCreator()
      : AttPluginCreator("Att5", 100.0, {0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 6, 10, 11, 12, 13, 14}) {}
};

class Att6PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att6PluginCreator()
      : AttPluginCreator("Att6", 100.0, {0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 6, 10, 11, 12, 13, 14}) {}
};

class Att7PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att7PluginCreator() : AttPluginCreator("Att7", 20.0, {}) {}
};

class Att8PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att8PluginCreator() : AttPluginCreator("Att8", 20.0, {}) {}
};

class Att9PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att9PluginCreator() : AttPluginCreator("Att9", 20.0, {}) {}
};

class Att10PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att10PluginCreator() : AttPluginCreator("Att10", 20.0, {}) {}
};

class Att11PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att11PluginCreator() : AttPluginCreator("Att11", 20.0, {}) {}
};

class Att12PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att12PluginCreator() : AttPluginCreator("Att12", 20.0, {}) {}
};

class Att13PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att13PluginCreator()
      : AttPluginCreator("Att13", 100.0, {0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 6, 10, 11, 12, 13, 14}) {
  }
};

class Att14PluginCreator : public linfer::ops::trt::AttPluginCreator {
 public:
  Att14PluginCreator()
      : AttPluginCreator("Att14", 100.0, {0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 6, 10, 11, 12, 13, 14}) {
  }
};

REGISTER_TENSORRT_PLUGIN(Att1PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att2PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att3PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att4PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att5PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att6PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att7PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att8PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att9PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att10PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att11PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att12PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att13PluginCreator);
REGISTER_TENSORRT_PLUGIN(Att14PluginCreator);

}  // namespace trt
}  // namespace ops
}  // namespace linfer
