#include <cuda_fp16.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

// #include "cuda_helper.h"
// #include "helper.h"
#include <cstdio>

#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/common/common_types.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "multiScaleDeformableAttnMeanKernel.h"

__global__ void ms_deformable_im2col_mean_gpu_kernel(const float* data_value,
                                                     const int32_t* data_spatial_shapes,
                                                     const float* data_sampling_loc,
                                                     const float* data_attn_weight,
                                                     const int batch_size,
                                                     const int spatial_size,
                                                     const int num_heads,
                                                     const int channels,
                                                     const int num_levels,
                                                     const int num_query,
                                                     const int num_point,
                                                     float* data_col) {
  const int c_col = threadIdx.x;
  const int m_col = threadIdx.y;
  const int query_col = blockIdx.x;
  float* data_col_ptr = data_col + (query_col * num_heads + m_col) * channels + c_col;

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(float) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储双线性插值weight(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(float)
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int level_point = num_levels * num_point;
  int batch_level_point = batch_size * level_point;
  int head_batch_level_point = num_heads * batch_level_point;
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);
  float4* interpolate_weight = reinterpret_cast<float4*>(interpolate_pos + head_batch_level_point);
  int32_t2* spatial_shapes_smem =
      reinterpret_cast<int32_t2*>(interpolate_weight + head_batch_level_point);
  float* attn_weight_smem = reinterpret_cast<float*>(spatial_shapes_smem + num_levels);

  // 进行双线性插值并将结果放入共享内存，注意，此处batch由第0维修改至第2维
  if (threadIdx.y < min(DIVUP(head_batch_level_point, blockDim.x), blockDim.y)) {
    for (int index = threadIdx.y * blockDim.x + threadIdx.x; index < head_batch_level_point;
         index += blockDim.y * blockDim.x) {
      int head_index = index / batch_level_point;
      int temp_index = index - head_index * batch_level_point;

      int batch_index = temp_index / level_point;
      temp_index -= batch_index * level_point;

      int level_index = temp_index / num_point;
      int point_index = temp_index - level_index * num_point;

      int data_weight_ptr =
          (((query_col * num_heads + head_index) * batch_size + batch_index) * num_levels +
           level_index) *
              num_point +
          point_index;
      const int32_t2 spatial = reinterpret_cast<const int32_t2*>(data_spatial_shapes)[level_index];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;
      int data_sampling_loc_ptr = data_weight_ptr << 1;

      if (batch_index == 0 && head_index == 0 && point_index == 0) {
        spatial_shapes_smem[level_index] = spatial;
      }

      const float loc_w = data_sampling_loc[data_sampling_loc_ptr];
      const float w_im = loc_w * spatial_w - 0.5f;
      const float loc_h = data_sampling_loc[data_sampling_loc_ptr + 1];
      const float h_im = loc_h * spatial_h - 0.5f;

      attn_weight_smem[index] = data_attn_weight[data_weight_ptr];

      const int h_low = floorf(h_im);
      const int w_low = floorf(w_im);
      const int h_high = h_low + 1;
      const int w_high = w_low + 1;

      const float lh = h_im - h_low;
      const float lw = w_im - w_low;
      const float hh = 1 - lh, hw = 1 - lw;

      const int w_stride = num_heads * channels;
      const int h_stride = spatial_w * w_stride;
      const int h_low_ptr_offset = h_low * h_stride;
      const int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      const int w_low_ptr_offset = w_low * w_stride;
      const int w_high_ptr_offset = w_low_ptr_offset + w_stride;

      int4 pos = {h_low_ptr_offset + w_low_ptr_offset,
                  h_low_ptr_offset + w_high_ptr_offset,
                  h_high_ptr_offset + w_low_ptr_offset,
                  h_high_ptr_offset + w_high_ptr_offset};

      interpolate_pos[index] = pos;

      float4 weight4 = {0.0f, 0.0f, 0.0f, 0.0f};

      if (h_low >= 0.0f && h_low < spatial_h) {
        if (w_low >= 0.0f && w_low < spatial_w) {
          weight4.x = hh * hw;
        }

        if (w_high >= 0.0f && w_high < spatial_w) {
          weight4.y = hh * lw;
        }
      }

      if (h_high >= 0.0f && h_high < spatial_h) {
        if (w_low >= 0.0f && w_low < spatial_w) {
          weight4.z = lh * hw;
        }

        if (w_high >= 0.0f && w_high < spatial_w) {
          weight4.w = lh * lw;
        }
      }

      interpolate_weight[index] = weight4;
    }
  }
  __syncthreads();

  const int channel_stride = channels;
  const int qid_stride = num_heads * channel_stride;
  const float* data_value_ptr = data_value + m_col * channel_stride + c_col;
  float ret = 0.0f;
  for (int batch_idx = 0; batch_idx < batch_size; batch_idx++) {
    float col = 0.0f;
    for (int l_col = 0; l_col < num_levels; ++l_col) {
      const int32_t2 spatial = spatial_shapes_smem[l_col];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;
      int index_base = m_col * batch_level_point + batch_idx * level_point + l_col * num_point;
      for (int p_col = 0; p_col < num_point; ++p_col) {
        int index = index_base + p_col;
        const float weight = attn_weight_smem[index];

        int4 pos = interpolate_pos[index];
        float4 interpolate_weights = interpolate_weight[index];

        float v1 = 0.0f;
        if (interpolate_weights.x > 0.0f) {
          v1 = data_value_ptr[pos.x];
        }

        float v2 = 0.0f;
        if (interpolate_weights.y > 0.0f) {
          v2 = data_value_ptr[pos.y];
        }

        float v3 = 0.0f;
        if (interpolate_weights.z > 0.0f) {
          v3 = data_value_ptr[pos.z];
        }

        float v4 = 0.0f;
        if (interpolate_weights.w > 0.0f) {
          v4 = data_value_ptr[pos.w];
        }
        float val = (interpolate_weights.x * v1 + interpolate_weights.y * v2 +
                     interpolate_weights.z * v3 + interpolate_weights.w * v4);
        col += val * weight;
      }
      data_value_ptr += qid_stride * spatial_h * spatial_w;
    }
    ret += col * 1e-4f;
  }

  //// FIXME 对某些任务可能会产生溢出问题，对onemodel任务1e-4f已够用。
  *data_col_ptr = ret / batch_size * 1e4f;
}

// 每个thread处理1个channels
__global__ void ms_deformable_im2col_mean_gpu_kernel(const __half* data_value,
                                                     const int32_t* data_spatial_shapes,
                                                     const __half* data_sampling_loc,
                                                     const __half* data_attn_weight,
                                                     const int batch_size,
                                                     const int spatial_size,
                                                     const int num_heads,
                                                     const int channels,
                                                     const int num_levels,
                                                     const int num_query,
                                                     const int num_point,
                                                     __half* data_col) {
  const int c_col = threadIdx.x;
  const int m_col = threadIdx.y;
  const int query_col = blockIdx.x;
  __half* data_col_ptr = data_col + (query_col * num_heads + m_col) * channels + c_col;

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储双线性插值weight(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(__half)
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int level_point = num_levels * num_point;
  int batch_level_point = batch_size * level_point;
  int head_batch_level_point = num_heads * batch_level_point;
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);
  half4* interpolate_weight = reinterpret_cast<half4*>(interpolate_pos + head_batch_level_point);
  int32_t2* spatial_shapes_smem =
      reinterpret_cast<int32_t2*>(interpolate_weight + head_batch_level_point);
  __half* attn_weight_smem = reinterpret_cast<__half*>(spatial_shapes_smem + num_levels);

  // 进行条件判断并读取data_attn_weight、data_sampling_loc放入共享内存
  if (threadIdx.y < min(DIVUP(head_batch_level_point, blockDim.x), blockDim.y)) {
    for (int index = threadIdx.y * blockDim.x + threadIdx.x; index < head_batch_level_point;
         index += blockDim.y * blockDim.x) {
      int head_index = index / batch_level_point;
      int temp_index = index - head_index * batch_level_point;

      int batch_index = temp_index / level_point;
      temp_index -= batch_index * level_point;

      int level_index = temp_index / num_point;
      int point_index = temp_index - level_index * num_point;

      int data_weight_ptr =
          (((query_col * num_heads + head_index) * batch_size + batch_index) * num_levels +
           level_index) *
              num_point +
          point_index;
      int data_sampling_loc_ptr = data_weight_ptr << 1;
      const int32_t2 spatial = reinterpret_cast<const int32_t2*>(data_spatial_shapes)[level_index];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;

      if (batch_index == 0 && head_index == 0 && point_index == 0) {
        spatial_shapes_smem[level_index] = spatial;
      }

      const __half loc_w = data_sampling_loc[data_sampling_loc_ptr];
      const __half w_im =
          __hsub(__hmul(loc_w, __float2half(static_cast<float>(spatial_w))), __float2half(0.5f));
      const __half loc_h = data_sampling_loc[data_sampling_loc_ptr + 1];
      const __half h_im =
          __hsub(__hmul(loc_h, __float2half(static_cast<float>(spatial_h))), __float2half(0.5f));

      attn_weight_smem[index] = data_attn_weight[data_weight_ptr];

      const __half h_low = hfloor(h_im);
      const __half w_low = hfloor(w_im);
      const __half h_high = __hadd(h_low, __float2half(1.f));
      const __half w_high = __hadd(w_low, __float2half(1.f));

      const __half lh = __hsub(h_im, h_low);
      const __half lw = __hsub(w_im, w_low);
      const __half hh = __hsub(__float2half(1.f), lh);
      const __half hw = __hsub(__float2half(1.f), lw);

      int w_stride = num_heads * channels;
      int h_stride = spatial_w * w_stride;
      int h_low_ptr_offset = static_cast<int>(h_low) * h_stride;
      int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      int w_low_ptr_offset = static_cast<int>(w_low) * w_stride;
      int w_high_ptr_offset = w_low_ptr_offset + w_stride;

      int4 pos = {h_low_ptr_offset + w_low_ptr_offset,
                  h_low_ptr_offset + w_high_ptr_offset,
                  h_high_ptr_offset + w_low_ptr_offset,
                  h_high_ptr_offset + w_high_ptr_offset};

      interpolate_pos[index] = pos;

      half4 weight4;
      weight4.left = __float2half2_rn(0.0f);
      weight4.right = __float2half2_rn(0.0f);

      if (__hge(h_low, __float2half(0.f)) &&
          __hle(h_low, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.x = __hmul(hh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.y = __hmul(hh, lw);
        }
      }

      if (__hge(h_high, __float2half(0.f)) &&
          __hle(h_high, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.x = __hmul(lh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.y = __hmul(lh, lw);
        }
      }

      interpolate_weight[index] = weight4;
    }
  }
  __syncthreads();

  const int channel_stride = channels;
  const int qid_stride = num_heads * channel_stride;
  const __half* data_value_ptr = data_value + m_col * channel_stride + c_col;
  float ret = 0.0f;
  for (int batch_idx = 0; batch_idx < batch_size; batch_idx++) {
    __half col = __float2half(0.0f);
    for (int l_col = 0; l_col < num_levels; ++l_col) {
      const int32_t2 spatial = spatial_shapes_smem[l_col];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;
      int index_base = m_col * batch_level_point + batch_idx * level_point + l_col * num_point;
      for (int p_col = 0; p_col < num_point; ++p_col) {
        int index = index_base + p_col;
        const __half weight = attn_weight_smem[index];

        int4 pos = interpolate_pos[index];
        half4 interpolate_weights = interpolate_weight[index];

        __half v1 = __float2half(0.0f);
        if (__hgt(interpolate_weights.left.x, __float2half(0.0f))) {
          v1 = data_value_ptr[pos.x];
        }

        __half v2 = __float2half(0.0f);
        if (__hgt(interpolate_weights.left.y, __float2half(0.0f))) {
          v2 = data_value_ptr[pos.y];
        }

        __half v3 = __float2half(0.0f);
        if (__hgt(interpolate_weights.right.x, __float2half(0.0f))) {
          v3 = data_value_ptr[pos.z];
        }

        __half v4 = __float2half(0.0f);
        if (__hgt(interpolate_weights.right.y, __float2half(0.0f))) {
          v4 = data_value_ptr[pos.w];
        }

        __half w1 = interpolate_weights.left.x, w2 = interpolate_weights.left.y,
               w3 = interpolate_weights.right.x, w4 = interpolate_weights.right.y;

        __half val =
            __hadd(__hadd(__hmul(w1, v1), __hmul(w2, v2)), __hadd(__hmul(w3, v3), __hmul(w4, v4)));

        col = __hfma(weight, val, col);
      }
      data_value_ptr += qid_stride * spatial_h * spatial_w;
    }

    ret += __half2float(col) * 1e-4f;
  }

  // FIXME
  // 对某些任务可能会产生溢出问题，对onemodel任务1e4f已够用。此处求均值需使用float，否则会导致精度下降约0.2%
  *data_col_ptr = __float2half((ret / batch_size) * 1e4f);
}

// 每个thread处理2个channels
__global__ void ms_deformable_im2col_mean_gpu_half2_kernel(const __half* data_value,
                                                           const int32_t* data_spatial_shapes,
                                                           const __half* data_sampling_loc,
                                                           const __half* data_attn_weight,
                                                           const int batch_size,
                                                           const int spatial_size,
                                                           const int num_heads,
                                                           const int channels,
                                                           const int num_levels,
                                                           const int num_query,
                                                           const int num_point,
                                                           __half* data_col) {
  const int c_col = threadIdx.x;
  const int m_col = threadIdx.y;
  const int query_col = blockIdx.x;
  __half2* data_col_ptr =
      reinterpret_cast<__half2*>(data_col + (query_col * num_heads + m_col) * channels + c_col * 2);

  // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
  // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads * num_levels
  // * num_point * 8 + num_levels * 2 - 1存储双线性插值weight(int32_t) num_heads * num_levels *
  // num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9 + num_levels * 2
  // - 1 存储data_attn_weight(__half)
  extern __shared__ __align__(16) unsigned char shared_mem[];
  int level_point = num_levels * num_point;
  int batch_level_point = batch_size * level_point;
  int head_batch_level_point = num_heads * batch_level_point;
  int4* interpolate_pos = reinterpret_cast<int4*>(shared_mem);
  half4* interpolate_weight = reinterpret_cast<half4*>(interpolate_pos + head_batch_level_point);
  int32_t2* spatial_shapes_smem =
      reinterpret_cast<int32_t2*>(interpolate_weight + head_batch_level_point);
  __half* attn_weight_smem = reinterpret_cast<__half*>(spatial_shapes_smem + num_levels);

  // 进行条件判断并读取data_attn_weight、data_sampling_loc放入共享内存
  if (threadIdx.y < min(DIVUP(head_batch_level_point, blockDim.x), blockDim.y)) {
    for (int index = threadIdx.y * blockDim.x + threadIdx.x; index < head_batch_level_point;
         index += blockDim.y * blockDim.x) {
      int head_index = index / batch_level_point;
      int temp_index = index - head_index * batch_level_point;

      int batch_index = temp_index / level_point;
      temp_index -= batch_index * level_point;

      int level_index = temp_index / num_point;
      int point_index = temp_index - level_index * num_point;

      int data_weight_ptr =
          (((query_col * num_heads + head_index) * batch_size + batch_index) * num_levels +
           level_index) *
              num_point +
          point_index;
      int data_sampling_loc_ptr = data_weight_ptr << 1;
      const int32_t2 spatial = reinterpret_cast<const int32_t2*>(data_spatial_shapes)[level_index];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;

      if (batch_index == 0 && head_index == 0 && point_index == 0) {
        spatial_shapes_smem[level_index] = spatial;
      }

      const __half loc_w = data_sampling_loc[data_sampling_loc_ptr];
      const __half w_im =
          __hsub(__hmul(loc_w, __float2half(static_cast<float>(spatial_w))), __float2half(0.5f));
      const __half loc_h = data_sampling_loc[data_sampling_loc_ptr + 1];
      const __half h_im =
          __hsub(__hmul(loc_h, __float2half(static_cast<float>(spatial_h))), __float2half(0.5f));

      attn_weight_smem[index] = data_attn_weight[data_weight_ptr];

      const __half h_low = hfloor(h_im);
      const __half w_low = hfloor(w_im);
      const __half h_high = __hadd(h_low, __float2half(1.f));
      const __half w_high = __hadd(w_low, __float2half(1.f));

      const __half lh = __hsub(h_im, h_low);
      const __half lw = __hsub(w_im, w_low);
      const __half hh = __hsub(__float2half(1.f), lh);
      const __half hw = __hsub(__float2half(1.f), lw);

      int w_stride = num_heads * channels / 2;
      int h_stride = spatial_w * w_stride;
      int h_low_ptr_offset = static_cast<int>(h_low) * h_stride;
      int h_high_ptr_offset = h_low_ptr_offset + h_stride;
      int w_low_ptr_offset = static_cast<int>(w_low) * w_stride;
      int w_high_ptr_offset = w_low_ptr_offset + w_stride;

      int4 pos = {h_low_ptr_offset + w_low_ptr_offset,
                  h_low_ptr_offset + w_high_ptr_offset,
                  h_high_ptr_offset + w_low_ptr_offset,
                  h_high_ptr_offset + w_high_ptr_offset};

      interpolate_pos[index] = pos;

      half4 weight4;
      weight4.left = __float2half2_rn(0.0f);
      weight4.right = __float2half2_rn(0.0f);

      if (__hge(h_low, __float2half(0.f)) &&
          __hle(h_low, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.x = __hmul(hh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.left.y = __hmul(hh, lw);
        }
      }

      if (__hge(h_high, __float2half(0.f)) &&
          __hle(h_high, __float2half(static_cast<float>(spatial_h - 1)))) {
        if (__hge(w_low, __float2half(0.f)) &&
            __hle(w_low, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.x = __hmul(lh, hw);
        }

        if (__hge(w_high, __float2half(0.f)) &&
            __hle(w_high, __float2half(static_cast<float>(spatial_w - 1)))) {
          weight4.right.y = __hmul(lh, lw);
        }
      }

      interpolate_weight[index] = weight4;
    }
  }
  __syncthreads();

  const int channel_stride = channels / 2;
  const int qid_stride = num_heads * channel_stride;
  const __half2* data_value_ptr =
      reinterpret_cast<const __half2*>(data_value) + m_col * channel_stride + c_col;
  float ret1 = 0.0f, ret2 = 0.0f;
  for (int batch_idx = 0; batch_idx < batch_size; batch_idx++) {
    __half2 col = __float2half2_rn(0.0f);
    for (int l_col = 0; l_col < num_levels; ++l_col) {
      const int32_t2 spatial = spatial_shapes_smem[l_col];
      const int32_t spatial_h = spatial.x;
      const int32_t spatial_w = spatial.y;
      int index_base = m_col * batch_level_point + batch_idx * level_point + l_col * num_point;
      for (int p_col = 0; p_col < num_point; ++p_col) {
        int index = index_base + p_col;
        const __half weight = attn_weight_smem[index];

        int4 pos = interpolate_pos[index];
        half4 interpolate_weights = interpolate_weight[index];

        __half2 v1 = __float2half2_rn(0.0f);
        if (__hgt(interpolate_weights.left.x, __float2half(0.0f))) {
          v1 = data_value_ptr[pos.x];
        }

        __half2 v2 = __float2half2_rn(0.0f);
        if (__hgt(interpolate_weights.left.y, __float2half(0.0f))) {
          v2 = data_value_ptr[pos.y];
        }

        __half2 w1 = __half2half2(interpolate_weights.left.x),
                w2 = __half2half2(interpolate_weights.left.y),
                w3 = __half2half2(interpolate_weights.right.x),
                w4 = __half2half2(interpolate_weights.right.y);

        __half2 v3 = __float2half2_rn(0.0f);
        if (__hgt(interpolate_weights.right.x, __float2half(0.0f))) {
          v3 = data_value_ptr[pos.z];
        }

        __half2 v4 = __float2half2_rn(0.0f);
        if (__hgt(interpolate_weights.right.y, __float2half(0.0f))) {
          v4 = data_value_ptr[pos.w];
        }

        __half2 val = __hadd2(__hadd2(__hmul2(w1, v1), __hmul2(w2, v2)),
                              __hadd2(__hmul2(w3, v3), __hmul2(w4, v4)));

        col = __hfma2(__half2half2(weight), val, col);
      }
      data_value_ptr += qid_stride * spatial_h * spatial_w;
    }
    ret1 += __half2float(col.x) * 1e-4f;
    ret2 += __half2float(col.y) * 1e-4f;
  }

  // FIXME
  // 对某些任务可能会产生溢出问题，对onemodel任务1e4f已够用。此处求均值需使用float，否则会导致精度下降约0.2%
  ret1 = (ret1 / batch_size) * 1e4f;
  ret2 = (ret2 / batch_size) * 1e4f;
  *data_col_ptr = __halves2half2(__float2half(ret1), __float2half(ret2));
}

void ms_deformable_im2col_mean_cuda(const float* data_value,
                                    const int32_t* data_spatial_shapes,
                                    const float* data_sampling_loc,
                                    const float* data_attn_weight,
                                    const int batch_size,
                                    const int spatial_size,
                                    const int num_heads,
                                    const int channels,
                                    const int num_levels,
                                    const int num_query,
                                    const int num_point,
                                    float* data_col,
                                    cudaStream_t stream) {
  dim3 block_size(channels, num_heads);
  dim3 grid_size(num_query, 1);

  // 0 ~ batch_size * num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
  // batch_size * num_heads * num_levels * num_point * 4 ~ batch_size * num_heads * num_levels *
  // num_point * 8 - 1存储双线性插值weight(float) batch_size * num_heads * num_levels * num_point
  // * 8 ~ batch_size * num_heads * num_levels * num_point * 8 + num_levels * 2 - 1存储level
  // shape(int32_t) batch_size * num_heads * num_levels * num_point * 8 + num_levels * 2 - 1 +
  // batch_size * num_heads * num_levels * num_point * 9 + num_levels * 2 - 1
  // 存储data_attn_weight(float)
  unsigned batch_head_level_kernel = batch_size * num_heads * num_levels * num_point;
  unsigned shared_mem_size = batch_head_level_kernel * 4 * (sizeof(float) + sizeof(int)) +
                             num_levels * 2 * sizeof(int32_t) +
                             batch_head_level_kernel * sizeof(float);

  ms_deformable_im2col_mean_gpu_kernel<<<grid_size, block_size, shared_mem_size, stream>>>(
      data_value,
      data_spatial_shapes,
      data_sampling_loc,
      data_attn_weight,
      batch_size,
      spatial_size,
      num_heads,
      channels,
      num_levels,
      num_query,
      num_point,
      data_col);

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    printf("error in ms_deformable_im2col_cuda: %s\n", cudaGetErrorString(err));
  }
}

void ms_deformable_im2col_mean_cuda(const __half* data_value,
                                    const int32_t* data_spatial_shapes,
                                    const __half* data_sampling_loc,
                                    const __half* data_attn_weight,
                                    const int batch_size,
                                    const int spatial_size,
                                    const int num_heads,
                                    const int channels,
                                    const int num_levels,
                                    const int num_query,
                                    const int num_point,
                                    __half* data_col,
                                    cudaStream_t stream) {
  // 若channel_num为奇数，为避免越界不使用half2
  if (channels % 2 == 0) {
    dim3 block_size(channels / 2, num_heads);
    dim3 grid_size(num_query, 1);

    // 0 ~ batch_size * num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
    // batch_size * num_heads * num_levels * num_point * 4 ~ batch_size * num_heads * num_levels
    // * num_point * 8 - 1存储双线性插值weight(__half) batch_size * num_heads * num_levels *
    // num_point * 8 ~ batch_size * num_heads * num_levels * num_point * 8 + num_levels * 2 -
    // 1存储level shape(int32_t) batch_size * num_heads * num_levels * num_point * 8 +
    // num_levels * 2 - 1 + batch_size * num_heads * num_levels * num_point * 9 + num_levels * 2
    // - 1 存储data_attn_weight(__half)
    unsigned batch_head_level_kernel = batch_size * num_heads * num_levels * num_point;
    unsigned shared_mem_size = batch_head_level_kernel * 4 * (sizeof(__half) + sizeof(int)) +
                               num_levels * 2 * sizeof(int32_t) +
                               batch_head_level_kernel * sizeof(__half);

    ms_deformable_im2col_mean_gpu_half2_kernel<<<grid_size, block_size, shared_mem_size, stream>>>(
        data_value,
        data_spatial_shapes,
        data_sampling_loc,
        data_attn_weight,
        batch_size,
        spatial_size,
        num_heads,
        channels,
        num_levels,
        num_query,
        num_point,
        data_col);
  } else {
    dim3 block_size(channels, num_heads);
    dim3 grid_size(num_query, 1);

    // 0 ~ num_heads * num_levels * num_point * 4 - 1存储双线性插值pos(int)
    // num_heads * num_levels * num_point * 4 ~ num_heads * num_levels * num_point * 8 -
    // 1存储双线性插值weight(__half) num_heads * num_levels * num_point * 8 ~ num_heads *
    // num_levels * num_point * 8 + num_levels * 2 - 1存储level shape(int32_t) num_heads *
    // num_levels * num_point * 8 + num_levels * 2 - 1 + num_heads * num_levels * num_point * 9
    // + num_levels * 2 - 1 存储data_attn_weight(__half)
    unsigned batch_head_level_kernel = batch_size * num_heads * num_levels * num_point;
    unsigned shared_mem_size = batch_head_level_kernel * 4 * (sizeof(__half) + sizeof(int)) +
                               num_levels * 2 * sizeof(int32_t) +
                               batch_head_level_kernel * sizeof(__half);

    ms_deformable_im2col_mean_gpu_kernel<<<grid_size, block_size, shared_mem_size, stream>>>(
        data_value,
        data_spatial_shapes,
        data_sampling_loc,
        data_attn_weight,
        batch_size,
        spatial_size,
        num_heads,
        channels,
        num_levels,
        num_query,
        num_point,
        data_col);
  }

  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    printf("error in ms_deformable_im2col_cuda: %s\n", cudaGetErrorString(err));
  }
}
