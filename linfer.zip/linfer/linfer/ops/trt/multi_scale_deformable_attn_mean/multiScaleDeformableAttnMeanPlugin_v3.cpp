#include "multiScaleDeformableAttnMeanPlugin_v3.h"

#include <cuda_fp16.h>

#include <iostream>
#include <stdexcept>

#include "linfer/ops/trt/common/trt_serialize.hpp"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"
#include "linfer/util/internal/trt/plugin.h"
#include "multiScaleDeformableAttnMeanKernel.h"

using linfer::ops::trt::MultiScaleDeformableAttnMeanPluginV3Creator;
REGISTER_TENSORRT_PLUGIN(MultiScaleDeformableAttnMeanPluginV3Creator);

namespace linfer {
namespace ops {
namespace trt {

constexpr char const* MSDA_MEAN_PLUGINV3_VERSION{"1"};
constexpr char const* MSDA_MEAN_PLUGINV3_NAME{"MultiScaleDeformableAttnMeanTRTV3"};

nvinfer1::PluginFieldCollection MultiScaleDeformableAttnMeanPluginV3Creator::mFC{};
std::vector<nvinfer1::PluginField> MultiScaleDeformableAttnMeanPluginV3Creator::mPluginAttributes;

MultiScaleDeformableAttnMeanPluginV3::MultiScaleDeformableAttnMeanPluginV3() {}

nvinfer1::IPluginCapability* MultiScaleDeformableAttnMeanPluginV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneCore methods
char const* MultiScaleDeformableAttnMeanPluginV3::getPluginName() const noexcept {
  return MSDA_MEAN_PLUGINV3_NAME;
}

char const* MultiScaleDeformableAttnMeanPluginV3::getPluginVersion() const noexcept {
  return MSDA_MEAN_PLUGINV3_VERSION;
}

int32_t MultiScaleDeformableAttnMeanPluginV3::getNbOutputs() const noexcept { return 1; }

void MultiScaleDeformableAttnMeanPluginV3::setPluginNamespace(
    char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* MultiScaleDeformableAttnMeanPluginV3::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

nvinfer1::IPluginV3* MultiScaleDeformableAttnMeanPluginV3::clone() noexcept {
  try {
    auto* plugin = new MultiScaleDeformableAttnMeanPluginV3();
    plugin->setPluginNamespace(mNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t MultiScaleDeformableAttnMeanPluginV3::getOutputDataTypes(
    nvinfer1::DataType* outputTypes,
    int32_t nbOutputs,
    nvinfer1::DataType const* inputTypes,
    int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as the first input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t MultiScaleDeformableAttnMeanPluginV3::getOutputShapes(
    nvinfer1::DimsExprs const* inputs,
    int32_t nbInputs,
    nvinfer1::DimsExprs const* shapeInputs,
    int32_t nbShapeInputs,
    nvinfer1::DimsExprs* outputs,
    int32_t nbOutputs,
    nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    // Output shape: [N, Lq, M, D]
    outputs[0].nbDims = 3;
    outputs[0].d[0] = exprBuilder.constant(1);  // batch维计算均值，输出shape为1
    outputs[0].d[1] = inputs[2].d[0];
    auto head_size = inputs[0].d[2]->getConstantValue();
    auto channel_size = inputs[0].d[3]->getConstantValue();
    outputs[0].d[2] = exprBuilder.constant(head_size * channel_size);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool MultiScaleDeformableAttnMeanPluginV3::supportsFormatCombination(
    int32_t pos,
    nvinfer1::DynamicPluginTensorDesc const* inOut,
    int32_t nbInputs,
    int32_t nbOutputs) noexcept {
  try {
    // Check format
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;
    switch (pos) {
      case 0:
        return (desc.type == nvinfer1::DataType::kFLOAT ||
                desc.type == nvinfer1::DataType::kHALF) &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case 1:
        return desc.type == nvinfer1::DataType::kINT32 &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case 2:
        return desc.type == inOut[0].desc.type && desc.format == inOut[0].desc.format;
      case 3:
        return desc.type == inOut[0].desc.type && desc.format == inOut[0].desc.format;
      case 4:
        return desc.type == inOut[0].desc.type && desc.format == inOut[0].desc.format;
      default:
        return false;
    }

  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t MultiScaleDeformableAttnMeanPluginV3::configurePlugin(
    nvinfer1::DynamicPluginTensorDesc const* in,
    int32_t nbInputs,
    nvinfer1::DynamicPluginTensorDesc const* out,
    int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const*
MultiScaleDeformableAttnMeanPluginV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    // This plugin has no fields to serialize
    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();
    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t MultiScaleDeformableAttnMeanPluginV3::getWorkspaceSize(
    nvinfer1::DynamicPluginTensorDesc const* inputs,
    int32_t nbInputs,
    nvinfer1::DynamicPluginTensorDesc const* outputs,
    int32_t nbOutputs) const noexcept {
  // No workspace needed for this plugin
  return 0;
}

int32_t MultiScaleDeformableAttnMeanPluginV3::onShapeChange(
    nvinfer1::PluginTensorDesc const* inputs,
    int32_t nbInputs,
    nvinfer1::PluginTensorDesc const* outputs,
    int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* MultiScaleDeformableAttnMeanPluginV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t MultiScaleDeformableAttnMeanPluginV3::enqueue(nvinfer1::PluginTensorDesc const* inputDesc,
                                                      nvinfer1::PluginTensorDesc const* outputDesc,
                                                      void const* const* inputs,
                                                      void* const* outputs,
                                                      void* workspace,
                                                      cudaStream_t stream) noexcept {
  try {
    const int batch = inputDesc[0].dims.d[0];
    const int spatial_size = inputDesc[0].dims.d[1];
    const int num_heads = inputDesc[0].dims.d[2];
    const int channels = inputDesc[0].dims.d[3];

    const int num_levels = inputDesc[1].dims.d[0];

    // attention_weights [2, 2500, 8, 1, 4] --> [2500, 8, 2, 4]
    // sampling_offsets [2, 2500, 8, 1, 4, 2] -> [2500, 8, 2, 1, 4, 2]
    const int num_query = inputDesc[2].dims.d[0];
    const int num_point = inputDesc[2].dims.d[4];

    auto data_type = inputDesc[0].type;
    ASSERT(data_type == nvinfer1::DataType::kFLOAT || data_type == nvinfer1::DataType::kHALF)

    switch (data_type) {
      case nvinfer1::DataType::kFLOAT:
        ms_deformable_im2col_mean_cuda((float*)inputs[0],
                                       (int32_t*)inputs[1],
                                       (float*)inputs[2],
                                       (float*)inputs[3],
                                       batch,
                                       spatial_size,
                                       num_heads,
                                       channels,
                                       num_levels,
                                       num_query,
                                       num_point,
                                       (float*)outputs[0],
                                       stream);
        break;
      case nvinfer1::DataType::kHALF:
        ms_deformable_im2col_mean_cuda((__half*)inputs[0],
                                       (int32_t*)inputs[1],
                                       (__half*)inputs[2],
                                       (__half*)inputs[3],
                                       batch,
                                       spatial_size,
                                       num_heads,
                                       channels,
                                       num_levels,
                                       num_query,
                                       num_point,
                                       (__half*)outputs[0],
                                       stream);
        break;
      default:
        return 1;
    }
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

// Plugin Creator Implementation
MultiScaleDeformableAttnMeanPluginV3Creator::MultiScaleDeformableAttnMeanPluginV3Creator() {
  mPluginAttributes.clear();
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}

char const* MultiScaleDeformableAttnMeanPluginV3Creator::getPluginName() const noexcept {
  return MSDA_MEAN_PLUGINV3_NAME;
}

char const* MultiScaleDeformableAttnMeanPluginV3Creator::getPluginVersion() const noexcept {
  return MSDA_MEAN_PLUGINV3_VERSION;
}

nvinfer1::PluginFieldCollection const*
MultiScaleDeformableAttnMeanPluginV3Creator::getFieldNames() noexcept {
  return &mFC;
}

nvinfer1::IPluginV3* MultiScaleDeformableAttnMeanPluginV3Creator::createPlugin(
    char const* name,
    nvinfer1::PluginFieldCollection const* fc,
    nvinfer1::TensorRTPhase phase) noexcept {
  try {
    // This plugin doesn't have any configurable parameters
    return new MultiScaleDeformableAttnMeanPluginV3();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

void MultiScaleDeformableAttnMeanPluginV3Creator::setPluginNamespace(
    char const* pluginNamespace) noexcept {
  mNamespace = pluginNamespace;
}

char const* MultiScaleDeformableAttnMeanPluginV3Creator::getPluginNamespace() const noexcept {
  return mNamespace.c_str();
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer