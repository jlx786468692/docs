#ifndef TENSORRT_OPS_MULTISCALEDEFORMABLEATTNMEANKERNEL_H
#define TENSORRT_OPS_MULTISCALEDEFORMABLEATTNMEANKERNEL_H

#include <cuda_runtime.h>

void ms_deformable_im2col_mean_cuda(const float* data_value,
                                    const int32_t* data_spatial_shapes,
                                    const float* data_sampling_loc,
                                    const float* data_attn_weight,
                                    const int batch_size,
                                    const int spatial_size,
                                    const int num_heads,
                                    const int channels,
                                    const int num_levels,
                                    const int num_query,
                                    const int num_point,
                                    float* data_col,
                                    cudaStream_t stream);

void ms_deformable_im2col_mean_cuda(const __half* data_value,
                                    const int32_t* data_spatial_shapes,
                                    const __half* data_sampling_loc,
                                    const __half* data_attn_weight,
                                    const int batch_size,
                                    const int spatial_size,
                                    const int num_heads,
                                    const int channels,
                                    const int num_levels,
                                    const int num_query,
                                    const int num_point,
                                    __half* data_col,
                                    cudaStream_t stream);

#endif  // TENSORRT_OPS_MULTISCALEDEFORMABLEATTNMEANKERNEL_H
