#include "softmax_v3.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "softmax_kernel.h"

using linfer::ops::trt::SoftmaxV3Creator;
REGISTER_TENSORRT_PLUGIN(SoftmaxV3Creator);

namespace linfer {
namespace ops {
namespace trt {

const char* SOFTMAX_PLUGINV3_VERSION{"1"};
static const char* SOFTMAX_PLUGINV3_NAME{"LinferSoftmaxV3"};

nvinfer1::PluginFieldCollection SoftmaxV3Creator::mFC{};
std::vector<nvinfer1::PluginField> SoftmaxV3Creator::mPluginAttributes;

nvinfer1::IPluginCapability* SoftmaxV3::getCapabilityInterface(
    nvinfer1::PluginCapabilityType type) noexcept {
  try {
    if (type == nvinfer1::PluginCapabilityType::kBUILD) {
      return static_cast<nvinfer1::IPluginV3OneBuild*>(this);
    }
    if (type == nvinfer1::PluginCapabilityType::kRUNTIME) {
      return static_cast<nvinfer1::IPluginV3OneRuntime*>(this);
    }
    PLUGIN_ASSERT(type == nvinfer1::PluginCapabilityType::kCORE);
    return static_cast<nvinfer1::IPluginV3OneCore*>(this);
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

SoftmaxV3::SoftmaxV3(int axis) : axis_(axis) {}

SoftmaxV3::~SoftmaxV3() {}

// IPluginV3OneCore methods
char const* SoftmaxV3::getPluginName() const noexcept { return SOFTMAX_PLUGINV3_NAME; }

char const* SoftmaxV3::getPluginVersion() const noexcept { return SOFTMAX_PLUGINV3_VERSION; }

int32_t SoftmaxV3::getNbOutputs() const noexcept { return 1; }

void SoftmaxV3::setPluginNamespace(char const* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

char const* SoftmaxV3::getPluginNamespace() const noexcept { return namespace_.c_str(); }

nvinfer1::IPluginV3* SoftmaxV3::clone() noexcept {
  try {
    auto* plugin = new SoftmaxV3(axis_);
    plugin->setPluginNamespace(namespace_.c_str());
    return plugin;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneBuild methods
int32_t SoftmaxV3::getOutputDataTypes(nvinfer1::DataType* outputTypes,
                                      int32_t nbOutputs,
                                      nvinfer1::DataType const* inputTypes,
                                      int32_t nbInputs) const noexcept {
  try {
    // Output type is the same as the first input type
    std::fill_n(outputTypes, nbOutputs, inputTypes[0]);

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

int32_t SoftmaxV3::getOutputShapes(nvinfer1::DimsExprs const* inputs,
                                   int32_t nbInputs,
                                   nvinfer1::DimsExprs const* shapeInputs,
                                   int32_t nbShapeInputs,
                                   nvinfer1::DimsExprs* outputs,
                                   int32_t nbOutputs,
                                   nvinfer1::IExprBuilder& exprBuilder) noexcept {
  try {
    const auto& input = inputs[0];
    int nbDims = input.nbDims;
    if (!(axis_ == -1 || axis_ == nbDims - 1)) {
      LERROR_FMT("SoftmaxTRT only supports last axis. Got axis=%d, nbDims=%d",
                 static_cast<int>(axis_),
                 static_cast<int>(nbDims));
      return STATUS_FAILURE;
    }

    outputs[0] = input;

    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

bool SoftmaxV3::supportsFormatCombination(int32_t pos,
                                          nvinfer1::DynamicPluginTensorDesc const* inOut,
                                          int32_t nbInputs,
                                          int32_t nbOutputs) noexcept {
  try {
    // Check format
    nvinfer1::PluginTensorDesc const& desc = inOut[pos].desc;
    switch (pos) {
      case 0:
        return (desc.type == nvinfer1::DataType::kFLOAT ||
                desc.type == nvinfer1::DataType::kHALF) &&
               desc.format == nvinfer1::TensorFormat::kLINEAR;
      case 1:
        return desc.type == inOut[0].desc.type && desc.format == inOut[0].desc.format;
      default:
        return false;
    }

  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return false;
}

int32_t SoftmaxV3::configurePlugin(nvinfer1::DynamicPluginTensorDesc const* in,
                                   int32_t nbInputs,
                                   nvinfer1::DynamicPluginTensorDesc const* out,
                                   int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::PluginFieldCollection const* SoftmaxV3::getFieldsToSerialize() noexcept {
  try {
    mDataToSerialize.clear();
    mDataToSerialize.emplace_back(
        nvinfer1::PluginField("axis", &axis_, nvinfer1::PluginFieldType::kINT32, 1));

    mFCToSerialize.nbFields = mDataToSerialize.size();
    mFCToSerialize.fields = mDataToSerialize.data();

    return &mFCToSerialize;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

// IPluginV3OneRuntime methods
size_t SoftmaxV3::getWorkspaceSize(nvinfer1::DynamicPluginTensorDesc const* inputs,
                                   int32_t nbInputs,
                                   nvinfer1::DynamicPluginTensorDesc const* outputs,
                                   int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t SoftmaxV3::onShapeChange(nvinfer1::PluginTensorDesc const* inputs,
                                 int32_t nbInputs,
                                 nvinfer1::PluginTensorDesc const* outputs,
                                 int32_t nbOutputs) noexcept {
  try {
    return STATUS_SUCCESS;
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return STATUS_FAILURE;
}

nvinfer1::IPluginV3* SoftmaxV3::attachToContext(
    nvinfer1::IPluginResourceContext* context) noexcept {
  try {
    // No resources need to be attached
    return clone();
  } catch (std::exception const& e) {
    linfer::util::caughtError(e);
  }
  return nullptr;
}

int32_t SoftmaxV3::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                           const nvinfer1::PluginTensorDesc* outputDesc,
                           const void* const* inputs,
                           void* const* outputs,
                           void* workspace,
                           cudaStream_t stream) noexcept {
  const void* input_ptr = inputs[0];
  void* output_ptr = outputs[0];

  auto input_dim = inputDesc[0].dims;
  unsigned int last_axis_len = input_dim.d[input_dim.nbDims - 1];
  unsigned int other_axis_len = 1;
  for (int i = 0; i < input_dim.nbDims - 1; ++i) {
    other_axis_len *= input_dim.d[i];
  }

  bool use_float16 = inputDesc[0].type == nvinfer1::DataType::kHALF;
  if (use_float16) {
    // half最大值65504，last_axis_len过大会导致溢出
    if (last_axis_len > 10000) {
      LERROR_FMT("A too large last_axis_len in softmax plugin can cause overflow");
    }
    launch_softmax_kernel((const __half*)input_ptr,
                          (__half*)output_ptr,
                          last_axis_len,
                          other_axis_len,
                          stream);
  } else {  // use float32
    launch_softmax_kernel((const float*)input_ptr,
                          (float*)output_ptr,
                          last_axis_len,
                          other_axis_len,
                          stream);
  }
  return 0;
}

SoftmaxV3Creator::SoftmaxV3Creator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("axis", nullptr, nvinfer1::PluginFieldType::kINT32, 1));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* SoftmaxV3Creator::getPluginVersion() const noexcept { return SOFTMAX_PLUGINV3_VERSION; }
const char* SoftmaxV3Creator::getPluginName() const noexcept { return SOFTMAX_PLUGINV3_NAME; }
const nvinfer1::PluginFieldCollection* SoftmaxV3Creator::getFieldNames() noexcept {
  return &SoftmaxV3Creator::mFC;
}

nvinfer1::IPluginV3* SoftmaxV3Creator::createPlugin(char const* SOFTMAX_PLUGINV3_NAME,
                                                    nvinfer1::PluginFieldCollection const* fc,
                                                    nvinfer1::TensorRTPhase phase) noexcept {
  int axis;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("axis") == 0) {
      axis = *static_cast<const int*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }

  SoftmaxV3* obj = new SoftmaxV3(axis);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void SoftmaxV3Creator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* SoftmaxV3Creator::getPluginNamespace() const noexcept { return namespace_.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
