#include "softmax.h"

#include <assert.h>
#include <nvtx3/nvToolsExt.h>
#include <stdio.h>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "../common/trt_serialize.hpp"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/lassert.h"
#include "linfer/util/log.h"
#include "linfer/util/numpy.h"
#include "softmax_kernel.h"

using linfer::ops::trt::SoftmaxPluginCreator;
REGISTER_TENSORRT_PLUGIN(SoftmaxPluginCreator);

namespace linfer {
namespace ops {
namespace trt {

enum INOUT_POS {
  input = 0,
  output_base = 1,
  output_base_input = output_base,
  output = output_base_input - output_base,
};

const char* SOFTMAX_PLUGIN_VERSION{"1"};
static const char* SOFTMAX_PLUGIN_NAME{"LinferSoftmax"};

nvinfer1::PluginFieldCollection SoftmaxPluginCreator::mFC{};
std::vector<nvinfer1::PluginField> SoftmaxPluginCreator::mPluginAttributes;

Softmax::Softmax(int axis) : axis_(axis) {}

Softmax::~Softmax() {}

int Softmax::getNbOutputs() const noexcept { return 1; }

nvinfer1::DataType Softmax::getOutputDataType(int index,
                                              const nvinfer1::DataType* inputTypes,
                                              int nbInputs) const noexcept {
  return inputTypes[INOUT_POS::input];
}

nvinfer1::DimsExprs Softmax::getOutputDimensions(int32_t outputIndex,
                                                 const nvinfer1::DimsExprs* inputs,
                                                 int32_t nbInputs,
                                                 nvinfer1::IExprBuilder& exprBuilder) noexcept {
  nvinfer1::DimsExprs output_dims = inputs[INOUT_POS::input];
  auto nbDims = inputs[INOUT_POS::input].nbDims;
  if (axis_ != -1 && axis_ != (nbDims - 1)) {
    LERROR_FMT("SoftmaxTRT now only support last axis, but: axis= %d, nbDims=%d",
               static_cast<int>(axis_),
               static_cast<int>(nbDims));
  }
  return output_dims;
}

bool Softmax::supportsFormatCombination(int32_t pos,
                                        const nvinfer1::PluginTensorDesc* inOut,
                                        int32_t nbInputs,
                                        int32_t nbOutputs) noexcept {
  auto dtype = inOut[pos].type;
  auto dformat = inOut[pos].format;

  switch (pos) {
    case INOUT_POS::input:
      return (dtype == nvinfer1::DataType::kFLOAT || dtype == nvinfer1::DataType::kHALF) &&
             dformat == nvinfer1::TensorFormat::kLINEAR;
      // return dtype == nvinfer1::DataType::kFLOAT && dformat ==
      // nvinfer1::TensorFormat::kLINEAR;
    case INOUT_POS::output_base_input:
      return dtype == inOut[INOUT_POS::input].type && dformat == inOut[INOUT_POS::input].format;
    default:
      return false;
  }
}

void Softmax::configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                              int32_t nbInputs,
                              const nvinfer1::DynamicPluginTensorDesc* out,
                              int32_t nbOutputs) noexcept {}

size_t Softmax::getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                                 int32_t nbInputs,
                                 const nvinfer1::PluginTensorDesc* outputs,
                                 int32_t nbOutputs) const noexcept {
  return 0;
}

int Softmax::initialize() noexcept { return 0; }

void Softmax::terminate() noexcept {}

int32_t Softmax::enqueue(const nvinfer1::PluginTensorDesc* inputDesc,
                         const nvinfer1::PluginTensorDesc* outputDesc,
                         const void* const* inputs,
                         void* const* outputs,
                         void* workspace,
                         cudaStream_t stream) noexcept {
  const void* input_ptr = inputs[INOUT_POS::input];
  void* output_ptr = outputs[INOUT_POS::output];

  auto input_dim = inputDesc[INOUT_POS::input].dims;
  unsigned int last_axis_len = input_dim.d[input_dim.nbDims - 1];
  unsigned int other_axis_len = 1;
  for (int i = 0; i < input_dim.nbDims - 1; ++i) {
    other_axis_len *= input_dim.d[i];
  }

  bool use_float16 = inputDesc[INOUT_POS::input].type == nvinfer1::DataType::kHALF;
  if (use_float16) {
    // half最大值65504，last_axis_len过大会导致溢出
    if (last_axis_len > 10000) {
      LERROR_FMT("A too large last_axis_len in softmax plugin can cause overflow");
    }
    launch_softmax_kernel((const __half*)input_ptr,
                          (__half*)output_ptr,
                          last_axis_len,
                          other_axis_len,
                          stream);
  } else {  // use float32
    launch_softmax_kernel((const float*)input_ptr,
                          (float*)output_ptr,
                          last_axis_len,
                          other_axis_len,
                          stream);
  }
  return 0;
}

size_t Softmax::getSerializationSize() const noexcept {
  // int axis_;
  return sizeof(int) * 1;
}

void Softmax::serialize(void* buffer) const noexcept {
  char* buf = reinterpret_cast<char*>(buffer);
  char* start = buf;
  write<int>(buf, axis_);
  LASSERT_MSG(buf, start + getSerializationSize());
}

const char* Softmax::getPluginType() const noexcept { return SOFTMAX_PLUGIN_NAME; }

const char* Softmax::getPluginVersion() const noexcept { return SOFTMAX_PLUGIN_VERSION; }

void Softmax::destroy() noexcept {}

nvinfer1::IPluginV2DynamicExt* Softmax::clone() const noexcept {
  auto plugin = new Softmax(axis_);
  plugin->setPluginNamespace(namespace_.c_str());
  return plugin;
}

void Softmax::setPluginNamespace(const char* pluginNamespace) noexcept {
  namespace_ = pluginNamespace;
}

const char* Softmax::getPluginNamespace() const noexcept { return namespace_.c_str(); }

void Softmax::attachToContext(cudnnContext* cudnnContext,
                              cublasContext* cublasContext,
                              nvinfer1::IGpuAllocator* gpuAllocator) noexcept {}

void Softmax::detachFromContext() noexcept {}

SoftmaxPluginCreator::SoftmaxPluginCreator() {
  mPluginAttributes.clear();
  mPluginAttributes.emplace_back(
      nvinfer1::PluginField("axis", nullptr, nvinfer1::PluginFieldType::kINT32, 2));
  mFC.nbFields = mPluginAttributes.size();
  mFC.fields = mPluginAttributes.data();
}
const char* SoftmaxPluginCreator::getPluginVersion() const noexcept {
  return SOFTMAX_PLUGIN_VERSION;
}
const char* SoftmaxPluginCreator::getPluginName() const noexcept { return SOFTMAX_PLUGIN_NAME; }
const nvinfer1::PluginFieldCollection* SoftmaxPluginCreator::getFieldNames() noexcept {
  return &SoftmaxPluginCreator::mFC;
}

nvinfer1::IPluginV2Ext* SoftmaxPluginCreator::createPlugin(
    const char* plugin_name,
    const nvinfer1::PluginFieldCollection* fc) noexcept {
  int axis;

  for (int32_t i = 0; i < fc->nbFields; i++) {
    std::string field_name(fc->fields[i].name);
    auto field_data = fc->fields[i].data;
    auto field_len = fc->fields[i].length;

    if (field_name.compare("axis") == 0) {
      axis = *static_cast<const int32_t*>(field_data);
    } else {
      LASSERT_MSG(false, "unexpected field_name: " + field_name);
    }
  }
  LINFO_FMT("axis: %d\n", axis);

  Softmax* obj = new Softmax(axis);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

nvinfer1::IPluginV2Ext* SoftmaxPluginCreator::deserializePlugin(const char* plugin_name,
                                                                const void* serialData,
                                                                size_t serialLength) noexcept {
  auto buf = reinterpret_cast<const char*>(serialData);
  auto buf_start = buf;
  auto axis = read<int>(buf);

  LINFO_FMT("axis: %d\n", axis);
  auto obj = new Softmax(axis);
  obj->setPluginNamespace(namespace_.c_str());
  return obj;
}

void SoftmaxPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
  namespace_ = libNamespace;
}

const char* SoftmaxPluginCreator::getPluginNamespace() const noexcept { return namespace_.c_str(); }

}  // namespace trt
}  // namespace ops
}  // namespace linfer
