#pragma once

#include <cuda_fp16.h>
#include <cuda_runtime.h>

namespace linfer {
namespace ops {
namespace trt {

void launch_softmax_kernel(const float* input,
                           float* output,
                           unsigned int last_axis_len,
                           unsigned int other_axis_len,
                           cudaStream_t stream);

void launch_softmax_kernel(const __half* input,
                           __half* output,
                           unsigned int last_axis_len,
                           unsigned int other_axis_len,
                           cudaStream_t stream);

}  // namespace trt
}  // namespace ops
}  // namespace linfer