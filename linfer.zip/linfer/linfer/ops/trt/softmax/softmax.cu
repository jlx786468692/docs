

#include <cmath>

#include "cuda_fp16.h"
#include "float.h"
#include "linfer/util/log.h"
#include "softmax.h"
#include "softmax_kernel.h"

namespace linfer {
namespace ops {
namespace trt {

// FIXME 为处理多batch的情况，暂时只处理单batch的情况
template <typename T>
__global__ void softmax_kernel(const T* input, T* output, unsigned n_per_thread, unsigned total) {
  // TODO
  unsigned global_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (global_idx >= total) {
    return;
  }

  T max_val = input[global_idx * n_per_thread];
  for (unsigned i = 1; i < n_per_thread; ++i) {
    if (input[global_idx * n_per_thread + i] > max_val) {
      max_val = input[global_idx * n_per_thread + i];
    }
  }

  T sum = 0;
  for (unsigned i = 0; i < n_per_thread; ++i) {
    sum += expf(input[global_idx * n_per_thread + i] - max_val);
  }

  for (unsigned i = 0; i < n_per_thread; ++i) {
    output[global_idx * n_per_thread + i] =
        expf(input[global_idx * n_per_thread + i] - max_val) / sum;
  }
}

template <>
__global__ void softmax_kernel(const __half* input,
                               __half* output,
                               unsigned n_per_thread,
                               unsigned total) {
  // TODO
  unsigned global_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (global_idx >= total) {
    return;
  }

  __half max_val = input[global_idx * n_per_thread];
  for (unsigned i = 1; i < n_per_thread; ++i) {
    if (input[global_idx * n_per_thread + i] > max_val) {
      max_val = input[global_idx * n_per_thread + i];
    }
  }

  __half sum = __float2half(0.0f);
  for (unsigned i = 0; i < n_per_thread; ++i) {
    sum = __hadd(hexp(__hsub(input[global_idx * n_per_thread + i], max_val)), sum);
  }

  for (unsigned i = 0; i < n_per_thread; ++i) {
    output[global_idx * n_per_thread + i] =
        __hdiv(hexp(__hsub(input[global_idx * n_per_thread + i], max_val)), sum);
  }
}

template <typename T>
void launch_softmax_kernel_(const T* input,
                            T* output,
                            unsigned int last_axis_len,
                            unsigned int other_axis_len,
                            cudaStream_t stream) {
  int thread_per_block = 256;
  int block_per_grid = std::ceil((float)other_axis_len / thread_per_block);
  softmax_kernel<T><<<block_per_grid, thread_per_block, 0, stream>>>(input,
                                                                     output,
                                                                     last_axis_len,
                                                                     other_axis_len);
  cudaError_t err = cudaGetLastError();
  if (err != cudaSuccess) {
    LERROR_FMT("error in launch_softmax_kernel_: %s\n", cudaGetErrorString(err));
  }
}

void launch_softmax_kernel(const float* input,
                           float* output,
                           unsigned int last_axis_len,
                           unsigned int other_axis_len,
                           cudaStream_t stream) {
  launch_softmax_kernel_(input, output, last_axis_len, other_axis_len, stream);
}

void launch_softmax_kernel(const __half* input,
                           __half* output,
                           unsigned int last_axis_len,
                           unsigned int other_axis_len,
                           cudaStream_t stream) {
  launch_softmax_kernel_(input, output, last_axis_len, other_axis_len, stream);
}

}  // namespace trt
}  // namespace ops
}  // namespace linfer
