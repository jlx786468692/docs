#include <NvInfer.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cmath>
#include <iostream>
#include <type_traits>

namespace nvinfer1 {
namespace plugin {

__global__ void fuse_clip_add_wrap_out_fp32(const half* input0, float* output, const int size) {
  int warp_id = threadIdx.x / 32;
  int lane_id = threadIdx.x % 32;
  int warp_offset = (blockIdx.x * (blockDim.x / 32) + warp_id) * 32;
  int global_idx = warp_offset + lane_id;
  if (global_idx < size) {
    half x = input0[global_idx];

    // 使用快速数学库函数
    x = __hgt(x, __float2half(0.0f)) ? x : __float2half(0.0f);
    x = __hlt(x, __float2half(1.0f)) ? x : __float2half(1.0f);

    half sub_result = __hsub(__float2half(1.0f), x);

    half left_clip = __hgt(x, __float2half(0.000000999f)) ? x : __float2half(0.000000999f);
    half right_clip =
        __hgt(sub_result, __float2half(0.000000999f)) ? sub_result : __float2half(0.000000999f);

    // 使用更高效的division-by-multiplication技术
    half div_result = __hdiv(left_clip, right_clip);

    // 使用更精确的log近似

    // half log_result = hlog(div_result);

    float div_result_float = __half2float(div_result);
    float log_result = logf(div_result_float);  // 使用FP32的logf计算
    // half log_result = __float2half(log_result_float);

    output[global_idx] = log_result;
  }
}

__global__ void fuse_clip_add_wrap(const half* input0, float* output, const int size) {
  int warp_id = threadIdx.x / 32;
  int lane_id = threadIdx.x % 32;
  int warp_offset = (blockIdx.x * (blockDim.x / 32) + warp_id) * 32;
  int global_idx = warp_offset + lane_id;
  if (global_idx < size) {
    half x = input0[global_idx];

    // 使用快速数学库函数
    x = __hgt(x, __float2half(0.0f)) ? x : __float2half(0.0f);
    x = __hlt(x, __float2half(1.0f)) ? x : __float2half(1.0f);

    half sub_result = __hsub(__float2half(1.0f), x);

    half left_clip = __hgt(x, __float2half(0.000000999f)) ? x : __float2half(0.000000999f);
    half right_clip =
        __hgt(sub_result, __float2half(0.000000999f)) ? sub_result : __float2half(0.000000999f);

    // 使用更高效的division-by-multiplication技术
    // half div_result = __hdiv(left_clip, right_clip);
    float div_result = __fdividef(__half2float(left_clip), __half2float(right_clip));
    // float div_result = __fdiv_rd(__half2float(left_clip), __half2float(right_clip));

    // 使用更精确的log近似
    // half log_result = hlog(div_result) ;
    // half log_result = hlog2(div_result) * __float2half(0.693147181f);
    // float div_result_float = __half2float(div_result);
    float log_result = logf(div_result);  // 使用FP32的logf计算
    // half log_result = __float2half(log_result_float);

    output[global_idx] = log_result;
  }
}

// div  +log  some times may case inf error
__global__ void fuse_clip_add_half2(const half2* input0, half2* output, const int size_half2) {
  int index = blockIdx.x * blockDim.x + threadIdx.x;
  if (index < size_half2) {
    // Load 2 elements at once
    half2 x = input0[index];

    // First clip: min=0
    const half2 zero = __float2half2_rn(0.0f);
    // Use proper half2 comparison and selection
    x = __hfma2(__hgt2(x, zero), x, __hmul2(__hle2(x, zero), zero));

    // Second clip: max=1
    const half2 one = __float2half2_rn(1.0f);
    // Use proper half2 comparison and selection
    x = __hfma2(__hlt2(x, one), x, __hmul2(__hge2(x, one), one));

    // Sub operation: A=1
    half2 sub_result = __hsub2(one, x);

    // Two more clip operations with min=0.000000999
    const half2 min_clip_val = __float2half2_rn(0.000000999f);
    // Use proper half2 comparison and selection
    half2 left_clip =
        __hfma2(__hgt2(x, min_clip_val), x, __hmul2(__hle2(x, min_clip_val), min_clip_val));
    half2 right_clip = __hfma2(__hgt2(sub_result, min_clip_val),
                               sub_result,
                               __hmul2(__hle2(sub_result, min_clip_val), min_clip_val));

    // Division
    half2 div_result = __h2div(left_clip, right_clip);

    // Log operation
    // Natural log approximation: ln(x) = log2(x) * ln(2)
    half2 log_result = h2log(div_result);
    // half2 log_result = h2log2(div_result) * __float2half2_rn(0.693147181f);

    // Store result - process 2 elements at once
    output[index] = log_result;
  }
}

int FusionClipAddLaunch(const void* input0, void* outputs, const int size, cudaStream_t stream) {
  const int block_size = 128;

  // if (size % 2 == 0) {
  //         // Size is even, we can use half2 processing for better performance
  //         const int size_half2 = size / 2; // Number of half2 elements
  //         const int grid_size = (size_half2 + block_size - 1) / block_size;

  //         fuse_clip_add_half2<<<grid_size, block_size, 0, stream>>>(
  //             static_cast<const half2*>(input0),
  //             static_cast<half2*>(outputs),
  //             size_half2
  //         );
  //     }

  // Size is odd, use single element processing
  const int grid_size = (size + block_size - 1) / block_size;

  fuse_clip_add_wrap<<<grid_size, block_size, 0, stream>>>(static_cast<const half*>(input0),
                                                           static_cast<float*>(outputs),
                                                           size);

  return 0;
}

}  // namespace plugin
}  // namespace nvinfer1