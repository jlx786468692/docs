#include "FusionClipAddPlugin.h"

#include <NvInfer.h>

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace nvinfer1 {
namespace plugin {

PluginFieldCollection FusionClipAddCreator::mFC{};
std::vector<PluginField> FusionClipAddCreator::mPluginAttributes;

FusionClipAdd::FusionClipAdd() {}

FusionClipAdd::FusionClipAdd(const void* serialData, size_t serialLength) {}

char const* FusionClipAdd::getPluginType() const noexcept { return FUSION_CLIP_SIGMOID_NAME; }

char const* FusionClipAdd::getPluginVersion() const noexcept { return FUSION_CLIP_SIGMOID_VERSION; }

int32_t FusionClipAdd::getNbOutputs() const noexcept { return 1; }

DimsExprs FusionClipAdd::getOutputDimensions(int32_t outputIndex,
                                             DimsExprs const* inputs,
                                             int32_t nbInputs,
                                             IExprBuilder& exprBuilder) noexcept {
  return inputs[0];
}

bool FusionClipAdd::supportsFormatCombination(int32_t pos,
                                              PluginTensorDesc const* inOut,
                                              int32_t nbInputs,
                                              int32_t nbOutputs) noexcept {
  // 1 input and 1 output
  // input.type == output.type
  ASSERT(0 <= pos && pos < 2);
  ASSERT(nbInputs == 1);
  ASSERT(nbOutputs == 1);
  ASSERT(pos < (nbInputs + nbOutputs));
  ASSERT(inOut != nullptr);

  const auto* in = &inOut[0];
  const auto* out = &inOut[1];

  // Verify format is Linear
  bool isFormatOK = (inOut[pos].format == nvinfer1::TensorFormat::kLINEAR);

  // Check data types
  if (pos == 0) {  // Input tensor
    isFormatOK &= (in->type == nvinfer1::DataType::kHALF);
  } else {                                                    // Output tensor
    isFormatOK &= (out->type == nvinfer1::DataType::kFLOAT);  // Match input type
  }

  return isFormatOK;
}

void FusionClipAdd::configurePlugin(DynamicPluginTensorDesc const* in,
                                    int32_t nbInputs,
                                    DynamicPluginTensorDesc const* out,
                                    int32_t nbOutputs) noexcept {
  // Calculate input size based on the input dimensions
  const nvinfer1::Dims& dims = in[0].desc.dims;
  mInputSize = 1;
  for (int i = 0; i < dims.nbDims; i++) {
    mInputSize *= dims.d[i];
  }
}

size_t FusionClipAdd::getWorkspaceSize(PluginTensorDesc const* inputs,
                                       int32_t nbInputs,
                                       PluginTensorDesc const* outputs,
                                       int32_t nbOutputs) const noexcept {
  return 0;
}

int32_t FusionClipAdd::enqueue(PluginTensorDesc const* inputDesc,
                               PluginTensorDesc const* outputDesc,
                               void const* const* inputs,
                               void* const* outputs,
                               void* workspace,
                               cudaStream_t stream) noexcept {
  try {
    FusionClipAddLaunch(inputs[0], outputs[0], mInputSize, stream);
    return cudaPeekAtLastError();
  } catch (std::exception const& e) {
    caughtError(e);
    return -1;
  }
}

size_t FusionClipAdd::getSerializationSize() const noexcept { return 0; }

void FusionClipAdd::serialize(void* buffer) const noexcept {}

void FusionClipAdd::destroy() noexcept { delete this; }

int32_t FusionClipAdd::initialize() noexcept { return 0; }

void FusionClipAdd::terminate() noexcept {}

void FusionClipAdd::setPluginNamespace(char const* pluginNamespace) noexcept {
  mPluginNamespace = pluginNamespace;
}

char const* FusionClipAdd::getPluginNamespace() const noexcept { return mPluginNamespace.c_str(); }

DataType FusionClipAdd::getOutputDataType(int32_t index,
                                          nvinfer1::DataType const* inputTypes,
                                          int32_t nbInputs) const noexcept {
  return nvinfer1::DataType::kFLOAT;
}

IPluginV2DynamicExt* FusionClipAdd::clone() const noexcept {
  try {
    auto* plugin = new FusionClipAdd();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
  }
  return nullptr;
}

// Plugin creator
FusionClipAddCreator::FusionClipAddCreator() {}

IPluginV2DynamicExt* FusionClipAddCreator::createPlugin(char const* name,
                                                        PluginFieldCollection const* fc) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new FusionClipAdd();
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

IPluginV2DynamicExt* FusionClipAddCreator::deserializePlugin(char const* name,
                                                             void const* serialData,
                                                             size_t serialLength) noexcept {
  try {
    IPluginV2DynamicExt* plugin = new FusionClipAdd(serialData, serialLength);
    plugin->setPluginNamespace(mPluginNamespace.c_str());
    return plugin;
  } catch (std::exception const& e) {
    caughtError(e);
    return nullptr;
  }
}

const char* FusionClipAddCreator::getPluginName() const noexcept {
  return FUSION_CLIP_SIGMOID_NAME;
}

const char* FusionClipAddCreator::getPluginVersion() const noexcept {
  return FUSION_CLIP_SIGMOID_VERSION;
}

const PluginFieldCollection* FusionClipAddCreator::getFieldNames() noexcept { return &mFC; }

void FusionClipAddCreator::setPluginNamespace(const char* libNamespace) noexcept {
  mPluginNamespace = libNamespace;
}

const char* FusionClipAddCreator::getPluginNamespace() const noexcept {
  return mPluginNamespace.c_str();
}

REGISTER_TENSORRT_PLUGIN(FusionClipAddCreator);

}  // namespace plugin
}  // namespace nvinfer1