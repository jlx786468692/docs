#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct Natten1DAVKernel {
  Natten1DAVKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    kernel_size_ = info.GetAttribute<int64_t>("kernel_size");
    dilation_ = info.GetAttribute<int64_t>("dilation");
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  int64_t kernel_size_, dilation_;

  static constexpr int att_idx_ = 0;
  static constexpr int value_idx_ = 1;
  const OrtApi& ort_;
};

class Natten1DAVOp : public Ort::CustomOpBase<Natten1DAVOp, Natten1DAVKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new Natten1DAVKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "Natten1DAV"; }

  size_t GetInputTypeCount() const { return 2; }
  ONNXTensorElementDataType GetInputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

  size_t GetOutputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetOutputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
