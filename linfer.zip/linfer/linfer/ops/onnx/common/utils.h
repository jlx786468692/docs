#include <vector>

inline unsigned long volume(const std::vector<int64_t>& d) {
  return std::accumulate(d.d, d.d + d.nbDims, 1UL, std::multiplies<unsigned long>());
}

inline size_t getElementSize(nvinfer1::DataType t) noexcept {
  switch (t) {
    case nvinfer1::DataType::kINT32:
      return 4;
    case nvinfer1::DataType::kFLOAT:
      return 4;
    case nvinfer1::DataType::kHALF:
      return 2;
    case nvinfer1::DataType::kBOOL:
    case nvinfer1::DataType::kINT8:
      return 1;
  }
  return 0;
}

inline size_t getNvTensorLenInByte(const nvinfer1::PluginTensorDesc& desc) {
  return volume(desc.dims) * getElementSize(desc.type);
}