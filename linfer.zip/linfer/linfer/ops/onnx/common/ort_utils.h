#pragma once

#include <onnxruntime_cxx_api.h>

#include <numeric>
#include <unordered_map>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

inline int64_t Volume(const std::vector<int64_t>& dims) {
  return std::accumulate(dims.begin(), dims.end(), 1LL, std::multiplies<int64_t>());
}

inline size_t GetElementSize(ONNXTensorElementDataType t) {
  switch (t) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
      return 4;  // float
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8:
      return 1;  // uint8_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8:
      return 1;  // int8_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT16:
      return 2;  // uint16_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16:
      return 2;  // int16_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:
      return 4;  // int32_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:
      return 8;  // int64_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL:
      return 1;  // bool (usually 1 byte)
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
      return 2;  // float16
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:
      return 8;  // double
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT32:
      return 4;  // uint32_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT64:
      return 8;  // uint64_t
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16:
      return 2;  // bfloat16
    default:
      throw std::invalid_argument("Unsupported ONNXTensorElementDataType");
  }
}

inline size_t GetORTTensorLenInByte(const Ort::TensorTypeAndShapeInfo& info) {
  return Volume(info.GetShape()) * static_cast<size_t>(GetElementSize(info.GetElementType()));
}

typedef std::unordered_map<std::string, std::vector<OrtCustomOp*>> CustomOpsTable;

CustomOpsTable& get_custom_ops();

template <const char* const domain, typename T>
class OrtOpsRegistry {
 public:
  OrtOpsRegistry() { get_custom_ops()[domain].push_back(&instance); }

 private:
  T instance{};
};

#define REGISTER_ONNXRUNTIME_OPS(domain, name)                     \
  static constexpr char const __domain_##domain##name[] = #domain; \
  static OrtOpsRegistry<__domain_##domain##name, name> ort_ops_registry_##domain##name {}

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
