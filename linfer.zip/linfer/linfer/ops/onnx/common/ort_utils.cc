#include "ort_utils.h"

namespace linfer {
namespace ops {
namespace onnx {

CustomOpsTable& get_custom_ops() {
  static CustomOpsTable _custom_ops;
  return _custom_ops;
}

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
