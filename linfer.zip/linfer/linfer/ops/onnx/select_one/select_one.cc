#include "select_one.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/select_one/select_one_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

void SelectOneKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  std::vector<int64_t> input_dims = input_0.GetTensorTypeAndShapeInfo().GetShape();

  std::vector<int64_t> output_dims = {select_num_};
  auto output0 = ctx.GetOutput(0, output_dims);
  auto output1 = ctx.GetOutput(1, output_dims);
  int input_size = input_dims[0];

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  bool use_float =
      input_0.GetTensorTypeAndShapeInfo().GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  if (use_float) {
    launch_select_one(stream,
                      output0.GetTensorMutableData<float>(),
                      output1.GetTensorMutableData<int32_t>(),
                      input_0.GetTensorData<float>(),
                      input_size,
                      select_num_);
  } else {
    launch_select_one(stream,
                      output0.GetTensorMutableData<int32_t>(),
                      output1.GetTensorMutableData<int32_t>(),
                      input_0.GetTensorData<int32_t>(),
                      input_size,
                      select_num_);
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, SelectOne);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
