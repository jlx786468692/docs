#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct SelectOneKernel {
  SelectOneKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    select_num_ = info.GetAttribute<int64_t>("select_num");
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  int64_t select_num_;
  const OrtApi& ort_;
};

class SelectOne : public Ort::CustomOpBase<SelectOne, SelectOneKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new SelectOneKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "LinferSelectOne"; }

  size_t GetInputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetInputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

  size_t GetOutputTypeCount() const { return 2; }

  ONNXTensorElementDataType GetOutputType(size_t index) const {
    if (index == 0) {
      return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
    } else {
      return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32;
    }
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
