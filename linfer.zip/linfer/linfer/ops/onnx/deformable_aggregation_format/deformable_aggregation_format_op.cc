#include "deformable_aggregation_format_op.h"

#include <cuda_fp16.h>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/deformable_aggregation_format/deformable_aggregation_format_kernel.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

namespace linfer {
namespace ops {
namespace onnx {

void DeformableAggregationFormatKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  int nbInputs = ctx.GetInputCount();
  int sample_pos = nbInputs - 2;
  int weight_pos = nbInputs - 1;

  Ort::ConstValue feature_map_0 = ctx.GetInput(0);
  Ort::ConstValue feature_map_1 = ctx.GetInput(1);
  Ort::ConstValue points_2d = ctx.GetInput(sample_pos);
  Ort::ConstValue weight = ctx.GetInput(weight_pos);

  std::vector<int64_t> feature_map_0_dims = feature_map_0.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> feature_map_1_dims = feature_map_1.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> points_2d_dims = points_2d.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> weight_dims = weight.GetTensorTypeAndShapeInfo().GetShape();

  int batch_size = points_2d_dims[0];
  ;  // 1
  ASSERT(batch_size == 1);
  int num_embeds = feature_map_0_dims[3];   // 256
  int num_cams = num_cams_;                 // 5 or 1
  int num_scale = ctx.GetInputCount() - 2;  // 3
  int num_anchors = points_2d_dims[1];      // 600
  int num_pts = points_2d_dims[2];          // 13
  int num_groups = weight_dims[5];          // 8
  ONNXTensorElementDataType data_type = feature_map_0.GetTensorTypeAndShapeInfo().GetElementType();

  std::vector<int64_t> output_dims{1, points_2d_dims[1], feature_map_0_dims[3]};
  auto output = ctx.GetOutput(0, output_dims);

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
  switch (data_type) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
      if (num_scale == 2) {
        int h_0 = feature_map_0_dims[1];
        int w_0 = feature_map_0_dims[2];
        int h_1 = feature_map_1_dims[1];
        int w_1 = feature_map_1_dims[2];

        deformable_aggregation_format(stream,
                                      output.GetTensorMutableData<float>(),
                                      feature_map_0.GetTensorData<float>(),
                                      feature_map_1.GetTensorData<float>(),
                                      points_2d.GetTensorData<float>(),
                                      weight.GetTensorData<float>(),
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1);
        break;
      }

      if (num_scale == 3) {
        int h_0 = feature_map_0_dims[1];
        int w_0 = feature_map_0_dims[2];
        int h_1 = feature_map_1_dims[1];
        int w_1 = feature_map_1_dims[2];
        Ort::ConstValue feature_map_2 = ctx.GetInput(2);
        std::vector<int64_t> feature_map_2_dims =
            feature_map_2.GetTensorTypeAndShapeInfo().GetShape();
        int h_2 = feature_map_2_dims[1];
        int w_2 = feature_map_2_dims[2];
        deformable_aggregation_format(stream,
                                      output.GetTensorMutableData<float>(),
                                      feature_map_0.GetTensorData<float>(),
                                      feature_map_1.GetTensorData<float>(),
                                      feature_map_2.GetTensorData<float>(),
                                      points_2d.GetTensorData<float>(),
                                      weight.GetTensorData<float>(),
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1,
                                      h_2,
                                      w_2);
        break;
      }

      if (num_scale == 4) {
        int h_0 = feature_map_0_dims[1];
        int w_0 = feature_map_0_dims[2];
        int h_1 = feature_map_1_dims[1];
        int w_1 = feature_map_1_dims[2];
        Ort::ConstValue feature_map_2 = ctx.GetInput(2);
        Ort::ConstValue feature_map_3 = ctx.GetInput(3);
        std::vector<int64_t> feature_map_2_dims =
            feature_map_2.GetTensorTypeAndShapeInfo().GetShape();
        std::vector<int64_t> feature_map_3_dims =
            feature_map_3.GetTensorTypeAndShapeInfo().GetShape();
        int h_2 = feature_map_2_dims[1];
        int w_2 = feature_map_2_dims[2];
        int h_3 = feature_map_3_dims[1];
        int w_3 = feature_map_3_dims[2];
        deformable_aggregation_format(stream,
                                      output.GetTensorMutableData<float>(),
                                      feature_map_0.GetTensorData<float>(),
                                      feature_map_1.GetTensorData<float>(),
                                      feature_map_2.GetTensorData<float>(),
                                      feature_map_3.GetTensorData<float>(),
                                      points_2d.GetTensorData<float>(),
                                      weight.GetTensorData<float>(),
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1,
                                      h_2,
                                      w_2,
                                      h_3,
                                      w_3);
        break;
      }

    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
      if (num_scale == 2) {
        int h_0 = feature_map_0_dims[1];
        int w_0 = feature_map_0_dims[2];
        int h_1 = feature_map_1_dims[1];
        int w_1 = feature_map_1_dims[2];

        deformable_aggregation_format(stream,
                                      output.GetTensorMutableData<float>(),
                                      feature_map_0.GetTensorData<__half>(),
                                      feature_map_1.GetTensorData<__half>(),
                                      points_2d.GetTensorData<float>(),
                                      weight.GetTensorData<__half>(),
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1);
        break;
      }

      if (num_scale == 3) {
        int h_0 = feature_map_0_dims[1];
        int w_0 = feature_map_0_dims[2];
        int h_1 = feature_map_1_dims[1];
        int w_1 = feature_map_1_dims[2];
        Ort::ConstValue feature_map_2 = ctx.GetInput(2);
        std::vector<int64_t> feature_map_2_dims =
            feature_map_2.GetTensorTypeAndShapeInfo().GetShape();
        int h_2 = feature_map_2_dims[1];
        int w_2 = feature_map_2_dims[2];
        deformable_aggregation_format(stream,
                                      output.GetTensorMutableData<float>(),
                                      feature_map_0.GetTensorData<__half>(),
                                      feature_map_1.GetTensorData<__half>(),
                                      feature_map_2.GetTensorData<__half>(),
                                      points_2d.GetTensorData<float>(),
                                      weight.GetTensorData<__half>(),
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1,
                                      h_2,
                                      w_2);
        break;
      }

      if (num_scale == 4) {
        int h_0 = feature_map_0_dims[1];
        int w_0 = feature_map_0_dims[2];
        int h_1 = feature_map_1_dims[1];
        int w_1 = feature_map_1_dims[2];
        Ort::ConstValue feature_map_2 = ctx.GetInput(2);
        Ort::ConstValue feature_map_3 = ctx.GetInput(3);
        std::vector<int64_t> feature_map_2_dims =
            feature_map_2.GetTensorTypeAndShapeInfo().GetShape();
        std::vector<int64_t> feature_map_3_dims =
            feature_map_3.GetTensorTypeAndShapeInfo().GetShape();
        int h_2 = feature_map_2_dims[1];
        int w_2 = feature_map_2_dims[2];
        int h_3 = feature_map_3_dims[1];
        int w_3 = feature_map_3_dims[2];
        deformable_aggregation_format(stream,
                                      output.GetTensorMutableData<float>(),
                                      feature_map_0.GetTensorData<__half>(),
                                      feature_map_1.GetTensorData<__half>(),
                                      feature_map_2.GetTensorData<__half>(),
                                      feature_map_2.GetTensorData<__half>(),
                                      points_2d.GetTensorData<float>(),
                                      weight.GetTensorData<__half>(),
                                      num_cams,
                                      num_embeds,
                                      num_scale,
                                      num_anchors,
                                      num_pts,
                                      num_groups,
                                      h_0,
                                      w_0,
                                      h_1,
                                      w_1,
                                      h_2,
                                      w_2,
                                      h_3,
                                      w_3);
        break;
      }
    default:
      break;
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, DeformableAggregationFormatOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
