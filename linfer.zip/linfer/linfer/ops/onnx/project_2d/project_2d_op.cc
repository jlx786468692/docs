#include "project_2d_op.h"

#include <assert.h>
#include <cuda_fp16.h>

#include <cmath>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/project_2d/project_2d_kernel.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

namespace linfer {
namespace ops {
namespace onnx {

enum INPUT_POS {
  key_points = 0,
  projection_mat,
  image_wh,
};

void Project2dKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue key_points = ctx.GetInput(INPUT_POS::key_points);
  Ort::ConstValue projection_mat = ctx.GetInput(INPUT_POS::projection_mat);
  Ort::ConstValue image_wh = ctx.GetInput(INPUT_POS::image_wh);

  std::vector<int64_t> key_points_dims = key_points.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> projection_mat_dims = projection_mat.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> image_wh_dims = image_wh.GetTensorTypeAndShapeInfo().GetShape();

  int batch_size = key_points_dims[0];      // 1
  int num_anchors = key_points_dims[1];     // 600
  int num_cams = projection_mat_dims[1];    // 5
  int num_pts = key_points_dims[2];         // 13
  int num_param0 = projection_mat_dims[2];  // 4
  int num_param1 = projection_mat_dims[3];  // 4
  int num_cor = key_points_dims[3];         // 3

  std::vector<int64_t> output_dims{key_points_dims[0],
                                   key_points_dims[1],
                                   key_points_dims[2],
                                   image_wh_dims[1],
                                   image_wh_dims[2]};
  auto output = ctx.GetOutput(0, output_dims);

  cudaStream_t cuda_stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
  ONNXTensorElementDataType data_type = key_points.GetTensorTypeAndShapeInfo().GetElementType();
  switch (data_type) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
      project_2d(cuda_stream,
                 output.GetTensorMutableData<float>(),
                 key_points.GetTensorData<float>(),
                 projection_mat.GetTensorData<float>(),
                 image_wh.GetTensorData<float>(),
                 num_anchors,
                 num_cams,
                 num_pts,
                 num_param0,
                 num_param1,
                 num_cor);
      break;
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
      ASSERT(batch_size == 1);
      project_2d(cuda_stream,
                 output.GetTensorMutableData<__half>(),
                 key_points.GetTensorData<__half>(),
                 projection_mat.GetTensorData<float>(),
                 image_wh.GetTensorData<float>(),
                 num_anchors,
                 num_cams,
                 num_pts,
                 num_param0,
                 num_param1,
                 num_cor);
      break;
    default:
      break;
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, Project2dOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
