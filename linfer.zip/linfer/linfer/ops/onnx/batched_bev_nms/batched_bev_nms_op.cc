#include "batched_bev_nms_op.h"

#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/batched_bev_nms/trt_batched_bev_nms.hpp"
#include "linfer/ops/trt/common/nms/batched_nms_kernel.hpp"
#include "linfer/ops/trt/common/nms/kernel.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

namespace linfer {
namespace ops {
namespace onnx {

void TRTBatchedBEVNMSKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  Ort::ConstValue input_1 = ctx.GetInput(1);
  std::vector<int64_t> input_dims0 = input_0.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> input_dims1 = input_1.GetTensorTypeAndShapeInfo().GetShape();

  const void* const locData = input_0.GetTensorData<void>();
  const void* const confData = input_1.GetTensorData<void>();

  std::vector<int64_t> output_dims0 = {input_dims0[0], keepTopK, 6};
  std::vector<int64_t> output_dims1 = {input_dims0[0], keepTopK};
  auto output0 = ctx.GetOutput(0, output_dims0);
  auto output1 = ctx.GetOutput(1, output_dims1);
  void* nmsedDets = static_cast<void*>(output0.GetTensorMutableData<float>());
  void* nmsedLabels = static_cast<void*>(output1.GetTensorMutableData<int32_t>());
  // void* nmsedIndex = nullptr;
  // if(returnIndex)
  // {
  //     std::vector<int64_t> output_dims2 = {input_dims0[0], keepTopK};
  //     auto output2 = ctx.GetOutput(2, output_dims2);
  //     nmsedIndex = static_cast<void*>(output2.GetTensorMutableData<int32_t>());
  // }
  std::vector<int64_t> output_dims2 = {input_dims0[0], keepTopK};
  auto output2 = ctx.GetOutput(2, output_dims2);
  void* nmsedIndex = static_cast<void*>(output2.GetTensorMutableData<int32_t>());

  size_t batch_size = input_dims0[0];
  size_t boxes_size = input_dims0[1] * input_dims0[2] * input_dims0[3];
  size_t score_size = input_dims1[1] * input_dims1[2];
  size_t num_priors = input_dims0[1];
  bool shareLocation = (input_dims0[2] == 1);

  int topk = topK > 0 && topK <= input_dims1[1] ? topK : input_dims1[1];
  bool rotated = true;
  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  void* workspace = nullptr;
  size_t workspace_size = detectionInferenceWorkspaceSize(shareLocation,
                                                          batch_size,
                                                          boxes_size,
                                                          score_size,
                                                          numClasses,
                                                          num_priors,
                                                          topk,
                                                          DataType::kFLOAT,
                                                          DataType::kFLOAT);
  CHECK_CUDA(cudaMallocAsync(&workspace, workspace_size, stream));
  CHECK_CUDA(cudaMemsetAsync(workspace, 0, workspace_size, stream));

  pluginStatus_t status = nmsInference(stream,
                                       batch_size,
                                       boxes_size,
                                       score_size,
                                       shareLocation,
                                       backgroundLabelId,
                                       num_priors,
                                       numClasses,
                                       topk,
                                       keepTopK,
                                       scoreThreshold,
                                       nullptr,
                                       0,
                                       iouThreshold,
                                       DataType::kFLOAT,
                                       locData,
                                       DataType::kFLOAT,
                                       confData,
                                       nmsedDets,
                                       nmsedLabels,
                                       nmsedIndex,
                                       workspace,
                                       isNormalized,
                                       false,
                                       clipBoxes,
                                       rotated);
  CHECK_CUDA(cudaFreeAsync(workspace, stream));
  ASSERT(status == STATUS_SUCCESS);
}

REGISTER_ONNXRUNTIME_OPS(linfer, TRTBatchedBEVNMSOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
