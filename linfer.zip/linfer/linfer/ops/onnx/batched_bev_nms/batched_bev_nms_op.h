#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct TRTBatchedBEVNMSKernel {
  TRTBatchedBEVNMSKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    backgroundLabelId = static_cast<int32_t>(info.GetAttribute<int64_t>("background_label_id"));
    numClasses = static_cast<int32_t>(info.GetAttribute<int64_t>("num_classes"));
    topK = static_cast<int32_t>(info.GetAttribute<int64_t>("topk"));
    keepTopK = static_cast<int32_t>(info.GetAttribute<int64_t>("keep_topk"));
    scoreThreshold = static_cast<float>(info.GetAttribute<float>("score_threshold"));
    iouThreshold = static_cast<float>(info.GetAttribute<float>("iou_threshold"));
    isNormalized = static_cast<bool>(info.GetAttribute<int64_t>("is_normalized"));
    clipBoxes = static_cast<bool>(info.GetAttribute<int64_t>("clip_boxes"));
    returnIndex = static_cast<bool>(info.GetAttribute<int64_t>("return_index"));
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

  // bool get_returnIndex() const
  // {
  //     return returnIndex;
  // }

 private:
  int32_t backgroundLabelId;
  int32_t numClasses;
  int32_t topK;
  int32_t keepTopK;
  float scoreThreshold;
  float iouThreshold;
  bool isNormalized;
  bool clipBoxes;
  bool returnIndex;
  const OrtApi& ort_;
};

class TRTBatchedBEVNMSOp
    : public Ort::CustomOpBase<TRTBatchedBEVNMSOp, TRTBatchedBEVNMSKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new TRTBatchedBEVNMSKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "TRTBatchedBEVNMS"; }

  size_t GetInputTypeCount() const { return 2; }
  ONNXTensorElementDataType GetInputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

  size_t GetOutputTypeCount() const {
    // int num = BatchedBEVNMSKernel->get_returnIndex() ? 3 : 2;
    int num = 3;
    return num;
  }
  ONNXTensorElementDataType GetOutputType(size_t index) const {
    if (index == 1 || index == 2) {
      return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32;
    }
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
  // mutable TRTBatchedBEVNMSKernel* BatchedBEVNMSKernel;
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
