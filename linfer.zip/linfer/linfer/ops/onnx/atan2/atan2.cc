#include "atan2.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/atan2/atan2_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

void Atan2Kernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  std::vector<int64_t> input_dims_0 = input_0.GetTensorTypeAndShapeInfo().GetShape();
  Ort::ConstValue input_1 = ctx.GetInput(1);
  std::vector<int64_t> input_dims_1 = input_1.GetTensorTypeAndShapeInfo().GetShape();

  std::vector<int64_t> output_dims = input_dims_0;
  auto output = ctx.GetOutput(0, output_dims);

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  bool use_float16 =
      input_0.GetTensorTypeAndShapeInfo().GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16;
  if (use_float16) {
    linfer::ops::trt::launch_atan2_kernel(input_0.GetTensorData<__half>(),
                                          input_1.GetTensorData<__half>(),
                                          output.GetTensorMutableData<__half>(),
                                          (int)num_,
                                          stream);
  } else {  // use float32
    linfer::ops::trt::launch_atan2_kernel(input_0.GetTensorData<float>(),
                                          input_1.GetTensorData<float>(),
                                          output.GetTensorMutableData<float>(),
                                          (int)num_,
                                          stream);
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, Atan2Op);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
