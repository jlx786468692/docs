#include "checkpoint_op.h"

#include <cuda_bf16.h>
#include <cuda_fp16.h>

#include "NvInferVersion.h"
#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/debug/checkpoint.cuh"
#include "linfer/ops/trt/debug/common.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/util.h"
#include "linfer/util/print.h"
#include "linfer/util/tensor.h"

namespace linfer {
namespace ops {
namespace onnx {

static size_t get_element_size(ONNXTensorElementDataType dataType) {
  switch (dataType) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:
      return 4;
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16:
      return 2;
    default:
      std::cerr << "Unsupported data type." << std::endl;
      return 0;
  }
}

std::vector<uint32_t> get_coord_by_offset(uint32_t offset, const std::vector<int64_t>& dims) {
  std::vector<uint32_t> coord(dims.size(), 0);
  for (int idx = dims.size() - 1; idx >= 0; idx -= 1) {
    coord[idx] = offset % dims[idx];
    offset /= dims[idx];
  }
  return coord;
}

std::string get_coord_str(uint32_t offset, const std::vector<int64_t>& dims) {
  auto coor = get_coord_by_offset(offset, dims);
  std::stringstream s;
  s << "(";
  int idx = 0;
  for (; idx < coor.size() - 1; ++idx) {
    s << std::to_string(coor[idx]) << ",";
  }
  s << std::to_string(coor[idx]) << ")";
  return s.str();
}

void CheckpointKernel::print_info() {
  uint32_t abs_mismatch_num = match_result_[CKPT_ABS_MISMATCH_NUM];
  uint32_t rel_mismatch_num = match_result_[CKPT_REL_MISMATCH_NUM];
  bool match = (0 == abs_mismatch_num) && (0 == rel_mismatch_num);

  std::vector<int64_t> dims = x_info_.GetShape();
  size_t total_len = 1;
  for (size_t i = 0; i < dims.size(); ++i) {
    total_len *= dims[i];
  }
  auto vis_data_len = std::min(vis_data_len_, (int32_t)total_len);

  bool vis_meta = vis_meta_ || (!match);

  if (match) {
    printf("All is matched!\n");
  } else {
    printf("ABS MISMATCH: %u/%lu = %.2f%%. ",
           abs_mismatch_num,
           total_len,
           (100.0 * abs_mismatch_num) / total_len);
    if (abs_mismatch_num > 0) {
      printf("MaxError: %.6f, MaxErrorIndex: %s.",
             *reinterpret_cast<float*>(match_result_.data() + CKPT_ABS_MAX_ERROR),
             get_coord_str(match_result_[CKPT_ABS_MAX_ERROR_OFFSET], dims).c_str());
    }

    printf("\nREL MISMATCH: %u/%lu = %.2f%%. ",
           rel_mismatch_num,
           total_len,
           (100.0 * rel_mismatch_num) / total_len);
    if (rel_mismatch_num > 0) {
      printf("MaxError: %.6f, MaxErrorIndex: %s.",
             *reinterpret_cast<float*>(match_result_.data() + CKPT_REL_MAX_ERROR),
             get_coord_str(match_result_[CKPT_REL_MAX_ERROR_OFFSET], dims).c_str());
    }
    printf("\n");

    if (x_info_.GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
      linfer::util::print_n_data<float>(reinterpret_cast<float*>(actual_data_.data()),
                                        vis_data_len,
                                        "actual");
      linfer::util::print_n_data<float>(reinterpret_cast<float*>(expect_data_.data()),
                                        vis_data_len,
                                        "expect");
    } else if (x_info_.GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32) {
      linfer::util::print_n_data<int>(reinterpret_cast<int*>(actual_data_.data()),
                                      vis_data_len,
                                      "actual");
      linfer::util::print_n_data<int>(reinterpret_cast<int*>(expect_data_.data()),
                                      vis_data_len,
                                      "expect");
    } else {
      LCHECK_MSG(false, "unsupported datatype: " + std::to_string(x_info_.GetElementType()));
    }
  }

  if (vis_meta) {
    printf(
        "--------------------------------------------------------------------------"
        "--------------\n");
  }
}

void print_info_graph_node(void* ptr) {
  auto ckpt_ptr = static_cast<CheckpointKernel*>(ptr);
  ckpt_ptr->print_info();
}

void CheckpointKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue x = ctx.GetInput(0);
  x_info_ = x.GetTensorTypeAndShapeInfo();
  Ort::ConstValue expect_x = ctx.GetInput(1);

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  uint32_t* workspace = nullptr;
  cudaMallocAsync(&workspace, CKPT_VALID_SIZE, stream);

  std::vector<int64_t> x_dims = x.GetTensorTypeAndShapeInfo().GetShape();
  size_t total_len = 1;
  for (size_t i = 0; i < x_dims.size(); ++i) {
    total_len *= x_dims[i];
  }
  ONNXTensorElementDataType x_type = x.GetTensorTypeAndShapeInfo().GetElementType();

  if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
    trt::launch_check_kernel(expect_x.GetTensorData<float>(),
                             x.GetTensorData<float>(),
                             total_len,
                             (const uint32_t*)workspace,
                             atol_,
                             rtol_,
                             stream);
  } else if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32) {
    trt::launch_check_kernel(expect_x.GetTensorData<int32_t>(),
                             x.GetTensorData<int32_t>(),
                             total_len,
                             (const uint32_t*)workspace,
                             atol_,
                             rtol_,
                             stream);
  } else if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16) {
    trt::launch_check_kernel(expect_x.GetTensorData<__half>(),
                             x.GetTensorData<__half>(),
                             total_len,
                             (const uint32_t*)workspace,
                             atol_,
                             rtol_,
                             stream);
#if NV_TENSORRT_MAJOR >= 10
  } else if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16) {
    trt::launch_check_kernel(expect_x.GetTensorData<__nv_bfloat16>(),
                             x.GetTensorData<__nv_bfloat16>(),
                             total_len,
                             (const uint32_t*)workspace,
                             atol_,
                             rtol_,
                             stream);
#endif
  }

  if (save_path_.size() > 1) {
    std::vector<size_t> shape(x_dims.size(), 0);
    for (size_t i = 0; i < x_dims.size(); ++i) {
      shape[i] = static_cast<size_t>(x_dims[i]);
    }

    void* ptr;
    CHECK_CUDA(cudaMallocHost(&ptr, total_len * get_element_size(x_type)));
    CHECK_CUDA(cudaMemcpy(ptr,
                          x.GetTensorRawData(),
                          total_len * get_element_size(x_type),
                          cudaMemcpyDeviceToHost));

    if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "onnx_actual_value",
                                             (float*)ptr,
                                             util::DataType::kFLOAT,
                                             shape,
                                             save_path_);
    } else if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "onnx_actual_value",
                                             (int32_t*)ptr,
                                             util::DataType::kINT32,
                                             shape,
                                             save_path_);
    } else if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_BFLOAT16) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "onnx_actual_value",
                                             (__nv_bfloat16*)ptr,
                                             util::DataType::kBF16,
                                             shape,
                                             save_path_);
    } else if (x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16) {
      linfer::util::save_data_to_safetensors(util::MemoryType::CPU,
                                             "onnx_actual_value",
                                             (__half*)ptr,
                                             util::DataType::kHALF,
                                             shape,
                                             save_path_);
    }

    CHECK_CUDA(cudaFreeHost(ptr));
  }

  int vis_len = std::min(vis_data_len_, static_cast<int>(total_len)) * get_element_size(x_type);
  cudaEvent_t event;
  CHECK_CUDA((cudaEventCreate(&event)));
  CHECK_CUDA(cudaMemcpyAsync(match_result_.data(),
                             workspace,
                             CKPT_VALID_SIZE,
                             cudaMemcpyDeviceToHost,
                             stream));
  CHECK_CUDA(cudaMemcpyAsync(actual_data_.data(),
                             x.GetTensorRawData(),
                             vis_len,
                             cudaMemcpyDeviceToHost,
                             stream));
  CHECK_CUDA(cudaMemcpyAsync(expect_data_.data(),
                             expect_x.GetTensorRawData(),
                             vis_len,
                             cudaMemcpyDeviceToHost,
                             stream));
  CHECK_CUDA(cudaEventRecord(event, stream));
  CHECK_CUDA(cudaStreamWaitEvent(stream, event, 0));

  // if on graph mode, insert HostNode for print checkpoint info.
  cudaStreamCaptureStatus capture_status;
  CHECK_CUDA(cudaStreamIsCapturing(stream, &capture_status));
  if (cudaStreamCaptureStatusActive == capture_status) {
    cudaGraph_t capturing_graph;
    const cudaGraphNode_t* deps;
    size_t dep_count;
    CHECK_CUDA(cudaStreamGetCaptureInfo_v2(stream,
                                           &capture_status,
                                           nullptr,
                                           &capturing_graph,
                                           &deps,
                                           &dep_count));

    cudaGraphNode_t kernelNode;
    cudaHostNodeParams kernelNodeParams{};
    kernelNodeParams.fn = print_info_graph_node;
    kernelNodeParams.userData = this;

    CHECK_CUDA(
        cudaGraphAddHostNode(&kernelNode, capturing_graph, deps, dep_count, &kernelNodeParams));
    CHECK_CUDA(cudaStreamUpdateCaptureDependencies(stream, &kernelNode, 1, 1));
  } else {
    CHECK_CUDA(cudaStreamSynchronize(stream));
    print_info();
  }

  // copy input to output according if replay.
  int val_idx = replay_ ? expect_val_idx_ : actual_val_idx_;
  Ort::TensorTypeAndShapeInfo val_info = ctx.GetInput(val_idx).GetTensorTypeAndShapeInfo();
  size_t byte_num = GetORTTensorLenInByte(val_info);
  cudaMemcpyAsync(ctx.GetOutput(0, val_info.GetShape()).GetTensorMutableRawData(),
                  ctx.GetInput(val_idx).GetTensorRawData(),
                  byte_num,
                  cudaMemcpyDeviceToDevice,
                  stream);
  CHECK_CUDA_STATUS("CheckpointLayer::enqueue");
}

REGISTER_ONNXRUNTIME_OPS(linfer, CheckpointOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
