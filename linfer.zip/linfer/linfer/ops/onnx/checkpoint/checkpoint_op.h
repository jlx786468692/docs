#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

#include "cuda_runtime.h"

namespace linfer {
namespace ops {
namespace onnx {

struct CheckpointKernel {
  CheckpointKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    desc_ = info.GetAttribute<std::string>("desc");
    vis_meta_ = static_cast<bool>(info.GetAttribute<int64_t>("vis_meta"));
    vis_data_len_ = info.GetAttribute<int64_t>("vis_data_len");
    atol_ = info.GetAttribute<float>("atol");
    rtol_ = info.GetAttribute<float>("rtol");
    replay_ = static_cast<bool>(info.GetAttribute<int64_t>("replay"));
    save_path_ = info.GetAttribute<std::string>("save_path");
  }

  void print_info();

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  const OrtApi& ort_;

  std::string desc_;
  bool vis_meta_, replay_;
  int vis_data_len_;
  float atol_, rtol_;
  std::string save_path_;  // filepath to save actual data(trt data)
  std::vector<uint32_t> match_result_;
  std::vector<uint32_t> expect_data_;
  std::vector<uint32_t> actual_data_;

  static constexpr int actual_val_idx_ = 0;
  static constexpr int expect_val_idx_ = 1;

  Ort::TensorTypeAndShapeInfo x_info_{nullptr};
};

class CheckpointOp : public Ort::CustomOpBase<CheckpointOp, CheckpointKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new CheckpointKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "LinferCheckpoint"; }

  size_t GetInputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetInputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }
  bool GetVariadicInputHomogeneity() const { return false; }

  size_t GetOutputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetOutputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }
  bool GetVariadicOutputHomogeneity() const { return false; }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
