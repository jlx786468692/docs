#include "max_selected.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/max_selected/max_selected_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

void MaxSelectedKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  std::vector<int64_t> input_dims_0 = input_0.GetTensorTypeAndShapeInfo().GetShape();
  Ort::ConstValue input_1 = ctx.GetInput(1);
  std::vector<int64_t> input_dims_1 = input_1.GetTensorTypeAndShapeInfo().GetShape();

  std::vector<int64_t> output_dims = input_dims_0;
  output_dims[1] = input_dims_1[0];
  auto output_0 = ctx.GetOutput(0, output_dims);
  auto output_1 = ctx.GetOutput(1, output_dims);

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  int num_vectors = int(input_dims_0[0]);
  int vector_length = int(input_dims_0[1]);
  int out_vectorlength = int(output_dims[1]);
  bool use_float16 =
      input_0.GetTensorTypeAndShapeInfo().GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16;
  if (use_float16) {
    linfer::ops::trt::launch_max_selected_kernel(input_0.GetTensorData<__half>(),
                                                 input_1.GetTensorData<int>(),
                                                 output_0.GetTensorMutableData<__half>(),
                                                 output_1.GetTensorMutableData<int>(),
                                                 num_vectors,
                                                 vector_length,
                                                 out_vectorlength,
                                                 stream);
  } else {  // use float32
    linfer::ops::trt::launch_max_selected_kernel(input_0.GetTensorData<float>(),
                                                 input_1.GetTensorData<int>(),
                                                 output_0.GetTensorMutableData<float>(),
                                                 output_1.GetTensorMutableData<int>(),
                                                 num_vectors,
                                                 vector_length,
                                                 out_vectorlength,
                                                 stream);
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, MaxSelectedOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
