#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct MaxSelectedKernel {
  MaxSelectedKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  const OrtApi& ort_;
};

class MaxSelectedOp : public Ort::CustomOpBase<MaxSelectedOp, MaxSelectedKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new MaxSelectedKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "LinferMaxSelected"; }

  size_t GetInputTypeCount() const { return 2; }
  ONNXTensorElementDataType GetInputType(size_t index) const {
    if (index == 0) return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
    if (index == 1) return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32;
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED;
  }

  size_t GetOutputTypeCount() const { return 2; }
  ONNXTensorElementDataType GetOutputType(size_t index) const {
    if (index == 0) return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
    if (index == 1) return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32;
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED;
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
