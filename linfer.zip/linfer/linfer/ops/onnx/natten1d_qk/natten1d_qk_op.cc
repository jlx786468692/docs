#include "natten1d_qk_op.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/natten1d/natten1d_qk.cuh"

namespace linfer {
namespace ops {
namespace onnx {

void Natten1DQKKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  Ort::ConstValue input_1 = ctx.GetInput(1);
  Ort::ConstValue input_2 = ctx.GetInput(2);

  std::vector<int64_t> input_dims = input_0.GetTensorTypeAndShapeInfo().GetShape();
  unsigned int batch_size = static_cast<unsigned int>(input_dims[0]);
  unsigned int head_size = static_cast<unsigned int>(input_dims[1]);
  unsigned int seq_len = static_cast<unsigned int>(input_dims[2]);
  unsigned int channel_size = static_cast<unsigned int>(input_dims[3]);
  unsigned int kernel_size = static_cast<unsigned int>(kernel_size_);
  unsigned int dilation = static_cast<unsigned int>(dilation_);

  std::vector<int64_t> output_dims;
  output_dims.push_back(batch_size);
  output_dims.push_back(head_size);
  output_dims.push_back(seq_len);
  output_dims.push_back(kernel_size);

  auto output = ctx.GetOutput(0, output_dims);
  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
  ONNXTensorElementDataType data_type = input_0.GetTensorTypeAndShapeInfo().GetElementType();

  switch (data_type) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
      trt::natten1d_qk(input_0.GetTensorData<float>(),
                       input_1.GetTensorData<float>(),
                       input_2.GetTensorData<float>(),
                       output.GetTensorMutableData<float>(),
                       batch_size,
                       seq_len,
                       head_size,
                       channel_size,
                       kernel_size,
                       dilation,
                       stream);
      break;

    // case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
    //     trt::natten1d_qk(input_0.GetTensorData<__half>(),
    //     input_1.GetTensorData<__half>(), input_2.GetTensorData<__half>(),
    //             output.GetTensorMutableData<__half>(), batch_size, seq_len,
    //             head_size, channel_size, kernel_size, dilation, cudaStream_t
    //             stream);
    //     break;
    default:
      break;
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, Natten1DQKOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
