#include "mean_op.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/mean/mean_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

void MeanKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  std::vector<int64_t> input_dims = input_0.GetTensorTypeAndShapeInfo().GetShape();
  auto axis = (axis_ < 0) ? (input_dims.size() + axis_) : axis_;
  unsigned int n_left = 1, n_right = 1, n_mean = input_dims[axis];
  for (int i = 0; i < axis; i++) {
    n_left *= input_dims[i];
  }
  for (int i = axis + 1; i < input_dims.size(); i++) {
    n_right *= input_dims[i];
  }

  std::vector<int64_t> output_dims = input_dims;
  if (keepdim_ == 0) {
    output_dims.erase(output_dims.begin() + axis);
  } else {
    output_dims[axis] = 1;
  }

  auto output = ctx.GetOutput(0, output_dims);
  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  bool use_float16 =
      input_0.GetTensorTypeAndShapeInfo().GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16;
  if (use_float16) {
    trt::launch_mean_kernel(input_0.GetTensorData<__half>(),
                            output.GetTensorMutableData<__half>(),
                            n_left,
                            n_mean,
                            n_right,
                            stream);
  } else {
    // use float32
    trt::launch_mean_kernel(input_0.GetTensorData<float>(),
                            output.GetTensorMutableData<float>(),
                            n_left,
                            n_mean,
                            n_right,
                            stream);
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, MeanOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
