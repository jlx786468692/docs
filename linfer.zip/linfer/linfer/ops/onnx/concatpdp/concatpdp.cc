#include "concatpdp.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/concatpdp/concatpdp_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

void ConcatpdpKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_0 = ctx.GetInput(0);
  std::vector<int64_t> input_dims_0 = input_0.GetTensorTypeAndShapeInfo().GetShape();
  Ort::ConstValue input_1 = ctx.GetInput(1);
  std::vector<int64_t> input_dims_1 = input_1.GetTensorTypeAndShapeInfo().GetShape();

  std::vector<int64_t> output_dims;        // = input_dims_0;
  output_dims.push_back(input_dims_1[0]);  // 第一维
  output_dims.push_back(input_dims_1[1]);  // 第二维
  output_dims.push_back(input_dims_0[1]);  // 第三维
  output_dims.push_back((input_dims_0[2] + input_dims_1[3]));

  auto output = ctx.GetOutput(0, output_dims);
  // printf("%d, %d, %d, %d\n", output_dims[0], output_dims[1], output_dims[2], output_dims[3]);
  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  int size2 = input_dims_0[1];
  int size1 = input_dims_1[1];
  int size3 = input_dims_0[2];

  bool use_float16 =
      input_0.GetTensorTypeAndShapeInfo().GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16;
  if (use_float16) {
    linfer::ops::trt::launch_concat_pdp_kernel(input_0.GetTensorData<__half>(),
                                               input_1.GetTensorData<__half>(),
                                               output.GetTensorMutableData<__half>(),
                                               size1,
                                               size2,
                                               size3,
                                               stream);
  } else {  // use float32
    linfer::ops::trt::launch_concat_pdp_kernel(input_0.GetTensorData<float>(),
                                               input_1.GetTensorData<float>(),
                                               output.GetTensorMutableData<float>(),
                                               size1,
                                               size2,
                                               size3,
                                               stream);
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, ConcatpdpOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
