#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct NoKernel {
  NoKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    num_inputs_ = info.GetAttribute<int64_t>("num_inputs");
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  int64_t num_inputs_;
  const OrtApi& ort_;
};

class NoOp : public Ort::CustomOpBase<NoOp, NoKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new NoKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "LinferNoOp"; }

  size_t GetInputTypeCount() const { return 1; };  // One input
  OrtCustomOpInputOutputCharacteristic GetInputCharacteristic(size_t index) const noexcept {
    return OrtCustomOpInputOutputCharacteristic::INPUT_OUTPUT_VARIADIC;  // The input is variadic
                                                                         // (like printf)
  }
  ONNXTensorElementDataType GetInputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED;  // Input can be any type
  };
  bool GetVariadicInputHomogeneity() const {
    return false;  // Each input argument can be of different types (heterogeneous).
  }

  size_t GetOutputTypeCount() const { return 1; };  // One output only
  OrtCustomOpInputOutputCharacteristic GetOutputCharacteristic(size_t index) const noexcept {
    return OrtCustomOpInputOutputCharacteristic::INPUT_OUTPUT_VARIADIC;  // The output is variadic
  }
  ONNXTensorElementDataType GetOutputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED;  // Output can be any type
  };
  bool GetVariadicOuputHomogeneity() const {
    return false;  // Each output operand can be of different type (heterogeneous).
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
