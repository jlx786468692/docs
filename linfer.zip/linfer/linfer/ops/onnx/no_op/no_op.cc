#include "no_op.h"

#include <cuda_fp16.h>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"

namespace linfer {
namespace ops {
namespace onnx {

void NoKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  for (int i = 0; i < num_inputs_; i++) {
    Ort::ConstValue input_x = ctx.GetInput(i);
    std::vector<int64_t> input_x_dims = input_x.GetTensorTypeAndShapeInfo().GetShape();
    size_t input_x_element_count = static_cast<size_t>(Volume(input_x_dims));
    ONNXTensorElementDataType input_x_type = input_x.GetTensorTypeAndShapeInfo().GetElementType();

    auto output = ctx.GetOutput(i, input_x_dims);

    if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
      cudaMemcpyAsync(output.GetTensorMutableData<float>(),
                      input_x.GetTensorData<float>(),
                      input_x_element_count * sizeof(float),
                      cudaMemcpyDeviceToDevice,
                      stream);
    } else if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16) {
      cudaMemcpyAsync(output.GetTensorMutableData<__half>(),
                      input_x.GetTensorData<__half>(),
                      input_x_element_count * sizeof(__half),
                      cudaMemcpyDeviceToDevice,
                      stream);
    } else if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32) {
      cudaMemcpyAsync(output.GetTensorMutableData<int32_t>(),
                      input_x.GetTensorData<int32_t>(),
                      input_x_element_count * sizeof(int32_t),
                      cudaMemcpyDeviceToDevice,
                      stream);
    }
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, NoOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
