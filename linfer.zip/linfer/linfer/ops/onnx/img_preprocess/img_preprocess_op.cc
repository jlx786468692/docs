#include "img_preprocess_op.h"

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/img_preprocess/ImgPreprocess_kernel.cuh"
#include "linfer/ops/trt/mean/mean_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

int ImgPreprocessKernel::imgIdx_ = 0;
int ImgPreprocessKernel::outputIdx_ = 0;

void ImgPreprocessKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input = ctx.GetInput(0);
  std::vector<int64_t> input_dims = input.GetTensorTypeAndShapeInfo().GetShape();

  int channels_in = input_dims[2];
  ASSERT(channels_in == CHANNELS_IN);
  std::vector<int64_t> output_dims;
  output_dims.push_back(1);
  output_dims.push_back(input_dims[2]);
  if (int8Input_) {
    output_dims.push_back(input_dims[0]);
    output_dims.push_back(input_dims[1]);
  } else {
    output_dims.push_back(input_dims[0] * 2);
    output_dims.push_back(input_dims[1] * 2);
  }
  int h = output_dims[2];
  int w = output_dims[3];
  ASSERT(w % N_POINT_PER_THREAD == 0);
  ASSERT(w <= MAX_THREAD_NUMS);
  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
  auto output = ctx.GetOutput(0, output_dims);
  ImgPreprocessInference(stream,
                         input.GetTensorData<void>(),
                         output.GetTensorMutableData<void>(),
                         h,
                         w,
                         w_.data(),
                         b_.data(),
                         outputDatatype_,
                         bgr2rgb_);
}

REGISTER_ONNXRUNTIME_OPS(linfer, ImgPreprocessOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
