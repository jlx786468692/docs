#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

#include "linfer/ops/trt/img_preprocess/ImgPreprocessConfig.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

namespace linfer {
namespace ops {
namespace onnx {

struct ImgPreprocessKernel {
  ImgPreprocessKernel(const OrtApi& api, const OrtKernelInfo* kernel_info) : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    qScalse_ = info.GetAttribute<float>("QScalse");
    int8Input_ = static_cast<bool>(info.GetAttribute<int64_t>("Int8Input"));
    int outputDatatype = static_cast<int>(info.GetAttribute<int64_t>("OutputDatatype"));
    switch (outputDatatype) {
      case 0:
        outputDatatype_ = FP32;
        break;
      case 1:
        outputDatatype_ = FP16;
        break;
      case 2:
        outputDatatype_ = INT8;
        break;
      default:
        throw std::invalid_argument("ImgPreprocess OutputDatatype is not supported\n");
    }
    mean_ = info.GetAttributes<float>("Mean");
    var_ = info.GetAttributes<float>("Var");
    bgr2rgb_ = static_cast<bool>(info.GetAttribute<int64_t>("BGR2RGB"));

    w_.resize(CHANNELS_IN);
    b_.resize(CHANNELS_IN);
    mean_.resize(CHANNELS_IN);
    var_.resize(CHANNELS_IN);

    for (int i = 0; i < CHANNELS_IN; i++) {
      // 原公式：(x / 255.0 - mean) / var * qscale, 注意此时的qscale是pytorch的q算子的scale的倒数。
      // 将其化简为w*x+b
      // 因此w = qscale / 255.0 / var, b = -mean / var * qscale

      w_[i] = qScalse_ / 255.0 / var_[i];
      if (outputDatatype_ == INT8) {
        // 其中+128.5的原因是，C++中将float转为int时，是直接去尾法，例如0.9为0，
        //-0.9也为0，但是期望用四舍五入的方法将float转为int，因此在这里先提前
        //+128.5，在后面计算时减去128。
        b_[i] = -mean_[i] / var_[i] * qScalse_ + 128.5;
      } else {
        b_[i] = -mean_[i] / var_[i] * qScalse_;
      }
    }
    if (outputDatatype_ != INT8 && qScalse_ != 1.0) {
      qScalse_ = 1.0;
      printf("the QScalse is set to 1.0\n");
    }
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  static int imgIdx_;
  static int outputIdx_;
  float qScalse_;
  OutputDatatype outputDatatype_;
  bool int8Input_;
  bool bgr2rgb_;
  std::vector<float> w_;
  std::vector<float> b_;
  std::vector<float> mean_;
  std::vector<float> var_;
  const OrtApi& ort_;
};

class ImgPreprocessOp : public Ort::CustomOpBase<ImgPreprocessOp, ImgPreprocessKernel, false> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new ImgPreprocessKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "ImgPreprocess"; }

  size_t GetInputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetInputType(size_t /*index*/) const {
    // if(img_preprocess->get_int8Input())
    // {
    //     return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8;
    // }
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

  size_t GetOutputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetOutputType(size_t /*index*/) const {
    // switch (img_preprocess->get_outputDatatype())
    // {
    //     case 0:
    //         return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
    //     case 1:
    //         return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16;
    //     case 2:
    //         return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8;
    //     default:
    //         throw std::invalid_argument("ImgPreprocess OutputDatatype is not supported\n");
    // }
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
