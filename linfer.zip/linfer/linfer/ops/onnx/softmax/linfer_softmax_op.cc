#include "linfer_softmax_op.h"

#include <cmath>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/softmax/softmax_kernel.h"

namespace linfer {
namespace ops {
namespace onnx {

void LinferSoftmaxKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_X = ctx.GetInput(0);
  const float* X = input_X.GetTensorData<float>();

  std::vector<int64_t> dimensions = input_X.GetTensorTypeAndShapeInfo().GetShape();
  auto output = ctx.GetOutput(0, dimensions);
  float* out = output.GetTensorMutableData<float>();

  int64_t last_axis_len = dimensions[dimensions.size() - 1];
  int64_t other_axis_len = 1;
  for (int i = 0; i < dimensions.size() - 1; ++i) {
    other_axis_len *= dimensions[i];
  }

  cudaStream_t cuda_stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
  trt::launch_softmax_kernel(X, out, last_axis_len, other_axis_len, cuda_stream);
}

REGISTER_ONNXRUNTIME_OPS(linfer, LinferSoftmaxOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
