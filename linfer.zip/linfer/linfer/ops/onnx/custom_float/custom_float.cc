#include "custom_float.h"

#include <cuda_fp16.h>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"

namespace linfer {
namespace ops {
namespace onnx {

void CustomFloatKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue input_x = ctx.GetInput(0);
  std::vector<int64_t> input_x_dims = input_x.GetTensorTypeAndShapeInfo().GetShape();
  size_t input_x_element_count = static_cast<size_t>(Volume(input_x_dims));

  auto output = ctx.GetOutput(0, input_x_dims);

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
  cudaMemcpyAsync(output.GetTensorMutableData<float>(),
                  input_x.GetTensorData<float>(),
                  input_x_element_count * sizeof(float),
                  cudaMemcpyDeviceToDevice,
                  stream);
}

REGISTER_ONNXRUNTIME_OPS(linfer, CustomFloat);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
