#include "custom_timeline_op.h"

#include <cuda_fp16.h>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"

namespace linfer {
namespace ops {
namespace onnx {

void CustomTimelineKernel::CopyMemory(const Ort::ConstValue& input_x,
                                      Ort::UnownedValue& output,
                                      cudaStream_t& stream) {
  size_t input_x_element_count = inputs_num_;
  ONNXTensorElementDataType input_x_type = input_x.GetTensorTypeAndShapeInfo().GetElementType();

  if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
    cudaMemcpyAsync(output.GetTensorMutableData<float>(),
                    input_x.GetTensorData<float>(),
                    input_x_element_count * sizeof(float),
                    cudaMemcpyDeviceToDevice,
                    stream);
  } else if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16) {
    cudaMemcpyAsync(output.GetTensorMutableData<__half>(),
                    input_x.GetTensorData<__half>(),
                    input_x_element_count * sizeof(__half),
                    cudaMemcpyDeviceToDevice,
                    stream);
  } else if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32) {
    cudaMemcpyAsync(output.GetTensorMutableData<int32_t>(),
                    input_x.GetTensorData<int32_t>(),
                    input_x_element_count * sizeof(int32_t),
                    cudaMemcpyDeviceToDevice,
                    stream);
  } else if (input_x_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8) {
    cudaMemcpyAsync(output.GetTensorMutableData<int8_t>(),
                    input_x.GetTensorData<int8_t>(),
                    input_x_element_count * sizeof(int8_t),
                    cudaMemcpyDeviceToDevice,
                    stream);
  }
}

void CustomTimelineKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);

  for (size_t i = 0; i < inputs_num_; i++) {
    Ort::ConstValue input_x = ctx.GetInput(i);
    std::vector<int64_t> input_x_dims = input_x.GetTensorTypeAndShapeInfo().GetShape();
    auto output = ctx.GetOutput(i, input_x_dims);
    cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());
    CopyMemory(input_x, output, stream);
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, CustomTimelineOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
