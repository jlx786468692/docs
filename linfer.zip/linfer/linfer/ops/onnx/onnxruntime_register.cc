#include "onnxruntime_register.h"

#include <cmath>
#include <mutex>
#include <system_error>
#include <vector>

#include "common/ort_utils.h"

#define ORT_API_MANUAL_INIT
#include "onnxruntime_cxx_api.h"
#undef ORT_API_MANUAL_INIT

using namespace linfer::ops::onnx;

static void AddOrtCustomOpDomainToContainer(Ort::CustomOpDomain&& domain) {
  static std::vector<Ort::CustomOpDomain> ort_custom_op_domain_container;
  static std::mutex ort_custom_op_domain_mutex;
  std::lock_guard<std::mutex> lock(ort_custom_op_domain_mutex);
  ort_custom_op_domain_container.push_back(std::move(domain));
}

OrtStatus* ORT_API_CALL RegisterCustomOps(OrtSessionOptions* options, const OrtApiBase* api) {
  static Ort::Env env(OrtLoggingLevel::ORT_LOGGING_LEVEL_VERBOSE, "ONNXRuntime");
  Ort::UnownedSessionOptions session_options(options);
  OrtCUDAProviderOptions cuda_options;
  session_options.AppendExecutionProvider_CUDA(cuda_options);
  for (auto& ops_table : get_custom_ops()) {
    std::string op_name = ops_table.first;
    std::vector<OrtCustomOp*> op_list = ops_table.second;
    Ort::CustomOpDomain domain{op_name.c_str()};
    for (auto& op : op_list) {
      domain.Add(op);
    }
    session_options.Add(domain);
    AddOrtCustomOpDomainToContainer(std::move(domain));
  }
  return nullptr;
}
