#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct LinferMultiScaleDeformableAttn3DKernel {
  LinferMultiScaleDeformableAttn3DKernel(const OrtApi& api, const OrtKernelInfo* kernel_info)
      : ort_(api) {
    Ort::ConstKernelInfo info{kernel_info};
    std::vector<int64_t> img_wh = info.GetAttributes<int64_t>("img_wh");
    std::vector<int64_t> bev_wh = info.GetAttributes<int64_t>("bev_wh");

    img_w_ = static_cast<unsigned int>(img_wh[0]);
    img_h_ = static_cast<unsigned int>(img_wh[1]);
    bev_w_ = static_cast<unsigned int>(bev_wh[0]);
    bev_h_ = static_cast<unsigned int>(bev_wh[1]);
  }

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  unsigned int img_w_ = 0;
  unsigned int img_h_ = 0;
  unsigned int bev_w_ = 0;
  unsigned int bev_h_ = 0;

  const OrtApi& ort_;
};

class LinferMultiScaleDeformableAttn3DOp
    : public Ort::CustomOpBase<LinferMultiScaleDeformableAttn3DOp,
                               LinferMultiScaleDeformableAttn3DKernel> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new LinferMultiScaleDeformableAttn3DKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "LinferMultiScaleDeformableAttn3D"; }

  size_t GetInputTypeCount() const { return 7; }
  ONNXTensorElementDataType GetInputType(size_t index) const {
    if (index == 1 || index == 6) {
      return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32;
    }
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

  size_t GetOutputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetOutputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
