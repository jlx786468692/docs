#include "multi_scale_deformable_attn_3d_op.h"

#include <cuda_fp16.h>

#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/multi_scale_deformable_attn_3d/msda_3d_kernel.cuh"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/log.h"

namespace linfer {
namespace ops {
namespace onnx {

enum INOUT_POS {
  value = 0,
  value_spatial_whi = 1,
  sample_height = 2,
  attention_weight = 3,
  lidar2img = 4,
  point_cloud_range = 5,
  kernel_offset = 6,
};

void LinferMultiScaleDeformableAttn3DKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);

  Ort::ConstValue value = ctx.GetInput(INOUT_POS::value);
  Ort::ConstValue value_spatial_whi = ctx.GetInput(INOUT_POS::value_spatial_whi);
  Ort::ConstValue sample_height = ctx.GetInput(INOUT_POS::sample_height);
  Ort::ConstValue attention_weight = ctx.GetInput(INOUT_POS::attention_weight);
  Ort::ConstValue lidar2img = ctx.GetInput(INOUT_POS::lidar2img);
  Ort::ConstValue point_cloud_range = ctx.GetInput(INOUT_POS::point_cloud_range);
  Ort::ConstValue kernel_offset = ctx.GetInput(INOUT_POS::kernel_offset);

  std::vector<int64_t> value_dims = value.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> sample_height_dims = sample_height.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> value_spatial_whi_dims =
      value_spatial_whi.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> attention_weight_dims =
      attention_weight.GetTensorTypeAndShapeInfo().GetShape();
  std::vector<int64_t> kernel_offset_dims = kernel_offset.GetTensorTypeAndShapeInfo().GetShape();

  std::vector<int64_t> dimensions{sample_height_dims[0],
                                  sample_height_dims[1],
                                  value_dims[3] * value_dims[4]};

  auto output = ctx.GetOutput(0, dimensions);
  float* float_out = output.GetTensorMutableData<float>();
  __half* half_out = output.GetTensorMutableData<__half>();

  unsigned int batch_num = value_dims[0];
  unsigned int cam_num = value_dims[1];
  unsigned int value_num = value_dims[2];
  unsigned int head_num = value_dims[3];
  unsigned int channel_num = value_dims[4];
  unsigned int level_num = value_spatial_whi_dims[0];
  unsigned int query_num = attention_weight_dims[1];
  unsigned int kernel_size = kernel_offset_dims[0];

  cudaStream_t cuda_stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  uint32_t* workspace = nullptr;
  size_t workspace_size = batch_num * query_num * cam_num * (1 + 2 * head_num) * sizeof(float);
  CHECK_CUDA(cudaMallocAsync(&workspace, workspace_size, cuda_stream));
  CHECK_CUDA(cudaMemsetAsync(workspace, 0, workspace_size, cuda_stream));
  float2* point2d_norm = reinterpret_cast<float2*>(workspace);
  uint32_t* cam_hit_arr =
      reinterpret_cast<uint32_t*>(point2d_norm + batch_num * query_num * cam_num * head_num);

  if (query_num != (bev_h_ * bev_w_)) {
    LERROR_FMT(
        "query_size not equal to bev_h * bev_w, query_size: %u, bev_h: %u, bev_w: "
        "%u",
        query_num,
        bev_h_,
        bev_w_);
  }

  ONNXTensorElementDataType data_type = value.GetTensorTypeAndShapeInfo().GetElementType();

  switch (data_type) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
      // use float32
      CHECK_CUDA(cudaMemsetAsync(float_out,
                                 0,
                                 sizeof(float) * batch_num * query_num * head_num * channel_num,
                                 cuda_stream));
      trt::launch_msda3d_kernel(value.GetTensorData<float>(),
                                value_spatial_whi.GetTensorData<int32_t>(),
                                sample_height.GetTensorData<float>(),
                                attention_weight.GetTensorData<float>(),
                                lidar2img.GetTensorData<float>(),
                                point_cloud_range.GetTensorData<float>(),
                                kernel_offset.GetTensorData<int32_t>(),
                                cam_hit_arr,
                                point2d_norm,
                                float_out,
                                batch_num,
                                cam_num,
                                value_num,
                                head_num,
                                channel_num,
                                level_num,
                                img_w_,
                                img_h_,
                                bev_w_,
                                bev_h_,
                                query_num,
                                kernel_size,
                                cuda_stream);
      break;

    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
      CHECK_CUDA(cudaMemsetAsync(half_out,
                                 0,
                                 sizeof(__half) * batch_num * query_num * head_num * channel_num,
                                 cuda_stream));
      trt::launch_msda3d_kernel(value.GetTensorData<__half>(),
                                value_spatial_whi.GetTensorData<int32_t>(),
                                sample_height.GetTensorData<float>(),
                                attention_weight.GetTensorData<__half>(),
                                lidar2img.GetTensorData<float>(),
                                point_cloud_range.GetTensorData<float>(),
                                kernel_offset.GetTensorData<int32_t>(),
                                cam_hit_arr,
                                point2d_norm,
                                half_out,
                                batch_num,
                                cam_num,
                                value_num,
                                head_num,
                                channel_num,
                                level_num,
                                img_w_,
                                img_h_,
                                bev_w_,
                                bev_h_,
                                query_num,
                                kernel_size,
                                cuda_stream);
      break;

    default:
      break;
  }

  CHECK_CUDA(cudaFreeAsync(workspace, cuda_stream));
}

REGISTER_ONNXRUNTIME_OPS(linfer, LinferMultiScaleDeformableAttn3DOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
