#pragma once

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace linfer {
namespace ops {
namespace onnx {

struct MultiScaleDeformableAttnKernel {
  MultiScaleDeformableAttnKernel(const OrtApi& api, const OrtKernelInfo* /*info*/) : ort_(api) {}

  void Compute(OrtKernelContext* context);
  OrtStatusPtr ComputeV2(OrtKernelContext* context) {
    Compute(context);
    return nullptr;
  }

 private:
  bool use_h2_ = false;
  const OrtApi& ort_;
};

class MultiScaleDeformableAttnOp
    : public Ort::CustomOpBase<MultiScaleDeformableAttnOp, MultiScaleDeformableAttnKernel> {
 public:
  void* CreateKernel(const OrtApi& api, const OrtKernelInfo* info) const {
    return new MultiScaleDeformableAttnKernel(api, info);
  };
  OrtStatusPtr CreateKernelV2(const OrtApi& api,
                              const OrtKernelInfo* info,
                              void** op_kernel) const {
    *op_kernel = CreateKernel(api, info);
    return nullptr;
  }

  const char* GetExecutionProviderType() const { return provider_; };
  const char* GetName() const { return "MultiScaleDeformableAttnTRT"; }

  size_t GetInputTypeCount() const { return 4; }
  ONNXTensorElementDataType GetInputType(size_t index) const {
    if (index == 0 || index == 2 || index == 3) {
      return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
    }
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32;
  }

  size_t GetOutputTypeCount() const { return 1; }
  ONNXTensorElementDataType GetOutputType(size_t /*index*/) const {
    return ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT;
  }

 private:
  const char* provider_{"CUDAExecutionProvider"};
};

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
