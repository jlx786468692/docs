#include "multi_scale_deformable_attn_op.h"

#include <system_error>

#include "cuda_fp16.h"
#include "cuda_runtime.h"
#include "linfer/ops/onnx/common/ort_utils.h"
#include "linfer/ops/trt/multi_scale_deformable_attn/multiScaleDeformableAttnKernel.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/checkMacrosPlugin.h"

namespace linfer {
namespace ops {
namespace onnx {

void MultiScaleDeformableAttnKernel::Compute(OrtKernelContext* context) {
  Ort::KernelContext ctx(context);
  Ort::ConstValue value = ctx.GetInput(0);
  Ort::ConstValue value_spatial_shapes = ctx.GetInput(1);
  Ort::ConstValue sampling_locations = ctx.GetInput(2);
  Ort::ConstValue attention_weights = ctx.GetInput(3);

  PLUGIN_ASSERT(value_spatial_shapes.GetTensorTypeAndShapeInfo().GetElementType() ==
                ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32);
  ONNXTensorElementDataType data_type = value.GetTensorTypeAndShapeInfo().GetElementType();
  PLUGIN_ASSERT(data_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
                data_type == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16);

  std::vector<int64_t> value_dims = value.GetTensorTypeAndShapeInfo().GetShape();
  const int64_t batch = value_dims[0];
  const int64_t spatial_size = value_dims[1];
  const int64_t num_heads = value_dims[2];
  const int64_t channels = value_dims[3];

  std::vector<int64_t> value_spatial_shapes_dims =
      value_spatial_shapes.GetTensorTypeAndShapeInfo().GetShape();
  const int num_levels = value_spatial_shapes_dims[0];

  std::vector<int64_t> sampling_locations_dims =
      sampling_locations.GetTensorTypeAndShapeInfo().GetShape();
  const int num_query = sampling_locations_dims[1];
  const int num_point = sampling_locations_dims[4];

  std::vector<int64_t> output_dims;
  // B
  output_dims.push_back(sampling_locations_dims[0]);
  // Q
  output_dims.push_back(sampling_locations_dims[1]);
  // H*C
  output_dims.push_back(sampling_locations_dims[2] * value_dims[3]);

  auto output = ctx.GetOutput(0, output_dims);

  cudaStream_t stream = static_cast<cudaStream_t>(ctx.GetGPUComputeStream());

  switch (data_type) {
    case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:
      ms_deformable_im2col_cuda(value.GetTensorData<float>(),
                                value_spatial_shapes.GetTensorData<int32_t>(),
                                sampling_locations.GetTensorData<float>(),
                                attention_weights.GetTensorData<float>(),
                                batch,
                                spatial_size,
                                num_heads,
                                channels,
                                num_levels,
                                num_query,
                                num_point,
                                output.GetTensorMutableData<float>(),
                                stream);
      break;
      // case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16:
      //   if (use_h2_) {
      //     ms_deformable_im2col_cuda<__half2>(
      //         value.GetTensorData<__half2>(),
      //         value_spatial_shapes.GetTensorData<int32_t>(),
      //         sampling_locations.GetTensorData<__half2>(),
      //         attention_weights.GetTensorData<__half2>(), batch, spatial_size,
      //         num_heads, channels, num_levels, num_query, num_point,
      //         output.GetTensorMutableData<__half2>(), stream);
      //   } else {
      //     ms_deformable_im2col_cuda<__half>(
      //         value.GetTensorData<__half>(),
      //         value_spatial_shapes.GetTensorData<int32_t>(),
      //         sampling_locations.GetTensorData<__half>(),
      //         attention_weights.GetTensorData<__half>(), batch, spatial_size,
      //         num_heads, channels, num_levels, num_query, num_point,
      //         output.GetTensorMutableData<__half>(), stream);
      //   }
      //   break;
    default:
      return;
  }
}

REGISTER_ONNXRUNTIME_OPS(linfer, MultiScaleDeformableAttnOp);

}  // namespace onnx
}  // namespace ops
}  // namespace linfer
