#include <cuda_runtime_api.h>

#include <algorithm>
#include <vector>

// headers in CUDA
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/extrema.h>
#include <thrust/host_vector.h>
#include <thrust/sort.h>

#include "linfer/ops/cuda/ops.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/util/internal/cuda/util.h"

__device__ void device_calculate_src_coordinate(const double* TransformMatrix,
                                                uint2* srcCoordinate,
                                                const int src_row,
                                                const int src_col,
                                                const int dst_row,
                                                const int dst_col) {
  const double M00 = TransformMatrix[0];
  const double M01 = TransformMatrix[1];
  const double M02 = TransformMatrix[2];
  const double M10 = TransformMatrix[3];
  const double M11 = TransformMatrix[4];
  const double M12 = TransformMatrix[5];
  const double M20 = TransformMatrix[6];
  const double M21 = TransformMatrix[7];
  const double M22 = TransformMatrix[8];
  // x, y are src, u, v are dst. Search in dst. (x, y) = T^(-1)(u, v)
  for (int v = blockDim.y * blockIdx.y + threadIdx.y; v < dst_row; v = v + gridDim.y * blockDim.y) {
    for (int u = blockDim.x * blockIdx.x + threadIdx.x; u < dst_col;
         u = u + gridDim.x * blockDim.x) {
      // src_x = srcCoordinate[v * dst_col + u].x, src_y = srcCoordinate[v * dst_col + u].y
      srcCoordinate[v * src_col + u].x =
          (uint)(((M02 - u * M22) * (v * M21 - M11) - (M12 - v * M22) * (u * M21 - M01)) /
                 ((u * M20 - M00) * (v * M21 - M11) - (v * M20 - M10) * (u * M21 - M01)));
      srcCoordinate[v * src_col + u].y =
          (uint)(((M02 - u * M22) * (v * M20 - M10) - (M12 - v * M22) * (u * M20 - M00)) /
                 ((u * M21 - M01) * (v * M20 - M10) - (v * M21 - M11) * (u * M20 - M00)));
      __syncthreads();
    }
  }
}

__device__ void device_mapping(const uchar3* src,
                               uchar3* dst,
                               const uint2* srcCoordinate,
                               const int src_row,
                               const int src_col,
                               const int dst_row,
                               const int dst_col) {
  // x, y are src, u, v are dst. Search in dst.
  for (int v = blockDim.y * blockIdx.y + threadIdx.y; v < dst_row; v = v + gridDim.y * blockDim.y) {
    for (int u = blockDim.x * blockIdx.x + threadIdx.x; u < dst_col;
         u = u + gridDim.x * blockDim.x) {
      uint src_index =
          srcCoordinate[v * dst_col + u].y * src_col + srcCoordinate[v * dst_col + u].x;
      if (src_index < src_col * src_row) {
        dst[v * dst_col + u].x = src[src_index].x;
        dst[v * dst_col + u].y = src[src_index].y;
        dst[v * dst_col + u].z = src[src_index].z;
      } else {
        dst[v * dst_col + u].x = 0;
        dst[v * dst_col + u].y = 0;
        dst[v * dst_col + u].z = 0;
      }

      __syncthreads();
    }
  }
}

__global__ void warpperspective(const uchar3* src,
                                uchar3* dst,
                                const double* TransformMatrix,
                                uint2* d_srcCoordinate,
                                const int src_row,
                                const int src_col,
                                const int dst_row,
                                const int dst_col) {
  device_calculate_src_coordinate(TransformMatrix,
                                  d_srcCoordinate,
                                  src_row,
                                  src_col,
                                  dst_row,
                                  dst_col);

  device_mapping(src, dst, d_srcCoordinate, src_row, src_col, dst_row, dst_col);
}

__global__ void undistort_single_image(const uchar3* src,
                                       uchar3* dst,
                                       float* const camera_matrix,
                                       float* const distCoeffs,
                                       const int dist_len,
                                       const int width,
                                       const int height) {
  int xIndex = threadIdx.x + blockDim.x * blockIdx.x;
  int yIndex = threadIdx.y + blockDim.y * blockIdx.y;
  int idx = yIndex * width + xIndex;
  float k1 = 0.0, k2 = 0.0, p1 = 0.0, p2 = 0.0, k3 = 0.0, k4 = 0.0, k5 = 0.0, k6 = 0.0;
  float kc1 = 1.0, kc2 = 0.0, kc3 = 0.0, kc4 = 0.0, kc5 = 0.0;
  if (dist_len == 5) {
    k1 = distCoeffs[0];
    k2 = distCoeffs[1];
    p1 = distCoeffs[2];
    p2 = distCoeffs[3];
    k3 = distCoeffs[4];
  } else if (dist_len == 8) {
    k1 = distCoeffs[0];
    k2 = distCoeffs[1];
    p1 = distCoeffs[2];
    p2 = distCoeffs[3];
    k3 = distCoeffs[4];
    k4 = distCoeffs[5];
    k5 = distCoeffs[6];
    k6 = distCoeffs[7];
  } else {
    kc2 = distCoeffs[0];
    kc3 = distCoeffs[1], kc4 = distCoeffs[2], kc5 = distCoeffs[3];
  }

  float fx = camera_matrix[0];
  float fy = camera_matrix[1];
  float cx = camera_matrix[2];
  float cy = camera_matrix[3];

  int x_undist, y_undist;

  if (dist_len == 4) {
    float x_n = ((float)xIndex - cx) / fx;
    float y_n = ((float)yIndex - cy) / fy;
    float r_square = x_n * x_n + y_n * y_n;
    float r = sqrt(r_square);
    float theta = atan(r);

    float theta_3 = theta * theta * theta;
    float theta_5 = theta_3 * theta * theta;
    float theta_7 = theta_5 * theta * theta;
    float theta_9 = theta_7 * theta * theta;
    float theta_d = kc1 * theta + kc2 * theta_3 + kc3 * theta_5 + kc4 * theta_7 + kc5 * theta_9;

    float inv_r = r > 1e-8 ? 1.0 / r : 1.0;
    float cdist = r > 1e-8 ? theta_d * inv_r : 1.0;
    float x_real = x_n * cdist;
    float y_real = y_n * cdist;

    x_undist = int(x_real * fx + cx);
    y_undist = int(y_real * fy + cy);
  } else {
    float x = ((float)xIndex - cx) / fx;
    float y = ((float)yIndex - cy) / fy;
    float r_square = x * x + y * y;
    float scale =
        1 + k1 * r_square + k2 * r_square * r_square + k3 * r_square * r_square * r_square;
    float divisor =
        1 + k4 * r_square + k5 * r_square * r_square + k6 * r_square * r_square * r_square;
    float x_tangent_distort = 2 * p1 * x * y + p2 * (r_square + 2 * x * x);
    float y_tangent_distort = p1 * (r_square + 2 * y * y) + 2 * p2 * x * y;

    float x0 = x * scale / divisor + x_tangent_distort;
    float y0 = y * scale / divisor + y_tangent_distort;
    x_undist = int(x0 * fx + cx);
    y_undist = int(y0 * fy + cy);
  }

  // 最近邻
  if (x_undist >= 0 && y_undist >= 0 && x_undist < width && y_undist < height) {
    dst[idx].x = src[y_undist * width + x_undist].x;
    dst[idx].y = src[y_undist * width + x_undist].y;
    dst[idx].z = src[y_undist * width + x_undist].z;
  } else {
    dst[idx].x = 0;
    dst[idx].y = 0;
    dst[idx].z = 0;
  }
}

__global__ void undistort_(unsigned char* src,
                           unsigned char* dst,
                           float* const camera_matrix,
                           float* const distCoeffs,
                           const int* dist_len,
                           const int* dist_len_current,
                           int batchSize,
                           const int width,
                           const int height,
                           const int channel) {
  int xIndex = threadIdx.x + blockDim.x * blockIdx.x;
  int yIndex = threadIdx.y + blockDim.y * blockIdx.y;
  int idx = yIndex * width * channel + xIndex * channel;
  for (int i = blockIdx.z; i < batchSize; i += gridDim.z) {
    float k1 = 0.0, k2 = 0.0, p1 = 0.0, p2 = 0.0, k3 = 0.0, k4 = 0.0, k5 = 0.0, k6 = 0.0;
    if (dist_len[i] == 5) {
      k1 = distCoeffs[dist_len_current[i] + 0];
      k2 = distCoeffs[dist_len_current[i] + 1];
      p1 = distCoeffs[dist_len_current[i] + 2];
      p2 = distCoeffs[dist_len_current[i] + 3];
      k3 = distCoeffs[dist_len_current[i] + 4];
    } else {
      k1 = distCoeffs[dist_len_current[i] + 0];
      k2 = distCoeffs[dist_len_current[i] + 1];
      p1 = distCoeffs[dist_len_current[i] + 2];
      p2 = distCoeffs[dist_len_current[i] + 3];
      k3 = distCoeffs[dist_len_current[i] + 4];
      k4 = distCoeffs[dist_len_current[i] + 5];
      k5 = distCoeffs[dist_len_current[i] + 6];
      k6 = distCoeffs[dist_len_current[i] + 7];
    }

    float fx = camera_matrix[4 * i + 0];
    float fy = camera_matrix[4 * i + 1];
    float cx = camera_matrix[4 * i + 2];
    float cy = camera_matrix[4 * i + 3];

    float x = ((float)xIndex - cx) / fx;
    float y = ((float)yIndex - cy) / fy;
    float r_square = x * x + y * y;
    float scale =
        1 + k1 * r_square + k2 * r_square * r_square + k3 * r_square * r_square * r_square;
    float divisor =
        1 + k4 * r_square + k5 * r_square * r_square + k6 * r_square * r_square * r_square;
    float x_tangent_distort = 2 * p1 * x * y + p2 * (r_square + 2 * x * x);
    float y_tangent_distort = p1 * (r_square + 2 * y * y) + 2 * p2 * x * y;

    float x0 = x * scale / divisor + x_tangent_distort;
    float y0 = y * scale / divisor + y_tangent_distort;
    int x_undist = int(x0 * fx + cx);
    int y_undist = int(y0 * fy + cy);

    // 最近邻
    if (x_undist >= 0 && y_undist >= 0 && x_undist < width && y_undist < height) {
      dst[i * width * height * channel + idx + 0] =
          src[i * width * height * channel + y_undist * width * channel + x_undist * channel + 0];
      dst[i * width * height * channel + idx + 1] =
          src[i * width * height * channel + y_undist * width * channel + x_undist * channel + 1];
      dst[i * width * height * channel + idx + 2] =
          src[i * width * height * channel + y_undist * width * channel + x_undist * channel + 2];
    } else {
      dst[i * width * height * channel + idx + 0] = 0;
      dst[i * width * height * channel + idx + 1] = 0;
      dst[i * width * height * channel + idx + 2] = 0;
    }
  }
}

// static __global__ void resizeConvertPaddingIntPackedTo32FPlanar(const unsigned char* __restrict__
// input, int iWidth,
//                                                                 int iHeight, int iPitch, float2
//                                                                 resizeScale, float* __restrict__
//                                                                 output, int oWidth, int oHeight,
//                                                                 int padd_w, int padd_h, int
//                                                                 batchSize, float3 meanData,
//                                                                 float3 stdData) {
//     const int x = blockIdx.x * blockDim.x + threadIdx.x;  //
//     cuda线程的x索引.x对应的comuln.这里的x
//                                                           //
//                                                           y是相对输出来说的,是指输出的宽高,不是输入的.
//     const int y = blockIdx.y * blockDim.y + threadIdx.y;  // cuda线程的y索引.y对应的是row.

//     //对于padding来说,x,y还是要用包含黑边的那个大的宽高,只是下面求dx dy的时候用不包含黑边的x,y.
//     if (x >= iWidth || y >= iHeight)
//         return;

//     /*
//     resizeScale是在外面求出来的,是输入/输出.
//     resizeScale.x = (float(inputWidth) / float(outputWidth);
//     假设输入是10*10,输出是5*5,那么dx=2x,dx其实是指输入的,x是指输出的.
//     */
//     // resizeScale.y = (float(inputHeight) / float(outputHeight));
//     const int dx = ((float)x * resizeScale.x);
//     const int dy = ((float)y * resizeScale.y);
//     // printf("mean: %f, %f, %f, std: %f, %f, %f \n", meanData.x, meanData.y, meanData.z,
//     stdData.x,
//     // stdData.y, stdData.z);
//     for (int i = blockIdx.z; i < batchSize; i += gridDim.z) {
//         if ((dx < iWidth) && (dy < iHeight)) {
//             output[i * oWidth * oHeight * 3 + oWidth * oHeight * 0 + (y + padd_h) * oWidth + (x +
//             padd_w)] =
//                 ((float)(*(input + i * iHeight * iPitch + dy * iPitch + dx * 3 + 2)) -
//                 meanData.x) / stdData.x;

//             output[i * oWidth * oHeight * 3 + oWidth * oHeight * 1 + (y + padd_h) * oWidth + (x +
//             padd_w)] =
//                 ((float)(*(input + i * iHeight * iPitch + dy * iPitch + dx * 3 + 1)) -
//                 meanData.y) / stdData.y;

//             output[i * oWidth * oHeight * 3 + oWidth * oHeight * 2 + (y + padd_h) * oWidth + (x +
//             padd_w)] =
//                 ((float)(*(input + i * iHeight * iPitch + dy * iPitch + dx * 3 + 0)) -
//                 meanData.z) / stdData.z;
//         }
//         //填充0.
//         if (x < padd_w || y < padd_h || x >= (oWidth - padd_w)) {
//             output[i * oWidth * oHeight * 3 + oWidth * oHeight * 0 + y * oWidth + x] = 0;
//             output[i * oWidth * oHeight * 3 + oWidth * oHeight * 1 + y * oWidth + x] = 0;
//             output[i * oWidth * oHeight * 3 + oWidth * oHeight * 2 + y * oWidth + x] = 0;
//         }
//     }
// }

// static __global__ void resizeConvertPaddingIntPackedTo32FPlanar_1(const unsigned char*
// __restrict__ input, int iWidth,
//                                                                   int iHeight, int iPitch, float2
//                                                                   resizeScale, float*
//                                                                   __restrict__ output, int
//                                                                   oWidth, int oHeight, int
//                                                                   padd_w, int padd_h, int
//                                                                   batchSize, float3 meanData,
//                                                                   float3 stdData) {
//     const int x = blockIdx.x * blockDim.x + threadIdx.x;  //
//     cuda线程的x索引.x对应的comuln.这里的x
//                                                           //
//                                                           y是相对输出来说的,是指输出的宽高,不是输入的.
//     const int y = blockIdx.y * blockDim.y + threadIdx.y;  // cuda线程的y索引.y对应的是row.
//     const int batch_idx = blockIdx.z;

//     if (x >= oWidth || y >= oHeight)
//         return;

//     // output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 0 + y * oWidth + x] = (0 -
//     // meanData.x) / stdData.x; output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 1 +
//     y *
//     // oWidth + x] = (0 - meanData.y) / stdData.y; output[batch_idx * oWidth * oHeight * 3 +
//     oWidth
//     // * oHeight * 2 + y * oWidth + x] = (0 - meanData.z) / stdData.z; output[batch_idx * oWidth
//     *
//     // oHeight * 3 + oWidth * oHeight * 0 + y * oWidth + x] = -123.675 / 58.395; output[batch_idx
//     *
//     // oWidth * oHeight * 3 + oWidth * oHeight * 1 + y * oWidth + x] = -116.28 / 57.12;
//     // output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 2 + y * oWidth + x] = -103.53
//     // / 57.375;

//     // return;

//     if (x < padd_w || y < padd_h || x >= (oWidth - padd_w)) {
//         output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 0 + y * oWidth + x] =
//             (100.0 - meanData.x) / stdData.x;
//         output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 1 + y * oWidth + x] =
//             (2.0 - meanData.y) / stdData.y;
//         output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 2 + y * oWidth + x] =
//             (30.0 - meanData.z) / stdData.z;
//     } else {
//         float fy = (float)((y - padd_h + 0.5f) * resizeScale.y - 0.5f);
//         int sy = __float2int_rd(fy);
//         fy -= sy;
//         sy = max(0, min(sy, iHeight - 2));

//         const unsigned char* a_ptr = &input[batch_idx * iHeight * iWidth * 3 + sy * iWidth * 3];
//         const unsigned char* b_ptr = &input[batch_idx * iHeight * iWidth * 3 + (sy + 1) * iWidth
//         * 3];

//         {
//             float fx = (float)((x + 0.5f) * resizeScale.x - 0.5f);
//             int sx = __float2int_rd(fx);
//             fx -= sx;
//             fx *= ((sx >= 0) && (sx < iWidth - 1));
//             sx = max(0, min(sx, iWidth - 2));

//             // (1.0f - fx) * (aPtr[sx] * (1.0f - fy) + bPtr[sx] * fy) + fx * (aPtr[sx + 1] *
//             (1.0f -
//             // fy) + bPtr[sx + 1] * fy);

//             output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 0 + y * oWidth + x] =
//                 ((float)((1.0f - fx) * (a_ptr[sx * 3 + 2] * (1.0f - fy) + b_ptr[sx * 3 + 2] * fy)
//                 +
//                          fx * (a_ptr[(sx + 1) * 3 + 2] * (1.0f - fy) + b_ptr[(sx + 1) * 3 + 2] *
//                          fy)) -
//                  meanData.x) /
//                 stdData.x;

//             output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 1 + y * oWidth + x] =
//                 ((float)((1.0f - fx) * (a_ptr[sx * 3 + 1] * (1.0f - fy) + b_ptr[sx * 3 + 1] * fy)
//                 +
//                          fx * (a_ptr[(sx + 1) * 3 + 1] * (1.0f - fy) + b_ptr[(sx + 1) * 3 + 1] *
//                          fy)) -
//                  meanData.y) /
//                 stdData.y;

//             output[batch_idx * oWidth * oHeight * 3 + oWidth * oHeight * 2 + y * oWidth + x] =
//                 ((float)((1.0f - fx) * (a_ptr[sx * 3 + 0] * (1.0f - fy) + b_ptr[sx * 3 + 0] * fy)
//                 +
//                          fx * (a_ptr[(sx + 1) * 3 + 0] * (1.0f - fy) + b_ptr[(sx + 1) * 3 + 0] *
//                          fy)) -
//                  meanData.z) /
//                 stdData.z;
//         }
//     }
// }

__global__ void bevdet_image_process(const unsigned char* __restrict__ input,
                                     int iWidth,
                                     int iHeight,
                                     int iPitch,
                                     float2 resizeScale,
                                     float* __restrict__ output,
                                     int oWidth,
                                     int oHeight,
                                     int padd_w,
                                     int padd_h,
                                     float3 meanData,
                                     float3 stdData) {
  const int x =
      blockIdx.x * blockDim.x + threadIdx.x;  // cuda线程的x索引.x对应的comuln.这里的x
                                              // y是相对输出来说的,是指输出的宽高,不是输入的.
  const int y = blockIdx.y * blockDim.y + threadIdx.y;  // cuda线程的y索引.y对应的是row.

  if (x >= oWidth || y >= oHeight) return;

  if (x < padd_w || y < padd_h || x >= (oWidth - padd_w)) {
    output[oWidth * oHeight * 0 + y * oWidth + x] = (100.0 - meanData.x) / stdData.x;
    output[oWidth * oHeight * 1 + y * oWidth + x] = (2.0 - meanData.y) / stdData.y;
    output[oWidth * oHeight * 2 + y * oWidth + x] = (30.0 - meanData.z) / stdData.z;
  } else {
    float fy = (float)((y - padd_h + 0.5f) * resizeScale.y - 0.5f);
    int sy = __float2int_rd(fy);
    fy -= sy;
    sy = max(0, min(sy, iHeight - 2));

    const unsigned char* a_ptr = &input[sy * iWidth * 3];
    const unsigned char* b_ptr = &input[(sy + 1) * iWidth * 3];
    {
      float fx = (float)((x + 0.5f) * resizeScale.x - 0.5f);
      int sx = __float2int_rd(fx);
      fx -= sx;
      fx *= ((sx >= 0) && (sx < iWidth - 1));
      sx = max(0, min(sx, iWidth - 2));

      output[oWidth * oHeight * 0 + y * oWidth + x] =
          ((float)((1.0f - fx) * (a_ptr[sx * 3 + 2] * (1.0f - fy) + b_ptr[sx * 3 + 2] * fy) +
                   fx * (a_ptr[(sx + 1) * 3 + 2] * (1.0f - fy) + b_ptr[(sx + 1) * 3 + 2] * fy)) -
           meanData.x) /
          stdData.x;

      output[oWidth * oHeight * 1 + y * oWidth + x] =
          ((float)((1.0f - fx) * (a_ptr[sx * 3 + 1] * (1.0f - fy) + b_ptr[sx * 3 + 1] * fy) +
                   fx * (a_ptr[(sx + 1) * 3 + 1] * (1.0f - fy) + b_ptr[(sx + 1) * 3 + 1] * fy)) -
           meanData.y) /
          stdData.y;

      output[oWidth * oHeight * 2 + y * oWidth + x] =
          ((float)((1.0f - fx) * (a_ptr[sx * 3 + 0] * (1.0f - fy) + b_ptr[sx * 3 + 0] * fy) +
                   fx * (a_ptr[(sx + 1) * 3 + 0] * (1.0f - fy) + b_ptr[(sx + 1) * 3 + 0] * fy)) -
           meanData.z) /
          stdData.z;
    }
  }
}

namespace linfer {
namespace ops {
namespace cuda {

struct BEVDetParam {
  int src_h;
  int src_w;
  int vcam_h;
  int vcam_w;
  int dist_len;
  std::vector<float> dist_param;
  std::vector<float> cam_in;
  std::vector<double> warp_mat;

  int src_img_size;
  int vcam_size;

  // device
  float* dist_param_d;
  float* cam_in_d;
  double* warp_mat_d;
  u_char* src_img_d;
  u_char* undist_img_d;
  u_char* vcam_d;
  uint2* src_coord_d;
};

class BEVDetUtils::Impl {
 private:
  cudaStream_t cuda_stream_;
  const int cam_num_ = 6;
  int imgs_size_total_ = 0;
  float3 mean_data_;
  float3 std_data_;

  int net_input_w_;
  int net_input_h_;
  int net_input_size_;
  std::vector<BEVDetParam> bevdet_params_;

  // unsigned char* output_vis_;
 public:
  Impl(const std::vector<int>& src_w_vec,
       const std::vector<int>& src_h_vec,
       const std::vector<int>& vcam_w_vec,
       const std::vector<int>& vcam_h_vec,
       const int net_input_w,
       const int net_input_h,
       const std::vector<float>& mean_data,
       const std::vector<float>& std_data,
       const std::vector<int>& dist_lens,
       const std::vector<float>& dist_coeffs,
       const std::vector<float>& camera_ins,
       const std::vector<double>& warp_mats,
       void* const stream) {
    if (stream) {
      cuda_stream_ = static_cast<cudaStream_t>(stream);
    } else {
      CHECK_CUDA(cudaStreamCreateWithFlags(&cuda_stream_, cudaStreamNonBlocking));
    }
    int current_dist = 0;
    for (int i = 0; i < cam_num_; ++i) {
      BEVDetParam bevdet_param;
      bevdet_param.src_h = src_h_vec[i];
      bevdet_param.src_w = src_w_vec[i];
      bevdet_param.vcam_h = vcam_h_vec[i];
      bevdet_param.vcam_w = vcam_w_vec[i];
      bevdet_param.dist_len = dist_lens[i];

      bevdet_param.dist_param.clear();
      for (int j = 0; j < bevdet_param.dist_len; ++j) {
        bevdet_param.dist_param.emplace_back(dist_coeffs[current_dist + j]);
      }
      current_dist += bevdet_param.dist_len;
      CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&bevdet_param.dist_param_d),
                            bevdet_param.dist_len * sizeof(float)));
      CHECK_CUDA(cudaMemcpy(bevdet_param.dist_param_d,
                            bevdet_param.dist_param.data(),
                            bevdet_param.dist_len * sizeof(float),
                            cudaMemcpyHostToDevice));

      bevdet_param.cam_in.clear();
      for (int j = 0; j < 4; ++j) {
        bevdet_param.cam_in.emplace_back(camera_ins[4 * i + j]);
      }
      std::cout << std::endl;
      CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&bevdet_param.cam_in_d), 4 * sizeof(float)));
      CHECK_CUDA(cudaMemcpy(bevdet_param.cam_in_d,
                            bevdet_param.cam_in.data(),
                            4 * sizeof(float),
                            cudaMemcpyHostToDevice));

      bevdet_param.warp_mat.clear();
      for (int j = 0; j < 9; ++j) {
        bevdet_param.warp_mat.emplace_back(warp_mats[9 * i + j]);
      }
      CHECK_CUDA(
          cudaMalloc(reinterpret_cast<void**>(&bevdet_param.warp_mat_d), 9 * sizeof(double)));
      CHECK_CUDA(cudaMemcpy(bevdet_param.warp_mat_d,
                            bevdet_param.warp_mat.data(),
                            9 * sizeof(double),
                            cudaMemcpyHostToDevice));

      bevdet_param.src_img_size = bevdet_param.src_h * bevdet_param.src_w * 3;
      CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&bevdet_param.src_img_d),
                            bevdet_param.src_img_size * sizeof(u_char)));
      CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&bevdet_param.undist_img_d),
                            bevdet_param.src_img_size * sizeof(u_char)));

      bevdet_param.vcam_size = bevdet_param.vcam_h * bevdet_param.vcam_w * 3;
      CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&bevdet_param.vcam_d),
                            bevdet_param.vcam_size * sizeof(u_char)));

      cudaMalloc(reinterpret_cast<void**>(&bevdet_param.src_coord_d),
                 sizeof(uint2) * bevdet_param.src_h * bevdet_param.src_w);

      imgs_size_total_ += bevdet_param.src_img_size;

      bevdet_params_.emplace_back(bevdet_param);
    }

    net_input_h_ = net_input_h;
    net_input_w_ = net_input_w;
    net_input_size_ = cam_num_ * 3 * net_input_h_ * net_input_w_;

    mean_data_ = make_float3(mean_data[0], mean_data[1], mean_data[2]);
    std_data_ = make_float3(std_data[0], std_data[1], std_data[2]);
  }

  void operate(const std::vector<unsigned char*>& images,
               float* output,
               std::vector<u_char*> vcams) {
    for (size_t i = 0; i < images.size(); ++i) {
      if (images[i] == nullptr) {
        std::cout << "[Warning] Bevdet image preprocess input image is null \n";
        return;
      }
      CHECK_CUDA(cudaMemcpy(bevdet_params_[i].src_img_d,
                            images[i],
                            bevdet_params_[i].src_img_size * sizeof(u_char),
                            cudaMemcpyHostToDevice));

      // undist
      dim3 blockDim_undist(32, 32, 1);
      dim3 gridDim_undist(DIVUP(bevdet_params_[i].src_w, blockDim_undist.x),
                          DIVUP(bevdet_params_[i].src_h, blockDim_undist.y),
                          1);

      undistort_single_image<<<gridDim_undist, blockDim_undist, 0, cuda_stream_>>>(
          reinterpret_cast<uchar3*>(bevdet_params_[i].src_img_d),
          reinterpret_cast<uchar3*>(bevdet_params_[i].undist_img_d),
          bevdet_params_[i].cam_in_d,
          bevdet_params_[i].dist_param_d,
          bevdet_params_[i].dist_len,
          bevdet_params_[i].src_w,
          bevdet_params_[i].src_h);
      // virtual camera
      // dim3 blockDim_warp(32, 32, 1);
      // dim3 gridDim_warp(10, 10, 1);
      // warpperspective<<<gridDim_warp, blockDim_warp, 0, cuda_stream_>>>(
      //     reinterpret_cast<uchar3*>(bevdet_params_[i].undist_img_d),
      //     reinterpret_cast<uchar3*>(bevdet_params_[i].vcam_d),
      //     bevdet_params_[i].warp_mat_d, bevdet_params_[i].src_coord_d,
      //     bevdet_params_[i].src_h, bevdet_params_[i].src_w,
      //     bevdet_params_[i].vcam_h, bevdet_params_[i].vcam_w
      // );
      // CHECK_CUDA(cudaMemcpy(
      //     reinterpret_cast<void*>(vcams[i]),
      //     reinterpret_cast<void*>(bevdet_params_[i].undist_img_d),
      //     bevdet_params_[i].src_img_size * sizeof(u_char),
      //     cudaMemcpyDeviceToHost
      // ));
      // std::cout << "Warpperspective done.\n";
      float r = float(bevdet_params_[i].src_w) / float(net_input_w_);
      float2 resize_scale = make_float2(r, r);
      int inside_w = round(bevdet_params_[i].src_w / r);  // 这个是用比例进行resize之后的宽,
      int inside_h = round(bevdet_params_[i].src_h / r);  // 这个是用比例进行resize之后的高.
      float padd_w = net_input_w_ - inside_w;
      float padd_h = net_input_h_ - inside_h;
      // launch kernel
      const dim3 blockDim1(32, 32, 1);
      // grid的宽高这样求,是为了保证一个grid能够处理完一张图片.
      const dim3 gridDim1(DIVUP(net_input_w_, blockDim1.x), DIVUP(net_input_h_, blockDim1.y), 1);
      int input_pitch = bevdet_params_[i].src_w * 3;

      // resize pad normalize rgb-->bgr
      if (output == nullptr) {
        std::cout << "[Warning] Bevdet infer input memory is null \n";
        return;
      }
      bevdet_image_process<<<gridDim1, blockDim1, 0, cuda_stream_>>>(
          bevdet_params_[i].undist_img_d,
          bevdet_params_[i].src_w,
          bevdet_params_[i].src_h,
          input_pitch,
          resize_scale,
          &output[net_input_h_ * net_input_w_ * 3 * i],
          net_input_w_,
          net_input_h_,
          padd_w,
          padd_h,
          mean_data_,
          std_data_);
    }
  }

  ~Impl() {
    for (size_t i = 0; i < bevdet_params_.size(); ++i) {
      cudaFreeAsync(bevdet_params_[i].src_img_d, cuda_stream_);
      cudaFreeAsync(bevdet_params_[i].undist_img_d, cuda_stream_);
      cudaFreeAsync(bevdet_params_[i].vcam_d, cuda_stream_);
      cudaFreeAsync(bevdet_params_[i].cam_in_d, cuda_stream_);
      cudaFreeAsync(bevdet_params_[i].dist_param_d, cuda_stream_);
      cudaFreeAsync(bevdet_params_[i].src_coord_d, cuda_stream_);
      cudaFreeAsync(bevdet_params_[i].warp_mat_d, cuda_stream_);
    }
  }
};

BEVDetUtils::BEVDetUtils(const std::vector<int>& src_w_vec,
                         const std::vector<int>& src_h_vec,
                         const std::vector<int>& vcam_w_vec,
                         const std::vector<int>& vcam_h_vec,
                         const int net_input_w,
                         const int net_input_h,
                         const std::vector<float>& mean_data,
                         const std::vector<float>& std_data,
                         const std::vector<int>& dist_lens,
                         const std::vector<float>& dist_coeffs,
                         const std::vector<float>& camera_ins,
                         const std::vector<double>& warp_mats,
                         void* const stream) {
  impl_ = new Impl(src_w_vec,
                   src_h_vec,
                   vcam_w_vec,
                   vcam_h_vec,
                   net_input_w,
                   net_input_h,
                   mean_data,
                   std_data,
                   dist_lens,
                   dist_coeffs,
                   camera_ins,
                   warp_mats,
                   stream);
}

BEVDetUtils::~BEVDetUtils() { delete impl_; }

void BEVDetUtils::operate(const std::vector<unsigned char*>& images,
                          float* output,
                          std::vector<u_char*> vcams) {
  return impl_->operate(images, output, vcams);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
