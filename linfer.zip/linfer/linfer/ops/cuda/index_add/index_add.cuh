#ifndef INDEX_ADD_CUH
#define INDEX_ADD_CUH

// heders in STL
#include <cuda_runtime_api.h>

#include <iostream>
#include <string>
#include <vector>

#include "cuda_fp16.h"
#include "linfer/ops/trt/plugin.h"
#include "linfer/util/internal/trt/plugin.h"

extern __global__ void index_add(float* dest,
                                 const int* index,
                                 const float* src,
                                 size_t col_size,
                                 size_t src_nRows,
                                 size_t area_per_thread,
                                 size_t hight_per_block,
                                 int* cnt);
extern __global__ void index_add_for_scatter_const(float* dest,
                                                   const int* index,
                                                   const float* src,
                                                   size_t col_size,
                                                   size_t src_nRows,
                                                   size_t area_per_thread,
                                                   size_t hight_per_block);
extern __global__ void index_put(float* dest,
                                 const int* index,
                                 const float* src,
                                 const int N,
                                 const int M,
                                 const int src_nrow);
extern void index_add_wrapper(float* output,
                              const int* index,
                              const float* updates,
                              const size_t dest_nRows,
                              const size_t val_nRows,
                              const size_t col_size,
                              cudaStream_t stream);
extern void index_add_wrapper(__half* output,
                              const int* index,
                              const __half* updates,
                              const size_t dest_nRows,
                              const size_t val_nRows,
                              const size_t col_size,
                              cudaStream_t stream);

#endif