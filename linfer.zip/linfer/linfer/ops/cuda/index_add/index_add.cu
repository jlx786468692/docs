#include <algorithm>
#include <string>
#include <vector>

#include "cuda_fp16.h"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/plugin.h"

template <typename T>
__global__ void index_add(T* dest,
                          const int* index,
                          const T* src,
                          size_t col_size,
                          size_t dest_nRows,
                          size_t src_nRows,
                          size_t area_per_thread,
                          size_t hight_per_block) {
  for (int i = 0; i < hight_per_block; i++) {
    register int src_row = blockIdx.x * hight_per_block + i;
    if (src_row < src_nRows) {
      register int dest_row = index[src_row];
      if ((dest_row < 0) || (dest_row >= dest_nRows)) {
        continue;
      }
      for (int j = 0; j < area_per_thread; j++) {
        register int offset = threadIdx.x * area_per_thread + j;
        if (offset < col_size) {
          register T a = src[src_row * col_size + offset];
          atomicAdd(dest + dest_row * col_size + offset, a);
        }
      }
    }
  }
}

// __global__ void index_add_for_scatter_const(float* dest, const int* index, const float* src,
// size_t col_size,
//                                             size_t src_nRows, size_t area_per_thread, size_t
//                                             hight_per_block) {
//     register int offset = threadIdx.x * area_per_thread;
//     for (int i = 0; i < hight_per_block; i++) {
//         register int src_row = blockIdx.x * hight_per_block + i;
//         if (src_row < src_nRows) {
//             register int dest_row = index_const[src_row];
//             for (int j = 0; j < area_per_thread; j++) {
//                 atomicAdd(dest + dest_row * col_size + offset + j, src[src_row * col_size +
//                 offset + j]);
//             }
//         }
//     }
// }

__global__ void index_put(float* dest,
                          const int* index,
                          const float* src,
                          const int N,
                          const int M,
                          const int src_nrow) {
  register int index_idx = blockIdx.x;
  // TODO copy @ptr to shared-memory
  if (index_idx >= 0 && index_idx < src_nrow) {  // TODO
    register int dest_idx = index[index_idx] * 128 + threadIdx.x;
    register int src_idx = index_idx * 128 + threadIdx.x;  // FIXME 128

    if (src_idx >= 0 && src_idx < N && dest_idx >= 0 && dest_idx < M) {
      float* ptr = dest + dest_idx;
      // *ptr += src[src_idx];
      atomicAdd(ptr, src[src_idx]);
      // *ptr = .0;
    }
  }
}

void index_add_wrapper(float* output,
                       const int* index,
                       const float* updates,
                       const size_t dest_nRows,
                       const size_t val_nRows,
                       const size_t col_size,
                       cudaStream_t stream) {
  const size_t max_thread = 1024;
  const size_t area_per_thread = (col_size - 1) / max_thread + 1;
  const size_t thread_size = std::min(col_size, max_thread);
  const size_t max_block = 1024;
  const size_t hight_per_block = (val_nRows - 1) / max_block + 1;
  const size_t block_size = std::min(val_nRows, max_block);
  index_add<<<block_size, thread_size, 0, stream>>>((float*)output,
                                                    (const int*)index,
                                                    (const float*)updates,
                                                    col_size,
                                                    dest_nRows,
                                                    val_nRows,
                                                    area_per_thread,
                                                    hight_per_block);
  CHECK_CUDA_STATUS("index_add");
}

void index_add_wrapper(__half* output,
                       const int* index,
                       const __half* updates,
                       const size_t dest_nRows,
                       const size_t val_nRows,
                       const size_t col_size,
                       cudaStream_t stream) {
  const size_t max_thread = 1024;
  const size_t area_per_thread = (col_size - 1) / max_thread + 1;
  const size_t thread_size = std::min(col_size, max_thread);
  const size_t max_block = 1024;
  const size_t hight_per_block = (val_nRows - 1) / max_block + 1;
  const size_t block_size = std::min(val_nRows, max_block);
  index_add<<<block_size, thread_size, 0, stream>>>((__half*)output,
                                                    (const int*)index,
                                                    (const __half*)updates,
                                                    col_size,
                                                    dest_nRows,
                                                    val_nRows,
                                                    area_per_thread,
                                                    hight_per_block);
  CHECK_CUDA_STATUS("index_add");
  // cudaStreamSynchronize(stream);
  // cudaMemcpyAsync(&zero_1, cnt,  sizeof(int), cudaMemcpyDeviceToHost, stream);
  // printf("the call time is %d the val_nRows is %d the col_size is %d\n", zero_1, val_nRows,
  // col_size); cudaFree(cnt);
}