#include <cublas_v2.h>
#include <cuda_runtime.h>
#include <cuda_runtime_api.h>

#include <chrono>
#include <iostream>
#include <vector>

#include "linfer/ops/cuda/ops.h"
#include "linfer/util/log.h"
#include "spdlog/spdlog.h"

namespace linfer {
namespace ops {
namespace cuda {

// zero the specify memory
__global__ void zero(float* d, size_t n, size_t part) {
  register size_t offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register float* ptr = d + blockIdx.x * n;
  for (; offset < end; ++offset) {
    *(ptr + offset) = .0;
  }
}

// d[index[2*i], index[2*i+1]] = 1
__global__ void set_value(float* d, size_t n, const int32_t* index, size_t index_len, size_t part) {
  // TODO copy to share memory

  register size_t offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (index_len < part_end) ? index_len : part_end;
  register float* ptr = d;
  register const int32_t* ptr_index = index;
  for (; offset < end; ++offset) {
    int idx = offset * 2;
    int x = *(ptr_index + idx);
    int y = *(ptr_index + idx + 1);
    ptr[x * n + y] = 1.0;
  }
}

// m1 = m1 + m2
// matrix size: n x n
__global__ void matrix_add(float* m1, const float* m2, size_t n, size_t part) {
  register size_t offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register float* ptr_m1 = m1 + blockIdx.x * n;
  register const float* ptr_m2 = m2 + blockIdx.x * n;

  for (; offset < end; ++offset) {
    *(ptr_m1 + offset) += *(ptr_m2 + offset);
  }
}

// get index of which item is greater than @val
__global__ void greater_than(const float* m,
                             size_t n,
                             int32_t* index,
                             int32_t* len,
                             float val,
                             size_t part) {
  register size_t offset = threadIdx.x * part;
  size_t part_end = offset + part;
  register size_t end = (n < part_end) ? n : part_end;
  register const float* ptr = m + blockIdx.x * n;

  for (; offset < end; ++offset) {
    if (*(ptr + offset) > val) {
      int32_t index_offset = atomicAdd(len, 2);
      index[index_offset] = blockIdx.x;
      index[index_offset + 1] = offset;
    }
  }
}

class RelationOps::Impl {
 private:
  cudaStream_t cuda_stream_;
  cublasHandle_t cublas_handle_;
  linfer::util::Tensor1D buf_mat_;
  linfer::util::Tensor1D buf_mat_tmp_;
  linfer::util::Tensor1D buf_pair_;
  linfer::util::Tensor1D buf_pre_;
  linfer::util::Tensor1D buf_suc_;
  linfer::util::Tensor1D buf_index_len_;
  linfer::util::Tensor1D buf_index_;

  // result = m1 x m2
  // matrix size: n x n
  void matrix_mul(float* result, const float* m1, const float* m2, size_t n) {
    float alpha = 1.0f, beta = .0f;
    cublasSgemm(cublas_handle_,
                CUBLAS_OP_N,
                CUBLAS_OP_N,
                n,
                n,
                n,
                &alpha,
                m2,
                n,
                m1,
                n,
                &beta,
                result,
                n);
  }

 public:
  Impl()
      : buf_mat_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 32),
        buf_mat_tmp_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 32),
        buf_pair_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 32),
        buf_pre_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 32),
        buf_suc_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 32),
        buf_index_len_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 4),
        buf_index_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 32) {
    buf_index_len_.resize(4);

    cudaError_t err = cudaStreamCreate(&cuda_stream_);  // make cuda stream
    if (cudaSuccess != err) {
      std::string errmsg(cudaGetErrorString(err));
      throw std::runtime_error("create cuda stream fail: " + errmsg);
    }

    cublasStatus_t stat = cublasCreate(&cublas_handle_);
    if (stat != CUBLAS_STATUS_SUCCESS) {
      throw std::runtime_error("cublasCreate failed, errcode: " +
                               std::to_string(static_cast<int>(stat)));
    }

    stat = cublasSetStream(cublas_handle_, cuda_stream_);
    if (stat != CUBLAS_STATUS_SUCCESS) {
      throw std::runtime_error("cublasSetStream failed, errcode: " +
                               std::to_string(static_cast<int>(stat)));
    }
  }

  // FIXME num_lanes > 1024?
  void operate(const size_t num_lanes,
               const std::vector<int32_t>& pair,
               const std::vector<float>& pre,
               const std::vector<float>& suc,
               std::vector<int32_t>& index) {
    // resize buf (sync) and set as zero
    size_t ele_num = num_lanes * num_lanes * sizeof(float);
    buf_mat_tmp_.resize(ele_num);
    buf_mat_.resize(ele_num);
    cudaMemsetAsync(buf_index_len_.get_buf(), 0, 4, cuda_stream_);

    const size_t thread_size = 256;
    size_t part = (num_lanes + thread_size - 1) / thread_size;
    zero<<<num_lanes, 256, 0, cuda_stream_>>>((float*)buf_mat_.get_buf(), num_lanes, part);

    // copy data to device
    ele_num = pair.size();
    buf_pair_.resize(ele_num);
    cudaMemcpyAsync(buf_pair_.get_buf(),
                    pair.data(),
                    ele_num * sizeof(int32_t),
                    cudaMemcpyHostToDevice,
                    cuda_stream_);

    ele_num = pre.size();
    buf_pre_.resize(ele_num);
    cudaMemcpyAsync(buf_pre_.get_buf(),
                    pre.data(),
                    ele_num * sizeof(float),
                    cudaMemcpyHostToDevice,
                    cuda_stream_);

    ele_num = suc.size();
    buf_suc_.resize(ele_num);
    cudaMemcpyAsync(buf_suc_.get_buf(),
                    suc.data(),
                    ele_num * sizeof(float),
                    cudaMemcpyHostToDevice,
                    cuda_stream_);

    ele_num = num_lanes * num_lanes * sizeof(int32_t) * 2;
    buf_index_.resize(ele_num);

    // set 1 according pair index
    int pair_num = pair.size() / 2;
    part = (pair_num + thread_size - 1) / thread_size;
    set_value<<<1, thread_size, 0, cuda_stream_>>>((float*)buf_mat_.get_buf(),
                                                   num_lanes,
                                                   (int*)buf_pair_.get_buf(),
                                                   pair_num,
                                                   part);

    // mat = mat x (pre + suc) + mat
    part = (num_lanes + thread_size - 1) / thread_size;
    matrix_add<<<num_lanes, thread_size, 0, cuda_stream_>>>((float*)buf_pre_.get_buf(),
                                                            (float*)buf_suc_.get_buf(),
                                                            num_lanes,
                                                            part);
    matrix_mul((float*)buf_mat_tmp_.get_buf(),
               (float*)buf_mat_.get_buf(),
               (float*)buf_pre_.get_buf(),
               num_lanes);
    matrix_add<<<num_lanes, thread_size, 0, cuda_stream_>>>((float*)buf_mat_tmp_.get_buf(),
                                                            (float*)buf_mat_.get_buf(),
                                                            num_lanes,
                                                            part);

    // get index of which value is greater than 0.5
    greater_than<<<num_lanes, thread_size, 0, cuda_stream_>>>((float*)buf_mat_tmp_.get_buf(),
                                                              num_lanes,
                                                              (int32_t*)buf_index_.get_buf(),
                                                              (int32_t*)buf_index_len_.get_buf(),
                                                              0.5,
                                                              part);

    // copy index len
    int32_t index_len = 0;
    cudaMemcpyAsync(&index_len,
                    buf_index_len_.get_buf(),
                    sizeof(int32_t),
                    cudaMemcpyDeviceToHost,
                    cuda_stream_);
    cudaStreamSynchronize(cuda_stream_);

    // resize index data and then copy index data
    index.resize(index_len);
    if (index_len > 0) {
      cudaMemcpyAsync(index.data(),
                      buf_index_.get_buf(),
                      index_len * sizeof(int32_t),
                      cudaMemcpyDeviceToHost,
                      cuda_stream_);
      cudaStreamSynchronize(cuda_stream_);
    }
  }
};

RelationOps::RelationOps() { impl_ = new Impl(); }
RelationOps::~RelationOps() { delete impl_; }

void RelationOps::operator()(const size_t num_lanes,
                             const std::vector<int32_t>& pair,
                             const std::vector<float>& pre,
                             const std::vector<float>& suc,
                             std::vector<int32_t>& index) {
  impl_->operate(num_lanes, pair, pre, suc, index);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
