#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "linfer/util/tensor.h"
#include "linfer/util/util.h"
namespace linfer {
namespace ops {
namespace cuda {

/**
 * @brief Caculate graph node relation. It for Prediction module.
 * @note You can instantiate once and call any time with difference data.
 * @exception std::runtime_error
 */
class RelationOps final {
 private:
  class Impl;
  Impl* impl_;

 public:
  RelationOps& operator=(const RelationOps&) = delete;
  RelationOps(const RelationOps&) = delete;
  RelationOps(const RelationOps&&) = delete;
  RelationOps();
  ~RelationOps();

  /**
   * @brief call ops calculation
   * @param[in] num_lanes:
   * @param[in] pair: M x 2 size. format: [x1, y1, x2, y2, ..., xM, yM]
   * @param[in] pre: N x N size. N is equal to num_lanes. format: [x11, x12, ..., x1N,
   * x21, x22, ..., x2N, ..., xNN].
   * @param[in] suc: N x N size. N is equal to num_lanes. format: [x11, x12, ..., x1N,
   * x21, x22, ..., x2N, ..., xNN].
   * @param[out] index: index with format: [x1, y1, x2, y2, ...]
   * @return void
   * @exception [std::invalid_argument, std::runtime_error]
   */
  void operator()(const size_t num_lanes,
                  const std::vector<int32_t>& pair,
                  const std::vector<float>& pre,
                  const std::vector<float>& suc,
                  std::vector<int32_t>& index);
};

/**
 * @brief Voxelize the point cloud data.
 * @exception std::runtime_error
 */
class VoxelizationOp final {
 private:
  class Impl;
  Impl* impl_;

 public:
  VoxelizationOp& operator=(const VoxelizationOp&) = delete;
  VoxelizationOp(const VoxelizationOp&) = delete;
  VoxelizationOp(const VoxelizationOp&&) = delete;
  /**
   * @brief VoxelizationOp constructor
   * @param[in] voxel_size: size of voxel: [x, y, z]. typical value: [0.16, 0.16, 4].
   * @param[in] point_cloud_range: range of point cloud data,
   *            format: [start_x, start_y, start_z, end_x, end_y, end_z].
   * @param[in] max_points: max point num of each voxel.
   * @param[in] stream: computation stream.
   * @return void.
   * @exception [std::invalid_argument, std::runtime_error]
   */
  VoxelizationOp(const std::vector<float>& voxel_size,
                 const std::vector<float>& point_cloud_range,
                 size_t max_points,
                 void* stream = nullptr);

  ~VoxelizationOp();

  /**
   * @brief Voxelize the point cloud data
   * @param[in] points: point cloud data, shape: N x 4[x, y, z, intensity].
   * @return std::unordered_map<std::string, linfer::util::Tensor>.
   *          keys: [voxel, coor, point_num]
   *          voxel: voxel
   *          coor: coordinate of each voxel.
   *          point_num: point number of each voxel.
   * @warning output tensor data will be release when next VoxelizationOp::operate()
   * be called.
   * @exception [std::invalid_argument, std::runtime_error]
   */
  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> operate(
      const linfer::util::Tensor& points);
};

/**
 * @brief Voxelize the point cloud data and convert into pillar.
 * @exception std::runtime_error
 */
class Voxelization4dOp final {
 private:
  class Impl;
  Impl* impl_;

 public:
  Voxelization4dOp& operator=(const Voxelization4dOp&) = delete;
  Voxelization4dOp(const Voxelization4dOp&) = delete;
  Voxelization4dOp(const Voxelization4dOp&&) = delete;

  Voxelization4dOp(const std::vector<float>& voxel_size,
                   const std::vector<float>& point_cloud_range,
                   size_t max_points,
                   int max_voxels,
                   void* stream = nullptr);

  ~Voxelization4dOp();

  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> operate(
      const linfer::util::Tensor& points,
      size_t point_size);
};

/**
 * @brief Voxelize the point cloud data and convert into voxel.
 * @exception std::runtime_error
 */
class VoxelizationSec final {
 private:
  class Impl;
  Impl* impl_;

 public:
  VoxelizationSec& operator=(const VoxelizationSec&) = delete;
  VoxelizationSec(const VoxelizationSec&) = delete;
  VoxelizationSec(const VoxelizationSec&&) = delete;

  VoxelizationSec(const int num_threads,
                  const int max_num_points,
                  const int max_num_voxels,
                  const int max_points_per_voxel,
                  const int num_point_feature,
                  const std::vector<int> grid_size,
                  const std::vector<float> voxel_size,
                  const std::vector<float> min_range,
                  void* stream = nullptr);

  ~VoxelizationSec();

  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> operate(
      const linfer::util::Tensor& points,
      size_t point_size);
};

struct BBox {
  int class_id;
  float score, x, y, z, w, l, h, rt;

  BBox() {}

  BBox(int class_id, float score, float x, float y, float z, float w, float l, float h, float rt)
      : class_id(class_id), score(score), x(x), y(y), z(z), w(w), l(l), h(h), rt(rt) {}
};

struct LidarBBox {
  int class_id;
  float score = 0.f, x = 0.f, y = 0.f, z = 0.f, w = 0.f, l = 0.f, h = 0.f, rt = 0.f;
  int pt_num = 0;

  LidarBBox() {}

  LidarBBox(int class_id,
            float score,
            float x,
            float y,
            float z,
            float w,
            float l,
            float h,
            float rt,
            int pt_num)
      : class_id(class_id),
        score(score),
        x(x),
        y(y),
        z(z),
        w(w),
        l(l),
        h(h),
        rt(rt),
        pt_num(pt_num) {}
};

/**
 * @brief Decoder for 3d bounding box.
 * @exception std::runtime_error
 */
class BBox3DDecoderOp final {
 private:
  class Impl;
  Impl* impl_;

 public:
  BBox3DDecoderOp& operator=(BBox3DDecoderOp&) = delete;
  BBox3DDecoderOp(const BBox3DDecoderOp&) = delete;
  BBox3DDecoderOp(const BBox3DDecoderOp&&) = delete;

  /**
   * @brief BBox3DDecoderOp constructor
   * @param[in] score_thresh:
   * @param[in] nms_thresh:
   * @param[in] feature_size_x:
   * @param[in] feature_size_y:
   * @param[in] range: [start_x, start_y, end_x, end_y].
   * @param[in] prior_box_per_anchor: [size_x, size_y, size_z, yaw, z_bottom_height].
   * @param[in] stream: computation stream.
   * @return anchors.
   * @exception [std::invalid_argument, std::runtime_error]
   */
  BBox3DDecoderOp(float score_thresh,
                  float nms_thresh,
                  size_t feature_size_x,
                  size_t feature_size_y,
                  const std::vector<float>& range,
                  const std::vector<std::vector<std::vector<float>>>& prior_box_per_anchor,
                  void* stream = nullptr);

  ~BBox3DDecoderOp();

  /**
   * @brief
   * @param[in] cls: classification feature map, shape: B x (num_class x 6) x H x W.
   * @param[in] bbox: bbox feature map, shape: B x 42(7x6) x H x W.
   * @param[in] dir_cls: direction feature map, shape: B x 12(2x6) x H x W.
   * @param[out] bbox: bounding box
   * @return bboxes with class and socre, shape: N x 9[class, score, x, y, z, w, l, h,
   * yaw].
   * @exception [std::invalid_argument, std::runtime_error]
   */
  void operate(const linfer::util::Tensor& feat_cls,
               const linfer::util::Tensor& feat_bbox,
               const linfer::util::Tensor& feat_dir_cls,
               std::vector<BBox>& bbox);
};

/**
 * @brief Anchor free decoder for 3d bounding box.
 * @exception std::runtime_error
 */
class AfBBox3DDecoderOp final {
 private:
  class Impl;
  Impl* impl_;

 public:
  AfBBox3DDecoderOp& operator=(AfBBox3DDecoderOp&) = delete;
  AfBBox3DDecoderOp(const AfBBox3DDecoderOp&) = delete;
  AfBBox3DDecoderOp(const AfBBox3DDecoderOp&&) = delete;

  AfBBox3DDecoderOp(const int num_anchor,
                    const int num_class,
                    const float score_threshold,
                    const float nms_overlap_threshold,
                    const int num_box_corners,
                    const int num_output_box_feature,
                    const int grid_x_size,
                    const int grid_y_size,
                    const float pillar_x_size,
                    const float pillar_y_size,
                    const float min_x_range,
                    const float min_y_range,
                    const int stride,
                    void* stream = nullptr);

  ~AfBBox3DDecoderOp();

  void operate(const linfer::util::Tensor& rpn_heatmap_output,
               const linfer::util::Tensor& rpn_reg_output,
               const linfer::util::Tensor& rpn_height_output,
               const linfer::util::Tensor& rpn_dim_output,
               const linfer::util::Tensor& rpn_rotc_output,
               const linfer::util::Tensor& rpn_rots_output,
               std::vector<BBox>& bbox);
};

/**
 * @brief BEVDet preprocess functions for speed up.
 * @exception std::runtime_error
 */
class BEVDetUtils final {
 private:
  class Impl;
  Impl* impl_;

 public:
  BEVDetUtils& operator=(BEVDetUtils&) = delete;
  BEVDetUtils(const BEVDetUtils&) = delete;
  BEVDetUtils(const BEVDetUtils&&) = delete;

  BEVDetUtils(const std::vector<int>& src_w_vec,
              const std::vector<int>& src_h_vec,
              const std::vector<int>& vcam_w_vec,
              const std::vector<int>& vcam_h_vec,
              const int net_input_w,
              const int net_input_h,
              const std::vector<float>& mean_data,
              const std::vector<float>& std_data,
              const std::vector<int>& dist_lens,
              const std::vector<float>& dist_coeffs,
              const std::vector<float>& camera_ins,
              const std::vector<double>& warp_mats,
              void* const stream);

  ~BEVDetUtils();

  void operate(const std::vector<unsigned char*>& images,
               float* output,
               std::vector<u_char*> vcams);
};

/**
 * @brief Anchor free decoder for 3d bounding box.
 * @exception std::runtime_error
 */
class BEVDetBBox3DDecoderOp final {
 private:
  class Impl;
  Impl* impl_;

 public:
  BEVDetBBox3DDecoderOp& operator=(BEVDetBBox3DDecoderOp&) = delete;
  BEVDetBBox3DDecoderOp(const BEVDetBBox3DDecoderOp&) = delete;
  BEVDetBBox3DDecoderOp(const BEVDetBBox3DDecoderOp&&) = delete;

  BEVDetBBox3DDecoderOp(const int num_anchor,
                        const int num_class,
                        const float score_threshold,
                        const float nms_overlap_threshold,
                        const int num_box_corners,
                        const int num_output_box_feature,
                        const int grid_x_size,
                        const int grid_y_size,
                        const float voxel_x_size,
                        const float voxel_y_size,
                        const float min_x_range,
                        const float min_y_range,
                        const float out_size_factor,
                        const int* group,
                        void* stream = nullptr);

  ~BEVDetBBox3DDecoderOp();

  void operate(const linfer::util::Tensor& heatmap_output,
               const linfer::util::Tensor& reg_output,
               const linfer::util::Tensor& height_output,
               const linfer::util::Tensor& dim_output,
               const linfer::util::Tensor& rot_output,
               std::vector<BBox>& bbox);
};

// TODO create cuda stream.

enum {
  VU_RGB = 0,
  VU_BGR = VU_RGB,
  VU_BGR2RGB = 1,
  VU_RGB2BGR = VU_BGR2RGB,
};
class VisionUtils {
 public:
  VisionUtils(const size_t buffer_size, void* const stream);
  VisionUtils(const size_t buffer_size,
              const float* mean,
              const float* std,
              const size_t channels,
              void* const stream);
  VisionUtils(const float* mean, const float* std, const size_t channels, void* const stream);
  /**
   * @brief Format BHWC -> BCHW and BGR -> RGB
   * @exception return false
   */
  bool TensorFormat(float* const input,
                    const size_t batch_size,
                    const size_t input_size,
                    const size_t input_channels,
                    const bool convert_color,
                    float* const output,
                    void* const stream);

  /**
   * @brief Format BHWC -> BCHW and BGR -> RGB and normalize, mean and std for rgb
   * @exception return false
   */
  bool TensorFormatAndNormalize(float* const input,
                                const size_t batch_size,
                                const size_t input_size,
                                const size_t input_channels,
                                const bool convert_color,
                                float* const output,
                                void* const stream);
  bool DeviceImageFormatAndNormalize(uint8_t* const input,
                                     const size_t batch_size,
                                     const size_t input_size,
                                     const size_t input_channels,
                                     const bool convert_color,
                                     float* const output,
                                     void* const stream);

 private:
  float* input_buffer_;
  float* mean_;
  float* std_;
};

class Bbox3dUtils {
 public:
  const int* GetHostOutputs();
  //  Bbox3dUtils(const size_t buffer_size, void* const stream);
  Bbox3dUtils(void* stream, const size_t det_size);
  void Reset(const size_t det_size);
  bool CountBboxPointcloud(const linfer::util::Tensor& points,
                           const size_t points_size,
                           const float* inputs_dets,
                           const size_t det_size,
                           const int* inputs_labels,
                           const size_t max_det_size);
  bool CountBboxPointcloudfast(const linfer::util::Tensor& points,
                               const size_t points_size,
                               const float* inputs_dets,
                               const size_t det_size,
                               const int* inputs_labels,
                               const size_t max_det_size);
  ~Bbox3dUtils();

 private:
  void* stream_;
  linfer::util::Tensor2D points_;
  std::vector<int, linfer::util::PinnedMemAllocator<int>> data_;
  std::vector<int, linfer::util::PinnedMemAllocator<int>> sub_data_;
};

// class Bbox3dUtilsExtra {
//  public:
//     const float* get_idx_output(); // for every bbox, its size is 2 x 4 x 128. 2
//     means x and y. the order of index is considered. const char* get_flag_output();
//     // if get_flag_output value is 0, the corresponde idx is invalid. int
//     output_size_of_per_bbox(); //
//     //  Bbox3dUtils(const size_t buffer_size, void* const stream);
//     Bbox3dUtilsExtra(void* stream, const size_t det_size);
//     void Reset(const size_t det_size);
//     bool Bbox_point_convex_hull(const linfer::util::Tensor& points, const size_t
//     points_size, const float* inputs_dets,
//                            const size_t det_size, const int* inputs_labels, const
//                            size_t max_det_size);
//     ~Bbox3dUtilsExtra();

//  private:
//     void reset_occupancy_flag(cudaStream_t* stream, const size_t det_size);

//     void* stream_;
//     linfer::util::Tensor2D points_;
//    //  std::vector<int, linfer::util::PinnedMemAllocator<int>> output_num;
//     std::vector<float, linfer::util::PinnedMemAllocator<float>> new_length_;
//     std::vector<float, linfer::util::PinnedMemAllocator<float>> point_idx_in_pixel_;
//     std::vector<char, linfer::util::PinnedMemAllocator<char>> occupancy_flag_;
//     std::vector<char, linfer::util::PinnedMemAllocator<char>> occupancy_flag_zero_;
//     std::vector<float, linfer::util::PinnedMemAllocator<float>> convex_output_;
//     std::vector<char, linfer::util::PinnedMemAllocator<char>> point_flag_;

// };

class E2ePredictionUtils final {
 private:
  class Impl;
  Impl* impl_;

 public:
  E2ePredictionUtils& operator=(E2ePredictionUtils&) = delete;
  E2ePredictionUtils(const E2ePredictionUtils&) = delete;
  E2ePredictionUtils(const E2ePredictionUtils&&) = delete;

  E2ePredictionUtils(const int32_t channels,
                     const int32_t src_width,
                     const int32_t src_height,
                     const int32_t resized_cols,
                     const int32_t resized_rows,
                     const int32_t cropTop,
                     const int32_t cropBottom,
                     const int32_t cropLeft,
                     const int32_t cropRight,
                     bool is_devcar,
                     void* const stream);

  ~E2ePredictionUtils();

  void operate(const uint8_t* images, float* output);
};

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
