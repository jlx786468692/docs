#include <cublas_v2.h>
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <thrust/device_ptr.h>
#include <thrust/execution_policy.h>
#include <thrust/pair.h>
#include <thrust/sort.h>
#include <thrust/unique.h>
// #include <unistd.h>

// #include <fstream>
#include <iostream>

#include "linfer/ops/cuda/ops.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/ops/trt/spconv/centerpoint_util.h"

__global__ void make_voxel_idx(float* dev_input_data,
                               int* dev_points_id,
                               int* dev_sorted_idx,
                               int input_pts_nums,
                               float min_x_range,
                               float min_y_range,
                               float min_z_range,
                               float voxel_x_size,
                               float voxel_y_size,
                               float voxel_z_size,
                               int voxel_x_dim,
                               int voxel_y_dim,
                               int voxel_z_dim,
                               int num_point_feature,
                               int* valid_pts) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= input_pts_nums) {
    return;
  }
  dev_points_id[idx] = idx;

  int y_coor = floor((dev_input_data[idx * num_point_feature + 1] - min_y_range) / voxel_y_size);
  int x_coor = floor((dev_input_data[idx * num_point_feature + 0] - min_x_range) / voxel_x_size);
  int z_coor = floor((dev_input_data[idx * num_point_feature + 2] - min_z_range) / voxel_z_size);

  if (x_coor >= 0 && x_coor < voxel_x_dim && y_coor >= 0 && y_coor < voxel_y_dim && z_coor >= 0 &&
      z_coor < voxel_z_dim) {
    dev_sorted_idx[idx] = z_coor * voxel_x_dim * voxel_y_dim + y_coor * voxel_x_dim + x_coor;
    atomicAdd(valid_pts, 1);
  } else {
    dev_sorted_idx[idx] = INT_MAX;
  }
}

__global__ void make_voxel_nums(int* sorted_idx,
                                int* points_num,
                                int* idx_ref_voxel_idx,
                                int input_pts_nums,
                                const int max_points_per_voxel) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= input_pts_nums) return;
  idx_ref_voxel_idx[idx] = idx;
  // if(idx == input_pts_nums - 1) {
  //   printf("last idx:%d\n",sorted_idx[idx]);
  // }
  if (idx != 0) {
    if (sorted_idx[idx - 1] != sorted_idx[idx]) {
      int num_count = 1;
      while (sorted_idx[idx] == sorted_idx[idx + num_count] && num_count < max_points_per_voxel) {
        num_count++;
      }
      points_num[idx] = num_count;
    }
  } else {
    int num_count = 1;
    while (sorted_idx[idx] == sorted_idx[idx + num_count] && num_count < max_points_per_voxel) {
      num_count++;
    }
    points_num[idx] = num_count;
  }
}

__global__ void make_voxel_features(float* dev_input_data,
                                    float* voxel_data,
                                    int* voxel_idx,
                                    int* voxel_num,
                                    int* dev_points_num,
                                    int* dev_points_id,
                                    int* dev_idx_ref_voxel_idx,
                                    int* dev_sorted_idx,
                                    int max_voxel_num,
                                    int point_feature_size,
                                    int voxel_x_dim,
                                    int voxel_y_dim,
                                    int voxel_z_dim) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= max_voxel_num) return;
  int start_point = dev_idx_ref_voxel_idx[idx];
  const int pts_num = dev_points_num[start_point];

#pragma unroll
  for (size_t feat_ind = 0; feat_ind < point_feature_size; feat_ind++) {
    float temp_sum = 0;
#pragma unroll
    for (size_t i = 0; i < pts_num; i++) {
      int ref_pt_id = dev_points_id[start_point + i];
      temp_sum += dev_input_data[point_feature_size * ref_pt_id + feat_ind];
    }
    voxel_data[idx * point_feature_size + feat_ind] = temp_sum / pts_num;
  }
  atomicAdd(voxel_num, 1);
  voxel_idx[idx * 4 + 0] = 0;
  voxel_idx[idx * 4 + 1] = dev_sorted_idx[idx] / (voxel_x_dim * voxel_y_dim);
  voxel_idx[idx * 4 + 2] =
      (dev_sorted_idx[idx] - (voxel_idx[idx * 4 + 1] * voxel_x_dim * voxel_y_dim)) / voxel_x_dim;
  voxel_idx[idx * 4 + 3] = dev_sorted_idx[idx] -
                           voxel_idx[idx * 4 + 1] * voxel_x_dim * voxel_y_dim -
                           voxel_x_dim * voxel_idx[idx * 4 + 2];
}

namespace linfer {
namespace ops {
namespace cuda {

class VoxelizationSec::Impl {
 private:
  // initializer list
  cudaStream_t stream_ = 0;
  const int num_threads_;
  const int max_num_points_;
  const int max_num_voxels_;
  const int max_num_points_per_voxel_;
  const int num_point_feature_;

  const int grid_x_size_;
  const int grid_y_size_;
  const int grid_z_size_;
  const float voxel_x_size_;
  const float voxel_y_size_;
  const float voxel_z_size_;
  const float min_x_range_;
  const float min_y_range_;
  const float min_z_range_;
  // end initializer list

  // device data
  linfer::util::Tensor2D points_;
  // middle data
  std::shared_ptr<linfer::util::Tensor1D> dev_sorted_idx_;
  std::shared_ptr<linfer::util::Tensor1D> dev_points_id_;
  std::shared_ptr<linfer::util::Tensor1D> dev_points_num_;
  std::shared_ptr<linfer::util::Tensor1D> dev_idx_ref_voxel_idx_;
  std::shared_ptr<linfer::util::Tensor1D> dev_valid_pts_;

  // device data --> output data
  std::shared_ptr<linfer::util::Tensor> dev_features_;
  std::shared_ptr<linfer::util::Tensor> dev_coors_;
  std::shared_ptr<linfer::util::Tensor> dev_voxel_cnt_;

 public:
  Impl(const int num_threads,
       const int max_num_points,
       const int max_num_voxels,
       const int max_points_per_voxel,
       const int num_point_feature,
       const std::vector<int> grid_size,
       const std::vector<float> voxel_size,
       const std::vector<float> min_range,
       void* stream = nullptr);
  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> operate(
      const linfer::util::Tensor& points,
      size_t point_size);
};

VoxelizationSec::Impl::Impl(const int num_threads,
                            const int max_num_points,
                            const int max_num_voxels,
                            const int max_points_per_voxel,
                            const int num_point_feature,
                            const std::vector<int> grid_size,
                            const std::vector<float> voxel_size,
                            const std::vector<float> min_range,
                            void* stream)
    : points_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 1, 5),
      num_threads_(num_threads),
      max_num_points_(max_num_points),
      max_num_voxels_(max_num_voxels),
      max_num_points_per_voxel_(max_points_per_voxel),
      num_point_feature_(num_point_feature),
      grid_x_size_(grid_size[0]),
      grid_y_size_(grid_size[1]),
      grid_z_size_(grid_size[2]),
      voxel_x_size_(voxel_size[0]),
      voxel_y_size_(voxel_size[1]),
      voxel_z_size_(voxel_size[2]),
      min_x_range_(min_range[0]),
      min_y_range_(min_range[1]),
      min_z_range_(min_range[2]) {
  if (stream) {
    stream_ = static_cast<cudaStream_t>(stream);
  } else {
    BASE_CUDA_CHECK(cudaStreamCreate(&stream_));
  }
  // init middle features
  dev_sorted_idx_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                                   util::DataType::kINT32,
                                                   nullptr,
                                                   max_num_points_));
  dev_points_id_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                                  util::DataType::kINT32,
                                                  nullptr,
                                                  max_num_points_));
  dev_points_num_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                                   util::DataType::kINT32,
                                                   nullptr,
                                                   max_num_points_));
  dev_idx_ref_voxel_idx_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                                          util::DataType::kINT32,
                                                          nullptr,
                                                          max_num_points_));
  dev_valid_pts_.reset(
      new linfer::util::Tensor1D(util::DeviceType::GPU, util::DataType::kINT32, nullptr, 1));
  // init output data
  dev_features_.reset(new linfer::util::Tensor4D(util::DeviceType::GPU,
                                                 util::DataType::kFLOAT,
                                                 nullptr,
                                                 1,
                                                 1,
                                                 max_num_voxels,
                                                 num_point_feature));
  dev_coors_.reset(new linfer::util::Tensor3D(util::DeviceType::GPU,
                                              util::DataType::kINT32,
                                              nullptr,
                                              1,
                                              max_num_voxels,
                                              4));
  dev_voxel_cnt_.reset(
      new linfer::util::Tensor2D(util::DeviceType::GPU, util::DataType::kINT32, nullptr, 1, 1));
}

std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>>
VoxelizationSec::Impl::operate(const linfer::util::Tensor& points, size_t point_size) {
  float* points_device_buf = nullptr;
  if (linfer::util::DeviceType::CPU == points.get_devicetype()) {
    points_.resize(points.get_dims());
    cudaMemcpyAsync(points_.get_buf(),
                    points.get_buf(),
                    points.get_len_in_byte(),
                    cudaMemcpyHostToDevice,
                    stream_);
    points_device_buf = (float*)points_.get_buf();
  } else {
    points_device_buf = (float*)points.get_buf();
  }
  BASE_CUDA_CHECK(
      cudaMemsetAsync(dev_sorted_idx_->get_buf(), 127, max_num_points_ * sizeof(int), stream_));
  BASE_CUDA_CHECK(
      cudaMemsetAsync(dev_points_id_->get_buf(), -1, max_num_points_ * sizeof(int), stream_));
  BASE_CUDA_CHECK(
      cudaMemsetAsync(dev_points_num_->get_buf(), 0, max_num_points_ * sizeof(int), stream_));
  BASE_CUDA_CHECK(cudaMemsetAsync(dev_idx_ref_voxel_idx_->get_buf(),
                                  127,
                                  max_num_points_ * sizeof(int),
                                  stream_));
  BASE_CUDA_CHECK(cudaMemsetAsync(dev_valid_pts_->get_buf(), 0, sizeof(int), stream_));

  BASE_CUDA_CHECK(cudaMemsetAsync(dev_voxel_cnt_->get_buf(), 0, sizeof(int), stream_));
  int num_block = DIVUP(point_size, num_threads_);
  make_voxel_idx<<<num_block, num_threads_, 0, stream_>>>(points_device_buf,
                                                          (int*)dev_points_id_->get_buf(),
                                                          (int*)dev_sorted_idx_->get_buf(),
                                                          point_size,
                                                          min_x_range_,
                                                          min_y_range_,
                                                          min_z_range_,
                                                          voxel_x_size_,
                                                          voxel_y_size_,
                                                          voxel_z_size_,
                                                          grid_x_size_,
                                                          grid_y_size_,
                                                          grid_z_size_,
                                                          num_point_feature_,
                                                          (int*)dev_valid_pts_->get_buf());

  // Use thrust::device_ptr for better compatibility
  thrust::device_ptr<int> d_sorted_idx_ptr((int*)dev_sorted_idx_->get_buf());
  thrust::device_ptr<int> d_points_id_ptr((int*)dev_points_id_->get_buf());
  thrust::device_ptr<int> d_idx_ref_voxel_idx_ptr((int*)dev_idx_ref_voxel_idx_->get_buf());

  thrust::sort_by_key(thrust::cuda::par.on(stream_),
                      d_sorted_idx_ptr,
                      d_sorted_idx_ptr + point_size,
                      d_points_id_ptr);

  int valid_pts = 0;
  BASE_CUDA_CHECK(cudaMemcpyAsync(&valid_pts,
                                  (int*)dev_valid_pts_->get_buf(),
                                  sizeof(int),
                                  cudaMemcpyDeviceToHost,
                                  stream_));
  // std::cout << "valid_pts:" << valid_pts << std::endl;
  make_voxel_nums<<<num_block, num_threads_, 0, stream_>>>((int*)dev_sorted_idx_->get_buf(),
                                                           (int*)dev_points_num_->get_buf(),
                                                           (int*)dev_idx_ref_voxel_idx_->get_buf(),
                                                           valid_pts,
                                                           max_num_points_per_voxel_);

  // Use thrust::unique_by_key with device_ptr for better compatibility
  auto new_end = thrust::unique_by_key(thrust::cuda::par.on(stream_),
                                       d_sorted_idx_ptr,
                                       d_sorted_idx_ptr + valid_pts,
                                       d_idx_ref_voxel_idx_ptr);

  int host_voxel_num = new_end.first - d_sorted_idx_ptr;
  int block = DIVUP(host_voxel_num, num_threads_);
  make_voxel_features<<<block, num_threads_, 0, stream_>>>(points_device_buf,
                                                           (float*)dev_features_->get_buf(),
                                                           (int*)dev_coors_->get_buf(),
                                                           (int*)dev_voxel_cnt_->get_buf(),
                                                           (int*)dev_points_num_->get_buf(),
                                                           (int*)dev_points_id_->get_buf(),
                                                           (int*)dev_idx_ref_voxel_idx_->get_buf(),
                                                           (int*)dev_sorted_idx_->get_buf(),
                                                           host_voxel_num,
                                                           num_point_feature_,
                                                           grid_x_size_,
                                                           grid_y_size_,
                                                           grid_z_size_);

  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> output;

  output["features_0_SubMConv3d"] = dev_features_;
  output["coors_0_SubMConv3d"] = dev_coors_;
  output["voxel_num_0_SubMConv3d"] = dev_voxel_cnt_;

  return output;
}

VoxelizationSec::VoxelizationSec(const int num_threads,
                                 const int max_num_points,
                                 const int max_num_voxels,
                                 const int max_points_per_voxel,
                                 const int num_point_feature,
                                 const std::vector<int> grid_size,
                                 const std::vector<float> voxel_size,
                                 const std::vector<float> min_range,
                                 void* stream) {
  impl_ = new Impl(num_threads,
                   max_num_points,
                   max_num_voxels,
                   max_points_per_voxel,
                   num_point_feature,
                   grid_size,
                   voxel_size,
                   min_range,
                   stream);
}

VoxelizationSec::~VoxelizationSec() { delete impl_; }

std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> VoxelizationSec::operate(
    const linfer::util::Tensor& points,
    size_t point_size) {
  return impl_->operate(points, point_size);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer