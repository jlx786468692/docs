#include <cublas_v2.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_runtime_api.h>

#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>

#include "fmt/format.h"
#include "linfer/ops/cuda/ops.h"
#include "linfer/util/internal/cuda/util.h"

// const int WARP_SIZE = 40;           // one warp(20 threads) for one pillar
const int WARPS_PER_BLOCK = 4;      // four warp for one block
const int THREADS_FOR_VOXEL = 512;  // threads number for a block
const int FEATURES_SIZE = 10;       // features maps number

/**
 * @brief count the number of points in each voxel, transfer the point data to
 * voxel data with the shape of [grid_x][grid_y][max_pts_per_voxel][feature
 * size]
 *
 * @param points : input points features
 * @param points_size : input points size
 * @param min_x_range : min range in x-axis for voxels
 * @param max_x_range : max range in x-axis for voxels
 * @param min_y_range : min range in y-axis for voxels
 * @param max_y_range : max range in y-axis for voxels
 * @param min_z_range : min range in z-axis for voxels
 * @param max_z_range : max range in z-axis for voxels
 * @param pillar_x_size : voxels size in x-axis
 * @param pillar_y_size : voxels size in y-axis
 * @param pillar_z_size : voxels size in z-axis
 * @param grid_y_size : total number of grid in y-axis
 * @param grid_x_size : total number of grid in x-axis
 * @param max_points_per_voxel : max calculate points for each voxel
 * @param mask : count of points in each voxel
 * @param voxels : point feature in voxel order
 * @param max_voxels : max number of voxel
 * @return void
 * @exception [std::invalid_argument, std::runtime_error]
 */
__global__ void generateVoxels_random_kernel(float* points,
                                             size_t points_size,
                                             float min_x_range,
                                             float max_x_range,
                                             float min_y_range,
                                             float max_y_range,
                                             float min_z_range,
                                             float max_z_range,
                                             float pillar_x_size,
                                             float pillar_y_size,
                                             float pillar_z_size,
                                             int grid_z_size,
                                             int grid_y_size,
                                             int grid_x_size,
                                             int max_points_per_voxel,
                                             unsigned int* mask,
                                             float* voxels) {
  int point_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (point_idx >= points_size) {
    return;
  }

  float4 point;
  point.x = points[point_idx * 4 + 0];
  point.y = points[point_idx * 4 + 1];
  point.z = points[point_idx * 4 + 2];
  point.w = points[point_idx * 4 + 3];
  // __syncthreads();

  int voxel_idx = floorf((point.x - min_x_range) / pillar_x_size);
  int voxel_idy = floorf((point.y - min_y_range) / pillar_y_size);
  int voxel_idz = floorf((point.z - min_z_range) / pillar_z_size);
  if (voxel_idx < 0 || voxel_idx >= grid_x_size || voxel_idy < 0 || voxel_idy >= grid_y_size ||
      voxel_idz < 0 || voxel_idz >= grid_z_size) {
    return;
  }

  unsigned int voxel_index = voxel_idy * grid_x_size + voxel_idx;

  unsigned int point_id = atomicAdd(&(mask[voxel_index]), 1);
  if (point_id >= max_points_per_voxel) {
    return;
  }
  float* address = voxels + (voxel_index * max_points_per_voxel + point_id) * 4;

  atomicExch(address, point.x);
  atomicExch(address + 1, point.y);
  atomicExch(address + 2, point.z);
  atomicExch(address + 3, point.w);
}

cudaError_t generateVoxels_random_launch(float* points,
                                         size_t points_size,
                                         float min_x_range,
                                         float max_x_range,
                                         float min_y_range,
                                         float max_y_range,
                                         float min_z_range,
                                         float max_z_range,
                                         float pillar_x_size,
                                         float pillar_y_size,
                                         float pillar_z_size,
                                         int grid_z_size,
                                         int grid_y_size,
                                         int grid_x_size,
                                         int max_points_per_voxel,
                                         unsigned int* mask,
                                         float* voxels,
                                         cudaStream_t stream) {
  int threadNum = THREADS_FOR_VOXEL;
  dim3 blocks((points_size + threadNum - 1) / threadNum);
  dim3 threads(threadNum);
  generateVoxels_random_kernel<<<blocks, threads, 0, stream>>>(points,
                                                               points_size,
                                                               min_x_range,
                                                               max_x_range,
                                                               min_y_range,
                                                               max_y_range,
                                                               min_z_range,
                                                               max_z_range,
                                                               pillar_x_size,
                                                               pillar_y_size,
                                                               pillar_z_size,
                                                               grid_z_size,
                                                               grid_y_size,
                                                               grid_x_size,
                                                               max_points_per_voxel,
                                                               mask,
                                                               voxels);
  cudaError_t err = cudaGetLastError();
  return err;
}

__global__ void generateBaseFeatures_kernel(unsigned int* mask,
                                            float* voxels,
                                            int grid_y_size,
                                            int grid_x_size,
                                            int max_points_per_voxel,
                                            int max_voxels,
                                            unsigned int* pillar_num,
                                            float* voxel_features,
                                            unsigned int* voxel_num,
                                            unsigned int* voxel_idxs) {
  unsigned int voxel_idx = blockIdx.x * blockDim.x + threadIdx.x;
  unsigned int voxel_idy = blockIdx.y * blockDim.y + threadIdx.y;
  // printf("voxel_idx:%d, voxel_idy:%d\n", voxel_idx, voxel_idy);
  if (voxel_idx >= grid_x_size || voxel_idy >= grid_y_size) {
    return;
  }

  unsigned int voxel_index = voxel_idy * grid_x_size + voxel_idx;
  unsigned int count = mask[voxel_index];
  if (count <= 0) {
    return;
  }
  count = count < max_points_per_voxel ? count : max_points_per_voxel;

  // Check if we've exceeded max_voxels limit before allocating
  unsigned int current_pillarId = atomicAdd(pillar_num, 1U);
  if (current_pillarId >= max_voxels) {
    // Roll back the counter increment and return
    atomicAdd(pillar_num, -1U);
    return;
  }

  voxel_num[current_pillarId] = count;

  uint4 coord = {0, 0, voxel_idy, voxel_idx};
  ((uint4*)voxel_idxs)[current_pillarId] = coord;
  for (int i = 0; i < count; i++) {
    int inIndex = voxel_index * max_points_per_voxel + i;
    int outIndex = current_pillarId * max_points_per_voxel + i;
    ((float4*)voxel_features)[outIndex] = ((float4*)voxels)[inIndex];
  }
  // clear buffer for next infer
  // mask[voxel_index] = 0;
  atomicExch(mask + voxel_index, 0);
}

// create 5 channels
cudaError_t generateBaseFeatures_launch(unsigned int* mask,
                                        float* voxels,
                                        int grid_y_size,
                                        int grid_x_size,
                                        int max_points_per_voxel,
                                        int max_voxels,
                                        unsigned int* pillar_num,
                                        float* voxel_features,
                                        unsigned int* voxel_num_points,
                                        unsigned int* coords,
                                        cudaStream_t stream) {
  dim3 threads = {20, 20};
  dim3 blocks = {(grid_x_size + threads.x - 1) / threads.x,
                 (grid_y_size + threads.y - 1) / threads.y};
  generateBaseFeatures_kernel<<<blocks, threads, 0, stream>>>(mask,
                                                              voxels,
                                                              grid_y_size,
                                                              grid_x_size,
                                                              max_points_per_voxel,
                                                              max_voxels,
                                                              pillar_num,
                                                              voxel_features,
                                                              voxel_num_points,
                                                              coords);
  // unsigned int params_input = 0;
  cudaError_t err = cudaGetLastError();
  return err;
}

// 5 channels -> 11 channels
__global__ void generateFeatures_kernel(float* voxel_features,
                                        unsigned int* voxel_num_points,
                                        unsigned int* coords,
                                        unsigned int* params,
                                        float voxel_x,
                                        float voxel_y,
                                        float voxel_z,
                                        float range_min_x,
                                        float range_min_y,
                                        float range_min_z,
                                        int max_points_per_voxel,
                                        float* features) {
  int pillar_idx = blockIdx.x * WARPS_PER_BLOCK + threadIdx.x / max_points_per_voxel;
  int point_idx = threadIdx.x % max_points_per_voxel;

  int pillar_idx_inBlock = threadIdx.x / max_points_per_voxel;
  unsigned int num_pillars = params[0];

  if (pillar_idx >= num_pillars) {
    return;
  }

  // load src
  // __shared__ float4 pillarSM[WARPS_PER_BLOCK][max_points_per_voxel];  // 4*20*4
  // __shared__ float4 pillarSumSM[WARPS_PER_BLOCK];                                      // 4*4
  // __shared__ float pillarOutSM[WARPS_PER_BLOCK][max_points_per_voxel][FEATURES_SIZE];  // 4*20*11
  // __shared__ uint4 cordsSM[WARPS_PER_BLOCK];                                           // 4*4
  // __shared__ int pointsNumSM[WARPS_PER_BLOCK];                                         // 4
  extern __shared__ float4 pillarSM[];
  float4* pillarSumSM = &pillarSM[WARPS_PER_BLOCK * max_points_per_voxel];
  float* pillarOutSM = (float*)&pillarSumSM[WARPS_PER_BLOCK];
  uint4* cordsSM = (uint4*)&pillarOutSM[WARPS_PER_BLOCK * max_points_per_voxel * FEATURES_SIZE];
  int* pointsNumSM = (int*)&cordsSM[WARPS_PER_BLOCK];
  if (threadIdx.x < WARPS_PER_BLOCK) {
    pointsNumSM[threadIdx.x] = voxel_num_points[blockIdx.x * WARPS_PER_BLOCK + threadIdx.x];
    cordsSM[threadIdx.x] = ((uint4*)coords)[blockIdx.x * WARPS_PER_BLOCK + threadIdx.x];
    pillarSumSM[threadIdx.x] = {0, 0, 0, 0};
  }

  pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx] =
      ((float4*)voxel_features)[pillar_idx * max_points_per_voxel + point_idx];
  __syncthreads();

  // calculate sm in a pillar
  if (point_idx < pointsNumSM[pillar_idx_inBlock]) {
    atomicAdd(&(pillarSumSM[pillar_idx_inBlock].x),
              pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].x);
    atomicAdd(&(pillarSumSM[pillar_idx_inBlock].y),
              pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].y);
    atomicAdd(&(pillarSumSM[pillar_idx_inBlock].z),
              pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].z);
  }
  __syncthreads();

  // feature-mean
  float4 mean;
  float validPoints = pointsNumSM[pillar_idx_inBlock];
  mean.x = pillarSumSM[pillar_idx_inBlock].x / validPoints;
  mean.y = pillarSumSM[pillar_idx_inBlock].y / validPoints;
  mean.z = pillarSumSM[pillar_idx_inBlock].z / validPoints;

  mean.x = pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].x - mean.x;
  mean.y = pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].y - mean.y;
  mean.z = pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].z - mean.z;

  // calculate offset
  float x_offset = voxel_x / 2 + (float)cordsSM[pillar_idx_inBlock].w * voxel_x + range_min_x;
  float y_offset = voxel_y / 2 + (float)cordsSM[pillar_idx_inBlock].z * voxel_y + range_min_y;
  float z_offset = voxel_z / 2 + (float)cordsSM[pillar_idx_inBlock].y * voxel_z + range_min_z;

  // feature-offset
  float4 center;
  center.x = pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].x - x_offset;
  center.y = pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].y - y_offset;
  center.z = pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].z - z_offset;
  // store output
  size_t pillarOutSM_index =
      pillar_idx_inBlock * max_points_per_voxel * FEATURES_SIZE + point_idx * FEATURES_SIZE;
  if (point_idx < pointsNumSM[pillar_idx_inBlock]) {
    pillarOutSM[pillarOutSM_index + 0] =
        pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].x;
    pillarOutSM[pillarOutSM_index + 1] =
        pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].y;
    pillarOutSM[pillarOutSM_index + 2] =
        pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].z;
    pillarOutSM[pillarOutSM_index + 3] =
        pillarSM[pillar_idx_inBlock * max_points_per_voxel + point_idx].w;
    pillarOutSM[pillarOutSM_index + 4] = mean.x;
    pillarOutSM[pillarOutSM_index + 5] = mean.y;
    pillarOutSM[pillarOutSM_index + 6] = mean.z;

    pillarOutSM[pillarOutSM_index + 7] = center.x;
    pillarOutSM[pillarOutSM_index + 8] = center.y;
    pillarOutSM[pillarOutSM_index + 9] = center.z;

  } else {
    pillarOutSM[pillarOutSM_index + 0] = 0;
    pillarOutSM[pillarOutSM_index + 1] = 0;
    pillarOutSM[pillarOutSM_index + 2] = 0;
    pillarOutSM[pillarOutSM_index + 3] = 0;

    pillarOutSM[pillarOutSM_index + 4] = 0;
    pillarOutSM[pillarOutSM_index + 5] = 0;
    pillarOutSM[pillarOutSM_index + 6] = 0;

    pillarOutSM[pillarOutSM_index + 7] = 0;
    pillarOutSM[pillarOutSM_index + 8] = 0;
    pillarOutSM[pillarOutSM_index + 9] = 0;
    // pillarOutSM[pillarOutSM_index + 10] = 0;
  }

  __syncthreads();

  for (int i = 0; i < FEATURES_SIZE; i++) {
    int outputSMId = pillar_idx_inBlock * max_points_per_voxel * FEATURES_SIZE +
                     i * max_points_per_voxel + point_idx;
    int outputId =
        pillar_idx * max_points_per_voxel * FEATURES_SIZE + i * max_points_per_voxel + point_idx;
    features[outputId] = ((float*)pillarOutSM)[outputSMId];
  }
}

cudaError_t generateFeatures_launch(float* voxel_features,
                                    unsigned int* voxel_num,
                                    unsigned int* voxel_idxs,
                                    unsigned int* params,
                                    float voxel_x,
                                    float voxel_y,
                                    float voxel_z,
                                    float range_min_x,
                                    float range_min_y,
                                    float range_min_z,
                                    int max_points_per_voxel,
                                    int max_voxel,
                                    float* features,
                                    cudaStream_t stream) {
  dim3 blocks((max_voxel + WARPS_PER_BLOCK - 1) / WARPS_PER_BLOCK);
  dim3 threads(WARPS_PER_BLOCK * max_points_per_voxel);
  // __shared__ float4 pillarSM[WARPS_PER_BLOCK][max_points_per_voxel];  // 4*20*4
  // __shared__ float4 pillarSumSM[WARPS_PER_BLOCK];  // 4*4
  // __shared__ float pillarOutSM[WARPS_PER_BLOCK][max_points_per_voxel][FEATURES_SIZE];  // 4*20*11
  // __shared__ uint4 cordsSM[WARPS_PER_BLOCK];       // 4*4
  // __shared__ int pointsNumSM[WARPS_PER_BLOCK];     // 4
  size_t shared_mem_size =
      sizeof(float4) * (WARPS_PER_BLOCK * max_points_per_voxel + WARPS_PER_BLOCK) +
      sizeof(float) * (WARPS_PER_BLOCK * max_points_per_voxel * (FEATURES_SIZE + 1)) +
      sizeof(uint4) * WARPS_PER_BLOCK + sizeof(int) * WARPS_PER_BLOCK;

  generateFeatures_kernel<<<blocks, threads, shared_mem_size, stream>>>(voxel_features,
                                                                        voxel_num,
                                                                        voxel_idxs,
                                                                        params,
                                                                        voxel_x,
                                                                        voxel_y,
                                                                        voxel_z,
                                                                        range_min_x,
                                                                        range_min_y,
                                                                        range_min_z,
                                                                        max_points_per_voxel,
                                                                        features);

  cudaError_t err = cudaGetLastError();
  return err;
}

namespace linfer {
namespace ops {
namespace cuda {

class Voxelization4dOp::Impl {
 private:
  cudaStream_t stream_ = 0;

  size_t max_points_per_voxel_;
  int grid_x_size_;
  int grid_y_size_;
  int grid_z_size_;
  int max_voxels_;

  float min_x_range_;
  float min_y_range_;
  float min_z_range_;
  float max_x_range_;
  float max_y_range_;
  float max_z_range_;
  float pillar_x_size_;
  float pillar_y_size_;
  float pillar_z_size_;

  size_t mask_size_;
  size_t voxels_size_;

  // device data --> intermediate data
  std::shared_ptr<linfer::util::Tensor1D> dev_mask_;
  std::shared_ptr<linfer::util::Tensor1D> dev_voxel_;
  linfer::util::Tensor2D points_;

  std::shared_ptr<linfer::util::Tensor1D> dev_num_pts_per_pillar_;
  std::shared_ptr<linfer::util::Tensor3D> dev_voxel_feat_;
  // device data --> output data
  std::shared_ptr<linfer::util::Tensor> dev_features_;
  std::shared_ptr<linfer::util::Tensor> dev_coors_;
  std::shared_ptr<linfer::util::Tensor> dev_voxel_cnt_;

 public:
  Impl(const std::vector<float>& voxel_size,
       const std::vector<float>& point_cloud_range,
       size_t max_points,
       int max_voxels,
       void* stream = nullptr);
  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> operate(
      const linfer::util::Tensor& points,
      size_t point_size);
};

Voxelization4dOp::Impl::Impl(const std::vector<float>& voxel_size,
                             const std::vector<float>& point_cloud_range,
                             size_t max_points,
                             int max_voxels,
                             void* stream)
    : max_points_per_voxel_(max_points),
      max_voxels_(max_voxels),
      points_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 1, 5) {
  if (stream) {
    stream_ = static_cast<cudaStream_t>(stream);
  } else {
    CHECK_CUDA(cudaStreamCreate(&stream_));
  }

  LASSERT_MSG(point_cloud_range.size() == 6, "point cloud range size should be 6");
  LASSERT_MSG(voxel_size.size() == 3, "voxel size should be 3");

  // init pc range, pillar size, grid size
  pillar_x_size_ = voxel_size[0];
  pillar_y_size_ = voxel_size[1];
  pillar_z_size_ = voxel_size[2];

  min_x_range_ = point_cloud_range[0];
  min_y_range_ = point_cloud_range[1];
  min_z_range_ = point_cloud_range[2];
  max_x_range_ = point_cloud_range[3];
  max_y_range_ = point_cloud_range[4];
  max_z_range_ = point_cloud_range[5];

  grid_x_size_ = static_cast<int>((max_x_range_ - min_x_range_) / pillar_x_size_);
  grid_y_size_ = static_cast<int>((max_y_range_ - min_y_range_) / pillar_y_size_);
  grid_z_size_ = static_cast<int>((max_z_range_ - min_z_range_) / pillar_z_size_);
  mask_size_ = grid_z_size_ * grid_y_size_ * grid_x_size_;
  voxels_size_ = grid_z_size_ * grid_y_size_ * grid_x_size_ * max_points_per_voxel_ * 4;
  // init data
  dev_mask_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                             util::DataType::kUINT32,
                                             nullptr,
                                             mask_size_));
  dev_voxel_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                              util::DataType::kFLOAT,
                                              nullptr,
                                              voxels_size_));

  dev_voxel_feat_.reset(new linfer::util::Tensor3D(util::DeviceType::GPU,
                                                   util::DataType::kFLOAT,
                                                   nullptr,
                                                   max_voxels_,
                                                   max_points_per_voxel_,
                                                   4));
  dev_num_pts_per_pillar_.reset(new linfer::util::Tensor1D(util::DeviceType::GPU,
                                                           util::DataType::kFLOAT,
                                                           nullptr,
                                                           max_voxels_));
  // init output data
  dev_features_.reset(new linfer::util::Tensor4D(util::DeviceType::GPU,
                                                 util::DataType::kFLOAT,
                                                 nullptr,
                                                 1,
                                                 max_voxels_,
                                                 max_points_per_voxel_,
                                                 FEATURES_SIZE));
  dev_coors_.reset(new linfer::util::Tensor2D(util::DeviceType::GPU,
                                              util::DataType::kINT32,
                                              nullptr,
                                              max_voxels_,
                                              4));
  dev_voxel_cnt_.reset(new linfer::util::Tensor4D(util::DeviceType::GPU,
                                                  util::DataType::kINT32,
                                                  nullptr,
                                                  1,
                                                  1,
                                                  1,
                                                  1));
}

std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>>
Voxelization4dOp::Impl::operate(const linfer::util::Tensor& points, size_t point_size) {
  // copy point data to device
  float* points_device_buf = nullptr;
  if (linfer::util::DeviceType::CPU == points.get_devicetype()) {
    points_.resize(points.get_dims());
    cudaMemcpyAsync(points_.get_buf(),
                    points.get_buf(),
                    points.get_len_in_byte(),
                    cudaMemcpyHostToDevice,
                    stream_);
    points_device_buf = (float*)points_.get_buf();
  } else {
    points_device_buf = (float*)points.get_buf();
  }
  cudaMemsetAsync(dev_mask_->get_buf(), 0, dev_mask_->get_len_in_byte(), stream_);
  cudaMemsetAsync(dev_voxel_->get_buf(), 0, dev_voxel_->get_len_in_byte(), stream_);
  cudaMemsetAsync(dev_voxel_feat_->get_buf(), 0, dev_voxel_feat_->get_len_in_byte(), stream_);

  cudaMemsetAsync(dev_voxel_cnt_->get_buf(), 0, dev_voxel_cnt_->get_len_in_byte(), stream_);
  cudaMemsetAsync(dev_num_pts_per_pillar_->get_buf(),
                  0,
                  dev_num_pts_per_pillar_->get_len_in_byte(),
                  stream_);

  generateVoxels_random_launch(points_device_buf,
                               point_size,
                               min_x_range_,
                               max_x_range_,
                               min_y_range_,
                               max_y_range_,
                               min_z_range_,
                               max_z_range_,
                               pillar_x_size_,
                               pillar_y_size_,
                               pillar_z_size_,
                               grid_z_size_,
                               grid_y_size_,
                               grid_x_size_,
                               max_points_per_voxel_,
                               (unsigned int*)dev_mask_->get_buf(),
                               (float*)dev_voxel_->get_buf(),
                               stream_);

  cudaMemsetAsync(dev_voxel_feat_->get_buf(), 0, dev_voxel_feat_->get_len_in_byte(), stream_);
  cudaMemsetAsync(dev_coors_->get_buf(), 0, dev_coors_->get_len_in_byte(), stream_);

  generateBaseFeatures_launch((unsigned int*)dev_mask_->get_buf(),
                              (float*)dev_voxel_->get_buf(),
                              grid_y_size_,
                              grid_x_size_,
                              max_points_per_voxel_,
                              max_voxels_,
                              (unsigned int*)dev_voxel_cnt_->get_buf(),
                              (float*)dev_voxel_feat_->get_buf(),
                              (unsigned int*)dev_num_pts_per_pillar_->get_buf(),
                              (unsigned int*)dev_coors_->get_buf(),
                              stream_);

  cudaMemsetAsync(dev_features_->get_buf(), 0, dev_features_->get_len_in_byte(), stream_);

  generateFeatures_launch((float*)dev_voxel_feat_->get_buf(),
                          (unsigned int*)dev_num_pts_per_pillar_->get_buf(),
                          (unsigned int*)dev_coors_->get_buf(),
                          (unsigned int*)dev_voxel_cnt_->get_buf(),
                          pillar_x_size_,
                          pillar_y_size_,
                          pillar_z_size_,
                          min_x_range_,
                          min_y_range_,
                          min_z_range_,
                          max_points_per_voxel_,
                          max_voxels_,
                          (float*)dev_features_->get_buf(),
                          stream_);
  // set output data
  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> output;
  output["input"] = dev_features_;
  output["coords"] = dev_coors_;
  // output["params"] = dev_voxel_cnt_;

  return output;
}

Voxelization4dOp::Voxelization4dOp(const std::vector<float>& voxel_size,
                                   const std::vector<float>& point_cloud_range,
                                   size_t max_points,
                                   int max_voxels,
                                   void* stream) {
  impl_ = new Impl(voxel_size, point_cloud_range, max_points, max_voxels, stream);
}

Voxelization4dOp::~Voxelization4dOp() { delete impl_; }

std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> Voxelization4dOp::operate(
    const linfer::util::Tensor& points,
    size_t point_size) {
  return impl_->operate(points, point_size);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer