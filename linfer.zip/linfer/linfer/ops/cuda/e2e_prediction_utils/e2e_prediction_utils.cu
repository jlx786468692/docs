#include <cuda_runtime_api.h>

#include <algorithm>
#include <vector>

// headers in CUDA
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/extrema.h>
#include <thrust/host_vector.h>
#include <thrust/sort.h>

#include "linfer/ops/cuda/ops.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/util/internal/cuda/util.h"
#include "nppi_geometry_transforms.h"

__global__ void NormalizeCHWBGRKernel(uint8_t* src,
                                      float* dst,
                                      float mean_0,
                                      float mean_1,
                                      float mean_2,
                                      float std_0,
                                      float std_1,
                                      float std_2,
                                      int32_t channel,
                                      int32_t resized_width,
                                      int32_t resized_height,
                                      int32_t num_per_channel) {
  int32_t i = blockDim.x * blockIdx.x + threadIdx.x;

  if (i < num_per_channel) {
    int32_t h = (i / resized_width) % resized_height;
    int32_t w = i % resized_width;
    int32_t src_index = h * resized_width * channel + w * channel;
    int32_t dst_index = h * resized_width + w;

    // A fusion kernel for BGR to RGB, normalize, HWC to CHW
    dst[dst_index] = (src[src_index + 2] - mean_0) / std_0;
    dst[1 * resized_height * resized_width + dst_index] = (src[src_index + 1] - mean_1) / std_1;
    dst[2 * resized_height * resized_width + dst_index] = (src[src_index] - mean_2) / std_2;
  }
}

__global__ void NormalizeCHWRGBKernel(uint8_t* src,
                                      float* dst,
                                      float mean_0,
                                      float mean_1,
                                      float mean_2,
                                      float std_0,
                                      float std_1,
                                      float std_2,
                                      int32_t channel,
                                      int32_t resized_width,
                                      int32_t resized_height,
                                      int32_t num_per_channel) {
  int32_t i = blockDim.x * blockIdx.x + threadIdx.x;

  if (i < num_per_channel) {
    int32_t h = (i / resized_width) % resized_height;
    int32_t w = i % resized_width;
    int32_t src_index = h * resized_width * channel + w * channel;
    int32_t dst_index = h * resized_width + w;

    // A fusion kernel for normalize, HWC to CHW
    dst[dst_index] = (src[src_index] - mean_0) / std_0;
    dst[1 * resized_height * resized_width + dst_index] = (src[src_index + 1] - mean_1) / std_1;
    dst[2 * resized_height * resized_width + dst_index] = (src[src_index + 2] - mean_2) / std_2;
  }
}

void normalize_chw(uint8_t* src,
                   float* dst,
                   int32_t resized_width,
                   int32_t resized_height,
                   int32_t image_channels,
                   const std::vector<float>& mean,
                   const std::vector<float>& std,
                   bool is_bgr,
                   const cudaStream_t& stream) {
  // Error code to check return values for CUDA calls
  cudaError_t err = cudaSuccess;

  // Using the float type to store the image data for model inference
  int32_t num_ele = image_channels * resized_width * resized_height;  // 3 * 256 * 704
  std::cout << "Resized image element :" << num_ele << std::endl;

  // Launch the CUDA Kernel
  int32_t num_per_channel = resized_width * resized_height;
  int32_t threads_per_block = 256;
  int32_t blocks_per_grid = (num_per_channel + threads_per_block - 1) / threads_per_block;
  std::cout << "CUDA kernel launch with  blocks :" << blocks_per_grid
            << "of threads :" << threads_per_block << std::endl;

  if (is_bgr) {
    NormalizeCHWBGRKernel<<<blocks_per_grid, threads_per_block, 0, stream>>>(src,
                                                                             dst,
                                                                             mean[0],
                                                                             mean[1],
                                                                             mean[2],
                                                                             std[0],
                                                                             std[1],
                                                                             std[2],
                                                                             image_channels,
                                                                             resized_width,
                                                                             resized_height,
                                                                             num_per_channel);
  } else {
    NormalizeCHWRGBKernel<<<blocks_per_grid, threads_per_block, 0, stream>>>(src,
                                                                             dst,
                                                                             mean[0],
                                                                             mean[1],
                                                                             mean[2],
                                                                             std[0],
                                                                             std[1],
                                                                             std[2],
                                                                             image_channels,
                                                                             resized_width,
                                                                             resized_height,
                                                                             num_per_channel);
  }

  err = cudaGetLastError();
  if (err != cudaSuccess) {
    std::cout << "Failed to launch NormalizeCHWKernel (error code:)!" << cudaGetErrorString(err)
              << std::endl;
    std::abort();
  }
}

void bilinear_resize(uint8_t* src,
                     uint8_t* dst,
                     int32_t width,
                     int32_t height,
                     int32_t resized_width,
                     int32_t resized_height,
                     int32_t image_channels,
                     const cudaStream_t& stream) {
  NppiSize src_size{width, height};
  NppiSize dst_size{resized_width, resized_height};
  NppiRect src_roi{0, 0, src_size.width, src_size.height};
  NppiRect dst_roi{0, 0, dst_size.width, dst_size.height};
  Npp8u* src_on_device{src};
  Npp8u* dst_on_device{dst};

  int32_t channels = static_cast<int32_t>(image_channels);

  NppStreamContext npp_stream_context;
  npp_stream_context.hStream = stream;

  int32_t ret = nppiResize_8u_C3R_Ctx(src_on_device,
                                      src_size.width * channels,
                                      src_size,
                                      src_roi,
                                      dst_on_device,
                                      dst_size.width * channels,
                                      dst_size,
                                      dst_roi,
                                      NppiInterpolationMode::NPPI_INTER_LINEAR,
                                      npp_stream_context);
  if (!(ret >= 0)) {
    std::cerr << "bilinear resize Check failed " << std::endl;
    std::abort();
  }
}
__global__ void cropImageKernel(const uint8_t* src,
                                uint8_t* dst,
                                int width,
                                int height,
                                int cropLeft,
                                int cropTop,
                                int cropRight,
                                int cropBottom) {
  int x = blockIdx.x * blockDim.x + threadIdx.x;
  int y = blockIdx.y * blockDim.y + threadIdx.y;

  int cropWidth = cropRight - cropLeft;
  int cropHeight = cropBottom - cropTop;

  if (x < cropWidth && y < cropHeight) {
    int srcIndex = (cropTop + y) * width + (cropLeft + x);
    int dstIndex = y * cropWidth + x;
    dst[dstIndex] = static_cast<uint8_t>(src[srcIndex]);
  }
}

void crop_image(uint8_t* src,
                uint8_t* dst,
                int32_t corp_left,
                int32_t corp_right,
                int32_t corp_top,
                int32_t corp_bottom,
                const cudaStream_t& stream) {
  int32_t cropWidth = corp_right - corp_left;
  int32_t cropHeight = corp_bottom - corp_top;

  dim3 blockSize(32, 32);
  dim3 gridSize((cropWidth + blockSize.x - 1) / blockSize.x,
                (cropHeight + blockSize.y - 1) / blockSize.y);

  cropImageKernel<<<gridSize, blockSize, 0, stream>>>(src,
                                                      dst,
                                                      cropWidth,
                                                      cropHeight,
                                                      corp_left,
                                                      corp_top,
                                                      corp_right,
                                                      corp_bottom);
}

// __global__ void resizeKernel(const unsigned char* src, int srcWidth, int srcHeight, unsigned
// char* dst, int dstWidth,
//                              int dstHeight, int channels) {
//     int x = blockIdx.x * blockDim.x + threadIdx.x;
//     int y = blockIdx.y * blockDim.y + threadIdx.y;

//     if (x < dstWidth && y < dstHeight) {
//         // 计算源图像的浮点坐标
//         float srcX = (x + 0.5f) * (float(srcWidth) / dstWidth) - 0.5f;
//         float srcY = (y + 0.5f) * (float(srcHeight) / dstHeight) - 0.5f;

//         // 计算源图像的整数坐标和插值权重
//         int srcX0 = static_cast<int>(floorf(srcX));
//         int srcX1 = min(srcX0 + 1, srcWidth - 1);
//         int srcY0 = static_cast<int>(floorf(srcY));
//         int srcY1 = min(srcY0 + 1, srcHeight - 1);

//         float alpha = srcX - srcX0;
//         float beta = srcY - srcY0;

//         // 确保坐标不超出边界
//         srcX0 = max(srcX0, 0);
//         srcX1 = max(srcX1, 0);
//         srcY0 = max(srcY0, 0);
//         srcY1 = max(srcY1, 0);

//         for (int c = 0; c < channels; ++c) {
//             // 计算四个邻域像素的值
//             float topLeft = src[(srcY0 * srcWidth + srcX0) * channels + c];
//             float topRight = src[(srcY0 * srcWidth + srcX1) * channels + c];
//             float bottomLeft = src[(srcY1 * srcWidth + srcX0) * channels + c];
//             float bottomRight = src[(srcY1 * srcWidth + srcX1) * channels + c];

//             // 执行双线性插值
//             float top = (1 - alpha) * topLeft + alpha * topRight;
//             float bottom = (1 - alpha) * bottomLeft + alpha * bottomRight;
//             float pixelValue = (1 - beta) * top + beta * bottom;

//             // 写入目标图像
//             dst[(y * dstWidth + x) * channels + c] = static_cast<unsigned char>(pixelValue);
//         }
//     }
// }

// void bilinear_resize(const unsigned char* d_src, int srcWidth, int srcHeight, unsigned char*
// d_dst, int dstWidth,
//                      int dstHeight, int channels, cudaStream_t stream) {
//     dim3 blockSize(32, 32);
//     dim3 gridSize((dstWidth + blockSize.x - 1) / blockSize.x, (dstHeight + blockSize.y - 1) /
//     blockSize.y);

//     resizeKernel<<<gridSize, blockSize, 0, stream>>>(d_src, srcWidth, srcHeight, d_dst, dstWidth,
//     dstHeight, channels);
// }

namespace linfer {
namespace ops {
namespace cuda {

class E2ePredictionUtils::Impl {
 private:
  cudaStream_t cuda_stream_;
  uint8_t* src_img_d;
  uint8_t* d_dst_u;
  uint8_t* d_crop_u;
  float* d_dst_f;

  // img param
  int32_t channels_;
  int32_t src_width_;
  int32_t src_height_;
  // resize img param
  int32_t resized_cols_;
  int32_t resized_rows_;
  // for crop param
  int32_t corp_top_;
  int32_t corp_bottom_;
  int32_t corp_left_;
  int32_t corp_right_;

  int32_t crop_cols_;
  int32_t crop_rows_;

  std::vector<float> img_mean_;
  std::vector<float> img_std_;
  bool is_devcar_;

 public:
  Impl(const int32_t channels,
       const int32_t src_width,
       const int32_t src_height,
       const int32_t resized_cols,
       const int32_t resized_rows,
       const int32_t cropTop,
       const int32_t cropBottom,
       const int32_t cropLeft,
       const int32_t cropRight,
       bool is_devcar,
       void* const stream) {
    if (stream) {
      cuda_stream_ = static_cast<cudaStream_t>(stream);
    } else {
      CHECK_CUDA(cudaStreamCreateWithFlags(&cuda_stream_, cudaStreamNonBlocking));
    }
    channels_ = channels_;
    src_height_ = src_height;
    src_width_ = src_width;
    resized_cols_ = resized_cols;
    resized_rows_ = resized_rows;
    corp_top_ = cropTop;
    corp_bottom_ = cropBottom;
    corp_left_ = cropLeft;
    corp_right_ = cropRight;
    is_devcar_ = is_devcar;
    img_mean_ = {123.675, 116.28, 103.53};
    img_std_ = {58.395, 57.12, 57.375};

    crop_cols_ = corp_right_ - corp_left_;
    crop_rows_ = corp_bottom_ - corp_top_;

    int32_t original_img_size = src_width_ * src_height_ * 3;
    CHECK_CUDA(
        cudaMalloc(reinterpret_cast<void**>(&src_img_d), original_img_size * sizeof(uint8_t)));

    int32_t resize_img_size = resized_cols_ * resized_rows_ * 3;
    CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&d_dst_u), resize_img_size * sizeof(uint8_t)));

    int32_t crop_img_size = crop_cols_ * crop_rows_ * 3;
    CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&d_crop_u), crop_img_size * sizeof(uint8_t)));

    CHECK_CUDA(cudaMalloc(reinterpret_cast<void**>(&d_dst_f), crop_img_size * sizeof(float)));
  }

  void operate(const uint8_t* input_image, float* output) {
    if (input_image == nullptr) {
      std::cout << "[Warning] e2e prediction image preprocess input image is null \n";
      return;
    }
    CHECK_CUDA(cudaMemcpy(src_img_d,
                          input_image,
                          channels_ * src_width_ * src_height_ * sizeof(u_char),
                          cudaMemcpyHostToDevice));
    // cuda kernel
    // bilinear_resize(src_img_d, src_width_, src_height_, d_dst_u, resized_cols_,
    // resized_rows_, channels_,
    //                 cuda_stream_);
    // nppi
    bilinear_resize(src_img_d,
                    d_dst_u,
                    src_width_,
                    src_height_,
                    resized_cols_,
                    resized_rows_,
                    channels_,
                    cuda_stream_);

    crop_image(d_dst_u, d_crop_u, corp_left_, corp_right_, corp_top_, corp_bottom_, cuda_stream_);
    if (is_devcar_) {
      normalize_chw(d_crop_u,
                    d_dst_f,
                    crop_cols_,
                    crop_rows_,
                    channels_,
                    img_mean_,
                    img_std_,
                    true,
                    cuda_stream_);
    } else {
      normalize_chw(d_crop_u,
                    d_dst_f,
                    crop_cols_,
                    crop_rows_,
                    channels_,
                    img_mean_,
                    img_std_,
                    false,
                    cuda_stream_);
    }
    cudaMemcpy(output,
               d_dst_f,
               3 * crop_cols_ * crop_rows_ * sizeof(float),
               cudaMemcpyDeviceToHost);
  }

  ~Impl() {
    cudaFreeAsync(src_img_d, cuda_stream_);
    cudaFreeAsync(d_dst_u, cuda_stream_);
    cudaFreeAsync(d_crop_u, cuda_stream_);
    cudaFreeAsync(d_dst_f, cuda_stream_);
  }
};

E2ePredictionUtils::E2ePredictionUtils(const int32_t channels,
                                       const int32_t src_width,
                                       const int32_t src_height,
                                       const int32_t resized_cols,
                                       const int32_t resized_rows,
                                       const int32_t cropTop,
                                       const int32_t cropBottom,
                                       const int32_t cropLeft,
                                       const int32_t cropRight,
                                       bool is_devcar,
                                       void* const stream) {
  impl_ = new Impl(channels,
                   src_width,
                   src_height,
                   resized_cols,
                   resized_rows,
                   cropTop,
                   cropBottom,
                   cropLeft,
                   cropRight,
                   is_devcar,
                   stream);
}

E2ePredictionUtils::~E2ePredictionUtils() { delete impl_; }

void E2ePredictionUtils::operate(const uint8_t* images, float* output) {
  return impl_->operate(images, output);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
