#include <iostream>

#include "linfer/ops/cuda/ops.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/util/internal/cuda/util.h"
#include "linfer/util/internal/trt/common.cuh"
#include "linfer/util/lassert.h"

namespace linfer {
namespace ops {
namespace cuda {

constexpr int THREADS_FOR_Bbox = 512;     // threads number for a block
constexpr int THREADS_FOR_Bbox_V4 = 224;  // threads number for a block
constexpr int MAX_THREAD_IN_BLOCK = 128;
constexpr int DET_MAX_SIZE = 200;
constexpr int SM_NUM = 82;

// V1
// Calculate the number of pointclouds in bbox
// __global__ void CountPointNum(const float* points, const size_t points_size, const
// float* inputs_dets,
//                               const size_t input_size, const int* inputs_labels, int*
//                               outputs) {
//     int index = blockIdx.x * blockDim.x + threadIdx.x;
//     int point_idx = index / input_size;
//     int box_idx = index % input_size;
//     if (point_idx >= points_size) {
//         return;
//     }
//     if (box_idx >= input_size) {
//         return;
//     }
//     if (inputs_labels[box_idx] == -1) {
//         return;
//     }
//     float x = points[point_idx * 5 + 0];
//     float y = points[point_idx * 5 + 1];
//     float z = points[point_idx * 5 + 2];
//     float cx = inputs_dets[box_idx * 8 + 0];
//     float cy = inputs_dets[box_idx * 8 + 1];
//     float cz = inputs_dets[box_idx * 8 + 2];
//     float dx = inputs_dets[box_idx * 8 + 3];
//     float dy = inputs_dets[box_idx * 8 + 4];
//     float dz = inputs_dets[box_idx * 8 + 5];
//     float rz = inputs_dets[box_idx * 8 + 6];
//     float shift_x = x - cx;
//     float shift_y = y - cy;
//     float cos_a = cos(rz);
//     float sin_a = sin(rz);
//     float local_x = shift_x * cos_a + shift_y * sin_a;
//     float local_y = shift_y * cos_a - shift_x * sin_a;
//     if (fabsf(z - cz) > dz / 2.f) {
//         return;
//     }
//     if (fabsf(local_x) > (dx / 2.f) || fabsf(local_y) > (dy / 2.f)) {
//         return;
//     }
//     atomicAdd(&outputs[box_idx], 1);
//     // outputs[box_idx] += 1;
//     return;
// }

// V2
__global__ void CountPointNumV2(const float* points,
                                const size_t points_size,
                                const float* inputs_dets,
                                const size_t input_size,
                                const int* inputs_labels,
                                int* outputs) {
  int index = blockIdx.x * blockDim.x + threadIdx.x;
  int point_idx = index;
  for (int i = 0; i < input_size; i++) {
    int box_idx = i;
    if (point_idx >= points_size) {
      continue;
    }
    if (box_idx >= input_size) {
      continue;
    }
    if (inputs_labels[box_idx] == -1) {
      continue;
    }
    float x = points[point_idx * 5 + 0];
    float y = points[point_idx * 5 + 1];
    float z = points[point_idx * 5 + 2];
    float cx = inputs_dets[box_idx * 8 + 0];
    float cy = inputs_dets[box_idx * 8 + 1];
    float cz = inputs_dets[box_idx * 8 + 2];
    float dx = inputs_dets[box_idx * 8 + 3];
    float dy = inputs_dets[box_idx * 8 + 4];
    float dz = inputs_dets[box_idx * 8 + 5];
    float rz = inputs_dets[box_idx * 8 + 6];
    float shift_x = x - cx;
    float shift_y = y - cy;
    float cos_a = cos(rz);
    float sin_a = sin(rz);
    float local_x = shift_x * cos_a + shift_y * sin_a;
    float local_y = shift_y * cos_a - shift_x * sin_a;
    if (fabsf(z - cz) > dz / 2.f) {
      continue;
    }
    if (fabsf(local_x) > (dx / 2.f) || fabsf(local_y) > (dy / 2.f)) {
      continue;
    }
    atomicAdd(&outputs[box_idx], 1);
  }
  return;
}

// V3
// __global__ void CountPointNum(const float* points, const size_t points_size, const
// float* inputs_dets,
//                               const size_t input_size, const int* inputs_labels, int*
//                               outputs) {
//     int index = blockIdx.x * blockDim.x + threadIdx.x;
//     int point_idx = index;
//     for (int i = 0; i < input_size; i++) {
//         int box_idx = i;
//         if (point_idx >= points_size) {
//             continue;
//         }
//         if (box_idx >= input_size) {
//             continue;
//         }
//         if (inputs_labels[box_idx] == -1) {
//             continue;
//         }
//         float x = points[point_idx * 5 + 0];
//         float y = points[point_idx * 5 + 1];
//         float z = points[point_idx * 5 + 2];

//         float cx, cy, cz, dx, dy, dz, rz, other;
//         asm volatile("ld.global.v4.u32 {%0, %1, %2, %3}, [%8];\n"
//                      "ld.global.v4.u32 {%4, %5, %6, %7}, [%9];\n"
//                      :"=r"(*reinterpret_cast<uint*>(&cx)),
//                      "=r"(*reinterpret_cast<uint*>(&cy)), \
//                       "=r"(*reinterpret_cast<uint*>(&cz)),
//                       "=r"(*reinterpret_cast<uint*>(&dx)), \
//                       "=r"(*reinterpret_cast<uint*>(&dy)),
//                       "=r"(*reinterpret_cast<uint*>(&dz)), \
//                       "=r"(*reinterpret_cast<uint*>(&rz)),
//                       "=r"(*reinterpret_cast<uint*>(&other)) \
//                      : "l"(inputs_dets + box_idx * 8), "l"(inputs_dets + box_idx * 8
//                      + 4));
//         float shift_x = x - cx;
//         float shift_y = y - cy;
//         float cos_a = cos(rz);
//         float sin_a = sin(rz);
//         float local_x = shift_x * cos_a + shift_y * sin_a;
//         float local_y = shift_y * cos_a - shift_x * sin_a;
//         if (fabsf(z - cz) > dz / 2.f) {
//             continue;
//         }
//         if (fabsf(local_x) > (dx / 2.f) || fabsf(local_y) > (dy / 2.f)) {
//             continue;
//         }
//         atomicAdd(&outputs[box_idx], 1);
//     }
//     return;
// }

// V4
__global__ void CountPointNumV4(const float* points,
                                const size_t points_size,
                                const float* inputs_dets,
                                const size_t input_size,
                                int point_in_block,
                                int point_in_thread,
                                const int* inputs_labels,
                                int* outputs) {
  __shared__ uint8_t tile[THREADS_FOR_Bbox_V4][DET_MAX_SIZE];

  int index_in_global = blockIdx.x * point_in_block + threadIdx.x * point_in_thread;
  int point_index_in_block = threadIdx.x * point_in_thread;
  int point_idx;
  int index_in_block = threadIdx.x;
  for (int i = 0; i < DET_MAX_SIZE; i++) {
    tile[index_in_block][i] = 0;
  }

  for (int j = 0; j < point_in_thread; j++) {
    point_idx = index_in_global + j;
    if (point_idx >= points_size) {
      break;
    }
    if (point_index_in_block + j >= point_in_block) {
      break;
    }
    for (int i = 0; i < input_size; i++) {
      int box_idx = i;
      if (inputs_labels[box_idx] == -1) {
        continue;
      }
      float x = points[point_idx * 5 + 0];
      float y = points[point_idx * 5 + 1];
      float z = points[point_idx * 5 + 2];
      float cx = inputs_dets[box_idx * 8 + 0];
      float cy = inputs_dets[box_idx * 8 + 1];
      float cz = inputs_dets[box_idx * 8 + 2];
      float dx = inputs_dets[box_idx * 8 + 3];
      float dy = inputs_dets[box_idx * 8 + 4];
      float dz = inputs_dets[box_idx * 8 + 5];
      float rz = inputs_dets[box_idx * 8 + 6];
      float shift_x = x - cx;
      float shift_y = y - cy;
      float cos_a = cos(rz);
      float sin_a = sin(rz);
      float local_x = shift_x * cos_a + shift_y * sin_a;
      float local_y = shift_y * cos_a - shift_x * sin_a;
      if (fabsf(z - cz) > dz / 2.f) {
        continue;
      }
      if (fabsf(local_x) > (dx / 2.f) || fabsf(local_y) > (dy / 2.f)) {
        continue;
      }
      tile[index_in_block][i] += 1;
    }
  }
  // if(blockIdx.x == 0){
  //     printf("%d %d   ", index_in_block, tile[index_in_block][2]);
  // }
  // if(blockIdx.x == 1){
  //     printf("%d %d   ", index_in_block, tile[index_in_block][2]);
  // }
  __syncthreads();

  if (index_in_block < input_size) {
    int tmp = 0;
    for (int i = 0; i < THREADS_FOR_Bbox_V4; i++) {
      tmp += tile[i][index_in_block];
    }
    outputs[blockIdx.x * DET_MAX_SIZE + index_in_block] = tmp;
  }
  return;
}

__global__ void SumCountPointNum(const int* sub_outputs, int* outputs) {
  int index = blockIdx.x * MAX_THREAD_IN_BLOCK + threadIdx.x;
  if (index < DET_MAX_SIZE) {
    int tmp = 0;
    for (int i = 0; i < SM_NUM; i++) {
      tmp += sub_outputs[i * DET_MAX_SIZE + index];
    }
    outputs[index] = tmp;
  }
}

const int* Bbox3dUtils::GetHostOutputs() { return data_.data(); }

Bbox3dUtils::Bbox3dUtils(void* stream, const size_t det_size)
    : points_(linfer::util::DeviceType::GPU, linfer::util::DataType::kFLOAT, nullptr, 1, 5) {
  if (stream) {
    stream_ = stream;
  } else {
    CHECK_CUDA(cudaStreamCreate(reinterpret_cast<cudaStream_t*>(&stream_)));
  }
  LASSERT(det_size <= DET_MAX_SIZE);  // TODO should use runtime check
  data_.resize(det_size);
  sub_data_.resize(det_size * SM_NUM);
}

void Bbox3dUtils::Reset(const size_t det_size) {
  LASSERT(det_size <= DET_MAX_SIZE);  // TODO should use runtime check
  data_.resize(det_size);
  sub_data_.resize(det_size * SM_NUM);
}

bool Bbox3dUtils::CountBboxPointcloud(const linfer::util::Tensor& points,
                                      const size_t points_size,
                                      const float* inputs_dets,
                                      const size_t det_size,
                                      const int* inputs_labels,
                                      const size_t max_det_size) {
  LASSERT(det_size <= DET_MAX_SIZE);  // TODO should use runtime check
  float* points_device_buf = nullptr;
  cudaStream_t stream = static_cast<cudaStream_t>(stream_);
  if (linfer::util::DeviceType::CPU == points.get_devicetype()) {
    if (points_.get_len_in_byte() < points.get_len_in_byte()) {
      points_.resize(points.get_dims());
    }
    cudaMemcpyAsync(points_.get_buf(),
                    points.get_buf(),
                    points.get_len_in_byte(),
                    cudaMemcpyHostToDevice,
                    stream);
    points_device_buf = (float*)points_.get_buf();
  } else {
    points_device_buf = (float*)points.get_buf();
  }
  int threadNum = THREADS_FOR_Bbox;
  // __constant__ float inputs_dets_on_const[200 * 8];
  // cudaMemcpyToSymbol(inputs_dets_on_const, inputs_dets, sizeof(float) * 200 * 8);

  // dim3 blocks((points_size * det_size + threadNum - 1) / threadNum);
  // dim3 threads(threadNum);

  dim3 blocks((points_size + threadNum - 1) / threadNum);
  dim3 threads(threadNum);
  cudaMemsetAsync(data_.data(), 0, sizeof(int) * max_det_size, stream);
  CountPointNumV2<<<blocks, threads, 0, stream>>>(points_device_buf,
                                                  points_size,
                                                  inputs_dets,
                                                  det_size,
                                                  inputs_labels,
                                                  data_.data());

  cudaStreamSynchronize(stream);
  return true;
}

bool Bbox3dUtils::CountBboxPointcloudfast(const linfer::util::Tensor& points,
                                          const size_t points_size,
                                          const float* inputs_dets,
                                          const size_t det_size,
                                          const int* inputs_labels,
                                          const size_t max_det_size) {
  LASSERT(det_size <= DET_MAX_SIZE);  // TODO should use runtime check
  float* points_device_buf = nullptr;
  cudaStream_t stream = static_cast<cudaStream_t>(stream_);
  if (linfer::util::DeviceType::CPU == points.get_devicetype()) {
    if (points_.get_len_in_byte() < points.get_len_in_byte()) {
      points_.resize(points.get_dims());
    }
    cudaMemcpyAsync(points_.get_buf(),
                    points.get_buf(),
                    points.get_len_in_byte(),
                    cudaMemcpyHostToDevice,
                    stream);
    points_device_buf = (float*)points_.get_buf();
  } else {
    points_device_buf = (float*)points.get_buf();
  }
  // int threadNum = THREADS_FOR_Bbox;
  // // __constant__ float inputs_dets_on_const[200 * 8];
  // // cudaMemcpyToSymbol(inputs_dets_on_const, inputs_dets, sizeof(float) * 200 *
  // 8);

  // // dim3 blocks((points_size * det_size + threadNum - 1) / threadNum);
  // // dim3 threads(threadNum);

  // dim3 blocks((points_size + threadNum - 1) / threadNum);
  // dim3 threads(threadNum);
  // cudaMemsetAsync(data_.data(), 0, sizeof(int) * max_det_size, stream);
  // CountPointNum<<<blocks, threads, 0, stream>>>(points_device_buf, points_size,
  // inputs_dets, det_size, inputs_labels,
  //                                               data_.data());

  int threadNum = THREADS_FOR_Bbox_V4;
  dim3 blocks(SM_NUM);
  dim3 threads(threadNum);
  int point_in_block = (points_size + SM_NUM - 1) / SM_NUM;
  int point_in_thread = (point_in_block + threadNum - 1) / threadNum;
  // printf("point_in_block is %d point_in_thread is %d\n", point_in_block,
  // point_in_thread);
  CountPointNumV4<<<blocks, threads, 0, stream>>>(points_device_buf,
                                                  points_size,
                                                  inputs_dets,
                                                  det_size,
                                                  point_in_block,
                                                  point_in_thread,
                                                  inputs_labels,
                                                  sub_data_.data());
  int block = (DET_MAX_SIZE + MAX_THREAD_IN_BLOCK - 1) / MAX_THREAD_IN_BLOCK;
  SumCountPointNum<<<block, MAX_THREAD_IN_BLOCK, 0, stream>>>(sub_data_.data(), data_.data());

  cudaStreamSynchronize(stream);
  return true;
}

Bbox3dUtils::~Bbox3dUtils() {
  data_.clear();
  sub_data_.clear();
};

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
