#include <cublas_v2.h>
#include <cuda_runtime_api.h>

#include <algorithm>
#include <cstdint>
#include <vector>

#include "fmt/format.h"
#include "linfer/ops/cuda/ops.h"
#include "linfer/util/internal/cuda/util.h"

#define OFFSET_X (0)
#define OFFSET_Y (1)
#define OFFSET_Z (2)
#define CONFIG_ELEMENT_SIZE (4)
#define OFFSET_MAX_POINT_NUM_PER_VOXEL \
  (0)  // max point num in one voxel. typical value: 32, range value: [1, 128].
// each voxel region size: [x, y, z]. typical value: [0.16, 0.16, 4], range value: [0.01, 0.01,
// 0.01] ~ [10, 10, 10].
#define OFFSET_VOXEL_SIZE (1)  // [x, y, z]
#define OFFSET_VOXEL_SIZE_X (OFFSET_VOXEL_SIZE + OFFSET_X)
#define OFFSET_VOXEL_SIZE_Y (OFFSET_VOXEL_SIZE + OFFSET_Y)
#define OFFSET_VOXEL_SIZE_Z (OFFSET_VOXEL_SIZE + OFFSET_Z)
#define OFFSET_REGION_START (4)  // region start: [x, y, z]
#define OFFSET_REGION_START_X (OFFSET_REGION_START + OFFSET_X)
#define OFFSET_REGION_START_Y (OFFSET_REGION_START + OFFSET_Y)
#define OFFSET_REGION_START_Z (OFFSET_REGION_START + OFFSET_Z)
#define OFFSET_REGION_END (7)  // region end: [x, y, z]
#define OFFSET_REGION_END_X (OFFSET_REGION_END + OFFSET_X)
#define OFFSET_REGION_END_Y (OFFSET_REGION_END + OFFSET_Y)
#define OFFSET_REGION_END_Z (OFFSET_REGION_END + OFFSET_Z)
#define OFFSET_VOXEL_COOR_LEN (10)
#define OFFSET_VOXEL_COOR_LEN_X (OFFSET_VOXEL_COOR_LEN + OFFSET_X)
#define OFFSET_VOXEL_COOR_LEN_Y (OFFSET_VOXEL_COOR_LEN + OFFSET_Y)
#define OFFSET_VOXEL_COOR_LEN_Z (OFFSET_VOXEL_COOR_LEN + OFFSET_Z)
#define TOTAL_CONFIG_LEN (13)

/**
 * @brief scatter point cloud data into voxel map.
 *
 * @param[in] config_ptr: voxelization config start address.
 * @param[in] points: point cloud data, shape: N x 4[x, y, z, instensity].
 * @param[in] point_num: total point num. typical value: 20000, range value: [0, 100000].
 * @param[out] voxel_map: voxel map, shape: X x Y. typical value: 500 x 500, range value: [1 x 1] ~
 * [10000, 10000].
 * @return void
 * @exception [std::invalid_argument, std::runtime_error]
 */
__global__ void scatter_kernel(const void* const config_ptr,
                               const float* const points,
                               size_t point_num,
                               uint32_t* voxel_map_point_cnt,
                               uint32_t* voxel_map) {
  auto config_ptr_uint32 = (uint32_t*)config_ptr;
  auto config_ptr_float = (float*)config_ptr;

  auto max_point_num_per_voxel = config_ptr_uint32[OFFSET_MAX_POINT_NUM_PER_VOXEL];
  register auto start_x = config_ptr_float[OFFSET_REGION_START_X];
  register auto start_y = config_ptr_float[OFFSET_REGION_START_Y];
  register auto start_z = config_ptr_float[OFFSET_REGION_START + OFFSET_Z];
  register auto end_x = config_ptr_float[OFFSET_REGION_END_X];
  register auto end_y = config_ptr_float[OFFSET_REGION_END_Y];
  register auto end_z = config_ptr_float[OFFSET_REGION_END + OFFSET_Z];
  register auto voxel_size_x = config_ptr_float[OFFSET_VOXEL_SIZE_X];
  register auto voxel_size_y = config_ptr_float[OFFSET_VOXEL_SIZE_Y];
  // register auto voxel_size_z = config_ptr_float[OFFSET_VOXEL_SIZE + OFFSET_Z];
  register auto voxel_coor_len_x = config_ptr_uint32[OFFSET_VOXEL_COOR_LEN_X];
  // register auto voxel_coor_len_y = config_ptr_uint32[OFFSET_VOXEL_COOR_LEN_Y];
  // register auto voxel_coor_len_z = config_ptr_float[OFFSET_VOXEL_COOR_LEN_Z];

  // every thread handle @max_point_num_per_voxel point, every point have [x, y, z, intensity]
  size_t start = (blockIdx.x * blockDim.x + threadIdx.x) * max_point_num_per_voxel * 4;
  size_t end =
      min((size_t)(blockIdx.x * blockDim.x + threadIdx.x + 1) * max_point_num_per_voxel * 4,
          point_num);

  // printf("config: \n");
  // printf("max_point_num_per_voxel: %u\n", max_point_num_per_voxel);
  // for (int i = 0; i < TOTAL_CONFIG_LEN ; ++i) {
  //     printf("%f, ", *(config_ptr_float + i));
  // }

  // printf("uint32:\n");
  // for (int i = 0; i < TOTAL_CONFIG_LEN ; ++i) {
  //     printf("%u, ", *(config_ptr_uint32 + i));
  // }

  // printf("start: %u, end: %u\n", start, end);
  // printf("start_x: %f, end_x: %f, start_y: %f, end_y: %f\n", start_x, end_x, start_y, end_y);
  // printf("voxel_size_x: %f, voxel_size_y: %f\n", voxel_size_x, voxel_size_y);
  // printf("voxel_coor_len_x: %u\n", voxel_coor_len_x);

  for (size_t point_idx = start; point_idx < end; point_idx += 4) {
    float x = points[point_idx + 0];
    float y = points[point_idx + 1];
    float z = points[point_idx + 2];

    // printf("x: %f, y: %f\n", x, y);

    if (x >= start_x && x <= end_x && y >= start_y && y <= end_y && z >= start_z && z <= end_z) {
      // uint32_t vx = floor(((x - start_x) / voxel_size_x) + 0.5);
      // uint32_t vy = floor(((y - start_y) / voxel_size_y) + 0.5);

      uint32_t vx = floor(((x - start_x) / voxel_size_x));
      uint32_t vy = floor(((y - start_y) / voxel_size_y));

      // uint32_t offset = vx * voxel_coor_len_x + vy;
      uint32_t offset = vy * voxel_coor_len_x + vx;
      // printf("voxel_coor_len_x: %u\n", voxel_coor_len_x);
      // printf("vx: %u, vy: %u, offset: %u\n", vx, vy, offset);

      uint32_t* point_cnt_ptr = voxel_map_point_cnt + offset;
      uint32_t point_cnt = atomicAdd(point_cnt_ptr, 1);
      if (point_cnt < max_point_num_per_voxel) {
        // printf("add_new_point, point_cnt: %u, x: %f, y: %f, vx: %u, vy: %u\n", point_cnt,
        // x, y, vx, vy);
        uint32_t* voxel_point_idx = voxel_map + offset * max_point_num_per_voxel + point_cnt;
        *voxel_point_idx = point_idx;
      } /* else {
          printf("ignore_one, point_cnt: %u, x: %f, y: %f, vx: %u, vy: %u\n", point_cnt, x, y,
      vx, vy);
      } */
    }
  }
}

/**
 * @brief gather valid voxel point from voxel map.
 *
 * @param[in] config_ptr: voxelization config start address.
 * @param[in] points: point cloud data, shape: N x 4[x, y, z, instensity].
 * @param[in] voxel_map_point_cnt: voxel map idx, shape: X x Y. typical value: 20000, range value:
 * [1 x 1] ~ [10000, 10000].
 * @param[in] voxel_map: voxel map, shape: X x Y x MAX_POINT_NUM_PER_VOXEL.
 *                       typical value: 500 x 500 x 32, range value: [1 x 1 x 32] ~ [10000 x 10000 x
 * 32].
 * @param[out] voxel_num: total voxel num.
 * @param[out] voxel: all voxel, shape: M x MAX_POINT_NUM_PER_VOXEL x 4[x, y, z, instensity].
 * @param[out] coor: voxel coordinate value, shape: M x 4[0, z, y, x].
 * @param[out] point_num_each_voxel: effective point num in each voxel, shape: M.
 * @return void
 * @exception [std::invalid_argument, std::runtime_error]
 */
__global__ void gather_kernel(const void* const config_ptr,
                              float* points,
                              uint32_t* voxel_map_point_cnt,
                              uint32_t* voxel_map,
                              uint32_t* voxel_num,
                              float* voxel,
                              uint32_t* coor,
                              uint32_t* point_num_each_voxel) {
  // every thread must handle x MAX_POINT_NUM_PER_VOXEL points.

  register auto config_ptr_uint32 = (uint32_t*)config_ptr;

  register auto max_point_num_per_voxel = config_ptr_uint32[OFFSET_MAX_POINT_NUM_PER_VOXEL];
  register auto voxel_coor_len_x = config_ptr_uint32[OFFSET_VOXEL_COOR_LEN_X];
  register auto voxel_coor_len_y = config_ptr_uint32[OFFSET_VOXEL_COOR_LEN_Y];
  register uint32_t voxel_coor_xy = voxel_coor_len_x * voxel_coor_len_y;

  // uint32_t part_start = blockIdx.x * blockDim.x + threadIdx.x;
  // uint32_t part_end = min(blockIdx.x * blockDim.x + threadIdx.x + 1, voxel_coor_xy);
  // for (uint32_t voxel_coor_idx = part_start; voxel_coor_idx < part_end; voxel_coor_idx += 1) {
  uint32_t voxel_coor_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (voxel_coor_idx < voxel_coor_xy) {
    uint32_t point_num = voxel_map_point_cnt[voxel_coor_idx];
    if (point_num > 0) {
      if (point_num > max_point_num_per_voxel) {
        point_num = max_point_num_per_voxel;
      }

      auto voxel_offset = atomicAdd(voxel_num, 1);
      uint32_t* coor_base = coor + voxel_offset * 4;
      coor_base[0] = 0;
      coor_base[1] = 0;
      coor_base[2] = voxel_coor_idx / voxel_coor_len_x;
      coor_base[3] = voxel_coor_idx % voxel_coor_len_x;
      // printf("voxel_num: %p\n", voxel_num);
      // printf("voxel_coor_idx: %u, point_num: %u, voxel_offset: %u, voxel_coor_len_x: %u\n",
      // voxel_coor_idx,
      //        point_num, voxel_offset, voxel_coor_len_x);
      // printf("vx: %u, vy: %u\n", coor_base[3], coor_base[2]);
      point_num_each_voxel[voxel_offset] = point_num;
      for (int i = 0; i < point_num; ++i) {
        //  copy point cloud data to voxel
        auto offset_point = voxel_coor_idx * max_point_num_per_voxel + i;
        auto src = points + voxel_map[offset_point];
        auto offset_voxel = (voxel_offset * max_point_num_per_voxel + i) * 4;
        auto dest = voxel + offset_voxel;
        // memcpy(dest, src, 16);  // size bytes: 4 x 4
        *dest = *src;
        *(dest + 1) = *(src + 1);
        *(dest + 2) = *(src + 2);
        *(dest + 3) = *(src + 3);
      }

      for (int i = point_num; i < max_point_num_per_voxel; ++i) {  // TODO
        auto offset_voxel = (voxel_offset * max_point_num_per_voxel + i) * 4;
        auto dest = voxel + offset_voxel;
        *dest = .0;
        *(dest + 1) = .0;
        *(dest + 2) = .0;
        *(dest + 3) = .0;
      }
    }
  }
}

namespace linfer {
namespace ops {
namespace cuda {

class VoxelizationOp::Impl {
 private:
  cudaStream_t cuda_stream_;
  size_t max_voxel_num_;
  size_t max_point_num_per_voxel_;

  linfer::util::Tensor1D config_;
  linfer::util::Tensor2D points_;
  linfer::util::Tensor1D voxel_num_;

  std::shared_ptr<linfer::util::Tensor> voxel_;
  std::shared_ptr<linfer::util::Tensor> coor_;
  std::shared_ptr<linfer::util::Tensor> point_num_each_voxel_;
  std::shared_ptr<linfer::util::Tensor> voxel_map_point_cnt_;
  std::shared_ptr<linfer::util::Tensor> voxel_map_;

 public:
  Impl(const std::vector<float>& voxel_size,
       const std::vector<float>& point_cloud_range,
       size_t max_points,
       void* stream = nullptr)
      : config_(linfer::util::DeviceType::GPU,
                linfer::util::DataType::kUINT32,
                nullptr,
                TOTAL_CONFIG_LEN),
        points_(linfer::util::DeviceType::GPU, linfer::util::DataType::kUINT32, nullptr, 1, 4),
        voxel_num_(linfer::util::DeviceType::GPU, linfer::util::DataType::kUINT32, nullptr, 1),
        max_point_num_per_voxel_(max_points) {
    if (stream) {
      cuda_stream_ = static_cast<cudaStream_t>(stream);
    } else {
      CHECK_CUDA(cudaStreamCreate(&cuda_stream_));
    }

    // set config and copy to device.
    std::vector<uint32_t> config(TOTAL_CONFIG_LEN, 0);
    uint8_t* config_ptr = reinterpret_cast<uint8_t*>(config.data());

    auto config_max_point = reinterpret_cast<uint32_t*>(
        config_ptr + OFFSET_MAX_POINT_NUM_PER_VOXEL * CONFIG_ELEMENT_SIZE);
    *config_max_point = max_points;

    auto config_voxel_size =
        reinterpret_cast<float*>(config_ptr + OFFSET_VOXEL_SIZE * CONFIG_ELEMENT_SIZE);
    memcpy(config_voxel_size, voxel_size.data(), 3 * CONFIG_ELEMENT_SIZE);

    float point_start_x = point_cloud_range[0];
    float point_start_y = point_cloud_range[1];
    float point_start_z = point_cloud_range[2];
    float point_end_x = point_cloud_range[3];
    float point_end_y = point_cloud_range[4];
    float point_end_z = point_cloud_range[5];

    auto config_region_start =
        reinterpret_cast<float*>(config_ptr + OFFSET_REGION_START * CONFIG_ELEMENT_SIZE);
    config_region_start[OFFSET_X] = point_start_x;
    config_region_start[OFFSET_Y] = point_start_y;
    config_region_start[OFFSET_Z] = point_start_z;

    auto config_region_end =
        reinterpret_cast<float*>(config_ptr + OFFSET_REGION_END * CONFIG_ELEMENT_SIZE);
    config_region_end[OFFSET_X] = point_end_x;
    config_region_end[OFFSET_Y] = point_end_y;
    config_region_end[OFFSET_Z] = point_end_z;

    // allocat memory.
    size_t shape_x = std::ceil((point_end_x - point_start_x) / voxel_size[0]);
    size_t shape_y = std::ceil((point_end_y - point_start_y) / voxel_size[1]);
    size_t shape_z = std::ceil((point_end_z - point_start_z) / voxel_size[2]);
    LASSERT_MSG(1 == shape_z, fmt::format("shape_z must be 1, but get: {}", shape_z));

    auto config_voxel_coor_len =
        reinterpret_cast<uint32_t*>(config_ptr + OFFSET_VOXEL_COOR_LEN * CONFIG_ELEMENT_SIZE);
    config_voxel_coor_len[OFFSET_X] = shape_x;
    config_voxel_coor_len[OFFSET_Y] = shape_y;
    config_voxel_coor_len[OFFSET_Z] = shape_z;

    // printf("point_end_x: %f\n", point_end_x);
    // printf("point_end_y: %f\n", point_end_y);
    // printf("point_end_z: %f\n", point_end_z);

    // printf("shape_x: %u\n", shape_x);
    // printf("shape_y: %u\n", shape_y);
    // printf("shape_z: %u\n", shape_z);

    // float* config_base_ptr = (float*)config.data();
    // for (int i = 0; i < TOTAL_CONFIG_LEN; ++i) {
    //     printf("%f, ", config_base_ptr[i]);
    // }

    // printf("\n");
    // uint32_t* config_base_ptr_u32 = (uint32_t*)config.data();
    // for (int i = 0; i < TOTAL_CONFIG_LEN; ++i) {
    //     printf("%u, ", config_base_ptr_u32[i]);
    // }

    cudaMemcpy(config_.get_buf(),
               config.data(),
               TOTAL_CONFIG_LEN * CONFIG_ELEMENT_SIZE,
               cudaMemcpyHostToDevice);

    // N = shape_x x shape_y
    // allocate cuda memory for voxel_(N x max_points x 4), coor_(N x 4),
    // point_num_each_voxel_(N) and voxel_map_point_cnt(N) and voxel map(N x
    // MAX_POINT_NUM_PER_VOXEL)
    size_t N = shape_x * shape_y;
    max_voxel_num_ = N;
    voxel_ = std::make_shared<linfer::util::Tensor3D>(linfer::util::DeviceType::GPU,
                                                      linfer::util::DataType::kFLOAT,
                                                      nullptr,
                                                      N,
                                                      max_points,
                                                      4);
    coor_ = std::make_shared<linfer::util::Tensor2D>(linfer::util::DeviceType::GPU,
                                                     linfer::util::DataType::kUINT32,
                                                     nullptr,
                                                     N,
                                                     4);
    point_num_each_voxel_ =
        std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                 linfer::util::DataType::kUINT32,
                                                 nullptr,
                                                 N);

    voxel_map_point_cnt_ = std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                                    linfer::util::DataType::kUINT32,
                                                                    nullptr,
                                                                    N);
    voxel_map_ = std::make_shared<linfer::util::Tensor2D>(linfer::util::DeviceType::GPU,
                                                          linfer::util::DataType::kUINT32,
                                                          nullptr,
                                                          N,
                                                          max_points);
  }

  std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> operate(
      const linfer::util::Tensor& points) {
    // copy point data to device
    float* points_device_buf = nullptr;
    if (linfer::util::DeviceType::CPU == points.get_devicetype()) {
      points_.resize(points.get_dims());
      cudaMemcpyAsync(points_.get_buf(),
                      points.get_buf(),
                      points.get_len_in_byte(),
                      cudaMemcpyHostToDevice,
                      cuda_stream_);

      points_device_buf = (float*)points_.get_buf();
    } else {
      points_device_buf = (float*)points.get_buf();
    }

    // init
    cudaMemsetAsync(voxel_num_.get_buf(), 0, 4, cuda_stream_);
    cudaMemsetAsync(voxel_map_point_cnt_->get_buf(),
                    0,
                    voxel_map_point_cnt_->get_len_in_byte(),
                    cuda_stream_);
    cudaMemsetAsync(voxel_map_->get_buf(), 0, voxel_map_->get_len_in_byte(), cuda_stream_);

    const size_t thread_size = 128;
    auto ele_num = points.get_len_in_element();
    size_t block_size = std::ceil((float)ele_num / (thread_size * max_point_num_per_voxel_));
    // printf("ele_num: %u, block_size: %u\n", ele_num, block_size);

    scatter_kernel<<<block_size, thread_size, 0, cuda_stream_>>>(
        (void*)config_.get_buf(),
        (float*)points_device_buf,
        points.get_len_in_element(),
        (uint32_t*)voxel_map_point_cnt_->get_buf(),
        (uint32_t*)voxel_map_->get_buf());

    block_size = std::ceil((float)max_voxel_num_ / thread_size);
    // printf("block_size: %u\n", block_size);
    gather_kernel<<<block_size, thread_size, 0, cuda_stream_>>>(
        (void*)config_.get_buf(),
        points_device_buf,
        (uint32_t*)voxel_map_point_cnt_->get_buf(),
        (uint32_t*)voxel_map_->get_buf(),
        (uint32_t*)voxel_num_.get_buf(),
        (float*)voxel_->get_buf(),
        (uint32_t*)coor_->get_buf(),
        (uint32_t*)point_num_each_voxel_->get_buf());

    uint32_t voxel_num = 0;
    cudaMemcpyAsync(&voxel_num, voxel_num_.get_buf(), 4, cudaMemcpyDeviceToHost, cuda_stream_);
    cudaStreamSynchronize(cuda_stream_);
    // printf("voxel_num: %u\n", voxel_num);

    // set output data
    std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> output;
    linfer::util::Dims dims;
    dims = voxel_->get_dims();
    dims.d[0] = voxel_num;
    voxel_->resize(dims);
    // printf("%s\n", dims.format().c_str());

    dims = coor_->get_dims();
    dims.d[0] = voxel_num;
    coor_->resize(dims);
    // printf("%s\n", dims.format().c_str());

    dims = point_num_each_voxel_->get_dims();
    dims.d[0] = voxel_num;
    point_num_each_voxel_->resize(dims);
    // printf("%s\n", dims.format().c_str());

    output["voxel"] = voxel_;
    output["coor"] = coor_;
    output["point_num"] = point_num_each_voxel_;
    return output;
  }
};

VoxelizationOp::VoxelizationOp(const std::vector<float>& voxel_size,
                               const std::vector<float>& point_cloud_range,
                               size_t max_points,
                               void* stream) {
  impl_ = new Impl(voxel_size, point_cloud_range, max_points, stream);
}

VoxelizationOp::~VoxelizationOp() { delete impl_; }

std::unordered_map<std::string, std::shared_ptr<linfer::util::Tensor>> VoxelizationOp::operate(
    const linfer::util::Tensor& points) {
  return impl_->operate(points);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
