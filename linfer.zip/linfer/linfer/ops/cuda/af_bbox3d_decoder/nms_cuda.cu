/******************************************************************************
 * Copyright 2020 The Apollo Authors. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/

// ------------------------------------------------------------------
// Copyright (c) 2015 Microsoft
// Licensed under The MIT License
// Modified from MATLAB Faster R-CNN
// (https://github.com/shaoqingren/faster_rcnn)
// ------------------------------------------------------------------

#include <algorithm>
// headers in local files
#include "common_cuda_helper.hpp"
#include "nms_cuda.h"
const float EPS = 1e-8;
struct Point {
  float x, y;
  __device__ Point() {}
  __device__ Point(double _x, double _y) { x = _x, y = _y; }
  __device__ void set(float _x, float _y) {
    x = _x;
    y = _y;
  }
  __device__ Point operator+(const Point& b) const { return Point(x + b.x, y + b.y); }
  __device__ Point operator-(const Point& b) const { return Point(x - b.x, y - b.y); }
};
__device__ inline float cross(const Point& a, const Point& b) { return a.x * b.y - a.y * b.x; }

__device__ inline float cross(const Point& p1, const Point& p2, const Point& p0) {
  return (p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y);
}
__device__ int check_rect_cross(const Point& p1,
                                const Point& p2,
                                const Point& q1,
                                const Point& q2) {
  int ret = min(p1.x, p2.x) <= max(q1.x, q2.x) && min(q1.x, q2.x) <= max(p1.x, p2.x) &&
            min(p1.y, p2.y) <= max(q1.y, q2.y) && min(q1.y, q2.y) <= max(p1.y, p2.y);
  return ret;
}
__device__ inline void rotate_around_center(const Point& center,
                                            const float angle_cos,
                                            const float angle_sin,
                                            Point& p) {
  float new_x = (p.x - center.x) * angle_cos - (p.y - center.y) * angle_sin + center.x;
  float new_y = (p.x - center.x) * angle_sin + (p.y - center.y) * angle_cos + center.y;
  p.set(new_x, new_y);
}

__device__ inline int check_in_box2d(const float* box, const Point& p) {
  // params: box (5) [x1, y1, x2, y2, angle]
  const float MARGIN = 1e-5;

  float center_x = (box[0] + box[2]) / 2;
  float center_y = (box[1] + box[3]) / 2;
  float angle_cos = cos(-box[4]),
        angle_sin = sin(-box[4]);  // rotate the point in the opposite direction of box
  float rot_x = (p.x - center_x) * angle_cos - (p.y - center_y) * angle_sin + center_x;
  float rot_y = (p.x - center_x) * angle_sin + (p.y - center_y) * angle_cos + center_y;
  return (rot_x > box[0] - MARGIN && rot_x < box[2] + MARGIN && rot_y > box[1] - MARGIN &&
          rot_y < box[3] + MARGIN);
}

__device__ inline int intersection(const Point& p1,
                                   const Point& p0,
                                   const Point& q1,
                                   const Point& q0,
                                   Point& ans) {
  // fast exclusion
  if (check_rect_cross(p0, p1, q0, q1) == 0) return 0;

  // check cross standing
  float s1 = cross(q0, p1, p0);
  float s2 = cross(p1, q1, p0);
  float s3 = cross(p0, q1, q0);
  float s4 = cross(q1, p1, q0);

  if (!(s1 * s2 > 0 && s3 * s4 > 0)) return 0;

  // calculate intersection of two lines
  float s5 = cross(q1, p1, p0);
  if (fabs(s5 - s1) > EPS) {
    ans.x = (s5 * q0.x - s1 * q1.x) / (s5 - s1);
    ans.y = (s5 * q0.y - s1 * q1.y) / (s5 - s1);

  } else {
    float a0 = p0.y - p1.y, b0 = p1.x - p0.x, c0 = p0.x * p1.y - p1.x * p0.y;
    float a1 = q0.y - q1.y, b1 = q1.x - q0.x, c1 = q0.x * q1.y - q1.x * q0.y;
    float D = a0 * b1 - a1 * b0;

    ans.x = (b0 * c1 - b1 * c0) / D;
    ans.y = (a1 * c0 - a0 * c1) / D;
  }

  return 1;
}
__device__ inline int point_cmp(const Point& a, const Point& b, const Point& center) {
  return atan2(a.y - center.y, a.x - center.x) > atan2(b.y - center.y, b.x - center.x);
}
__device__ inline float box_overlap(const float* box_a, const float* box_b) {
  // params: box_a (5) [x1, y1, x2, y2, angle]
  // params: box_b (5) [x1, y1, x2, y2, angle]

  float a_x1 = box_a[0], a_y1 = box_a[1], a_x2 = box_a[2], a_y2 = box_a[3], a_angle = box_a[4];
  float b_x1 = box_b[0], b_y1 = box_b[1], b_x2 = box_b[2], b_y2 = box_b[3], b_angle = box_b[4];

  Point center_a((a_x1 + a_x2) / 2, (a_y1 + a_y2) / 2);
  Point center_b((b_x1 + b_x2) / 2, (b_y1 + b_y2) / 2);

  Point box_a_corners[5];
  box_a_corners[0].set(a_x1, a_y1);
  box_a_corners[1].set(a_x2, a_y1);
  box_a_corners[2].set(a_x2, a_y2);
  box_a_corners[3].set(a_x1, a_y2);

  Point box_b_corners[5];
  box_b_corners[0].set(b_x1, b_y1);
  box_b_corners[1].set(b_x2, b_y1);
  box_b_corners[2].set(b_x2, b_y2);
  box_b_corners[3].set(b_x1, b_y2);

  // get oriented corners
  float a_angle_cos = cos(a_angle), a_angle_sin = sin(a_angle);
  float b_angle_cos = cos(b_angle), b_angle_sin = sin(b_angle);

  for (int k = 0; k < 4; k++) {
    rotate_around_center(center_a, a_angle_cos, a_angle_sin, box_a_corners[k]);
    rotate_around_center(center_b, b_angle_cos, b_angle_sin, box_b_corners[k]);
  }

  box_a_corners[4] = box_a_corners[0];
  box_b_corners[4] = box_b_corners[0];

  // get intersection of lines
  Point cross_points[16];
  Point poly_center;
  int cnt = 0, flag = 0;

  poly_center.set(0, 0);
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      flag = intersection(box_a_corners[i + 1],
                          box_a_corners[i],
                          box_b_corners[j + 1],
                          box_b_corners[j],
                          cross_points[cnt]);
      if (flag) {
        poly_center = poly_center + cross_points[cnt];
        cnt++;
      }
    }
  }

  // check corners
  for (int k = 0; k < 4; k++) {
    if (check_in_box2d(box_a, box_b_corners[k])) {
      poly_center = poly_center + box_b_corners[k];
      cross_points[cnt] = box_b_corners[k];
      cnt++;
    }
    if (check_in_box2d(box_b, box_a_corners[k])) {
      poly_center = poly_center + box_a_corners[k];
      cross_points[cnt] = box_a_corners[k];
      cnt++;
    }
  }

  poly_center.x /= cnt;
  poly_center.y /= cnt;

  // sort the points of polygon
  Point temp;
  for (int j = 0; j < cnt - 1; j++) {
    for (int i = 0; i < cnt - j - 1; i++) {
      if (point_cmp(cross_points[i], cross_points[i + 1], poly_center)) {
        temp = cross_points[i];
        cross_points[i] = cross_points[i + 1];
        cross_points[i + 1] = temp;
      }
    }
  }

  // get the overlap areas
  float area = 0;
  for (int k = 0; k < cnt - 1; k++) {
    area += cross(cross_points[k] - cross_points[0], cross_points[k + 1] - cross_points[0]);
  }

  return fabs(area) / 2.0;
}

__device__ inline float devIoU(float const* const a, float const* const b) {
  // float left = max(a[0], b[0]), right = min(a[2], b[2]);
  // float top = max(a[1], b[1]), bottom = min(a[3], b[3]);
  // float width = max(right - left + 1, 0.f), height = max(bottom - top + 1, 0.f);
  // float interS = width * height;
  float Sa = (a[2] - a[0]) * (a[3] - a[1]);
  float Sb = (b[2] - b[0]) * (b[3] - b[1]);
  float s_overlap = box_overlap(a, b);
  return s_overlap / fmaxf(Sa + Sb - s_overlap, EPS);
}

__global__ void nms_kernel(const int n_boxes,
                           const float nms_overlap_thresh,
                           const float* dev_boxes,
                           uint64_t* dev_mask,
                           const int num_box_corners) {
  const int row_start = blockIdx.y;
  const int col_start = blockIdx.x;

  const int block_threads = blockDim.x;

  const int row_size = fminf(n_boxes - row_start * block_threads, block_threads);
  const int col_size = fminf(n_boxes - col_start * block_threads, block_threads);

  // __shared__ float block_boxes[NUM_THREADS_MACRO * NUM_2D_BOX_CORNERS_MACRO];
  __shared__ float block_boxes[NUM_THREADS_MACRO * 5];
  if (threadIdx.x < col_size) {
    block_boxes[threadIdx.x * num_box_corners + 0] =
        dev_boxes[(block_threads * col_start + threadIdx.x) * num_box_corners + 0];
    block_boxes[threadIdx.x * num_box_corners + 1] =
        dev_boxes[(block_threads * col_start + threadIdx.x) * num_box_corners + 1];
    block_boxes[threadIdx.x * num_box_corners + 2] =
        dev_boxes[(block_threads * col_start + threadIdx.x) * num_box_corners + 2];
    block_boxes[threadIdx.x * num_box_corners + 3] =
        dev_boxes[(block_threads * col_start + threadIdx.x) * num_box_corners + 3];
    block_boxes[threadIdx.x * num_box_corners + 4] =
        dev_boxes[(block_threads * col_start + threadIdx.x) * num_box_corners + 4];
  }
  __syncthreads();

  if (threadIdx.x < row_size) {
    const int cur_box_idx = block_threads * row_start + threadIdx.x;
    // const float cur_box[NUM_2D_BOX_CORNERS_MACRO] = {
    //     dev_boxes[cur_box_idx * num_box_corners + 0],
    //     dev_boxes[cur_box_idx * num_box_corners + 1],
    //     dev_boxes[cur_box_idx * num_box_corners + 2],
    //     dev_boxes[cur_box_idx * num_box_corners + 3]};
    const float* cur_box = dev_boxes + cur_box_idx * 5;
    unsigned long long t = 0;
    int start = 0;
    if (row_start == col_start) {
      start = threadIdx.x + 1;
    }
    for (int i = start; i < col_size; ++i) {
      if (devIoU(cur_box, block_boxes + i * num_box_corners) > nms_overlap_thresh) {
        t |= 1ULL << i;
      }
    }
    const int col_blocks = DIVUP(n_boxes, block_threads);
    dev_mask[cur_box_idx * col_blocks + col_start] = t;
  }
}

NmsCuda::NmsCuda(const int num_threads,
                 const int num_box_corners,
                 const float nms_overlap_threshold)
    : num_threads_(num_threads),
      num_box_corners_(num_box_corners),
      nms_overlap_threshold_(nms_overlap_threshold) {}

void NmsCuda::DoNmsCuda(const int host_filter_count,
                        float* dev_sorted_box_for_nms,
                        const cudaStream_t stream,
                        uint64_t* mask_ptr,
                        size_t* mask_size,
                        int* out_keep_inds,
                        int* out_num_to_keep) {
  const int col_blocks = DIVUP(host_filter_count, num_threads_);
  dim3 blocks(DIVUP(host_filter_count, num_threads_), DIVUP(host_filter_count, num_threads_));
  dim3 threads(num_threads_);
  void* gpu_ptr = nullptr;
  cudaHostGetDevicePointer(&gpu_ptr, (void*)mask_ptr, 0);
  nms_kernel<<<blocks, threads, 0, stream>>>(host_filter_count,
                                             nms_overlap_threshold_,
                                             dev_sorted_box_for_nms,
                                             (uint64_t*)gpu_ptr,
                                             num_box_corners_);
  // postprocess for nms output
  cudaStreamSynchronize(stream);
  std::vector<uint64_t> remv(col_blocks);
  memset(&remv[0], 0, sizeof(uint64_t) * col_blocks);

  for (int i = 0; i < host_filter_count; ++i) {
    int nblock = i / num_threads_;
    int inblock = i % num_threads_;

    if (!(remv[nblock] & (1ULL << inblock))) {
      out_keep_inds[(*out_num_to_keep)++] = i;
      uint64_t* p = mask_ptr + i * col_blocks;
      for (int j = nblock; j < col_blocks; ++j) {
        remv[j] |= p[j];
      }
    }
  }
}