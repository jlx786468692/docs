#include <cuda_runtime_api.h>

#include <algorithm>
#include <vector>

#include "linfer/ops/cuda/ops.h"
#include "linfer/util/internal/cuda/util.h"

namespace linfer {
namespace ops {
namespace cuda {

const float ThresHold = 1e-8;

inline float cross(const float2 p1, const float2 p2, const float2 p0) {
  return (p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y);
}

inline int check_box2d(const BBox box, const float2 p) {
  const float MARGIN = 1e-2;
  float center_x = box.x;
  float center_y = box.y;
  float angle_cos = cos(-box.rt);
  float angle_sin = sin(-box.rt);
  float rot_x = (p.x - center_x) * angle_cos + (p.y - center_y) * (-angle_sin);
  float rot_y = (p.x - center_x) * angle_sin + (p.y - center_y) * angle_cos;

  return (fabs(rot_x) < box.w / 2 + MARGIN && fabs(rot_y) < box.l / 2 + MARGIN);
}

bool intersection(const float2 p1, const float2 p0, const float2 q1, const float2 q0, float2& ans) {
  if ((std::min(p0.x, p1.x) <= std::max(q0.x, q1.x) &&
       std::min(q0.x, q1.x) <= std::max(p0.x, p1.x) &&
       std::min(p0.y, p1.y) <= std::max(q0.y, q1.y) &&
       std::min(q0.y, q1.y) <= std::max(p0.y, p1.y)) == 0)
    return false;

  float s1 = cross(q0, p1, p0);
  float s2 = cross(p1, q1, p0);
  float s3 = cross(p0, q1, q0);
  float s4 = cross(q1, p1, q0);

  if (!(s1 * s2 > 0 && s3 * s4 > 0)) return false;

  float s5 = cross(q1, p1, p0);
  if (fabs(s5 - s1) > ThresHold) {
    ans.x = (s5 * q0.x - s1 * q1.x) / (s5 - s1);
    ans.y = (s5 * q0.y - s1 * q1.y) / (s5 - s1);

  } else {
    float a0 = p0.y - p1.y, b0 = p1.x - p0.x, c0 = p0.x * p1.y - p1.x * p0.y;
    float a1 = q0.y - q1.y, b1 = q1.x - q0.x, c1 = q0.x * q1.y - q1.x * q0.y;
    float D = a0 * b1 - a1 * b0;

    ans.x = (b0 * c1 - b1 * c0) / D;
    ans.y = (a1 * c0 - a0 * c1) / D;
  }

  return true;
}

inline void rotate_around_center(const float2& center,
                                 const float angle_cos,
                                 const float angle_sin,
                                 float2& p) {
  float new_x = (p.x - center.x) * angle_cos + (p.y - center.y) * (-angle_sin) + center.x;
  float new_y = (p.x - center.x) * angle_sin + (p.y - center.y) * angle_cos + center.y;
  p = float2{new_x, new_y};
  return;
}

inline float box_overlap(const BBox& box_a, const BBox& box_b) {
  float a_angle = box_a.rt, b_angle = box_b.rt;
  float a_dx_half = box_a.w / 2, b_dx_half = box_b.w / 2, a_dy_half = box_a.l / 2,
        b_dy_half = box_b.l / 2;
  float a_x1 = box_a.x - a_dx_half, a_y1 = box_a.y - a_dy_half;
  float a_x2 = box_a.x + a_dx_half, a_y2 = box_a.y + a_dy_half;
  float b_x1 = box_b.x - b_dx_half, b_y1 = box_b.y - b_dy_half;
  float b_x2 = box_b.x + b_dx_half, b_y2 = box_b.y + b_dy_half;
  float2 box_a_corners[5];
  float2 box_b_corners[5];

  float2 center_a = float2{box_a.x, box_a.y};
  float2 center_b = float2{box_b.x, box_b.y};

  float2 cross_points[16];
  float2 poly_center = {0, 0};
  int cnt = 0;
  bool flag = false;

  box_a_corners[0] = float2{a_x1, a_y1};
  box_a_corners[1] = float2{a_x2, a_y1};
  box_a_corners[2] = float2{a_x2, a_y2};
  box_a_corners[3] = float2{a_x1, a_y2};

  box_b_corners[0] = float2{b_x1, b_y1};
  box_b_corners[1] = float2{b_x2, b_y1};
  box_b_corners[2] = float2{b_x2, b_y2};
  box_b_corners[3] = float2{b_x1, b_y2};

  float a_angle_cos = cos(a_angle), a_angle_sin = sin(a_angle);
  float b_angle_cos = cos(b_angle), b_angle_sin = sin(b_angle);

  for (int k = 0; k < 4; k++) {
    rotate_around_center(center_a, a_angle_cos, a_angle_sin, box_a_corners[k]);
    rotate_around_center(center_b, b_angle_cos, b_angle_sin, box_b_corners[k]);
  }

  box_a_corners[4] = box_a_corners[0];
  box_b_corners[4] = box_b_corners[0];

  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      flag = intersection(box_a_corners[i + 1],
                          box_a_corners[i],
                          box_b_corners[j + 1],
                          box_b_corners[j],
                          cross_points[cnt]);
      if (flag) {
        poly_center = {poly_center.x + cross_points[cnt].x, poly_center.y + cross_points[cnt].y};
        cnt++;
      }
    }
  }

  for (int k = 0; k < 4; k++) {
    if (check_box2d(box_a, box_b_corners[k])) {
      poly_center = {poly_center.x + box_b_corners[k].x, poly_center.y + box_b_corners[k].y};
      cross_points[cnt] = box_b_corners[k];
      cnt++;
    }
    if (check_box2d(box_b, box_a_corners[k])) {
      poly_center = {poly_center.x + box_a_corners[k].x, poly_center.y + box_a_corners[k].y};
      cross_points[cnt] = box_a_corners[k];
      cnt++;
    }
  }

  poly_center.x /= cnt;
  poly_center.y /= cnt;

  float2 temp;
  for (int j = 0; j < cnt - 1; j++) {
    for (int i = 0; i < cnt - j - 1; i++) {
      if (atan2(cross_points[i].y - poly_center.y, cross_points[i].x - poly_center.x) >
          atan2(cross_points[i + 1].y - poly_center.y, cross_points[i + 1].x - poly_center.x)) {
        temp = cross_points[i];
        cross_points[i] = cross_points[i + 1];
        cross_points[i + 1] = temp;
      }
    }
  }

  float area = 0;
  for (int k = 0; k < cnt - 1; k++) {
    float2 a = {cross_points[k].x - cross_points[0].x, cross_points[k].y - cross_points[0].y};
    float2 b = {cross_points[k + 1].x - cross_points[0].x,
                cross_points[k + 1].y - cross_points[0].y};
    area += (a.x * b.y - a.y * b.x);
  }
  return fabs(area) / 2.0;
}

int nms_cpu(std::vector<BBox>& bndboxes, const float nms_thresh, std::vector<BBox>& nms_pred) {
  std::sort(bndboxes.begin(), bndboxes.end(), [](const BBox& boxes1, const BBox& boxes2) {
    return boxes1.score > boxes2.score;
  });
  std::vector<int> suppressed(bndboxes.size(), 0);
  for (size_t i = 0; i < bndboxes.size(); i++) {
    if (suppressed[i] == 1) {
      continue;
    }
    nms_pred.emplace_back(bndboxes[i]);
    for (size_t j = i + 1; j < bndboxes.size(); j++) {
      if (suppressed[j] == 1) {
        continue;
      }

      float sa = bndboxes[i].w * bndboxes[i].l;
      float sb = bndboxes[j].w * bndboxes[j].l;
      float s_overlap = box_overlap(bndboxes[i], bndboxes[j]);
      float iou = s_overlap / fmaxf(sa + sb - s_overlap, ThresHold);

      if (iou >= nms_thresh) {
        suppressed[j] = 1;
      }
    }
  }
  return 0;
}

__device__ float sigmoid(const float x) { return 1.0f / (1.0f + expf(-x)); }

__global__ void bbox3d_decode_kernal(const float* cls_input,
                                     float* box_input,
                                     const float* dir_cls_input,
                                     float* anchors,
                                     float* bndbox_output,
                                     int* object_counter,
                                     const float min_x_range,
                                     const float max_x_range,
                                     const float min_y_range,
                                     const float max_y_range,
                                     const int feature_x_size,
                                     const int feature_y_size,
                                     const int num_anchors,
                                     const int num_classes,
                                     const int num_box_values,
                                     const float score_thresh,
                                     const float dir_offset) {
  int loc_index = blockIdx.x;
  int ith_anchor = threadIdx.x;
  if (ith_anchor >= num_anchors * num_classes) {
    return;
  }
  int col = loc_index % feature_x_size;
  int row = loc_index / feature_x_size;

  float x_step = (max_x_range - min_x_range) / feature_x_size;
  float y_step = (max_y_range - min_y_range) / feature_y_size;
  float x_offset = min_x_range + col * x_step;  // FIXME
  float y_offset = min_y_range + row * y_step;  // FIXME

  int cls_offset = (loc_index * blockDim.x + ith_anchor) * num_classes;
  int32_t cls_id = 0;
  const float* scores = cls_input + cls_offset;
  float max_score = .0;
  for (int i = 0; i < num_classes; i++) {
    float cls_score = sigmoid(scores[i]);
    if (cls_score > max_score) {
      max_score = cls_score;
      cls_id = i;
    }
  }

  if (max_score >= score_thresh) {
    int box_offset = (loc_index * blockDim.x + ith_anchor) * 7;
    int dir_cls_offset = (loc_index * blockDim.x + ith_anchor) * 2;
    float* anchor_ptr = anchors + ith_anchor * 5;
    float z_offset = anchor_ptr[2] / 2 + anchor_ptr[4];  // center point
    float anchor[7] = {x_offset + x_step / 2,
                       y_offset + y_step / 2,
                       z_offset,
                       anchor_ptr[0],
                       anchor_ptr[1],
                       anchor_ptr[2],
                       anchor_ptr[3]};
    float* box_encodings = box_input + box_offset;

    float xa = anchor[0];
    float ya = anchor[1];
    float za = anchor[2];
    float dxa = anchor[3];
    float dya = anchor[4];
    float dza = anchor[5];
    float ra = anchor[6];
    float diagonal = sqrtf(dxa * dxa + dya * dya);
    box_encodings[0] = box_encodings[0] * diagonal + xa;
    box_encodings[1] = box_encodings[1] * diagonal + ya;
    // box_encodings[2] = box_encodings[2] * dza + za;
    float zg = box_encodings[2] * dza + za;
    box_encodings[3] = expf(box_encodings[3]) * dxa;
    box_encodings[4] = expf(box_encodings[4]) * dya;
    box_encodings[5] = expf(box_encodings[5]) * dza;
    box_encodings[6] = box_encodings[6] + ra;

    zg = zg - box_encodings[5] / 2;  // TODO 减去 anchor_ptr[2] / 2 ？
    box_encodings[2] = zg;

    // from mmdetection3d
    // period: pi
    // dir_offset: -pi/2
    // dir_rot = val - torch.floor(val / period + offset) * period
    // bboxes[..., 6] = (
    //         dir_rot + self.dir_offset +
    //         np.pi * dir_scores.to(bboxes.dtype))
    int dir = dir_cls_input[dir_cls_offset] > dir_cls_input[dir_cls_offset + 1] ? 0 : 1;
    float yaw = box_input[box_offset + 6] + dir_offset;
    float dir_rot = yaw - floor(yaw / M_PI) * M_PI;
    yaw = dir_rot - dir_offset + M_PI * dir;

    int resCount = (int)atomicAdd(object_counter, 1);
    float* data = bndbox_output + resCount * 9;
    data[0] = box_input[box_offset];
    data[1] = box_input[box_offset + 1];
    data[2] = box_input[box_offset + 2];
    data[3] = box_input[box_offset + 3];
    data[4] = box_input[box_offset + 4];
    data[5] = box_input[box_offset + 5];
    data[6] = yaw;
    int32_t* pcls = reinterpret_cast<int32_t*>(data + 7);
    *pcls = cls_id;
    data[8] = max_score;
  }
}

cudaError_t launch_bbox3d_decode_kernal(const float* cls_input,
                                        float* box_input,
                                        const float* dir_cls_input,
                                        float* anchors,
                                        float* bndbox_output,
                                        int* object_counter,
                                        const float min_x_range,
                                        const float max_x_range,
                                        const float min_y_range,
                                        const float max_y_range,
                                        const int feature_x_size,
                                        const int feature_y_size,
                                        const int num_anchors,
                                        const int num_classes,
                                        const int num_box_values,
                                        const float score_thresh,
                                        const float dir_offset,
                                        cudaStream_t stream) {
  int bev_size = feature_x_size * feature_y_size;
  dim3 threads(num_anchors * num_classes);
  dim3 blocks(bev_size);

  bbox3d_decode_kernal<<<blocks, threads, 0, stream>>>(cls_input,
                                                       box_input,
                                                       dir_cls_input,
                                                       anchors,
                                                       bndbox_output,
                                                       object_counter,
                                                       min_x_range,
                                                       max_x_range,
                                                       min_y_range,
                                                       max_y_range,
                                                       feature_x_size,
                                                       feature_y_size,
                                                       num_anchors,
                                                       num_classes,
                                                       num_box_values,
                                                       score_thresh,
                                                       dir_offset);
  return cudaGetLastError();
}

class BBox3DDecoderOp::Impl {
 private:
  cudaStream_t cuda_stream_;
  size_t num_class_;
  size_t anchor_per_class_;
  size_t val_len_per_anchor_;
  float score_thresh_;
  float nms_thresh_;
  size_t feature_size_x_;
  size_t feature_size_y_;
  std::vector<float> range_;
  std::vector<BBox> bbox_cand_;

  linfer::util::Tensor3D prior_box_per_anchor_point_;
  linfer::util::Tensor1D bbox_num_;
  std::shared_ptr<linfer::util::TensorHostDevice2D> bbox_;

 public:
  Impl(float score_thresh,
       float nms_thresh,
       size_t feature_size_x,
       size_t feature_size_y,
       std::vector<float> range,
       std::vector<std::vector<std::vector<float>>> prior_box_per_anchor_point,
       void* stream)
      : num_class_(prior_box_per_anchor_point.size()),
        anchor_per_class_(prior_box_per_anchor_point[0].size()),
        val_len_per_anchor_(prior_box_per_anchor_point[0][0].size()),
        score_thresh_(score_thresh),
        nms_thresh_(nms_thresh),
        feature_size_x_(feature_size_x),
        feature_size_y_(feature_size_y),
        range_(range),
        prior_box_per_anchor_point_(linfer::util::DeviceType::GPU,
                                    linfer::util::DataType::kFLOAT,
                                    nullptr,
                                    num_class_,
                                    anchor_per_class_,
                                    val_len_per_anchor_),
        bbox_num_(linfer::util::DeviceType::GPU, linfer::util::DataType::kUINT32, nullptr, 1),
        bbox_(nullptr) {
    if (stream) {
      cuda_stream_ = static_cast<cudaStream_t>(stream);
    } else {
      CHECK_CUDA(cudaStreamCreate(&cuda_stream_));
    }

    bbox_ = std::make_shared<linfer::util::TensorHostDevice2D>(
        linfer::util::DataType::kFLOAT,
        nullptr,
        nullptr,
        feature_size_x * feature_size_y * num_class_ * anchor_per_class_,
        9);

    std::vector<float> anchor_data(num_class_ * anchor_per_class_ * val_len_per_anchor_, .0);
    for (int i = 0; i < num_class_; ++i) {
      for (int j = 0; j < anchor_per_class_; ++j) {
        for (int k = 0; k < val_len_per_anchor_; ++k) {
          size_t offset = i * val_len_per_anchor_ * anchor_per_class_ + j * val_len_per_anchor_ + k;
          anchor_data[offset] = prior_box_per_anchor_point[i][j][k];
        }
      }
    }
    cudaMemcpy(prior_box_per_anchor_point_.get_buf(),
               anchor_data.data(),
               anchor_data.size() * sizeof(float),
               cudaMemcpyHostToDevice);
  }

  void operate(const linfer::util::Tensor& feat_cls,
               const linfer::util::Tensor& feat_bbox,
               const linfer::util::Tensor& feat_dir_cls,
               std::vector<BBox>& bbox) {
    LASSERT_MSG(feat_cls.get_devicetype() == linfer::util::DeviceType::GPU,
                "feat_cls data must on GPU");
    LASSERT_MSG(feat_bbox.get_devicetype() == linfer::util::DeviceType::GPU,
                "feat_bbox data must on GPU");
    LASSERT_MSG(feat_dir_cls.get_devicetype() == linfer::util::DeviceType::GPU,
                "feat_dir_cls data must on GPU");

    auto feat_dims = feat_bbox.get_dims();
    LASSERT_MSG(feature_size_x_ == feat_dims.d[2], "feature_size_x is not match");
    LASSERT_MSG(feature_size_y_ == feat_dims.d[1], "feature_size_y is not match");

    cudaMemsetAsync(bbox_num_.get_buf(), 0, 4, cuda_stream_);
    launch_bbox3d_decode_kernal((float*)feat_cls.get_buf(),
                                (float*)feat_bbox.get_buf(),
                                (float*)feat_dir_cls.get_buf(),
                                (float*)prior_box_per_anchor_point_.get_buf(),
                                (float*)bbox_->get_gpu_buf(),
                                (int*)bbox_num_.get_buf(),
                                range_[0],
                                range_[2],
                                range_[1],
                                range_[3],
                                feature_size_x_,
                                feature_size_y_,
                                anchor_per_class_,
                                num_class_,
                                val_len_per_anchor_,
                                score_thresh_,
                                M_PI_2,
                                cuda_stream_);

    uint32_t bbox_num = 0;
    cudaMemcpyAsync(&bbox_num, bbox_num_.get_buf(), 4, cudaMemcpyDeviceToHost, cuda_stream_);
    cudaStreamSynchronize(cuda_stream_);

    bbox_cand_.resize(bbox_num);
    if (bbox_num > 0) {
      cudaMemcpy(bbox_->get_cpu_buf(),
                 bbox_->get_gpu_buf(),
                 bbox_num * 9 * 4,
                 cudaMemcpyDeviceToHost);
      float* bbox_out = (float*)bbox_->get_cpu_buf();
      for (int i = 0; i < bbox_num; ++i) {
        int32_t* pcls = reinterpret_cast<int32_t*>(bbox_out + i * 9 + 7);
        bbox_cand_[i] = BBox(*pcls,
                             bbox_out[i * 9 + 8],
                             bbox_out[i * 9],
                             bbox_out[i * 9 + 1],
                             bbox_out[i * 9 + 2],
                             bbox_out[i * 9 + 3],
                             bbox_out[i * 9 + 4],
                             bbox_out[i * 9 + 5],
                             bbox_out[i * 9 + 6]);
      }
      nms_cpu(bbox_cand_, nms_thresh_, bbox);
    }
  }
};

BBox3DDecoderOp::BBox3DDecoderOp(
    float score_thresh,
    float nms_thresh,
    size_t feature_size_x,
    size_t feature_size_y,
    const std::vector<float>& range,
    const std::vector<std::vector<std::vector<float>>>& prior_box_per_anchor,
    void* stream) {
  impl_ = new Impl(score_thresh,
                   nms_thresh,
                   feature_size_x,
                   feature_size_y,
                   range,
                   prior_box_per_anchor,
                   stream);
}

BBox3DDecoderOp::~BBox3DDecoderOp() { delete impl_; }

void BBox3DDecoderOp::operate(const linfer::util::Tensor& feat_cls,
                              const linfer::util::Tensor& feat_bbox,
                              const linfer::util::Tensor& feat_dir_cls,
                              std::vector<BBox>& bbox) {
  return impl_->operate(feat_cls, feat_bbox, feat_dir_cls, bbox);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
