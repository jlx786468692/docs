#include <cuda_runtime_api.h>

#include <algorithm>
#include <vector>

// headers in CUDA
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/host_vector.h>
#include <thrust/sort.h>

#include "linfer/ops/cuda/af_bbox3d_decoder/nms_cuda.h"
#include "linfer/ops/cuda/ops.h"
#include "linfer/ops/trt/common/common_cuda_helper.hpp"
#include "linfer/util/internal/cuda/util.h"

__global__ void bevdet_filter_kernel(const float* heatmap_preds,
                                     const float* reg_preds,
                                     const float* height_preds,
                                     const float* dim_preds,
                                     const float* rot_preds,
                                     float* filtered_box,
                                     float* filtered_score,
                                     int* filtered_label,
                                     float* box_for_nms,
                                     int* filter_count,
                                     const float score_threshold,
                                     const int num_box_corners,
                                     const int num_output_box_feature,
                                     const int num_class,
                                     const int half_grid_x_size,
                                     const int half_grid_y_size,
                                     const float voxel_x_size,
                                     const float voxel_y_size,
                                     const float min_x_range,
                                     const float min_y_range,
                                     const float out_size_factor,
                                     const int* group,
                                     const int num_big_class) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;
  int stride_ = half_grid_x_size * half_grid_y_size;
  if (tid >= stride_) return;
  int grid_x = tid % half_grid_x_size;
  int grid_y = tid / half_grid_x_size;

  for (int i = 0; i < num_class; ++i) {
    float score = 1 / (1 + expf(-heatmap_preds[tid * num_class + i]));
    // printf("%d: %f \n", tid, score);
    if (score > score_threshold) {
      //   printf("tid: %d, min_x_range: %f, min_y_range: %f \n", tid,min_x_range,
      //   min_y_range); printf("group: %d \n",  group[i]);
      int counter = atomicAdd(filter_count, 1);

      float box_px = (grid_x + reg_preds[2 * (tid * num_big_class + group[i])]) * out_size_factor *
                         voxel_x_size +
                     min_x_range;
      float box_py = (grid_y + reg_preds[2 * (tid * num_big_class + group[i]) + 1]) *
                         out_size_factor * voxel_y_size +
                     min_y_range;

      float box_pz = height_preds[tid * num_big_class + group[i]];

      float box_dx = expf(dim_preds[3 * (tid * num_big_class + group[i]) + 0]);
      float box_dy = expf(dim_preds[3 * (tid * num_big_class + group[i]) + 1]);
      float box_dz = expf(dim_preds[3 * (tid * num_big_class + group[i]) + 2]);

      float rots = rot_preds[2 * (tid * num_big_class + group[i]) + 0];
      float rotc = rot_preds[2 * (tid * num_big_class + group[i]) + 1];
      // float box_ro = atan2(rotc, rots) + M_PI;
      float box_ro = atan2(rots, rotc);
      // float period = M_PI * 2 ;
      // box_ro = box_ro - floor(box_ro / period + 0.5) * period;
      //   printf("%d: %f , %f \n", tid, rots, rotc);
      //   printf("%d: %f, %f , %f , %f ,\n", tid, score, rots, rotc, box_ro );
      //   printf("%d: %f, %f , %f , %d, %d, %d, %d\n", tid, score, box_px, box_py, grid_x,
      //   grid_y,
      //     half_grid_x_size, half_grid_y_size);
      // box_pz = box_pz + box_dz / 2;

      filtered_box[counter * num_output_box_feature + 0] = box_px;
      filtered_box[counter * num_output_box_feature + 1] = box_py;
      filtered_box[counter * num_output_box_feature + 2] = box_pz;
      filtered_box[counter * num_output_box_feature + 3] = box_dx;
      filtered_box[counter * num_output_box_feature + 4] = box_dy;
      filtered_box[counter * num_output_box_feature + 5] = box_dz;
      filtered_box[counter * num_output_box_feature + 6] = box_ro;
      filtered_score[counter] = score;
      filtered_label[counter] = i;

      box_for_nms[counter * num_box_corners + 0] = -0.5 * box_dx + box_px;
      box_for_nms[counter * num_box_corners + 1] = -0.5 * box_dy + box_py;
      box_for_nms[counter * num_box_corners + 2] = 0.5 * box_dx + box_px;
      box_for_nms[counter * num_box_corners + 3] = 0.5 * box_dy + box_py;
      //   float yaw = - box_ro - M_PI / 2 ;
      float yaw = box_ro;

      box_for_nms[counter * num_box_corners + 4] = yaw;
    }
  }
}

__global__ void bevdet_sort_boxes_by_indexes_kernel(float* filtered_box,
                                                    int* filtered_label,
                                                    float* filtered_score,
                                                    float* box_for_nms,
                                                    int* indexes,
                                                    int filter_count,
                                                    float* sorted_filtered_boxes,
                                                    int* sorted_filtered_label,
                                                    float* sorted_filtered_score,
                                                    float* sorted_box_for_nms,
                                                    const int num_box_corners,
                                                    const int num_output_box_feature) {
  int tid = threadIdx.x + blockIdx.x * blockDim.x;
  if (tid < filter_count) {
    int sort_index = indexes[tid];
    sorted_filtered_boxes[tid * num_output_box_feature + 0] =
        filtered_box[sort_index * num_output_box_feature + 0];
    sorted_filtered_boxes[tid * num_output_box_feature + 1] =
        filtered_box[sort_index * num_output_box_feature + 1];
    sorted_filtered_boxes[tid * num_output_box_feature + 2] =
        filtered_box[sort_index * num_output_box_feature + 2];
    sorted_filtered_boxes[tid * num_output_box_feature + 3] =
        filtered_box[sort_index * num_output_box_feature + 3];
    sorted_filtered_boxes[tid * num_output_box_feature + 4] =
        filtered_box[sort_index * num_output_box_feature + 4];
    sorted_filtered_boxes[tid * num_output_box_feature + 5] =
        filtered_box[sort_index * num_output_box_feature + 5];
    sorted_filtered_boxes[tid * num_output_box_feature + 6] =
        filtered_box[sort_index * num_output_box_feature + 6];
    sorted_filtered_score[tid] = filtered_score[sort_index];
    sorted_filtered_label[tid] = filtered_label[sort_index];

    sorted_box_for_nms[tid * num_box_corners + 0] = box_for_nms[sort_index * num_box_corners + 0];
    sorted_box_for_nms[tid * num_box_corners + 1] = box_for_nms[sort_index * num_box_corners + 1];
    sorted_box_for_nms[tid * num_box_corners + 2] = box_for_nms[sort_index * num_box_corners + 2];
    sorted_box_for_nms[tid * num_box_corners + 3] = box_for_nms[sort_index * num_box_corners + 3];
    sorted_box_for_nms[tid * num_box_corners + 4] = box_for_nms[sort_index * num_box_corners + 4];
  }
}

namespace linfer {
namespace ops {
namespace cuda {

class BEVDetBBox3DDecoderOp::Impl {
 private:
  cudaStream_t cuda_stream_;
  const int num_anchor_;
  const int num_class_;
  const float score_threshold_;
  const int num_threads_ = 64;
  const float nms_overlap_threshold_;
  const int num_box_corners_;
  const int num_output_box_feature_;
  const int grid_x_size_;
  const int grid_y_size_;
  const float voxel_x_size_;
  const float voxel_y_size_;
  const float min_x_range_;
  const float min_y_range_;
  const float out_size_factor_;
  const int num_box_values_ = 7;
  const int num_big_class_ = 3;
  int* group_;

  std::shared_ptr<linfer::util::Tensor> dev_filtered_box_;
  std::shared_ptr<linfer::util::Tensor> dev_filtered_score_;
  std::shared_ptr<linfer::util::Tensor> dev_box_for_nms_;

  std::shared_ptr<linfer::util::Tensor> dev_filtered_label_;
  std::shared_ptr<linfer::util::Tensor> dev_filter_count_;

  std::unique_ptr<NmsCuda> nms_cuda_ptr_;
  uint64_t* mask_ptr_ = nullptr;
  size_t mask_size_ = 100000;
  const int input_nms_max_size_ = 4096;

 public:
  Impl(const int num_anchor,
       const int num_class,
       const float score_threshold,
       const float nms_overlap_threshold,
       const int num_box_corners,
       const int num_output_box_feature,
       const int grid_x_size,
       const int grid_y_size,
       const float voxel_x_size,
       const float voxel_y_size,
       const float min_x_range,
       const float min_y_range,
       const float out_size_factor,
       const int* group,
       void* stream)
      : num_anchor_(num_anchor),
        num_class_(num_class),
        score_threshold_(score_threshold),
        nms_overlap_threshold_(nms_overlap_threshold),
        num_box_corners_(num_box_corners),
        num_output_box_feature_(num_output_box_feature),
        grid_x_size_(grid_x_size),
        grid_y_size_(grid_y_size),
        voxel_x_size_(voxel_x_size),
        voxel_y_size_(voxel_y_size),
        min_x_range_(min_x_range),
        min_y_range_(min_y_range),
        out_size_factor_(out_size_factor) {
    if (stream) {
      cuda_stream_ = static_cast<cudaStream_t>(stream);
    } else {
      CHECK_CUDA(cudaStreamCreateWithFlags(&cuda_stream_, cudaStreamNonBlocking));
    }

    nms_cuda_ptr_.reset(new NmsCuda(num_threads_, num_box_corners, nms_overlap_threshold));

    dev_filtered_box_ = std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                                 linfer::util::DataType::kFLOAT,
                                                                 nullptr,
                                                                 num_box_values_ * num_anchor_);
    dev_filtered_score_ = std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                                   linfer::util::DataType::kFLOAT,
                                                                   nullptr,
                                                                   num_anchor_);
    dev_filtered_label_ = std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                                   linfer::util::DataType::kINT32,
                                                                   nullptr,
                                                                   num_anchor_);
    dev_box_for_nms_ =
        std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                 linfer::util::DataType::kFLOAT,
                                                 nullptr,
                                                 num_anchor_ * 5);  // kNumBoxCorners: 5
    dev_filter_count_ = std::make_shared<linfer::util::Tensor1D>(linfer::util::DeviceType::GPU,
                                                                 linfer::util::DataType::kINT32,
                                                                 nullptr,
                                                                 1);

    const int col_blocks = DIVUP(input_nms_max_size_, num_threads_);
    // cudaMalloc((void**)&mask_data, host_filter_count[0] * col_blocks *
    // sizeof(unsigned long long));
    cudaHostAlloc((void**)&mask_ptr_,
                  input_nms_max_size_ * col_blocks * sizeof(uint64_t),
                  cudaHostAllocMapped);

    (cudaMallocAsync(reinterpret_cast<void**>(&group_), num_class * sizeof(int), cuda_stream_));
    (cudaMemcpyAsync(group_, group, num_class * sizeof(int), cudaMemcpyHostToDevice, cuda_stream_));
  }
  void operate(const linfer::util::Tensor& heatmap_output,
               const linfer::util::Tensor& reg_output,
               const linfer::util::Tensor& height_output,
               const linfer::util::Tensor& dim_output,
               const linfer::util::Tensor& rot_output,
               std::vector<BBox>& bbox) {
    cudaMemsetAsync(dev_filter_count_->get_buf(), 0, sizeof(int), cuda_stream_);
    const int num_blocks_filter_kernel = DIVUP(num_anchor_, num_threads_);
    bevdet_filter_kernel<<<num_blocks_filter_kernel, num_threads_, 0, cuda_stream_>>>(
        (const float*)heatmap_output.get_buf(),
        (const float*)reg_output.get_buf(),
        (const float*)height_output.get_buf(),
        (const float*)dim_output.get_buf(),
        (const float*)rot_output.get_buf(),
        (float*)dev_filtered_box_->get_buf(),
        (float*)dev_filtered_score_->get_buf(),
        (int*)dev_filtered_label_->get_buf(),
        (float*)dev_box_for_nms_->get_buf(),
        (int*)dev_filter_count_->get_buf(),
        score_threshold_,
        num_box_corners_,
        num_output_box_feature_,
        num_class_,
        grid_x_size_,
        grid_y_size_,
        voxel_x_size_,
        voxel_y_size_,
        min_x_range_,
        min_y_range_,
        out_size_factor_,
        group_,
        num_big_class_);
    int host_filter_count[1] = {0};

    (cudaMemcpyAsync(host_filter_count,
                     dev_filter_count_->get_buf(),
                     sizeof(int),
                     cudaMemcpyDeviceToHost,
                     cuda_stream_));
    // std::cout << "host_filter_count:"  << host_filter_count[0] << std::endl;
    if (host_filter_count[0] == 0) {
      return;
    }

    int* dev_indexes;
    float *dev_sorted_filtered_box, *dev_sorted_box_for_nms;
    float* dev_sorted_filtered_score;
    int* dev_sorted_filtered_label;
    (cudaMallocAsync(reinterpret_cast<void**>(&dev_indexes),
                     host_filter_count[0] * sizeof(int),
                     cuda_stream_));
    (cudaMallocAsync(reinterpret_cast<void**>(&dev_sorted_filtered_box),
                     num_output_box_feature_ * host_filter_count[0] * sizeof(float),
                     cuda_stream_));
    (cudaMallocAsync(reinterpret_cast<void**>(&dev_sorted_filtered_score),
                     host_filter_count[0] * sizeof(float),
                     cuda_stream_));
    (cudaMallocAsync(reinterpret_cast<void**>(&dev_sorted_filtered_label),
                     host_filter_count[0] * sizeof(int),
                     cuda_stream_));
    (cudaMallocAsync(reinterpret_cast<void**>(&dev_sorted_box_for_nms),
                     num_box_corners_ * host_filter_count[0] * sizeof(float),
                     cuda_stream_));

    thrust::device_ptr<float> dev_ptr_filtered_score((float*)dev_filtered_score_->get_buf());
    thrust::host_vector<float> host_filtered_score_(host_filter_count[0]);
    thrust::copy(dev_ptr_filtered_score,
                 dev_ptr_filtered_score + size_t(host_filter_count[0]),
                 host_filtered_score_.begin());

    thrust::host_vector<int> host_indexes(host_filter_count[0]);
    thrust::sequence(host_indexes.begin(), host_indexes.end());
    thrust::sort_by_key(host_filtered_score_.begin(),
                        host_filtered_score_.end(),
                        host_indexes.begin(),
                        thrust::greater<float>());
    (cudaMemcpyAsync(dev_indexes,
                     thrust::raw_pointer_cast(host_indexes.data()),
                     host_filter_count[0] * sizeof(int),
                     cudaMemcpyHostToDevice,
                     cuda_stream_));
    const int num_blocks = DIVUP(host_filter_count[0], num_threads_);
    bevdet_sort_boxes_by_indexes_kernel<<<num_blocks, num_threads_, 0, cuda_stream_>>>(
        (float*)dev_filtered_box_->get_buf(),
        (int*)dev_filtered_label_->get_buf(),
        (float*)dev_filtered_score_->get_buf(),
        (float*)dev_box_for_nms_->get_buf(),
        dev_indexes,
        host_filter_count[0],
        dev_sorted_filtered_box,
        dev_sorted_filtered_label,
        dev_sorted_filtered_score,
        dev_sorted_box_for_nms,
        num_box_corners_,
        num_output_box_feature_);

    int keep_inds[host_filter_count[0]];
    memset(keep_inds, 0, host_filter_count[0] * sizeof(int));
    int out_num_objects = 0;

    int boxSize =
        host_filter_count[0] > input_nms_max_size_ ? input_nms_max_size_ : host_filter_count[0];

    nms_cuda_ptr_->DoNmsCuda(boxSize,
                             dev_sorted_box_for_nms,
                             cuda_stream_,
                             mask_ptr_,
                             &mask_size_,
                             keep_inds,
                             &out_num_objects);
    float host_filtered_box[host_filter_count[0] * num_output_box_feature_];
    float host_filtered_score[host_filter_count[0]];
    int host_filtered_label[host_filter_count[0]];

    (cudaMemcpyAsync(host_filtered_box,
                     dev_sorted_filtered_box,
                     num_output_box_feature_ * host_filter_count[0] * sizeof(float),
                     cudaMemcpyDeviceToHost,
                     cuda_stream_));
    (cudaMemcpyAsync(host_filtered_score,
                     dev_sorted_filtered_score,
                     host_filter_count[0] * sizeof(float),
                     cudaMemcpyDeviceToHost,
                     cuda_stream_));
    (cudaMemcpyAsync(host_filtered_label,
                     dev_sorted_filtered_label,
                     host_filter_count[0] * sizeof(int),
                     cudaMemcpyDeviceToHost,
                     cuda_stream_));

    for (size_t i = 0; i < out_num_objects; ++i)
      bbox.push_back(BBox(host_filtered_label[keep_inds[i]],
                          host_filtered_score[keep_inds[i]],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 0],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 1],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 2],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 4],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 3],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 5],
                          host_filtered_box[keep_inds[i] * num_output_box_feature_ + 6]));
  }
};

BEVDetBBox3DDecoderOp::BEVDetBBox3DDecoderOp(const int num_anchor,
                                             const int num_class,
                                             const float score_threshold,
                                             const float nms_overlap_threshold,
                                             const int num_box_corners,
                                             const int num_output_box_feature,
                                             const int grid_x_size,
                                             const int grid_y_size,
                                             const float voxel_x_size,
                                             const float voxel_y_size,
                                             const float min_x_range,
                                             const float min_y_range,
                                             const float out_size_factor,
                                             const int* group,
                                             void* stream) {
  impl_ = new Impl(num_anchor,
                   num_class,
                   score_threshold,
                   nms_overlap_threshold,
                   num_box_corners,
                   num_output_box_feature,
                   grid_x_size,
                   grid_y_size,
                   voxel_x_size,
                   voxel_y_size,
                   min_x_range,
                   min_y_range,
                   out_size_factor,
                   group,
                   stream);
}

BEVDetBBox3DDecoderOp::~BEVDetBBox3DDecoderOp() { delete impl_; }

void BEVDetBBox3DDecoderOp::operate(const linfer::util::Tensor& heatmap_output,
                                    const linfer::util::Tensor& reg_output,
                                    const linfer::util::Tensor& height_output,
                                    const linfer::util::Tensor& dim_output,
                                    const linfer::util::Tensor& rot_output,
                                    std::vector<BBox>& bbox) {
  return impl_->operate(heatmap_output, reg_output, height_output, dim_output, rot_output, bbox);
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
