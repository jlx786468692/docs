#include <iostream>

#include "linfer/ops/cuda/ops.h"

namespace linfer {
namespace ops {
namespace cuda {

constexpr size_t kTHREADS_PER_BLOCK = 1024;

__global__ void FormatKernel(float* const input_ptr,
                             const size_t batch_size,
                             const size_t input_size,
                             const size_t input_channels,
                             bool convert_color,
                             float* tensor_ptr) {
  const __uint32_t index = blockIdx.x * blockDim.x + threadIdx.x;
  const __uint32_t each_batch = index / input_size;
  const __uint32_t each_index = index - each_batch * input_size;
  if (index < batch_size * input_size) {
    const float* pt =
        input_ptr + each_batch * input_size * input_channels + each_index * input_channels;
    *(tensor_ptr + each_batch * input_size * input_channels + each_index) =
        convert_color ? *(pt + 2) : *pt;
    *(tensor_ptr + each_batch * input_size * input_channels + each_index + input_size) = *(pt + 1);
    *(tensor_ptr + each_batch * input_size * input_channels + each_index + input_size * 2) =
        convert_color ? *pt : *(pt + 2);
  }
}

__global__ void FormatAndNormalize(float* const input_ptr,
                                   const size_t batch_size,
                                   const size_t input_size,
                                   const size_t input_channels,
                                   const float* mean,
                                   const float* std,
                                   bool convert_color,
                                   float* tensor_ptr) {
  const __uint32_t index = blockIdx.x * blockDim.x + threadIdx.x;
  const __uint32_t each_batch = index / input_size;
  const __uint32_t each_index = index - each_batch * input_size;
  if (index < batch_size * input_size) {
    const float* pt =
        input_ptr + each_batch * input_size * input_channels + each_index * input_channels;
    *(tensor_ptr + each_batch * input_size * input_channels + each_index) =
        ((convert_color ? *(pt + 2) : *pt) - mean[0]) / std[0];
    *(tensor_ptr + each_batch * input_size * input_channels + each_index + input_size) =
        (*(pt + 1) - mean[1]) / std[1];
    *(tensor_ptr + each_batch * input_size * input_channels + each_index + input_size * 2) =
        ((convert_color ? *pt : *(pt + 2)) - mean[2]) / std[2];
  }
}

__global__ void SimpleFormatAndNormalize(uint8_t* const input_ptr,
                                         const size_t batch_size,
                                         const size_t input_size,
                                         const size_t input_channels,
                                         const float* mean,
                                         const float* std,
                                         const bool convert_color,
                                         float* const tensor_ptr) {
  const __uint32_t index = blockIdx.x * blockDim.x + threadIdx.x;
  if (index < batch_size * input_size) {
    const uint8_t* pt = input_ptr + index * input_channels;
    float* out = tensor_ptr + index * input_channels;

    *out = (static_cast<float>(convert_color ? *(pt + 2) : *pt) - mean[0]) / std[0];
    *(out + 1) = (static_cast<float>(*(pt + 1)) - mean[1]) / std[1];
    *(out + 2) = (static_cast<float>(convert_color ? *pt : *(pt + 2)) - mean[2]) / std[2];
  }
}

VisionUtils::VisionUtils(const size_t buffer_size, void* const stream) {
  cudaMallocAsync(reinterpret_cast<void**>(&input_buffer_),
                  buffer_size * sizeof(float),
                  static_cast<cudaStream_t>(stream));
}

VisionUtils::VisionUtils(const size_t buffer_size,
                         const float* mean,
                         const float* std,
                         const size_t channels,
                         void* const stream) {
  cudaMallocAsync(reinterpret_cast<void**>(&input_buffer_),
                  buffer_size * sizeof(float),
                  static_cast<cudaStream_t>(stream));
  // mean
  cudaMallocAsync(reinterpret_cast<void**>(&mean_),
                  channels * sizeof(float),
                  static_cast<cudaStream_t>(stream));
  cudaMemcpyAsync(mean_,
                  mean,
                  channels * sizeof(float),
                  cudaMemcpyHostToDevice,
                  static_cast<cudaStream_t>(stream));
  // std
  cudaMallocAsync(reinterpret_cast<void**>(&std_),
                  channels * sizeof(float),
                  static_cast<cudaStream_t>(stream));
  cudaMemcpyAsync(std_,
                  std,
                  channels * sizeof(float),
                  cudaMemcpyHostToDevice,
                  static_cast<cudaStream_t>(stream));
}

VisionUtils::VisionUtils(const float* mean,
                         const float* std,
                         const size_t channels,
                         void* const stream) {
  // mean
  cudaMallocAsync(reinterpret_cast<void**>(&mean_),
                  channels * sizeof(float),
                  static_cast<cudaStream_t>(stream));
  cudaMemcpyAsync(mean_,
                  mean,
                  channels * sizeof(float),
                  cudaMemcpyHostToDevice,
                  static_cast<cudaStream_t>(stream));
  // std
  cudaMallocAsync(reinterpret_cast<void**>(&std_),
                  channels * sizeof(float),
                  static_cast<cudaStream_t>(stream));
  cudaMemcpyAsync(std_,
                  std,
                  channels * sizeof(float),
                  cudaMemcpyHostToDevice,
                  static_cast<cudaStream_t>(stream));
}

bool VisionUtils::TensorFormat(float* const input,
                               const size_t batch_size,
                               const size_t input_size,
                               const size_t input_channels,
                               const bool convert_color,
                               float* const output,
                               void* const stream) {
  if (input == nullptr || output == nullptr || stream == nullptr) {
    printf("[ERROR] [VisionUtils] invalid params:  input, output, stream.");
    return false;
  }
  cudaMemcpyAsync(input_buffer_,
                  input,
                  batch_size * input_size * input_channels * sizeof(float),
                  cudaMemcpyHostToDevice,
                  static_cast<cudaStream_t>(stream));
  size_t block = (batch_size * input_size + kTHREADS_PER_BLOCK - 1) / kTHREADS_PER_BLOCK;
  FormatKernel<<<block, kTHREADS_PER_BLOCK, 0, static_cast<cudaStream_t>(stream)>>>(input_buffer_,
                                                                                    batch_size,
                                                                                    input_size,
                                                                                    input_channels,
                                                                                    convert_color,
                                                                                    output);
  return true;
}

bool VisionUtils::TensorFormatAndNormalize(float* const input,
                                           const size_t batch_size,
                                           const size_t input_size,
                                           const size_t input_channels,
                                           const bool convert_color,
                                           float* const output,
                                           void* const stream) {
  if (input == nullptr || output == nullptr || stream == nullptr) {
    printf("[ERROR] [VisionUtils] invalid params:  input, output, stream.\n");
    return false;
  }
  if (mean_ == nullptr || std_ == nullptr) {
    printf("[ERROR] [VisionUtils] Construction error. \n");
    return false;
  }
  cudaMemcpyAsync(input_buffer_,
                  input,
                  batch_size * input_size * input_channels * sizeof(float),
                  cudaMemcpyHostToDevice,
                  static_cast<cudaStream_t>(stream));
  size_t block = (batch_size * input_size + kTHREADS_PER_BLOCK - 1) / kTHREADS_PER_BLOCK;
  FormatAndNormalize<<<block, kTHREADS_PER_BLOCK, 0, static_cast<cudaStream_t>(stream)>>>(
      input_buffer_,
      batch_size,
      input_size,
      input_channels,
      mean_,
      std_,
      convert_color,
      output);
  return true;
}

bool VisionUtils::DeviceImageFormatAndNormalize(uint8_t* const input,
                                                const size_t batch_size,
                                                const size_t input_size,
                                                const size_t input_channels,
                                                const bool convert_color,
                                                float* const output,
                                                void* const stream) {
  if (input == nullptr || output == nullptr || stream == nullptr) {
    printf("[ERROR] [VisionUtils] invalid params:  input, output, stream.\n");
    return false;
  }
  if (mean_ == nullptr || std_ == nullptr) {
    printf("[ERROR] [VisionUtils] Construction error. \n");
    return false;
  }
  size_t block = (batch_size * input_size + kTHREADS_PER_BLOCK - 1) / kTHREADS_PER_BLOCK;
  SimpleFormatAndNormalize<<<block, kTHREADS_PER_BLOCK, 0, static_cast<cudaStream_t>(stream)>>>(
      input,
      batch_size,
      input_size,
      input_channels,
      mean_,
      std_,
      convert_color,
      output);
  return true;
}

}  // namespace cuda
}  // namespace ops
}  // namespace linfer
