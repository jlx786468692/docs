import os
import sys


current_path = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(current_path, "lib")

sys.path.insert(0, lib_path)
sys.path.insert(0, current_path)
