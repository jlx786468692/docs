# flake8: noqa
import os
import math
import operator
import warnings
from typing import cast, Dict, Optional, Sequence, Tuple, Union

import numpy as np

# @manual=//deeplearning/trt/python:py_tensorrt
import tensorrt as trt
import torch

from ..converter_registry import tensorrt_converter

from ..tracer.acc_tracer import acc_ops
from ..types import *  # noqa: F403
from torch.fx.immutable_collections import immutable_list
from torch.fx.node import Argument, Target

from ..utils import get_dynamic_dims, torch_dtype_from_trt, torch_dtype_to_trt
from .converter_utils import *  # noqa: F403
from lutility import logger as _LOGGER


@tensorrt_converter(acc_ops.conv1d)
def acc_ops_conv1d(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Conv received input {input_val} that is not part " "of the TensorRT region!"
        )

    # Process 1d input with unsqueeze -> conv2d -> squeeze to calculated conv1d
    unsqueeze_layer = network.add_shuffle(input=input_val)
    unsqueeze_layer.reshape_dims = tuple([*input_val.shape, 1])
    set_layer_name(unsqueeze_layer, target, name + "_unsqueeze")
    input_val = unsqueeze_layer.get_output(0)

    if has_dynamic_shape(input_val.shape):
        assert input_val.shape[1] != -1, "Channel dim can't be dynamic for convolution."

    # for now we'll assume bias is constant Tensor or None,
    # and bias being ITensor is not supported in TensorRT api
    # right now
    if kwargs["bias"] is not None and not isinstance(kwargs["bias"], torch.Tensor):
        raise RuntimeError(
            f"linear {name} has bias of type {type(kwargs['bias'])}, Expect Optional[Tenosr]"
        )
    bias = to_numpy(kwargs["bias"])  # type: ignore[arg-type]
    if bias is not None:
        bias = bias[None]
    weight = kwargs["weight"]

    if network.has_explicit_precision or isinstance(weight, TRTTensor):
        weight = get_trt_tensor(network, weight, f"{name}_weight")
        # Expand 1d weight with unsqueeze for calculation
        unsqueeze_weight_layer = network.add_shuffle(input=weight)
        unsqueeze_weight_layer.reshape_dims = tuple([*weight.shape, 1])
        set_layer_name(unsqueeze_layer, target, name + "_unsqueeze_weight")
        weight = unsqueeze_weight_layer.get_output(0)
        weight_shape = tuple(kwargs["weight"].shape)  # type: ignore[union-attr]
        # will need to use uninitialized weight and set it later to support
        # ITensor weights
        dummy_weight = trt.Weights()
        layer = network.add_convolution_nd(
            input=input_val,
            num_output_maps=weight.shape[0],
            kernel_shape=weight.shape[2:],
            kernel=dummy_weight,
            bias=bias,
        )

        layer.set_input(1, weight)
    else:
        if not isinstance(kwargs["weight"], torch.Tensor):
            raise RuntimeError(
                f"linear {name} has weight of type {type(kwargs['weight'])}, Expect Optional[Tenosr]"
            )
        weight = to_numpy(weight)
        weight = np.expand_dims(weight, -1)
        layer = network.add_convolution_nd(
            input=input_val,
            num_output_maps=weight.shape[0],
            kernel_shape=weight.shape[2:],
            kernel=weight,
            bias=bias,
        )
    # expand params to 2d for computation
    padding = list(kwargs["padding"])
    padding.append(0)
    stride = extend_attr_to_tuple(kwargs["stride"], 2)
    dilation = extend_attr_to_tuple(kwargs["dilation"], 2)

    set_layer_name(layer, target, name)
    layer.stride_nd = stride
    layer.padding_nd = padding
    layer.dilation_nd = dilation
    if kwargs["groups"] is not None:
        layer.num_groups = kwargs["groups"]

    result = layer.get_output(0)
    squeeze_layer = network.add_shuffle(input=result)
    squeeze_layer.reshape_dims = tuple(result.shape[:-1])
    set_layer_name(squeeze_layer, target, name + "_squeeze")
    return squeeze_layer.get_output(0)


@tensorrt_converter(acc_ops.conv3d)
@tensorrt_converter(acc_ops.conv2d)
def acc_ops_convnd(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Conv received input {input_val} that is not part " "of the TensorRT region!"
        )

    if has_dynamic_shape(input_val.shape):
        assert input_val.shape[1] != -1, "Channel dim can't be dynamic for convolution."

    # for now we'll assume bias is constant Tensor or None,
    # and bias being ITensor is not supported in TensorRT api
    # right now
    if kwargs["bias"] is not None and not isinstance(kwargs["bias"], torch.Tensor):
        raise RuntimeError(
            f"linear {name} has bias of type {type(kwargs['bias'])}, Expect Optional[Tenosr]"
        )
    bias = to_numpy(kwargs["bias"])  # type: ignore[arg-type]

    if network.has_explicit_precision:
        weight = kwargs["weight"]
        if isinstance(weight, TRTTensor):
            weight = get_trt_tensor(network, kwargs["weight"], f"{name}_weight")
            weight_shape = tuple(kwargs["weight"].shape)  # type: ignore[union-attr]
            # will need to use uninitialized weight and set it later to support
            # ITensor weights
            dummy_weight = trt.Weights()
            layer = network.add_convolution_nd(
                input=input_val,
                num_output_maps=weight.shape[0],
                kernel_shape=weight.shape[2:],
                kernel=dummy_weight,
                bias=bias,
            )

            layer.set_input(1, weight)
        else:
            trt_conv_weight = trt.Weights(np.ascontiguousarray(weight.cpu(), dtype=np.float32))
            layer = network.add_convolution_nd(
                input=input_val,
                num_output_maps=weight.shape[0],
                kernel_shape=weight.shape[2:],
                kernel=trt_conv_weight,
                bias=bias,
            )

    else:
        if not isinstance(kwargs["weight"], torch.Tensor):
            raise RuntimeError(
                f"linear {name} has weight of type {type(kwargs['weight'])}, Expect Optional[Tenosr]"
            )
        weight = to_numpy(kwargs["weight"])
        layer = network.add_convolution_nd(
            input=input_val,
            num_output_maps=weight.shape[0],
            kernel_shape=weight.shape[2:],
            kernel=weight,
            bias=bias,
        )

    set_layer_name(layer, target, name)
    layer.stride_nd = kwargs["stride"]
    layer.padding_nd = kwargs["padding"]
    layer.dilation_nd = kwargs["dilation"]
    if kwargs["groups"] is not None:
        layer.num_groups = kwargs["groups"]

    return layer.get_output(0)


@tensorrt_converter(acc_ops.conv_transpose2d)
@tensorrt_converter(acc_ops.conv_transpose3d)
def acc_ops_conv_transposend(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Transpose conv received input {input_val} that is not part " "of the TensorRT region!"
        )

    if has_dynamic_shape(input_val.shape):
        assert input_val.shape[1] != -1, "Channel dim can't be dynamic for transpose convolution."

    # for now we'll assume bias is constant Tensor or None,
    # and bias being ITensor is not supported in TensorRT api
    # right now
    if kwargs["bias"] is not None and not isinstance(kwargs["bias"], torch.Tensor):
        raise RuntimeError(
            f"ConvTranspose {name} has bias of type {type(kwargs['bias'])}, Expect Optional[Tensor]"
        )
    bias = to_numpy(kwargs["bias"])  # type: ignore[arg-type]

    if network.has_explicit_precision:
        weight = kwargs["weight"]
        if isinstance(weight, TRTTensor):  # e.g. deconv be quant
            dummy_weight = trt.Weights()
            layer = network.add_deconvolution_nd(
                input=input_val,
                num_output_maps=weight.shape[1] * kwargs["groups"],
                kernel_shape=weight.shape[2:],
                kernel=dummy_weight,
                bias=bias,
            )
            layer.set_input(1, weight)
        else:  # e.g. deconv not be quant
            trt_conv_weight = trt.Weights(np.ascontiguousarray(weight.cpu(), dtype=np.float32))
            layer = network.add_deconvolution_nd(
                input=input_val,
                num_output_maps=weight.shape[1] * kwargs["groups"],
                kernel_shape=weight.shape[2:],
                kernel=trt_conv_weight,
                bias=bias,
            )
    else:
        if not isinstance(kwargs["weight"], torch.Tensor):
            raise RuntimeError(
                f"conv {name} has weight of type {type(kwargs['weight'])}, Expect Optional[Tensor]"
            )
        weight = to_numpy(kwargs["weight"])
        # nn.ConvTranspose2d/3d weight size is (in_channels, out_channels/groups, kernel_0, kernel_1, [kernel_2])
        layer = network.add_deconvolution_nd(
            input=input_val,
            num_output_maps=weight.shape[1] * kwargs["groups"],
            kernel_shape=weight.shape[2:],
            kernel=weight,
            bias=bias,
        )

    set_layer_name(layer, target, name)
    layer.stride_nd = kwargs["stride"]
    layer.padding_nd = kwargs["padding"]
    layer.dilation_nd = kwargs["dilation"]
    if kwargs["groups"] is not None:
        layer.num_groups = kwargs["groups"]

    return layer.get_output(0)


@tensorrt_converter(acc_ops.pad, enabled=trt.__version__ < "8.2")
def acc_ops_pad_with_padding_layer(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    pad = cast(Sequence[int], kwargs["pad"])
    mode = kwargs["mode"]
    value = kwargs["value"] if kwargs["value"] is not None else 0
    rank = len(input_val.shape)  # type: ignore[union-attr]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"pad received input {input_val} that is not part " "of the TensorRT region!"
        )

    if mode != "constant":
        raise RuntimeError(f"Currently we only support constant mode for pad, got {mode}.")

    if len(pad) / 2 > rank:
        raise RuntimeError(
            f"Trying to pad last {len(pad) / 2} dimension but the input only has {rank} dimension."
        )

    if value != 0:
        raise RuntimeError(f"Currently we only support padding value of 0, got {value}.")

    if len(pad) > 4:
        raise RuntimeError("Currently we only support padding last two dimensions.")

    pre_padding = tuple(pad[len(pad) - i - 2] for i in range(0, len(pad), 2))
    post_padding = tuple(pad[len(pad) - i - 1] for i in range(0, len(pad), 2))

    layer = network.add_padding(
        input_val,
        pre_padding if len(pre_padding) == 2 else (0,) + pre_padding,
        post_padding if len(post_padding) == 2 else (0,) + post_padding,
    )
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.pad, enabled=trt.__version__ >= "8.2")
def acc_ops_pad_with_slice_layer(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    pad = cast(Sequence[int], kwargs["pad"])
    mode = kwargs["mode"]
    value = kwargs["value"] if kwargs["value"] is not None else 0
    rank = len(input_val.shape)  # type: ignore[union-attr]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"pad received input {input_val} that is not part " "of the TensorRT region!"
        )

    if mode != "constant":
        raise RuntimeError(f"Currently we only support constant mode for pad, got {mode}.")

    if len(pad) / 2 > rank:
        raise RuntimeError(
            f"Trying to pad last {len(pad) / 2} dimension but the input only has {rank} dimension."
        )

    # cast value to TRTensor
    dt = torch_dtype_from_trt(input_val.dtype)
    value = 0 if value == None else value
    value_const = get_trt_tensor(network, torch.tensor([value], dtype=dt), f"{name}_value")

    input_shape = input_val.shape
    pre_start = tuple(i - 1 for i in input_shape)
    prefix_len = len(input_shape) - len(pad) // 2
    pre_shape = tuple(
        input_shape[i] + (pad[-(i - prefix_len) * 2 - 2] if i >= prefix_len else 0)
        for i in range(0, len(input_shape))
    )
    pre_stride = [-1] * len(input_shape)

    layer = network.add_slice(
        input_val,
        pre_start,
        pre_shape,
        pre_stride,
    )
    layer.set_input(4, value_const)
    layer.mode = trt.SliceMode.FILL
    set_layer_name(layer, target, f"pre_{name}")
    half_pad_output = layer.get_output(0)

    shape = half_pad_output.shape
    mid_start = tuple(i - 1 for i in shape)
    mid_stride = [-1] * len(shape)
    layer = network.add_slice(half_pad_output, mid_start, shape, mid_stride)
    layer.set_input(4, value_const)
    layer.mode = trt.SliceMode.FILL
    set_layer_name(layer, target, f"transpose_{name}")
    transpose_output = layer.get_output(0)

    shape = transpose_output.shape
    post_start = tuple([0] * len(shape))
    post_shape = tuple(
        shape[i] + (pad[-(i - prefix_len) * 2 - 1] if i >= prefix_len else 0)
        for i in range(0, len(shape))
    )
    post_stride = tuple([1] * len(shape))

    layer = network.add_slice(transpose_output, post_start, post_shape, post_stride)
    layer.set_input(4, value_const)
    layer.mode = trt.SliceMode.FILL
    set_layer_name(layer, target, f"post_{name}")
    return layer.get_output(0)


@tensorrt_converter(acc_ops.flatten)
def acc_ops_flatten(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"flatten received input {input_val} that is not part " "of the TensorRT region!"
        )

    num_dims = len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)
    start_dim = get_positive_dim(
        cast(int, kwargs["start_dim"] if "start_dim" in kwargs else 0), num_dims
    )
    end_dim = get_positive_dim(
        cast(int, kwargs["end_dim"] if "end_dim" in kwargs else -1), num_dims
    )

    if network.has_implicit_batch_dimension:
        assert start_dim != 0, "Can't flatten batch dimension when it's implicit."
        start_dim -= 1
        end_dim -= 1

    layer = network.add_shuffle(input_val)
    set_layer_name(layer, target, name)

    # If there're dynamic shapes then we need to use shape layers
    # to figure out the final shape after flatten. We first slice
    # the input shape to three parts:
    #   1. dimensions before start_dim
    #   2. dimensions between start_dim and end_dim
    #   3. dimensions after end_dim
    # Part 1 and 3 might not exist if start_dim is 0 or end_dim is
    # last dim. Then we do a reduced multiplication over part 2 to
    # get flattened dim. Finally, we concatenate the three parts to
    # get the final shape.
    if has_dynamic_shape(input_val.shape):
        input_shape_layer = network.add_shape(input_val)
        input_shape_layer.name = f"{name}_orig_shape"

        final_shapes = []

        # Shapes before start_dim
        if start_dim > 0:
            prefix_shape_layer = network.add_slice(
                input_shape_layer.get_output(0),
                start=(0,),
                shape=(start_dim,),
                stride=(1,),
            )
            prefix_shape_layer.name = f"{name}_pre_shape"
            final_shapes.append(prefix_shape_layer.get_output(0))

        flatten_shape_layer = network.add_slice(
            input_shape_layer.get_output(0),
            start=(start_dim,),
            shape=(end_dim - start_dim + 1,),
            stride=(1,),
        )
        flatten_shape_layer.name = f"{name}_need_flatten"
        flatten_shape_layer = network.add_reduce(
            flatten_shape_layer.get_output(0),
            trt.ReduceOperation.PROD,
            axes=get_axes_for_reduce_op(0, False),
            keep_dims=True,
        )
        flatten_shape_layer.name = f"{name}_flatten_dim"
        final_shapes.append(flatten_shape_layer.get_output(0))

        # Shapes after start_dim
        if end_dim < len(input_val.shape) - 1:
            suffix_shape_layer = network.add_slice(
                input_shape_layer.get_output(0),
                start=(end_dim + 1,),
                shape=(len(input_val.shape) - end_dim - 1,),
                stride=(1,),
            )
            suffix_shape_layer.name = f"{name}_suffix_shape"
            final_shapes.append(suffix_shape_layer.get_output(0))

        final_shape_layer = network.add_concatenation(final_shapes)
        final_shape_layer.axis = 0
        final_shape_layer.name = f"{name}_final_shape"
        layer.set_input(1, final_shape_layer.get_output(0))
    else:
        final_shape = []
        flatten_dim = 1
        for i, s in enumerate(input_val.shape):
            if i >= start_dim and i <= end_dim:
                flatten_dim *= s
            elif i == end_dim + 1:
                final_shape.append(flatten_dim)
                final_shape.append(s)
            else:
                final_shape.append(s)
        if end_dim == len(input_val.shape) - 1:
            final_shape.append(flatten_dim)

        layer.reshape_dims = tuple(final_shape)

    return layer.get_output(0)


# For implicit batch dim mode, we use this to represent batch dim if we
# ever trying to retrieve it via size() and we hope it will fail hard if
# it's used somewhere else.
IMPLICIT_BATCH_DIM = -999


@tensorrt_converter(acc_ops.size)
def acc_ops_size(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_t = kwargs["input"]
    if type(input_t) == torch.nn.Parameter or type(input_t) == torch.Tensor:
        if not has_dynamic_shape(input_t.shape) and network.has_implicit_batch_dimension:
            return torch.Size((IMPLICIT_BATCH_DIM,) + tuple(input_t.shape))
        return input_t.shape

    # input_val = get_trt_tensor(network, input_t, f"{name}_input_t")
    input_val = input_t
    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"size received input {input_val} that is not part " "of the TensorRT region!"
        )

    # FIXME
    # if not has_dynamic_shape(input_val.shape):
    if True:
        if network.has_implicit_batch_dimension:
            return torch.Size((IMPLICIT_BATCH_DIM,) + tuple(input_val.shape))
        return torch.Size(input_val.shape)

    layer = network.add_shape(input_val)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.numel)
def acc_ops_numel(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"size received input {input_val} that is not part " "of the TensorRT region!"
        )

    if has_dynamic_shape(input_val.shape):
        raise RuntimeError(f"numel does not support dynamic shapes.")

    numel = np.prod(input_val.shape)
    layer = network.add_constant((1,), trt.Weights(np.array(numel, dtype=np.float32)))
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.batch_norm)
def acc_ops_batch_norm(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"BatchNorm2d received input {input_val} that is not part " "of the TensorRT region!"
        )

    if has_dynamic_shape(input_val.shape):
        assert input_val.shape[1] != -1, "Channel dim can't be dynamic for batch norm."

    scale = cast(torch.Tensor, to_numpy(cast(torch.Tensor, kwargs["weight"]))) / np.sqrt(
        cast(torch.Tensor, to_numpy(cast(torch.Tensor, kwargs["running_var"])))
        + cast(float, kwargs["eps"])
    )

    bias = (
        to_numpy(cast(torch.Tensor, kwargs["bias"]))
        - to_numpy(cast(torch.Tensor, kwargs["running_mean"])) * scale
    )
    power = np.ones_like(scale)

    # For BatchNorm1d, reshape 1d to 2d
    output_shape = input_val.shape
    if not network.has_implicit_batch_dimension and len(input_val.shape) < 4:
        assert (
            len(get_dynamic_dims(input_val.shape)) <= 1
        ), "BatchNorm1D with more than one dynamic dims is not currently supported."
        reshape_layer = network.add_shuffle(input_val)
        if len(input_val.shape) == 2:
            reshape_layer.reshape_dims = (input_val.shape[0], input_val.shape[1], 1, 1)
        else:  # len(input_val.shape) == 3
            reshape_layer.reshape_dims = (
                input_val.shape[0],
                input_val.shape[1],
                input_val.shape[2],
                1,
            )
        set_layer_name(reshape_layer, target, f"{name}_reshape_2d")
        input_val = reshape_layer.get_output(0)
    layer = network.add_scale(input_val, trt.ScaleMode.CHANNEL, bias, scale, power)
    set_layer_name(layer, target, name)

    # For BatchNorm1d, reshape output back to 1d
    if not network.has_implicit_batch_dimension and len(output_shape) < 4:
        reshape_output_layer = network.add_shuffle(layer.get_output(0))
        reshape_output_layer.reshape_dims = tuple(output_shape)
        set_layer_name(reshape_output_layer, target, f"{name}_reshape_1d")
        layer = reshape_output_layer
    return layer.get_output(0)


@tensorrt_converter(acc_ops.group_norm)
def acc_ops_group_norm(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"GroupNorm received input {input_val} that is not part " "of the TensorRT region!"
        )

    if has_dynamic_shape(input_val.shape):
        assert input_val.shape[1] != -1, "Channel dim can't be dynamic for group norm."

    if isinstance(kwargs["weight"], torch.Tensor):
        weight = get_trt_tensor(network, kwargs["weight"], f"{name}weight")
    else:
        weight = None
    if isinstance(kwargs["bias"], torch.Tensor):
        bias = get_trt_tensor(network, kwargs["bias"], f"{name}bias")
    else:
        bias = None
    inputs = [kwargs["input"], weight, bias]

    mPluginAttributes = list()
    mPluginAttributes.append(
        trt.PluginField(
            "num_groups", np.array(kwargs["num_groups"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "eps", np.array(kwargs["eps"], dtype=np.float32), trt.PluginFieldType.FLOAT32
        )
    )
    field_collection = trt.PluginFieldCollection(mPluginAttributes)
    plugin = get_trt_plugin("GroupNorm", field_collection, "1", "")
    layer = network.add_plugin_v2(inputs, plugin)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.layer_norm)
def acc_ops_layer_norm(network, target, args, kwargs, name):
    input_val = kwargs["input"]

    if not isinstance(input_val, trt.tensorrt.ITensor):
        raise RuntimeError(
            f"LayerNorm received input {input_val} that is not part " "of the TensorRT region!"
        )

    gamma = kwargs["weight"].detach().cpu().float().numpy()
    gamma_field = trt.PluginField("gamma", gamma, trt.PluginFieldType.FLOAT32)
    beta = kwargs["bias"].detach().cpu().float().numpy()
    beta_field = trt.PluginField("beta", beta, trt.PluginFieldType.FLOAT32)
    eps_field = trt.PluginField(
        "eps", np.array([kwargs["eps"]], dtype=np.float32), trt.PluginFieldType.FLOAT32
    )
    try:
        normalized_shape = np.array(kwargs["normalized_shape"], dtype=np.int32)
    except TypeError:
        _LOGGER.error("Unable to convert normalized_shape to a field, fall back to []")
        normalized_shape = np.array([], dtype=np.int32)

    normalized_shape_filed = trt.PluginField(
        "normalized_shape", normalized_shape, trt.PluginFieldType.INT32
    )
    field_collection = trt.PluginFieldCollection(
        [gamma_field, beta_field, eps_field, normalized_shape_filed]
    )

    try:
        if network.has_implicit_batch_dimension:
            plugin = get_trt_plugin("layer_norm", field_collection, "1", "fx2trt")
        else:
            plugin = get_trt_plugin("LayerNormDynamic", field_collection, "1", "fx2trt")
    except AssertionError:
        _LOGGER.error("Unable to find layer norm plugin, fall back to TensorRT implementation.")
        return layer_norm(network, target, args, kwargs, name)
    layer = network.add_plugin_v2([input_val], plugin)
    layer.name = name
    return layer.get_output(0)


def layer_norm(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"LayerNorm received input {input_val} that is not part " "of the TensorRT region!"
        )

    shape = kwargs["weight"].shape  # type: ignore[union-attr]
    broadcasted_shape = (1,) * (len(input_val.shape) - len(shape)) + shape
    gamma = to_numpy(kwargs["weight"].reshape(*shape))  # type: ignore[union-attr]
    beta = to_numpy(kwargs["bias"].reshape(*shape))  # type: ignore[union-attr]
    eps = kwargs["eps"]

    axes = 0
    for d in range(len(shape)):
        axes |= 1 << (len(input_val.shape) - d - 1)

    # E[x]
    mean_expected_layer = network.add_reduce(
        input_val, trt.ReduceOperation.AVG, axes, keep_dims=True
    )
    set_layer_name(mean_expected_layer, target, f"{name}_mean_expected")

    # X-E[x]
    sub_trt = add_binary_elementwise_layer(
        network,
        input_val,
        mean_expected_layer.get_output(0),
        trt.ElementWiseOperation.SUB,
        target,
        f"{name}_sub",
    )
    # Variance = mean(pow(x_sub_mean,2))
    pow_tensor = network.add_constant(
        (1,) * len(input_val.shape),
        trt.Weights(np.ascontiguousarray([2.0], dtype=np.float32)),
    )
    pow_tensor.name = f"{name}_power"
    pow_var = add_binary_elementwise_layer(
        network,
        sub_trt,
        pow_tensor.get_output(0),
        trt.ElementWiseOperation.POW,
        target,
        f"{name}_pow_var",
    )
    mean_trt_layer = network.add_reduce(pow_var, trt.ReduceOperation.AVG, axes, keep_dims=True)
    set_layer_name(mean_trt_layer, target, f"{name}_mean")
    # Variance + eps
    eps_tensor = network.add_constant(
        (1,) * len(input_val.shape),
        trt.Weights(np.ascontiguousarray([eps], dtype=np.float32)),
    )
    eps_tensor.name = f"{name}_eps"
    add_trt = add_binary_elementwise_layer(
        network,
        mean_trt_layer.get_output(0),
        eps_tensor.get_output(0),
        trt.ElementWiseOperation.SUM,
        target,
        f"{name}_add",
    )
    # SQRT((Var + eps))
    sqrt_trt = add_unary_layer(network, add_trt, trt.UnaryOperation.SQRT, target, f"{name}_sqrt")
    # (x - E[x]) / sqrt((var + eps))
    div_trt = add_binary_elementwise_layer(
        network,
        sub_trt,
        sqrt_trt,
        trt.ElementWiseOperation.DIV,
        target,
        f"{name}_div_trt",
    )

    assert gamma is not None
    gamma_tensor = network.add_constant(gamma.shape, trt.Weights(np.ascontiguousarray(gamma)))  # type: ignore[attr-defined]
    gamma_tensor.name = f"{name}_gamma"
    assert beta is not None
    beta_tensor = network.add_constant(gamma.shape, trt.Weights(np.ascontiguousarray(beta)))  # type: ignore[attr-defined]
    beta_tensor.name = f"{name}_beta"
    # y * gamma + beta
    scale_layer = add_binary_elementwise_layer(
        network,
        div_trt,
        gamma_tensor.get_output(0),
        trt.ElementWiseOperation.PROD,
        target,
        f"{name}_scale",
    )
    return add_binary_elementwise_layer(
        network,
        scale_layer,
        beta_tensor.get_output(0),
        trt.ElementWiseOperation.SUM,
        target,
        name,
    )


@tensorrt_converter(acc_ops.softmax)
def acc_ops_softmax(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    input_ranks = len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)  # type: ignore[union-attr]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"softmax received input {input_val} that is not part " "of the TensorRT region!"
        )

    # Used to get dim when dim is None. Copied from PyTorch softmax implementation.
    def get_softmax_dim(ndim: int) -> int:
        if ndim == 0 or ndim == 1 or ndim == 3:
            ret = 0
        else:
            ret = 1
        return ret

    if kwargs["dim"] is None:
        dim = get_softmax_dim(input_ranks)
    else:
        dim = cast(int, kwargs["dim"])

    dim = get_positive_dim(dim, input_ranks)
    if network.has_implicit_batch_dimension:
        assert dim != 0, "Can't apply softmax on batch dimension when it's implicit."
        dim -= 1

    layer = network.add_softmax(input_val)
    layer.axes = 1 << dim
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.tile)
def acc_ops_tile(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_t = kwargs["input"]
    input_val = get_trt_tensor(network, input_t, f"{name}_input")

    dims = tuple(cast(Sequence[int], kwargs["dims"]))
    n_input_dims = len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)

    if len(dims) > n_input_dims:
        assert not network.has_implicit_batch_dimension
        layer = network.add_shuffle(input_val)
        layer.name = f"{name}_reshape"
        num_preceding_ones = len(dims) - n_input_dims

        if len(get_dynamic_dims(input_val.shape)) > 1:
            input_shape_layer = network.add_shape(input_val)
            input_shape_layer.name = f"{name}_input_shape"
            preceding_ones = network.add_constant(
                (num_preceding_ones,),
                np.ascontiguousarray([1] * num_preceding_ones, np.int32),
            ).get_output(0)
            reshape_layer = network.add_concatenation(
                [preceding_ones, input_shape_layer.get_output(0)]
            )
            reshape_layer.axis = 0
            reshape_layer.name = f"{name}_reshape_dims"
            layer.set_input(1, reshape_layer.get_output(0))
        else:
            layer.reshape_dims = (1,) * (len(dims) - n_input_dims) + tuple(input_val.shape)
        input_val = layer.get_output(0)
    else:
        dims = (1,) * (n_input_dims - len(dims)) + dims

    if network.has_implicit_batch_dimension:
        assert dims[0] == 1, "Can't tile the batch dim when it's implicit."
        dims = dims[1:]
    starts = [0] * len(dims)
    shapes = []
    if all(isinstance(d, int) for d in dims):
        shapes = [i * j for i, j in zip(input_val.shape, dims)]  # type: ignore[union-attr]
    else:
        shape = []
        for i, (s, d) in enumerate(zip(input_val.shape, dims)):
            if isinstance(d, TRTTensor) and len(d.shape) == 0:
                d = prepend_ones(network, d, f"{name}_{i}", 1)
            else:
                d = get_trt_tensor(network, d, f"{name}_{i}")
            shape.append(d)
            mul = add_binary_elementwise_layer(
                network,
                s,
                d,
                trt.ElementWiseOperation.PROD,
                target,
                f"{name}_mul_{i}",
            )
            shapes.append(mul)
        dims = shape
    # If there's dynmaic dim then there would be negative dims in shapes which is not allowed.
    # Here we build a dummy shapes array.
    if has_dynamic_shape(input_val.shape):  # type: ignore[union-attr]
        shapes = [1] * len(dims)
    strides = [1] * len(dims)
    layer = network.add_slice(input_val, starts, shapes, strides)
    layer.mode = trt.SliceMode.WRAP
    set_layer_name(layer, target, name)

    if has_dynamic_shape(input_val.shape):  # type: ignore[union-attr]
        starts_tensor = network.add_constant(
            (len(dims),), np.ascontiguousarray([0] * len(dims), np.int32)
        ).get_output(0)
        if all(isinstance(d, int) for d in dims):
            dims_tensor = network.add_constant(
                (len(dims),), np.ascontiguousarray(dims, np.int32)
            ).get_output(0)
        else:
            assert all(isinstance(d, TRTTensor) for d in dims)
            concat_dims_layer = network.add_concatenation(inputs=dims)
            concat_dims_layer.axis = 0
            concat_dims_layer.name = f"{name}_tile_dim"
            dims_tensor = concat_dims_layer.get_output(0)
        input_shape_layer = network.add_shape(input_val)
        input_shape_layer.name = f"{name}_slice_input_shape"
        slice_shapes_tensor = add_binary_elementwise_layer(
            network,
            input_shape_layer.get_output(0),
            dims_tensor,
            trt.ElementWiseOperation.PROD,
            target,
            f"{name}_slice_shapes",
        )
        layer.set_input(1, starts_tensor)
        layer.set_input(2, slice_shapes_tensor)

    return layer.get_output(0)


@tensorrt_converter(acc_ops.sign)
def acc_ops_sign(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if trt.__version__ >= "8.2" and not network.has_implicit_batch_dimension:
        input_val = kwargs["input"]
        operation_type = trt.UnaryOperation.SIGN
        return add_unary_layer(network, input_val, operation_type, target, name)

    return sign(network, input_val, target, name)


@tensorrt_converter(acc_ops.relu)
def acc_ops_relu(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.ActivationType.RELU
    return add_activation_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.leaky_relu)
def acc_ops_leaky_relu(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    negative_slope = kwargs["negative_slope"]
    operation_type = trt.ActivationType.LEAKY_RELU
    return add_activation_layer(network, input_val, operation_type, target, name, negative_slope)


@tensorrt_converter(acc_ops.elu)
def acc_ops_elu(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    alpha = kwargs["alpha"]
    operation_type = trt.ActivationType.ELU
    return add_activation_layer(network, input_val, operation_type, target, name, alpha)


@tensorrt_converter(acc_ops.selu)
def acc_ops_selu(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.ActivationType.SELU
    return add_activation_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.softsign)
def acc_ops_softsign(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.ActivationType.SOFTSIGN
    return add_activation_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.sin)
def acc_ops_sin(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.SIN
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.cos)
def acc_ops_cos(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.COS
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.tan)
def acc_ops_tan(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.TAN
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.sinh)
def acc_ops_sinh(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.SINH
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.cosh)
def acc_ops_cosh(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.COSH
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.tanh)
def acc_ops_tanh(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.ActivationType.TANH
    return add_activation_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.asin)
def acc_ops_asin(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.ASIN
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.acos)
def acc_ops_acos(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.ACOS
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.atan)
def acc_ops_atan(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.ATAN
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.exp)
def acc_ops_exp(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.EXP
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.log)
def acc_ops_log(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.LOG
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.sqrt)
def acc_ops_sqrt(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.SQRT
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.reciprocal)
def acc_ops_reciprocal(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.RECIP
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.abs)
def acc_ops_abs(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.ABS
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.neg)
def acc_ops_neg(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.NEG
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.floor)
def acc_ops_floor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.FLOOR
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.ceil)
def acc_ops_ceil(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.CEIL
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.sum)
def acc_ops_sum(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> TRTTensor:
    return add_reduce_layer(network, target, args, kwargs, trt.ReduceOperation.SUM, name)


@tensorrt_converter(acc_ops.prod)
def acc_ops_prod(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> TRTTensor:
    return add_reduce_layer(network, target, args, kwargs, trt.ReduceOperation.PROD, name)


@tensorrt_converter(acc_ops.mean)
def acc_ops_mean(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> TRTTensor:
    return add_reduce_layer(network, target, args, kwargs, trt.ReduceOperation.AVG, name)


def add_acc_ops_full_reduce(network, target, args, kwargs, name, reduce_op):
    input_val = kwargs["input"]
    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"max received input {input_val} that is not part " "of the TensorRT region!"
        )
    assert (
        not network.has_implicit_batch_dimension
    ), "Do not support max over all the elements for implicit batch."

    dim = range(len(input_val.shape))

    layer = network.add_reduce(
        input_val,
        reduce_op,
        get_axes_for_reduce_op(dim, network.has_implicit_batch_dimension),
        False,
    )
    set_layer_name(layer, target, name)
    return layer.get_output(0)


def add_acc_ops_dim_reduce(network, target, args, kwargs, name, reduce_op):
    new_kwargs = kwargs.copy()
    new_kwargs["k"] = 1

    if reduce_op == trt.ReduceOperation.MAX:
        new_kwargs["largest"] = True
    elif reduce_op == trt.ReduceOperation.MIN:
        new_kwargs["largest"] = False
    new_kwargs["sorted"] = False

    topk_out0, topk_out1 = acc_ops_topk(network, target, args, new_kwargs, name + "_topk")

    topk_out0.name = f"{name}_topk0"
    topk_out1.name = f"{name}_topk1"

    if "keepdim" in new_kwargs and new_kwargs["keepdim"]:
        return topk_out0, topk_out1

    dim = new_kwargs["dim"]
    if network.has_implicit_batch_dimension:
        assert dim != 0, "can't reduce on dim == 0 when network has implicit batch dimension"
        # we remove the first dim in the shape tuple when it is implicit
        dim -= 1
    input_val = topk_out0
    shape = input_val.shape

    output_shape = []
    dest_dim = dim
    if -1 == dim:
        dest_dim = len(shape) - 1
    for i, s in enumerate(shape):
        if i == dest_dim and s == 1:
            continue
        output_shape.append(s)

    shuffle_layer0 = network.add_shuffle(input_val)
    shuffle_layer0.reshape_dims = tuple(output_shape)
    set_layer_name(shuffle_layer0, target, f"{name}_shuffle0")

    input_val = topk_out1
    shape = input_val.shape

    shuffle_layer1 = network.add_shuffle(input_val)
    shuffle_layer1.reshape_dims = tuple(output_shape)
    set_layer_name(shuffle_layer1, target, f"{name}_shuffle1")

    return shuffle_layer0.get_output(0), shuffle_layer1.get_output(0)


@tensorrt_converter(acc_ops.max_full_reduce, no_implicit_batch_dim=True)
def acc_ops_max_full_reduce(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_acc_ops_full_reduce(network, target, args, kwargs, name, trt.ReduceOperation.MAX)


@tensorrt_converter(acc_ops.min_full_reduce, no_implicit_batch_dim=True)
def acc_ops_min_full_reduce(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_acc_ops_full_reduce(network, target, args, kwargs, name, trt.ReduceOperation.MIN)


@tensorrt_converter(acc_ops.max_dim_reduce)
def acc_ops_max_dim_reduce(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_acc_ops_dim_reduce(network, target, args, kwargs, name, trt.ReduceOperation.MAX)


@tensorrt_converter(acc_ops.min_dim_reduce)
def acc_ops_min_dim_reduce(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_acc_ops_dim_reduce(network, target, args, kwargs, name, trt.ReduceOperation.MIN)


@tensorrt_converter(acc_ops.maximum)
def acc_ops_maximum(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.MAX,
        target,
        name,
    )


@tensorrt_converter(acc_ops.minimum)
def acc_ops_minimum(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.MIN,
        target,
        name,
    )


@tensorrt_converter(acc_ops.dtype)
def acc_ops_dtype(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    return input_val.dtype


@tensorrt_converter(acc_ops.device)
def acc_ops_device(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    # TRT always assume the device is cuda not cpu
    return torch.device("cuda")


@tensorrt_converter(acc_ops.to_dtype)
def acc_ops_to_dtype(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    input_dtype = kwargs["acc_out_ty"].dtype
    input_t = get_trt_tensor(network, input_val, f"{name}_input_t")
    if input_dtype:
        if isinstance(input_dtype, torch.dtype):
            input_dtype = torch_dtype_to_trt(input_dtype)
        if input_dtype != input_t.dtype:
            # input tensor type is not same as the expect type, so cast it.
            input_t = type_cast(network, target, f"{name}_input", input_t, input_dtype)
    return input_t


@tensorrt_converter(acc_ops.logical_not)
def acc_ops_logical_not(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    operation_type = trt.UnaryOperation.NOT
    # cast to bool type
    if input_val.dtype in (trt.float32, trt.float16, trt.int32):
        input_val = type_cast(network, target, f"{name}_input", input_val, trt.bool)
    return add_unary_layer(network, input_val, operation_type, target, name)


@tensorrt_converter(acc_ops.logical_and, no_implicit_batch_dim=True)
@tensorrt_converter(acc_ops.bitwise_and, no_implicit_batch_dim=True)
def acc_ops_logical_and(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError(
            "The `logical_and` function should be called with explicit batch dimension."
        )

    input_t = kwargs["input"]
    other_t = kwargs["other"]
    # we only support both inputs are bool type
    if target == acc_ops.bitwise_and:

        def check_is_bool(input_t):
            if isinstance(input_t, TRTTensor):
                assert input_t.dtype == trt.bool, "We currently do not support input is non-bool"
            elif isinstance(input_t, torch.Tensor):
                assert input_t.dtype == torch.bool, "We currently do not support input is non-bool"
            else:
                assert isinstance(input_t.bool), "We currently do not support input is non-bool"

        check_is_bool(input_t)
        check_is_bool(other_t)

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")

    if input_t.dtype != trt.bool:
        input_t = type_cast(network, target, f"{name}_input", input_t, trt.bool)
    if other_t.dtype != trt.bool:
        other_t = type_cast(network, target, f"{name}_other", other_t, trt.bool)
    return add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.AND, target, name
    )


@tensorrt_converter(acc_ops.bool)
def acc_ops_bool(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    input_val = get_trt_tensor(network, input_val, f"{name}_input")
    layer_i = network.add_identity(input_val)
    layer_i.set_output_type(0, trt.bool)
    set_layer_name(layer_i, target, f"{name}_input_dtype_change")
    return layer_i.get_output(0)


@tensorrt_converter(acc_ops.ne, no_implicit_batch_dim=True)
def acc_ops_ne(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `ne` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    other_t = kwargs["other"]

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")

    input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)
    eq_t = add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.EQUAL, target, name
    )

    return add_unary_layer(network, eq_t, trt.UnaryOperation.NOT, target, name)


@tensorrt_converter(acc_ops.clone, no_implicit_batch_dim=True)
def acc_ops_clone(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `clone` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    # other_t = kwargs["other"]

    # input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    # other_t = get_trt_tensor(network, other_t, f"{name}_other_t")

    # input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)
    # eq_t = add_binary_elementwise_layer(network, input_t, other_t, trt.ElementWiseOperation.EQUAL, target, name)

    return input_t


@tensorrt_converter(acc_ops.eq, no_implicit_batch_dim=True)
def acc_ops_eq(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `eq` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    other_t = kwargs["other"]

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")

    input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)
    return add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.EQUAL, target, name
    )


@tensorrt_converter(acc_ops.gt, no_implicit_batch_dim=True)
def acc_ops_gt(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `gt` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    other_t = kwargs["other"]

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")

    input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)
    return add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.GREATER, target, name
    )


@tensorrt_converter(acc_ops.ge, no_implicit_batch_dim=True)
def acc_ops_ge(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `gt` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    other_t = kwargs["other"]

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")
    input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)

    less_result = add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.GREATER, target, name + "_gt"
    )
    equal_result = add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.EQUAL, target, name + "_eq"
    )
    return add_binary_elementwise_layer(
        network, less_result, equal_result, trt.ElementWiseOperation.OR, target, name
    )


@tensorrt_converter(acc_ops.lt, no_implicit_batch_dim=True)
def acc_ops_lt(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `lt` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    other_t = kwargs["other"]

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")

    input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)
    return add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.LESS, target, name
    )


@tensorrt_converter(acc_ops.le, no_implicit_batch_dim=True)
def acc_ops_le(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError("The `lt` function should be called with explicit batch dimension.")

    input_t = kwargs["input"]
    other_t = kwargs["other"]

    input_t = get_trt_tensor(network, input_t, f"{name}_input_t")
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")
    input_t, other_t = dtype_uniform(network, target, name, input_t, other_t)

    less_result = add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.LESS, target, name + "_less"
    )
    equal_result = add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.EQUAL, target, name + "_eq"
    )
    return add_binary_elementwise_layer(
        network, less_result, equal_result, trt.ElementWiseOperation.OR, target, name
    )


@tensorrt_converter(acc_ops.logical_or, no_implicit_batch_dim=True)
def acc_ops_logical_or(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError(
            "The `logical_or` function should be called with explicit batch dimension."
        )

    input_t = kwargs["input"]
    other_t = kwargs["other"]
    if isinstance(other_t, (torch.Tensor, bool)):
        if isinstance(other_t, bool):
            other_t = int(other_t)
        elif other_t.dtype == torch.bool:
            other_t = other_t.to(torch.int32)
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")
    if input_t.dtype != trt.bool:
        layer_i = network.add_identity(input_t)
        layer_i.set_output_type(0, trt.bool)
        set_layer_name(layer_i, target, f"{name}_input_dtype_change")
        input_t = layer_i.get_output(0)
    if other_t.dtype != trt.bool:
        layer_o = network.add_identity(other_t)
        layer_o.set_output_type(0, trt.bool)
        set_layer_name(layer_o, target, f"{name}_other_dtype_change")
        other_t = layer_o.get_output(0)

    return add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.OR, target, name
    )


@tensorrt_converter(acc_ops.logical_xor, no_implicit_batch_dim=True)
def acc_ops_logical_xor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if network.has_implicit_batch_dimension:
        raise RuntimeError(
            "The `logical_xor` function should be called with explicit batch dimension."
        )

    input_t = kwargs["input"]
    other_t = kwargs["other"]
    if isinstance(other_t, (torch.Tensor, bool)):
        if isinstance(other_t, bool):
            other_t = int(other_t)
        elif other_t.dtype == torch.bool:
            other_t = other_t.to(torch.int32)
    other_t = get_trt_tensor(network, other_t, f"{name}_other_t")
    if input_t.dtype != trt.bool:
        layer_i = network.add_identity(input_t)
        layer_i.set_output_type(0, trt.bool)
        set_layer_name(layer_i, target, f"{name}_input_dtype_change")
        input_t = layer_i.get_output(0)
    if other_t.dtype != trt.bool:
        layer_o = network.add_identity(other_t)
        layer_o.set_output_type(0, trt.bool)
        set_layer_name(layer_o, target, f"{name}_other_dtype_change")
        other_t = layer_o.get_output(0)

    return add_binary_elementwise_layer(
        network, input_t, other_t, trt.ElementWiseOperation.XOR, target, name
    )


# T113156424 Have some accuracy problems in hf_T5.
# [TRT] [W] Weights [name=isinf_1_inf_t]: Converted FP32 value in weights (either FP32 infinity or FP32 value outside FP16 range) to corresponding FP16 infinity. If this is not the desired behavior, please modify the weights or retrain with regularization to reduce the magnitude of the weights.
# @tensorrt_converter(acc_ops.isinf)
# def acc_ops_isinf(
#     network: TRTNetwork,
#     target: Target,
#     args: Tuple[Argument, ...],
#     kwargs: Dict[str, Argument],
#     name: str,
# ) -> Union[TRTTensor, Sequence[TRTTensor]]:
#     input_t = kwargs["input"]
#     if not isinstance(input_t, TRTTensor):
#         raise RuntimeError(
#             f"isinf received input {input_t} that is not part "
#             "of the TensorRT region!"
#         )
#     tdtype = torch_dtype_from_trt(input_t.dtype)

#     inf_t = torch.ones(tuple(input_t.shape))
#     inf_t = inf_t * float("inf")
#     inf_t = inf_t.to(tdtype)
#     inf_t = get_trt_tensor(network, inf_t, f"{name}_inf_t")

#     ninf_t = torch.ones(tuple(input_t.shape))
#     ninf_t = ninf_t * float("-inf")
#     ninf_t = ninf_t.to(tdtype)
#     ninf_t = get_trt_tensor(network, ninf_t, f"{name}_ninf_t")

#     kwargs_new = {"input": input_t, "other": inf_t}
#     inf_output = acc_ops_eq(network, target, None, kwargs_new, name + "_compare_inf")
#     kwargs_new = {"input": input_t, "other": ninf_t}
#     ninf_output = acc_ops_eq(network, target, None, kwargs_new, name + "_compare_ninf")
#     kwargs_new = {"input": inf_output, "other": ninf_output}
#     output = acc_ops_logical_or(network, target, None, kwargs_new, name + "_compare")
#     return output


@tensorrt_converter(acc_ops.any)
def acc_ops_any(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_t = kwargs["input"]
    if not isinstance(input_t, TRTTensor):
        raise RuntimeError(
            f"isinf received input {input_t} that is not part " "of the TensorRT region!"
        )

    if input_t.dtype in (trt.float32, trt.float16, trt.int32):
        comp_t = torch.zeros(tuple([*input_t.shape])).to(torch_dtype_from_trt(input_t.dtype))
        comp_t = get_trt_tensor(network, comp_t, f"{name}_comp_t")
        kwargs_new = {"input": input_t, "other": comp_t}
        eq_output = acc_ops_eq(network, target, None, kwargs_new, name + "_eq")
        kwargs_new = {"input": eq_output}
        not_output = acc_ops_logical_not(network, target, None, kwargs_new, name + "_not")
    else:
        not_output = input_t
    # cast bool result to int
    int_output = type_cast(network, target, f"{name}_cast_int", not_output, trt.int32)
    # sum
    if "dim" in kwargs:
        kwargs_new = {
            "input": int_output,
            "dim": kwargs["dim"],
            "keepdim": False if "keepdim" not in kwargs else kwargs["keepdim"],
        }
    else:
        kwargs_new = {"input": int_output}
    sum_output = acc_ops_sum(network, target, None, kwargs_new, name + "_sum")
    # cast int to bool
    output = type_cast(network, target, f"{name}_cast_bool", sum_output, trt.bool)
    output.name = output.name + "_any"
    return output


@tensorrt_converter(acc_ops.fmod)
def acc_ops_fmod(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    # NOTE: TRT doesnt currently implement fmod so we need multiple operations to perform it
    trunc_div_value = trunc_div(
        kwargs["input"], kwargs["other"], network, target, name + "_trunc_div"
    )
    prod_value = add_binary_elementwise_layer(
        network,
        trunc_div_value,
        kwargs["other"],
        trt.ElementWiseOperation.PROD,
        target,
        name + "_prod",
    )
    sub_value = add_binary_elementwise_layer(
        network,
        kwargs["input"],
        prod_value,
        trt.ElementWiseOperation.SUB,
        target,
        name + "_sub",
    )
    return sub_value


# T113156424 embedding implemenatation is very limited and shows no usage in hf models due to the indices are int64.
# if we cast to int32, it will create accuracy issues. We'd better leave it to future implementation.
# @tensorrt_converter(acc_ops.embedding, no_implicit_batch_dim=True)
# def acc_ops_embedding(
#     network: TRTNetwork,
#     target: Target,
#     args: Tuple[Argument, ...],
#     kwargs: Dict[str, Argument],
#     name: str,
# ) -> Union[TRTTensor, Sequence[TRTTensor]]:
#     if network.has_implicit_batch_dimension:
#         raise RuntimeError(
#             "The `embedding` function should be called with explicit batch dimension."
#         )

#     indices_tensor = kwargs["input"]
#     embedding_tensor = kwargs["weight"]
#     if isinstance(indices_tensor, torch.Tensor) and indices_tensor.dtype == torch.int64:
#         indices_tensor = indices_tensor.to(torch.int32)
#         warnings.warn(
#             "Embedding op has indices_tensor dtype=int64. Reduce it to int32 to run on TRT. Accuracy may not be correct!"
#         )
#     if (
#         isinstance(embedding_tensor, torch.Tensor)
#         and embedding_tensor.dtype == torch.int64
#     ):
#         embedding_tensor = embedding_tensor.to(torch.int32)
#         warnings.warn(
#             "Embedding op has embedding_tensor dtype=int64. Reduce it to int32 to run on TRT. Accuracy may not be correct!"
#         )
#     indices_tensor = get_trt_tensor(network, indices_tensor, f"{name}_indices_tensor")
#     embedding_tensor = get_trt_tensor(
#         network, embedding_tensor, f"{name}_embedding_tensor"
#     )

#     # unsupported parameters
#     # ignore padding_idx since it is meaningful for training only
#     max_norm = kwargs["max_norm"]
#     norm_type = kwargs["norm_type"]
#     scale_grad_by_freq = kwargs["scale_grad_by_freq"]
#     sparse = kwargs["sparse"]

#     if max_norm is not None:
#         raise RuntimeError(
#             f"Currently we don't support specifying max_norm, got {max_norm}."
#         )

#     if norm_type != 2.0:
#         raise RuntimeError(
#             f"Currently we don't support specifying max_norm, got {norm_type} for norm_type."
#         )

#     if scale_grad_by_freq:
#         raise RuntimeError(
#             "Currently we don't support scale gradient by word frequency."
#         )

#     if sparse:
#         raise RuntimeError("Currently we don't support sparse gradient.")

#     # Implement embedding lookup with gather layer
#     gather_layer = network.add_gather(embedding_tensor, indices_tensor, axis=0)
#     set_layer_name(gather_layer, target, name + "_gather")
#     return gather_layer.get_output(0)


@tensorrt_converter(acc_ops.max_pool1d)
def acc_ops_max_pool1d(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_trt = kwargs["input"]
    if not isinstance(input_trt, TRTTensor):
        raise RuntimeError(
            f"Max_pool1d received input {input_trt} that is not part " "of the TensorRT region!"
        )

    # adds unsqueeze layer -> max pool 2d -> squeeze layer to emulate max pool 1d.
    unsqueeze_layer = network.add_shuffle(input=input_trt)
    unsqueeze_layer.reshape_dims = tuple([*input_trt.shape, 1])
    set_layer_name(unsqueeze_layer, target, name + "_unsqueeze")

    input_trt = unsqueeze_layer.get_output(0)

    kernel_size = extend_attr_to_tuple(kwargs["kernel_size"], 1)
    stride = extend_attr_to_tuple(kwargs["stride"], 1)
    padding = extend_attr_to_tuple(kwargs["padding"], 1)
    dilation = extend_attr_to_tuple(kwargs["dilation"], 1)

    ceil_mode = kwargs["ceil_mode"]

    if len(stride) == 0 or stride[0] == None:
        stride = kernel_size

    if any(
        [
            not isinstance(param, int)
            for param in [kernel_size[0], stride[0], padding[0], dilation[0]]
        ]
    ):
        raise RuntimeError(
            f"Parameters kernel_size, stride, padding, and dilation should be of type int."
        )
    if dilation[0] != 1:
        raise RuntimeError(f"Only support dilation=1 for maxpool, but got {dilation}")

    max_pooling_layer = network.add_pooling(
        input=input_trt, type=trt.PoolingType.MAX, window_size=(kernel_size[0], 1)
    )
    max_pooling_layer.stride_nd = stride + (1,)
    max_pooling_layer.padding_nd = padding + (0,)
    set_layer_name(max_pooling_layer, target, name)

    if ceil_mode:
        max_pooling_layer.padding_mode = trt.PaddingMode.EXPLICIT_ROUND_UP
    input_trt = max_pooling_layer.get_output(0)
    squeeze_layer = network.add_shuffle(input=input_trt)
    squeeze_layer.reshape_dims = tuple(input_trt.shape[:-1])
    set_layer_name(squeeze_layer, target, name + "_squeeze")
    return squeeze_layer.get_output(0)


@tensorrt_converter(acc_ops.max_pool2d)
@tensorrt_converter(acc_ops.max_pool3d)
def acc_ops_max_poolnd(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"MaxPool2d received input {input_val} that is not part " "of the TensorRT region!"
        )
    extend_len = 2 if target == acc_ops.max_pool2d else 3
    kernel_size = extend_attr_to_tuple(kwargs["kernel_size"], extend_len)
    stride = extend_attr_to_tuple(kwargs["stride"], extend_len)
    padding = extend_attr_to_tuple(kwargs["padding"], extend_len)
    dilation = extend_attr_to_tuple(kwargs["dilation"], extend_len)
    ceil_mode = kwargs["ceil_mode"]

    if len(stride) == 0 or stride[0] == None:
        stride = kernel_size

    ones = (1,) * extend_len
    if dilation != ones:
        raise RuntimeError(f"Only support dilation=(1, 1) for maxpool, but got {dilation}")

    layer = network.add_pooling_nd(
        input=input_val, type=trt.PoolingType.MAX, window_size=kernel_size
    )
    layer.stride_nd = stride
    layer.padding_nd = padding
    set_layer_name(layer, target, name)

    if ceil_mode:
        layer.padding_mode = trt.PaddingMode.EXPLICIT_ROUND_UP

    return layer.get_output(0)


@tensorrt_converter(acc_ops.squeeze)
def acc_ops_squeeze(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"squeeze received input {input_val} that is not part " "of the TensorRT region!"
        )

    dim = cast(Optional[int], kwargs["dim"] if "dim" in kwargs else None)
    # Squeeze with dim=None would only work in explicit batch dim mode without any dynamic
    # dim, which is a very rare case. For now we just claim not supporting dim=None.
    assert dim is not None, "We don't support dim=None right now for squeeze."

    dim = get_positive_dim(
        dim, len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)
    )
    if network.has_implicit_batch_dimension:
        assert dim != 0, "We don't support squeeze batch dim when it's implicit."
        dim -= 1

    assert input_val.shape[dim] != -1, "We don't support squeeze dynamic dim."
    assert (
        len(get_dynamic_dims(input_val.shape)) <= 1
    ), "Currently more than one dynamic dim for input to squeeze is not supported."

    output_shape = []
    for i, s in enumerate(input_val.shape):
        if i == dim and s == 1:
            continue
        output_shape.append(s)
    layer = network.add_shuffle(input_val)
    layer.reshape_dims = tuple(output_shape)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.add)
def acc_ops_add(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    # tensors = [kwargs["input"], kwargs["other"]]
    # max_dynamic_range = .0
    # for idx, t in enumerate(tensors):
    #     if hasattr(t, "dynamic_range") and t.dynamic_range is not None:
    #         _LOGGER.debug(f"idx: {idx}, dynamic_range: {t.dynamic_range[1]}")
    #         max_dynamic_range = max(max_dynamic_range, t.dynamic_range[1])

    # if max_dynamic_range > .0:
    #     _LOGGER.warn("all input tensor set to max_dynamic_range")
    #     for t in tensors:
    #         if hasattr(t, "dynamic_range"):
    #             t.reset_dynamic_range()
    #             _LOGGER.debug(f"set max_dynamic_range to: {max_dynamic_range}")
    #             t.set_dynamic_range(-max_dynamic_range, max_dynamic_range)

    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.SUM,
        target,
        name,
    )


@tensorrt_converter(acc_ops.sub)
def acc_ops_sub(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.SUB,
        target,
        name,
    )


@tensorrt_converter(acc_ops.div)
def acc_ops_div(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.DIV,
        target,
        name,
    )


@tensorrt_converter(acc_ops.floor_div)
def acc_ops_floor_div(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.FLOOR_DIV,
        target,
        name,
    )


@tensorrt_converter(acc_ops.trunc_div)
def acc_ops_trunc_div(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return trunc_div(kwargs["input"], kwargs["other"], network, target, name)


@tensorrt_converter(acc_ops.mul)
def acc_ops_mul(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    tensors = [kwargs["input"], kwargs["other"]]
    max_dynamic_range = 0.0
    for idx, t in enumerate(tensors):
        if hasattr(t, "dynamic_range") and t.dynamic_range is not None:
            print(f"idx: {idx}, dynamic_range: {t.dynamic_range[1]}")
            max_dynamic_range = max(max_dynamic_range, t.dynamic_range[1])

    if max_dynamic_range > 0.0:
        _LOGGER.warn("all input tensor set to max_dynamic_range")
        for t in tensors:
            if hasattr(t, "dynamic_range"):
                t.reset_dynamic_range()
                print(f"set max_dynamic_range to: {max_dynamic_range}")
                t.set_dynamic_range(-max_dynamic_range, max_dynamic_range)

    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["other"],
        trt.ElementWiseOperation.PROD,
        target,
        name,
    )


@tensorrt_converter(acc_ops.pow)
def acc_ops_pow(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return add_binary_elementwise_layer(
        network,
        kwargs["input"],
        kwargs["exponent"],
        trt.ElementWiseOperation.POW,
        target,
        name,
    )


@tensorrt_converter(acc_ops.unsqueeze)
def acc_ops_unsqueeze(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_t = kwargs["input"]
    input_val = get_trt_tensor(network, input_t, f"{name}_input_t")
    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"unsqueeze received input {input_val} that is not part " "of the TensorRT region!"
        )

    dim = cast(int, kwargs["dim"])
    input_shape = input_val.shape
    input_shape_size = (
        len(input_val.shape) + 1 if network.has_implicit_batch_dimension else len(input_val.shape)
    )
    dim = get_positive_dim(dim, input_shape_size + 1)

    if network.has_implicit_batch_dimension:
        assert dim != 0
        dim -= 1

    assert (
        len(get_dynamic_dims(input_val.shape)) <= 1
    ), "Currently we don't support unsqueeze with more than one dynamic dims."
    layer = network.add_shuffle(input_val)
    layer.reshape_dims = tuple(input_val.shape)[:dim] + (1,) + tuple(input_val.shape)[dim:]
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.topk)
def acc_ops_topk(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    k = kwargs["k"]
    # sorted = kwargs.get("sorted", True)
    dim = kwargs.get("dim", -1)
    dim = -1 if dim is None else dim
    largest = kwargs.get("largest", True)

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"topk received input {input_val} that is not part " "of the TensorRT region!"
        )

    # Output values are sorted.
    # Ref: https://docs.nvidia.com/deeplearning/tensorrt/api/python_api/infer/Graph/Network.html#tensorrt.INetworkDefinition.add_topk
    # if sorted and k != 1:
    #     raise RuntimeError("Currently we don't support sorted=True in topk.")

    if not network.has_implicit_batch_dimension and len(input_val.shape) <= 1:
        raise RuntimeError("At least 2 dimensions are required for input to topk.")

    num_dims = len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)
    dim = get_positive_dim(dim, num_dims)  # type: ignore[arg-type]
    operation = trt.TopKOperation.MAX if largest else trt.TopKOperation.MIN
    layer = network.add_topk(
        input_val,
        operation,
        k,
        get_axes_for_reduce_op(dim, network.has_implicit_batch_dimension),
    )
    set_layer_name(layer, target, name)
    return layer.get_output(0), layer.get_output(1)


@tensorrt_converter(acc_ops.adaptive_avg_pool3d)
@tensorrt_converter(acc_ops.adaptive_avg_pool2d)
def acc_ops_adaptive_avg_poolnd(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"AdaptiveAvgPool2d received input {input_val} that is not part "
            "of the TensorRT region!"
        )

    extend_len = 2 if target == acc_ops.adaptive_avg_pool2d else 3
    assert all(
        input_val.shape[-(i + 1)] != -1 for i in range(extend_len)
    ), "AdaptiveAvgPool2d and AdaptiveAvgPool3d currently doesn't support dynamic shapes for last two dims."

    output_size = cast(Sequence[int], extend_attr_to_tuple(kwargs["output_size"], extend_len))
    for input_dim, output_dim in zip(input_val.shape[-extend_len:], output_size):
        if input_dim % output_dim != 0:
            raise RuntimeError(
                "For AdaptiveAvgPool, input dim has to be integer multiple of output dim."
                f"Got input dim {input_dim}, output dim {output_dim}"
            )

    stride = tuple(input_val.shape[-extend_len + i] // output_size[i] for i in range(extend_len))
    kernel_size = tuple(
        input_val.shape[-extend_len + i] - (output_size[i] - 1) * stride[i]
        for i in range(extend_len)
    )
    layer = network.add_pooling_nd(
        input=input_val, type=trt.PoolingType.AVERAGE, window_size=kernel_size
    )
    layer.stride_nd = stride
    set_layer_name(layer, target, name)

    return layer.get_output(0)


@tensorrt_converter(acc_ops.avg_pool1d)
def acc_ops_avg_pool1d(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"AvgPool1d received input {input_val} that is not part " "of the TensorRT region!"
        )

    kernel_size = extend_attr_to_tuple(kwargs["kernel_size"], 1)
    stride = extend_attr_to_tuple(kwargs["stride"], 1)
    padding = extend_attr_to_tuple(kwargs["padding"], 1)
    ceil_mode = kwargs["ceil_mode"]
    count_include_pad = kwargs["count_include_pad"]

    if len(stride) == 0 or stride[0] == None:
        stride = kernel_size

    shuffle_layer = network.add_shuffle(input_val)
    shuffle_layer.reshape_dims = tuple(input_val.shape) + (1,)
    set_layer_name(shuffle_layer, target, name + "_shuffle1")
    shuffle_out = shuffle_layer.get_output(0)

    layer = network.add_pooling_nd(
        input=shuffle_out, type=trt.PoolingType.AVERAGE, window_size=(kernel_size[0], 1)
    )

    layer.stride_nd = stride + (1,)
    layer.padding_nd = padding + (0,)
    layer.average_count_excludes_padding = False if count_include_pad else True
    set_layer_name(layer, target, name)
    if ceil_mode:
        layer.padding_mode = trt.PaddingMode.EXPLICIT_ROUND_UP

    output = layer.get_output(0)
    layer = network.add_shuffle(output)
    layer.reshape_dims = tuple(output.shape)[:-1]
    set_layer_name(layer, target, name + "_shuffle2")

    return layer.get_output(0)


@tensorrt_converter(acc_ops.avg_pool2d)
def acc_ops_avg_pool2d(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"AvgPool2d received input {input_val} that is not part " "of the TensorRT region!"
        )

    kernel_size = extend_attr_to_tuple(kwargs["kernel_size"], 2)
    stride = extend_attr_to_tuple(kwargs["stride"], 2)
    padding = extend_attr_to_tuple(kwargs["padding"], 2)
    ceil_mode = kwargs["ceil_mode"]
    count_include_pad = kwargs["count_include_pad"]
    divisor_override = kwargs["divisor_override"]

    if len(stride) == 0 or stride[0] == None:
        stride = kernel_size

    if divisor_override:
        raise RuntimeError("TensorRT does not support divisor_override.")

    layer = network.add_pooling(
        input=input_val, type=trt.PoolingType.AVERAGE, window_size=kernel_size
    )
    layer.stride = stride
    layer.padding = padding
    layer.average_count_excludes_padding = False if count_include_pad else True
    set_layer_name(layer, target, name)

    if ceil_mode:
        layer.padding_mode = trt.PaddingMode.EXPLICIT_ROUND_UP

    return layer.get_output(0)


# infer the destination shape for reshape op
# for example: src[-1, 100, 2], dest[-1, 20, -1, 2], then return[-1, 20, 5, 2]
def infer_shape(src, dest):
    src_size = 1
    for l in src:
        if l != -1:
            src_size *= l

    dest_size = 1
    for l in dest:
        if l != -1:
            dest_size *= l

    result = [0] * len(dest)
    shape_val = src_size // dest_size
    for idx in range(len(dest)):
        if -1 == dest[idx] and -1 != src[idx]:
            result[idx] = shape_val
        else:
            result[idx] = dest[idx]
    return result


@tensorrt_converter(acc_ops.reshape)
def acc_ops_reshape(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    max_dynamic_range = -1.0
    if isinstance(input_val, TRTTensor):
        if input_val.dynamic_range is not None:
            max_dynamic_range = max(max_dynamic_range, input_val.dynamic_range[1])

    # for case where input_val is TRTensor
    input_val = get_trt_tensor(network, input_val, f"{name}_input_val")

    shape = kwargs["acc_out_ty"].shape  # type: ignore[misc]
    if network.has_implicit_batch_dimension:
        shape = shape[1:]

    layer = network.add_shuffle(input_val)

    if all(isinstance(s, int) for s in shape):
        assert shape.count(-1) - tuple(input_val.shape).count(-1) <= 1
        layer.reshape_dims = tuple(infer_shape(list(input_val.shape), shape))
    else:
        # Convert all the dimensions to trt Tensors.
        trt_shape = []

        for i, s in enumerate(shape):
            if isinstance(s, TRTTensor):
                if len(s.shape) == 0:
                    s = prepend_ones(network, s, f"{name}_{i}", 1)
                trt_shape.append(s)
            else:
                trt_shape.append(get_trt_tensor(network, s, f"{name}_{i}"))

        shape_layer = network.add_concatenation(inputs=trt_shape)
        shape_layer.axis = 0
        shape_layer.name = f"{name}_output_shape"
        layer.set_input(1, shape_layer.get_output(0))

    set_layer_name(layer, target, name)
    layer_output = layer.get_output(0)
    if max_dynamic_range > 0.0:
        layer_output.set_dynamic_range(-max_dynamic_range, max_dynamic_range)
    return layer_output


@tensorrt_converter(acc_ops.slice_tensor)
def acc_ops_slice_tensor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"slice_tensor received input {input_val} that is not part " "of the TensorRT region!"
        )

    ranks = len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)
    dim = get_positive_dim(cast(int, kwargs["dim"]), ranks)
    dynamic_shape = has_dynamic_shape(input_val.shape)
    if network.has_implicit_batch_dimension:
        if dim == 0:
            raise RuntimeError(
                f"We do not support slice_tensor at batch dim when it's implicit, got {dim}!"
            )
        dim = dim - 1
    else:
        if dynamic_shape:
            # Check whether slice target dim is dynamic shape dim
            assert input_val.shape[dim] != -1, "Can't chunk on dynamic shape dimension!"

    start_int = cast(int, kwargs["start"])
    stop_int = cast(int, kwargs["stop"])
    step_int = cast(int, kwargs["step"])
    start = [0] * len(input_val.shape)
    start[dim] = start_int
    stride = [1] * len(start)
    stride[dim] = step_int
    output_shape = list(input_val.shape)
    output_shape[dim] = (stop_int - start_int) // step_int

    if dynamic_shape > 0:
        output_shape = get_shape_with_dynamic_shape(network, output_shape, input_val, target, name)
    layer = network.add_slice(
        input_val,
        start=start,
        shape=[] if dynamic_shape else output_shape,
        stride=stride,
    )
    if dynamic_shape:
        layer.set_input(2, output_shape)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.expand)
def acc_ops_expand_tensor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_t = kwargs["input"]
    shape = list(kwargs["sizes"])

    input_val = get_trt_tensor(network, input_t, f"{name}_input")

    if network.has_implicit_batch_dimension:
        shape = shape[1:]

    ranks = len(input_val.shape)
    # TRT does not support different dimension size
    assert len(shape) == ranks
    shape = [input_val.shape[i] if shape[i] == -1 else shape[i] for i in range(ranks)]
    if list(shape) == list(input_val.shape):  # not need to expand
        return input_val

    inshape = tuple(input_val.shape)
    shape = tuple(shape)
    start = tuple([0] * ranks)
    stride = tuple(
        [int(i == o) for i, o in zip(inshape, shape)]
    )  # stride == 1 if dimensions match, 0 otherwise
    output_shape = shape
    dynamic_shape = has_dynamic_shape(input_val.shape)
    if dynamic_shape > 0:
        output_shape = get_shape_with_dynamic_shape(network, shape, input_val, target, name)
    layer = network.add_slice(
        input_val,
        start=start,
        shape=[] if dynamic_shape else output_shape,
        stride=stride,
    )
    if dynamic_shape:
        layer.set_input(2, output_shape)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.where)
def acc_ops_where(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    condition_t = kwargs["condition"]
    x_t = kwargs["x"]
    y_t = kwargs["y"]

    if type(x_t) != TRTTensor:
        x_t = to_torch(x_t)
        # assert type(x_t) is torch.Tensor, f"value {x_t} is not torch.Tensor!"

    if type(y_t) != TRTTensor:
        y_t = to_torch(y_t)
        # assert type(y_t) is torch.Tensor, f"value {y_t} is not torch.Tensor!"

    x_shape = list(x_t.shape)
    y_shape = list(y_t.shape)
    condition_shape = list(condition_t.shape)
    output_shape = list(torch.broadcast_shapes(condition_shape, x_shape, y_shape))

    # expand shape
    if type(condition_t) != TRTTensor:
        assert condition_t.dtype == torch.bool, "condition dtype is not bool"
        if condition_shape != output_shape:
            condition_t.expand(output_shape)
        condition_t = condition_t.to(torch.int32)
        condition_const = get_trt_tensor(network, condition_t, f"{name}_condition")
        condition_layer = network.add_identity(condition_const)
        condition_layer.set_output_type(0, trt.bool)
        set_layer_name(condition_layer, target, f"{name}_condition")
        condition_val = condition_layer.get_output(0)
    else:
        assert condition_t.dtype == trt.bool, "mask dtype is not bool!"
        if condition_shape != output_shape:
            condition_val = acc_ops_expand_tensor(
                network,
                target,
                None,
                {"input": condition_t, "sizes": output_shape},
                name=f"{name}_expand",
            )
        else:
            condition_val = condition_t

    if type(x_t) != TRTTensor:
        if x_shape != output_shape:
            # special case where 1 element in x_t
            if len(x_t.shape) == 0:
                x_t = x_t.unsqueeze(0)
            x_t = x_t.expand(output_shape)
        x_val = get_trt_tensor(network, x_t, f"{name}_x")
    else:
        x_val = x_t
        if x_shape != output_shape:
            x_val = acc_ops_expand_tensor(
                network,
                target,
                None,
                {"input": x_val, "sizes": output_shape},
                name=f"{name}_x_expand",
            )

    if type(y_t) != TRTTensor:
        if y_shape != output_shape:
            # special case where 1 element in y_t
            if len(y_t.shape) == 0:
                y_t = y_t.unsqueeze(0)
            y_t = y_t.expand(output_shape)
        y_val = get_trt_tensor(network, y_t, f"{name}_y")
    else:
        y_val = y_t
        if y_shape != output_shape:
            y_val = acc_ops_expand_tensor(
                network,
                target,
                None,
                {"input": y_val, "sizes": output_shape},
                name=f"{name}_y_expand",
            )

    select_layer = network.add_select(condition_val, x_val, y_val)

    set_layer_name(select_layer, target, f"{name}_select")

    return select_layer.get_output(0)


@tensorrt_converter(acc_ops.masked_fill, no_implicit_batch_dim=True)
def acc_ops_masked_fill_tensor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_t = kwargs["input"]
    mask_t = kwargs["mask"]
    value_t = kwargs["value"]
    if network.has_implicit_batch_dimension:
        raise RuntimeError(
            "We don't support masked_fill with implicit batch dimension due to select layer!"
        )

    shape = list(input_t.shape)
    mask_shape = list(mask_t.shape)

    assert type(value_t) in (
        float,
        int,
        torch.Tensor,
    ), f"value {value_t} is not one of (float, int, torch.Tensor)!"

    if type(mask_t) != TRTTensor:
        assert mask_t.dtype == torch.bool, "mask dtype is not bool!"
        if mask_shape != shape:
            mask_t = mask_t.expand(shape)
        mask_t = mask_t.to(torch.int32)
        mask_const = get_trt_tensor(network, mask_t, f"{name}_mask")
        mask_layer = network.add_identity(mask_const)
        mask_layer.set_output_type(0, trt.bool)
        set_layer_name(mask_layer, target, f"{name}_mask")
        mask_val = mask_layer.get_output(0)
    else:
        assert mask_t.dtype == trt.bool, "mask dtype is not bool!"
        if mask_shape != shape:
            mask_val = acc_ops_expand_tensor(
                network,
                target,
                None,
                {"input": mask_t, "sizes": shape},
                name=f"{name}_expand",
            )
        else:
            mask_val = mask_t

    if type(value_t) is torch.Tensor:
        value_t = value_t.cpu().numpy()
    # cast to input type
    input_dtype = torch_dtype_from_trt(input_t.dtype)
    value_t = (torch.ones(shape) * value_t).to(input_dtype)
    input_val = get_trt_tensor(network, input_t, f"{name}_input")
    value_val = get_trt_tensor(network, value_t, f"{name}_input")
    layer = network.add_select(mask_val, value_val, input_val)
    set_layer_name(layer, target, f"{name}_select")
    return layer.get_output(0)


@tensorrt_converter(acc_ops.split)
def acc_ops_split(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"split received input {input_val} that is not part " "of the TensorRT region!"
        )

    dim = cast(int, kwargs["dim"])
    dynamic_shape = has_dynamic_shape(input_val.shape)
    if network.has_implicit_batch_dimension:
        assert dim != 0, "Can't split on batch dim when it's implicit!"
        dim -= 1
    else:
        if dynamic_shape > 0:
            # Check whether slice target dim is dynamic shape dim
            assert input_val.shape[dim] != -1, "Can't chunk on dynamic shape dimension!"

    split_size = cast(int, kwargs["split_size"])
    start = [0] * len(input_val.shape)
    stride = [1] * len(start)
    offset = 0
    num_splits = (input_val.shape[dim] + split_size - 1) // split_size
    if num_splits < 1:
        raise RuntimeError(f"Invalid split: {input_val.shape[dim]} with split_size={split_size}")

    max_offset = input_val.shape[dim]
    # add slice layers
    output = []
    for i in range(num_splits):
        shape = list(input_val.shape)
        shape[dim] = min(split_size, cast(int, max_offset - offset))
        start[dim] = offset
        if dynamic_shape:
            shape = get_shape_with_dynamic_shape(
                network, shape, input_val, target, f"{name}_shape_{i}"
            )
        layer = network.add_slice(
            input_val, start=start, shape=[] if dynamic_shape else shape, stride=stride
        )
        if dynamic_shape:
            layer.set_input(2, shape)
        offset += split_size
        set_layer_name(layer, target, f"{name}_{i}")
        output.append(layer.get_output(0))
    return output


@tensorrt_converter(acc_ops.linear)
def acc_ops_linear(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Linear received input {input_val} that is not part " "of the TensorRT region!"
        )

    dynamic_dims = get_dynamic_dims(input_val.shape)
    assert len(dynamic_dims) < 2 and input_val.shape[-1] != -1, (
        "Currently we only support one dynmaic " "dim for linear and it can't be the last dim."
    )

    if False:  # TODO use add_fully_connected
        # os.environ.get("USE_IMPlICT_QUANT").upper() == "TRUE":
        if not isinstance(kwargs["weight"], torch.Tensor):
            raise RuntimeError(
                f"linear {name} has weight of type {type(kwargs['weight'])}, Expect Optional[Tenosr]"
            )

        if not isinstance(kwargs["bias"], torch.Tensor):
            raise RuntimeError(
                f"linear {name} has bias of type {type(kwargs['bias'])}, Expect Optional[Tenosr]"
            )

        weight = to_numpy(kwargs["weight"])
        bias = to_numpy(kwargs["bias"])
        print(weight.shape)
        layer = network.add_fully_connected(
            input=input_val, num_outputs=weight.shape[0], kernel=weight, bias=bias
        )
        return layer.get_output(0)
    else:
        if isinstance(kwargs["weight"], torch.Tensor):
            weight = get_trt_tensor(network, kwargs["weight"].t(), f"{name}_weight")
            weight_op = trt.MatrixOperation.NONE
        else:
            assert isinstance(
                kwargs["weight"], TRTTensor
            ), f"Expect weight to be trt tensor but got {type(kwargs['weight'])}"
            weight = kwargs["weight"]
            weight_op = trt.MatrixOperation.TRANSPOSE

        preset_diff = 0
        if len(input_val.shape) == 1:
            preset_diff -= 1
            input_op = trt.MatrixOperation.VECTOR
        else:
            input_op = trt.MatrixOperation.NONE

        input_val, weight = broadcast(
            network, input_val, weight, f"{name}_input", f"{name}_weight", preset_diff
        )
        matmul_layer = network.add_matrix_multiply(input_val, input_op, weight, weight_op)
        set_layer_name(matmul_layer, target, f"{name}_matmul")
        res = matmul_layer.get_output(0)

        if kwargs["bias"] is not None:
            bias = get_trt_tensor(network, kwargs["bias"], f"{name}_bias")  # type: ignore[arg-type]
            res = add_binary_elementwise_layer(
                network,
                matmul_layer.get_output(0),
                bias,
                trt.ElementWiseOperation.SUM,
                target,
                f"{name}_add",
            )
        return res


def add_clamp(network, input, val, op):
    acc_ops_clamp_shape = (1,) * len(input.shape)  # broadcast all dimensions
    acc_ops_clamp_tensor = (
        val * torch.ones(acc_ops_clamp_shape, dtype=torch_dtype_from_trt(input.dtype)).cpu().numpy()
    )
    acc_ops_clamp_trt = network.add_constant(acc_ops_clamp_shape, acc_ops_clamp_tensor)
    layer = network.add_elementwise(input, acc_ops_clamp_trt.get_output(0), op)

    return layer


@tensorrt_converter(acc_ops.clamp)
def acc_ops_clamp(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    min_val = kwargs["min"]
    max_val = kwargs["max"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Clamp received input {input_val} that is not part " "of the TensorRT region!"
        )

    if min_val is not None:
        clamp_min_layer = add_clamp(network, input_val, min_val, trt.ElementWiseOperation.MAX)
        set_layer_name(clamp_min_layer, target, f"{name}_clamp_min")
        input_val = clamp_min_layer.get_output(0)
    if max_val is not None:
        clamp_max_layer = add_clamp(network, input_val, max_val, trt.ElementWiseOperation.MIN)
        set_layer_name(clamp_max_layer, target, f"{name}_clamp_max")
        input_val = clamp_max_layer.get_output(0)

    return input_val


@tensorrt_converter(acc_ops.tuple_construct)
def acc_ops_tuple_construct(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return kwargs["tensors"]


@tensorrt_converter(acc_ops.contiguous)
def acc_ops_contiguous(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return kwargs["input"]


# check if is colon slice or not
def is_colon(sli) -> bool:
    return all(i is None for i in (sli.start, sli.step, sli.stop))


# check wheather can use trt.gather layer.
# if yes, return the (axis, index)
# if no, return (None, None
def try_use_gather(input_val, slices) -> Tuple[Optional[int], List]:
    list_cnt = 0
    ellipsis_cnt = 0
    for s in slices:
        if isinstance(s, (list, tuple, TRTTensor)):
            list_cnt += 1
        elif isinstance(s, slice):
            if not is_colon(s):  # e.g. tensor[..., 2:10]
                return None, None
        elif s is Ellipsis:
            ellipsis_cnt += 1

    if list_cnt == 0 or list_cnt > 1:
        return None, None

    assert ellipsis_cnt <= 1
    if ellipsis_cnt == 1:
        num_ellipsis = len(input_val.shape) - len(slices) + 1
    else:
        num_ellipsis = 0

    axis = 0
    for s in slices:
        if isinstance(s, (list, tuple, TRTTensor)):
            return axis, s
        elif isinstance(s, slice):
            axis += 1
        elif s is Ellipsis:
            axis += num_ellipsis
        else:
            raise AssertionError("should not reach here!")


@tensorrt_converter(acc_ops.getitem)
def acc_ops_getitem(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    slices = kwargs["idx"]
    if not isinstance(input_val, TRTTensor):
        return operator.getitem(input_val, slices)  # type: ignore[arg-type]

    if not isinstance(slices, (tuple, list)):
        slices = (slices,)

    axis, index = try_use_gather(input_val, slices)
    if axis and axis >= 0:
        kwargs = dict(input=input_val, dim=axis, index=index)
        return acc_ops_index_select(network, target, args, kwargs, name)

    for s in slices:
        assert s == Ellipsis or isinstance(
            s, (int, slice)
        ), f"slices item type must int or slice, but: {slices}. try to use index_select or gather op."

    dynamic_shape = get_dynamic_dims(input_val.shape)
    if len(dynamic_shape) > 0:
        for i, s in zip(input_val.shape, slices):
            assert i > 0 or (
                s in [slice(None, None, None), slice(0, None, None), Ellipsis]
            ), "We don't support slicing tensor on dynamic shape. "

    def num_slice_types(slices):
        """
        Gather the number of slice in getitem slices.
        """
        return sum(1 for s in slices if isinstance(s, (slice, int)))

    def slice_to_trt_params(py_slice, dim_size):
        """
        Convert python slice to TensorRT slice layer parameters.
        """
        start = get_positive_dim(py_slice.start, dim_size) if py_slice.start != None else 0
        stride = py_slice.step if py_slice.step != None else 1
        stop = get_positive_dim(py_slice.stop, dim_size) if py_slice.stop != None else dim_size
        size = math.ceil((stop - start) * 1.0 / stride)
        return start, size, stride

    if network.has_implicit_batch_dimension:
        # Raise an error if it's trying to subscript batch dimension unless it's
        # slice(None, None, None).
        batch_subscript = slices[0]
        if batch_subscript not in [slice(None, None, None), slice(0, None, None)]:
            raise RuntimeError(
                f"{name}: Can't subscript batch dimension when it's implicit. Got {slices}"
            )

        # Remove batch_dim subscript
        slices = slices[1:]

    # Replace ellipsis with expanded slices.
    # Compute the number of dim ellipsis represent.
    num_ellipsis = len(input_val.shape) - num_slice_types(slices)
    new_slices = []
    for s in slices:
        if s == Ellipsis:
            # pass explicit start to guard against negative num_ellipsis
            for _ in range(0, num_ellipsis):
                new_slices.append(slice(None, None, None))
        else:
            new_slices.append(s)
    slices = new_slices

    # Build trt slice layer params
    start = []
    size = []
    stride = []

    i = 0
    for s in slices:
        if s is None:
            continue

        if isinstance(s, slice):
            params = slice_to_trt_params(s, input_val.shape[i])
            start.append(params[0])
            size.append(params[1])
            stride.append(params[2])
        else:
            start.append(get_positive_dim(s, input_val.shape[i]))
            size.append(1)
            stride.append(1)
        i += 1

    while i < len(input_val.shape):
        start.append(0)
        size.append(input_val.shape[i])
        stride.append(1)
        i += 1

    if dynamic_shape:
        size = get_shape_with_dynamic_shape(network, size, input_val, target, name)

    layer = network.add_slice(
        input=input_val,
        start=start,
        shape=[] if dynamic_shape else size,
        stride=stride,
    )
    if dynamic_shape:
        layer.set_input(2, size)
    set_layer_name(layer, target, name)

    # Add shuffle layer to insert dimensions for 'None' and remove dimensions for 'int'.
    if any(not isinstance(s, slice) for s in slices):
        slice_out = layer.get_output(0)
        layer = network.add_shuffle(slice_out)
        set_layer_name(layer, target, f"{name}_shuffle")
        final_shape = []
        original_idx = 0
        for s in slices:
            # If it's a slice, keep the dim.
            if isinstance(s, slice):
                final_shape.append(slice_out.shape[original_idx])
                original_idx += 1
            # If it's None, extend the dim.
            elif s is None:
                final_shape.append(1)
            # If it's a int, remove the dim.
            else:
                original_idx += 1
        layer.reshape_dims = tuple(final_shape) + tuple(slice_out.shape)[original_idx:]

    return layer.get_output(0)


@tensorrt_converter(acc_ops.cat)
def acc_ops_cat(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    tensors = kwargs["tensors"]
    dim = kwargs["dim"]

    # get max dynamic_range, and set to other.
    max_dynamic_range = 0.0
    for idx, t in enumerate(tensors):
        if t.dynamic_range is not None:
            print(f"idx: {idx}, dynamic_range: {t.dynamic_range[1]}")
            max_dynamic_range = max(max_dynamic_range, t.dynamic_range[1])

    if max_dynamic_range > 0.0:
        for t in tensors:
            t.reset_dynamic_range()
            print(f"set max_dynamic_range to: {max_dynamic_range}")
            t.set_dynamic_range(-max_dynamic_range, max_dynamic_range)

    if any(not isinstance(t, TRTTensor) for t in tensors):  # type: ignore[union-attr]
        raise RuntimeError(
            f"cat received inputs {tensors} that is not part " "of the TensorRT region!"
        )
    layer = network.add_concatenation(inputs=tensors)
    if dim < 0:
        if network.has_implicit_batch_dimension:
            dim = len(tensors[0].shape) + 1 + dim
        else:
            dim = len(tensors[0].shape) + dim

    layer.axis = dim - (1 if network.has_implicit_batch_dimension else 0)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.matmul)
def acc_ops_matmul(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = get_trt_tensor(network, kwargs["input"], f"{name}_input")
    other_val = get_trt_tensor(network, kwargs["other"], f"{name}_other")

    for i in [input_val, other_val]:
        if not isinstance(i, TRTTensor):
            raise RuntimeError(
                f"matmul received input {i} that is not part of the TensorRT region!"
            )

    input_matrix_op = other_matrix_op = trt.MatrixOperation.NONE
    preset_diff = 0

    if len(input_val.shape) == 1:
        preset_diff -= 1
        input_matrix_op = trt.MatrixOperation.VECTOR

    if len(other_val.shape) == 1:
        preset_diff += 1
        other_matrix_op = trt.MatrixOperation.VECTOR

    input_val, other_val = broadcast(
        network, input_val, other_val, f"{name}_input", f"{name}_other", preset_diff
    )
    layer = network.add_matrix_multiply(input_val, input_matrix_op, other_val, other_matrix_op)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.hardsigmoid)
def acc_ops_hard_sigmoid(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Hard sigmoid received input {input_val} that is not part " "of the TensorRT region!"
        )

    return add_activation_layer(
        network,
        input_val,
        trt.ActivationType.HARD_SIGMOID,
        target,
        name,
        alpha=1 / 6,
        beta=0.5,
    )


@tensorrt_converter(acc_ops.sigmoid)
def acc_ops_sigmoid(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"Sigmoid received input {input_val} that is not part " "of the TensorRT region!"
        )

    return add_activation_layer(network, input_val, trt.ActivationType.SIGMOID, target, name)


@tensorrt_converter(acc_ops.permute)
def acc_ops_permute(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    ranks = len(input_val.shape) + (1 if network.has_implicit_batch_dimension else 0)  # type: ignore[union-attr]
    if len(kwargs["permutation"]) == 1:
        index = kwargs["permutation"][0]
    else:
        index = kwargs["permutation"]
    permutation = [get_positive_dim(i, ranks) for i in cast(Sequence[int], index)]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"permute received input {input_val} that is not part " "of the TensorRT region!"
        )

    if network.has_implicit_batch_dimension:
        assert permutation[0] == 0, "Can't permute batch dimension when it's implicit."
        permutation = [i - 1 for i in permutation[1:]]

    layer = network.add_shuffle(input_val)
    layer.second_transpose = tuple(permutation)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.quantize_per_tensor)
def acc_ops_quantize_per_tensor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    name_prefix = name
    input_val = get_trt_tensor(network, kwargs["input"], f"{name}_input")

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part " "of the TensorRT region!"
        )

    qparams = kwargs["acc_out_ty"].qparams  # type: ignore[misc]
    q_scale = qparams["scale"]
    q_zero_point = qparams["zero_point"]
    dtype = kwargs["acc_out_ty"].dtype  # type: ignore[misc]
    if dtype not in (torch.quint8, torch.qint8, torch.qint32):
        raise RuntimeError(
            "Only support (torch.quint8, torch.qint8, torch.qint32) "
            f"quantized type in quantize_per_tensor, get {dtype}."
        )

    if q_zero_point != 0:
        raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")

    scale_layer = network.add_constant(
        (1,), trt.Weights(np.ascontiguousarray([float(q_scale)], dtype=np.float32))
    )
    # scale_layer.name = input_val.name + ".per_tensor_quant.scale"
    scale_layer.name = name_prefix + ".per_tensor_quant.scale"
    scale = scale_layer.get_output(0)
    # assert trt.__version__ > "8.0", "Explicit quantize op is only supported in "
    # "TensorRT 8.0 or above, current TensorRT version:" + trt.__version__
    layer = network.add_quantize(input=input_val, scale=scale)
    layer.axis = 0
    # set_layer_name(layer, target, f"{input_val.name}_per_tensor_quant")
    set_layer_name(layer, target, f"{name_prefix}_per_tensor_quant")
    return layer.get_output(0)


@tensorrt_converter("quantize_per_tensor")
def acc_ops_quantize_per_tensor(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    name_prefix = name
    input_val = get_trt_tensor(network, kwargs["input"], f"{name}_input")

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part " "of the TensorRT region!"
        )

    # qparams = kwargs["acc_out_ty"].qparams  # type: ignore[misc]
    # q_scale = qparams["scale"]
    # q_zero_point = qparams["zero_point"]
    # dtype = kwargs["acc_out_ty"].dtype  # type: ignore[misc]

    q_scale = kwargs["scale"]
    q_zero_point = kwargs["zero_point"]
    dtype = kwargs["dtype"]  # type: ignore[misc]

    if dtype not in (torch.quint8, torch.qint8, torch.qint32):
        raise RuntimeError(
            "Only support (torch.quint8, torch.qint8, torch.qint32) "
            f"quantized type in quantize_per_tensor, get {dtype}."
        )

    if q_zero_point != 0:
        raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")

    scale_layer = network.add_constant(
        (1,), trt.Weights(np.ascontiguousarray([float(q_scale)], dtype=np.float32))
    )
    # scale_layer.name = input_val.name + ".per_tensor_quant.scale"
    scale_layer.name = name_prefix + ".per_tensor_quant.scale"
    scale = scale_layer.get_output(0)
    # assert trt.__version__ > "8.0", "Explicit quantize op is only supported in "
    # "TensorRT 8.0 or above, current TensorRT version:" + trt.__version__
    layer = network.add_quantize(input=input_val, scale=scale)
    layer.axis = 0
    # set_layer_name(layer, target, f"{input_val.name}_per_tensor_quant")
    set_layer_name(layer, target, f"{name_prefix}_per_tensor_quant")
    return layer.get_output(0)


@tensorrt_converter(acc_ops.quantize_per_channel)
def acc_ops_quantize_per_channel(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    name_prefix = name
    input_val = get_trt_tensor(network, kwargs["input"], f"{name}_input")

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part " "of the TensorRT region!"
        )

    qparams = kwargs["acc_out_ty"].qparams  # type: ignore[misc]
    q_per_channel_scales = qparams["scale"]
    q_per_channel_zero_points = qparams["zero_point"]
    q_per_channel_axis = qparams["axis"]
    dtype = kwargs["acc_out_ty"].dtype  # type: ignore[misc]
    if dtype not in (torch.quint8, torch.qint8, torch.qint32):
        raise RuntimeError(
            "Only support (torch.quint8, torch.qint8, torch.qint32) "
            f"quantized type in quantize_per_tensor, get {dtype}."
        )

    # Make sure zero_points are all 0 because only symmetric quantization
    # is supported in TensorRT
    if not torch.equal(
        q_per_channel_zero_points,
        torch.zeros(q_per_channel_zero_points.shape, dtype=q_per_channel_zero_points.dtype),
    ):
        raise RuntimeError(f"Only support zero_point == 0, get {q_per_channel_zero_points}")

    if not torch.all(torch.ge(q_per_channel_scales, 0)):
        raise RuntimeError(f"All scale values must be >= 0, get {q_per_channel_scales}")

    scale_layer = network.add_constant(
        q_per_channel_scales.shape,
        trt.Weights(np.ascontiguousarray(q_per_channel_scales, dtype=np.float32)),
    )
    # scale_layer.name = input_val.name + ".per_channel_quant.scale"
    scale_layer.name = name_prefix.name + ".per_channel_quant.scale"
    scale = scale_layer.get_output(0)
    # assert trt.__version__ > "8.0", "Explicit quantize op is only supported in "
    # "TensorRT 8.0 or above, current TensorRT version:" + trt.__version__
    layer = network.add_quantize(input=input_val, scale=scale)
    layer.axis = q_per_channel_axis
    # set_layer_name(layer, target, f"{input_val.name}_per_channel_quant")
    set_layer_name(layer, target, f"{name_prefix}_per_channel_quant")
    return layer.get_output(0)


@tensorrt_converter(acc_ops.dequantize)
def acc_ops_dequantize(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    input_val_tensor_meta = kwargs["_itensor_to_tensor_meta"][input_val]  # type: ignore[index]

    name_prefix = name

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part " "of the TensorRT region!"
        )

    qparams = input_val_tensor_meta.qparams  # type: ignore[misc]
    qscheme = qparams["qscheme"]
    if qscheme == torch.per_tensor_affine:
        q_scale = qparams["scale"]
        q_zero_point = qparams["zero_point"]
        q_axis = 0
        scale_shape = (1,)
        if q_zero_point != 0:
            raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")
    elif qscheme == torch.per_channel_affine:
        q_scale = qparams["scale"]
        q_zero_point = qparams["zero_point"]
        q_axis = qparams["axis"]
        assert isinstance(
            q_scale, immutable_list
        ), "expected q_scale to be immutable_list got {}".format(type(q_scale))
        scale_shape = (len(q_scale),)
        if any(x != 0 for x in q_zero_point):
            raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")
    else:
        raise RuntimeError("Unsupported qscheme in dequantize: {qscheme}")

    dtype = input_val_tensor_meta.dtype  # type: ignore[misc]

    if dtype not in (torch.quint8, torch.qint8, torch.qint32):
        raise RuntimeError(
            "Only support (torch.quint8, torch.qint8, torch.qint32) "
            f"quantized type in dequantize, get {dtype}."
        )

    scale_layer = network.add_constant(
        scale_shape, trt.Weights(np.ascontiguousarray(q_scale, dtype=np.float32))
    )
    # scale_layer.name = input_val.name + ".dequant.scale"
    scale_layer.name = name_prefix + ".dequant.scale"
    scale = scale_layer.get_output(0)
    # assert trt.__version__ > "8.0", "Explicit dequantize op is only supported in "
    # "TensorRT 8.0 or above, current TensorRT version:" + trt.__version__
    layer = network.add_dequantize(input=input_val, scale=scale)
    # set_layer_name(layer, target, f"{input_val.name}_.dequant")
    set_layer_name(layer, target, f"{name_prefix}_.dequant")
    layer.axis = q_axis
    return layer.get_output(0)


@tensorrt_converter("dequantize")
def acc_ops_dequantize(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    input_val_tensor_meta = kwargs["_itensor_to_tensor_meta"][input_val]  # type: ignore[index]

    name_prefix = name

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part " "of the TensorRT region!"
        )

    qparams = input_val_tensor_meta.qparams  # type: ignore[misc]

    q_scale = kwargs["scale"]
    q_zero_point = kwargs["zero_point"]
    q_axis = 0
    scale_shape = (1,)
    if q_zero_point != 0:
        raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")

    dtype = kwargs["dtype"]

    # qscheme = qparams["qscheme"]
    # if qscheme == torch.per_tensor_affine:
    #     q_scale = qparams["scale"]
    #     q_zero_point = qparams["zero_point"]
    #     q_axis = 0
    #     scale_shape = (1, )
    #     if q_zero_point != 0:
    #         raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")
    # elif qscheme == torch.per_channel_affine:
    #     q_scale = qparams["scale"]
    #     q_zero_point = qparams["zero_point"]
    #     q_axis = qparams["axis"]
    #     assert isinstance(q_scale, immutable_list), "expected q_scale to be immutable_list got {}".format(type(q_scale))
    #     scale_shape = (len(q_scale), )
    #     if any(x != 0 for x in q_zero_point):
    #         raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")
    # else:
    #     raise RuntimeError("Unsupported qscheme in dequantize: {qscheme}")

    # dtype = input_val_tensor_meta.dtype  # type: ignore[misc]

    if dtype not in (torch.quint8, torch.qint8, torch.qint32):
        raise RuntimeError(
            "Only support (torch.quint8, torch.qint8, torch.qint32) "
            f"quantized type in dequantize, get {dtype}."
        )

    scale_layer = network.add_constant(
        scale_shape, trt.Weights(np.ascontiguousarray(q_scale, dtype=np.float32))
    )
    # scale_layer.name = input_val.name + ".dequant.scale"
    scale_layer.name = name_prefix + ".dequant.scale"
    scale = scale_layer.get_output(0)
    # assert trt.__version__ > "8.0", "Explicit dequantize op is only supported in "
    # "TensorRT 8.0 or above, current TensorRT version:" + trt.__version__
    layer = network.add_dequantize(input=input_val, scale=scale)
    # set_layer_name(layer, target, f"{input_val.name}_.dequant")
    set_layer_name(layer, target, f"{name_prefix}_.dequant")
    layer.axis = q_axis
    return layer.get_output(0)


def fake_quantize_per_tensor_affine(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    q_scale = args[1]
    q_zero_point = args[2] if len(args) > 2 else 0

    if os.environ.get("USE_IMPlICT_QUANT", "FLASE").upper() == "TRUE":
        x = args[0]
        if not isinstance(x, TRTTensor):
            return x
        q_scale = args[1]
        range_max = q_scale * 128
        x.set_dynamic_range(-range_max, range_max)
        return x

    name_prefix = name
    input_val = get_trt_tensor(network, args[0], name)

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part of the TensorRT region!"
        )

    if q_zero_point != 0:
        raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")

    scale_layer = network.add_constant(
        (1,), trt.Weights(np.ascontiguousarray([float(q_scale)], dtype=np.float32))
    )

    scale_layer.name = f"{name_prefix}.scale"
    scale = scale_layer.get_output(0)

    layer = network.add_quantize(input=input_val, scale=scale)
    layer.axis = 0
    set_layer_name(layer, target, f"{name_prefix}.quant")
    input_val_q = layer.get_output(0)

    # add dequantize
    layer = network.add_dequantize(input=input_val_q, scale=scale)
    set_layer_name(layer, target, f"{name_prefix}.dequant")
    layer.axis = 0
    return layer.get_output(0)


@tensorrt_converter("fake_quantize_per_tensor_affine")
def acc_ops_fake_quantize_per_tensor_affine(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return fake_quantize_per_tensor_affine(network, target, args, kwargs, name)


@tensorrt_converter("fake_quant")
def acc_ops_fake_quant_forward(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    return fake_quantize_per_tensor_affine(network, target, args, kwargs, name)


@tensorrt_converter("fake_quantize_per_channel_affine")
def acc_ops_fake_quantize_per_channel_affine(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = get_trt_tensor(network, args[0], f"{name}_input")
    q_per_channel_scales = args[1]
    q_zero_point = args[2]
    q_per_channel_axis = args[3]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{name} received input {input_val} that is not part of the TensorRT region!"
        )

    if any([x != 0 for x in q_zero_point]):
        raise RuntimeError(f"Only support zero_point == 0, get {q_zero_point}")

    scale_layer = network.add_constant(
        q_per_channel_scales.shape,
        trt.Weights(np.ascontiguousarray(q_per_channel_scales.cpu(), dtype=np.float32)),
    )
    scale_layer.name = input_val.name + ".per_channel_quant.scale"
    scale = scale_layer.get_output(0)
    # assert trt.__version__ > "8.0", "Explicit quantize op is only supported in "
    # "TensorRT 8.0 or above, current TensorRT version:" + trt.__version__
    layer = network.add_quantize(input=input_val, scale=scale)
    layer.axis = q_per_channel_axis
    set_layer_name(layer, target, f"{input_val.name}_per_channel_quant")
    input_val_q = layer.get_output(0)

    # add dequantize
    layer = network.add_dequantize(input=input_val_q, scale=scale)
    set_layer_name(layer, target, f"{input_val.name}_.dequant")
    layer.axis = q_per_channel_axis
    return layer.get_output(0)


@tensorrt_converter(acc_ops.gelu, no_implicit_batch_dim=True)
def acc_ops_gelu(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"GELU received input {input_val} that is not part " "of the TensorRT region!"
        )
    if network.has_implicit_batch_dimension:
        raise RuntimeError("GeLU converter currently doesn't support implicit batch dimension")

    plugin_name = "CustomGeluPluginDynamic"
    # type_id 0 for float32, 1 for  float16
    type_id = trt.PluginField("type_id", np.array(0, dtype=np.int32), trt.PluginFieldType.INT32)
    field_collection = TRTPluginFieldCollection([type_id])
    plugin_version = "1"

    plugin = get_trt_plugin(plugin_name, field_collection, plugin_version)

    layer = network.add_plugin_v2([input_val], plugin)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.chunk)
def acc_ops_chunk(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    chunks = cast(int, kwargs["chunks"])
    dim = cast(int, kwargs["dim"])
    input_dim_size = len(input_val.shape)  # type: ignore[union-attr]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"chunk received input {input_val} that is not part " "of the TensorRT region!"
        )

    dynamic_shape = has_dynamic_shape(input_val.shape)
    if network.has_implicit_batch_dimension:
        input_dim_size += 1
        dim = get_positive_dim(dim, input_dim_size)
        assert dim != 0, "Can't chunk on batch dim when it's implicit!"
        dim -= 1
    else:
        if dynamic_shape:
            assert input_val.shape[dim] != -1, "Can't chunk on dynamic shape dimension!"
        dim = get_positive_dim(dim, input_dim_size)

    if chunks > input_val.shape[dim]:
        warnings.warn(
            f"Asked for {chunks} chunks along dimention "
            f"{dim} on tensor with size {input_val.shape}, chunks "
            f"will default to {input_val.shape[dim]}",
            RuntimeWarning,
        )
        chunks = input_val.shape[dim]

    start = [0] * len(input_val.shape)
    stride = [1] * len(start)
    offset = 0
    split_size = (input_val.shape[dim] + chunks - 1) // chunks

    max_offset = input_val.shape[dim]
    # add slice layers
    output = []
    for i in range(chunks):
        shape = list(input_val.shape)
        shape[dim] = min(split_size, max_offset - offset)
        if dynamic_shape:
            shape = get_shape_with_dynamic_shape(network, shape, input_val, target, f"{name}_{i}")
        start[dim] = offset
        layer = network.add_slice(
            input_val, start=start, shape=[] if dynamic_shape else shape, stride=stride
        )
        if dynamic_shape:
            layer.set_input(2, shape)
        offset += split_size
        set_layer_name(layer, target, f"{name}_{i}")
        output.append(layer.get_output(0))
    return output


@tensorrt_converter(acc_ops.cumsum, no_implicit_batch_dim=True)
def acc_ops_cumsum(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    dim = cast(int, kwargs["dim"])
    input_shape = input_val.shape  # type: ignore[union-attr]
    input_dim_size = len(input_val.shape)  # type: ignore[union-attr]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"cumsum received input {input_val} that is not part " "of the TensorRT region!"
        )
    if network.has_implicit_batch_dimension:
        raise RuntimeError("cumsum converter currently doesn't support implicit batch dimension")
    dim = get_positive_dim(dim, input_dim_size)
    loop = network.add_loop()
    trip_limit = None
    if input_shape[dim] > 0:
        axis = torch.tensor(input_shape[dim], dtype=torch.int32)
        trip_limit_layer = network.add_constant(axis.shape, to_numpy(axis))
    else:
        input_shape = network.add_shape(input_val).get_output(0)
        dim_value = torch.tensor(dim, dtype=torch.int32)
        axis = network.add_constant(dim_value.shape, to_numpy(dim_value)).get_output(0)
        trip_limit_layer = network.add_gather(input_shape, axis, 0)
    set_layer_name(trip_limit_layer, target, f"{name}_trip_limit")
    trip_limit = trip_limit_layer.get_output(0)

    loop.add_trip_limit(trip_limit, trt.TripLimit(0))
    iterator = loop.add_iterator(input_val, dim, False)
    data = iterator.get_output(0)
    new_dims = tuple(data.shape)
    zero_tensor = torch.zeros(new_dims, dtype=trt_dtype_to_torch_dtype(input_val.dtype))
    zero_tensor = network.add_constant(zero_tensor.shape, to_numpy(zero_tensor)).get_output(0)

    running_sum = loop.add_recurrence(zero_tensor)
    set_layer_name(running_sum, target, f"{name}_running_sum_1")
    running_sum_tensor = running_sum.get_output(0)

    current_sum = add_binary_elementwise_layer(
        network,
        data,
        running_sum_tensor,
        trt.ElementWiseOperation.SUM,
        target,
        f"{name}_sum_1",
    )
    running_sum.set_input(1, current_sum)

    running_sum = loop.add_recurrence(zero_tensor)
    set_layer_name(running_sum, target, f"{name}_running_sum_2")
    running_sum_tensor = running_sum.get_output(0)

    current_sum = add_binary_elementwise_layer(
        network,
        data,
        running_sum_tensor,
        trt.ElementWiseOperation.SUM,
        target,
        f"{name}_sum_2",
    )
    running_sum.set_input(1, current_sum)

    loop_output = loop.add_loop_output(current_sum, trt.LoopOutput.CONCATENATE, dim)
    set_layer_name(loop_output, target, f"{name}_loop_output")
    loop_output.set_input(1, trip_limit)
    return loop_output.get_output(0)


@tensorrt_converter(acc_ops.hardtanh)
def acc_ops_hardtanh(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"hardtanh received input {input_val} that is not part " "of the TensorRT region!"
        )

    return add_activation_layer(
        network,
        input_val,
        trt.ActivationType.CLIP,
        target,
        name,
        alpha=kwargs["min_val"],
        beta=kwargs["max_val"],
    )


@tensorrt_converter(acc_ops.interpolate)
def acc_ops_interpolate(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    size = kwargs["size"]
    scale_factor = kwargs["scale_factor"]
    mode = kwargs["mode"]
    align_corners = kwargs["align_corners"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"interpolate received input {input_val} that is not part " "of the TensorRT region!"
        )

    dim = input_val.shape
    ranks = len(input_val.shape)
    if network.has_implicit_batch_dimension:
        assert ranks >= 2 and ranks <= 4, "Interpolate expects inputs are 3D,4D,5D in shape"
        ranks = ranks - 1
    else:
        assert ranks >= 3 and ranks <= 5, "Interpolate expects inputs are 3D,4D,5D in shape"
        ranks = ranks - 2

    layer = network.add_resize(input_val)
    if network.has_implicit_batch_dimension:
        if size != None:
            if not isinstance(size, Sequence):
                layer.shape = [dim[0]] + [size] * ranks
            else:
                layer.shape = [dim[0]] + list(size)
        if scale_factor != None:
            if not isinstance(scale_factor, Sequence):
                layer.scales = [1] + [scale_factor] * ranks
            else:
                layer.scales = [1] + list(scale_factor)
    else:
        if size != None:
            if not isinstance(size, Sequence):
                layer.shape = [dim[0], dim[1]] + [size] * ranks
            else:
                layer.shape = [dim[0], dim[1]] + list(size)
        if scale_factor != None:
            if not isinstance(scale_factor, Sequence):
                layer.scales = [1, 1] + [scale_factor] * ranks
            else:
                layer.scales = [1, 1] + list(scale_factor)

    if mode.lower() in ["linear", "bilinear", "trilinear"]:
        layer.resize_mode = trt.ResizeMode.LINEAR
    else:
        layer.resize_mode = trt.ResizeMode.NEAREST

    if align_corners:
        layer.coordinate_transformation = trt.ResizeCoordinateTransformation.ALIGN_CORNERS

    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.new_ones)
def acc_ops_new_ones(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    size_val = kwargs["size"]
    dtype_val = kwargs.get("dtype")
    if dtype_val is None:
        dtype_val = input_val.dtype
        dtype_val = torch_dtype_from_trt(dtype_val)

    device_val = kwargs.get("device")
    assert device_val == "cuda" or device_val == None, f"device is not `cuda` but {device_val}"

    weight = torch.ones(size_val, dtype=dtype_val)
    return get_trt_tensor(network, weight, f"{name}_weight")


@tensorrt_converter(acc_ops.new_empty)
def acc_ops_new_empty(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    size_val = kwargs["size"]
    dtype_val = kwargs.get("dtype")
    if dtype_val is None:
        dtype_val = input_val.dtype
        dtype_val = torch_dtype_from_trt(dtype_val)

    device_val = kwargs.get("device")
    assert device_val == "cuda" or device_val == None, f"device is not `cuda` but {device_val}"

    weight = torch.zeros(size_val, dtype=dtype_val)
    return get_trt_tensor(network, weight, f"{name}_weight")


@tensorrt_converter(acc_ops.einsum)
def acc_ops_einsum(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = list(kwargs["operands"])
    equation = kwargs["equation"]
    assert type(equation) is str, "equation type is not str"
    const_flag = False
    for i, input_source in enumerate(input_val):
        if type(input_source) == torch.Tensor:
            # const change to TRTensor always output with dtype FLOAT even though stored memory is other type
            # so we cast to float first. And we need other inputs to be the same float type
            input_source = input_source.to(torch.float)
            const_flag = True
        input_val[i] = get_trt_tensor(network, input_source, name + f"_input_source{i}")

    if const_flag:
        for i, input_source in enumerate(input_val):
            if input_source.dtype != trt.float32:
                input_val[i] = type_cast(
                    network, target, f"{name}_input_cast{i}", input_source, trt.float32
                )
    einsum_layer = network.add_einsum(inputs=input_val, equation=equation)
    return einsum_layer.get_output(0)


@tensorrt_converter(acc_ops.as_strided)
def acc_ops_as_strided(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    size = kwargs["size"]
    stride = kwargs["stride"]
    offset = kwargs.get("storage_offset")
    if offset == None:
        offset = 0

    # convert to 1d vector
    new_kwargs = {}
    new_kwargs["input"] = kwargs["input"]
    new_kwargs["start_dim"] = 0
    new_kwargs["end_dim"] = -1
    flatten_output = acc_ops_flatten(network, target, [], new_kwargs, name + "_flatten")
    # use gather to collect output from 1d flatten_output
    rank = len(size)
    assert len(size) == len(stride), "size and stride shapes are not the same"

    def nested(rank, size, stride, current, dim, indices):
        if dim == rank:
            indices.append(current)
            return
        for i in range(size[dim]):
            current = current + stride[dim] * i
            nested(rank, size, stride, current, dim + 1, indices)
            current = current - stride[dim] * i

    indices = []
    nested(rank, size, stride, 0, 0, indices)
    indices = torch.tensor(indices, dtype=torch.int)
    indices = indices + offset
    indices_tensor = get_trt_tensor(network, indices, name + "_indices_tensor")
    gather_layer = network.add_gather(flatten_output, indices_tensor, axis=0)
    # resize the output to match size
    shuffle_layer = network.add_shuffle(gather_layer.get_output(0))
    set_layer_name(shuffle_layer, target, name + "_shuffle")
    shuffle_layer.reshape_dims = tuple(size)

    return shuffle_layer.get_output(0)


def add_activation_layer(
    network: TRTNetwork,
    input_val: TRTTensor,
    operation_type: trt.ActivationType,
    target: Target,
    name: str,
    alpha: Optional[Any] = None,
    beta: Optional[Any] = None,
) -> TRTTensor:
    """
    Add a TensorRT Activation layer to `network`.

    Args:
        network (TRTNetwork): TensorRT network object.
        input_val (TRTTensor): Input to the activation op.
            Must be a TensorRT tensor.
        op_type (trt.ElementWiseOperation): Type of the TensorRT activation
            operation.
        target (Target): Target of fx node.
        name (str): The name we want to assign to the created TensorRT layer.
        alpha (Optional[Any]): If not None, we will use it to set the alpha
            attribute of the created TensorRT activation layer.
        beta (Optional[Any]): If not None, we will use it to set the beta
            attribute of the created TensorRT activation layer.

    Returns:
        The output of TensorRT Activation layer.
    """
    if not isinstance(input_val, TRTTensor):
        raise RuntimeError(
            f"{operation_type} received input {input_val} that is not part "
            "of the TensorRT region!"
        )
    layer = network.add_activation(input_val, operation_type)
    if alpha is not None:
        layer.alpha = alpha
    if beta is not None:
        layer.beta = beta
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.local_response_norm)
def acc_ops_local_response_norm(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    size = kwargs["size"]
    alpha = kwargs["alpha"]
    beta = kwargs["beta"]
    k = kwargs["k"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError("input is not TRTTensor")

    # add_lrn(self, input: tensorrt.tensorrt.ITensor, window: int, alpha: float, beta: float, k: float)
    layer = network.add_lrn(input_val, size, alpha, beta, k)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.flip)
def acc_ops_flip(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    dims = kwargs["dims"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError("input is not TRTTensor")

    start = [0] * len(input_val.shape)
    start[dims] = input_val.shape[dims] - 1
    stride = [1] * len(input_val.shape)
    stride[dims] = -1

    dynamic_shape = has_dynamic_shape(input_val.shape)
    shape = input_val.shape
    if dynamic_shape:
        shape = []
        output_shape = get_shape_with_dynamic_shape(
            network, input_val.shape, input_val, target, name
        )
    layer = network.add_slice(input_val, start, shape, stride)
    set_layer_name(layer, target, name)
    if dynamic_shape:
        layer.set_input(2, output_shape)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.long)
def acc_ops_long(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]

    if not isinstance(input_val, TRTTensor):
        raise RuntimeError("input is not TRTTensor")
    return type_cast(network, target, name, input_val, trt.int32)


@tensorrt_converter(acc_ops.index_put)
def acc_ops_index_put(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    indices = kwargs["indices"]
    values = kwargs["values"]
    accumulate = kwargs["accumulate"]

    assert isinstance(
        values, TRTTensor
    ), "values must be come from prev layer output, so must be TRTTensor"
    assert isinstance(indices, (tuple, list)) and len(indices) == 1
    assert isinstance(
        indices[0], TRTTensor
    ), "indices element must be come from prev layer output, so must be TRTTensor"

    indice = indices[0]
    indice_reshape_layer = network.add_shuffle(indice)
    indice_dest_shape = list(indice.shape)
    indice_dest_shape.append(1)
    indice_reshape_layer.reshape_dims = trt.Dims(indice_dest_shape)
    indice_output = indice_reshape_layer.get_output(0)

    if isinstance(input_val, TRTTensor):
        input = input_val
    else:
        # NOTE if not TRTTensor type, it must be a constant
        layer = network.add_constant(tuple(input_val.shape), trt.Weights(to_numpy(input_val)))
        set_layer_name(layer, target, f"{name}_constant")
        constant = layer.get_output(0)
        input = constant

    if accumulate:
        # use scatter plugin
        field_collection = trt.PluginFieldCollection()
        name = name.replace("index_put", "ScatterNDPlugin")
        plugin = get_trt_plugin("ScatterNDPlugin", field_collection, "1", "")
        inputs = [input, indice_output, values]
        layer = network.add_plugin_v2(inputs, plugin)
        set_layer_name(layer, target, name)
        return layer.get_output(0)
    else:
        layer = network.add_scatter(input, indice_output, values, trt.ScatterMode.ND)
        set_layer_name(layer, target, name)
        return layer.get_output(0)


@tensorrt_converter(acc_ops.index_select)
def acc_ops_index_select(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    dim = kwargs["dim"]
    index = kwargs["index"]

    if not isinstance(input_val, TRTTensor):
        input_val = get_trt_tensor(network, input_val, f"{name}_input")

    if not isinstance(index, TRTTensor):
        index = get_trt_tensor(network, index, f"{name}_index")

    layer = network.add_gather(input_val, index, dim)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter(acc_ops.gather)
def acc_ops_gather(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    input_val = kwargs["input"]
    dim = kwargs["dim"]
    index = kwargs["index"]
    if not isinstance(input_val, TRTTensor):
        input_val = get_trt_tensor(network, input_val, f"{name}_input")

    if not isinstance(index, TRTTensor):
        index = get_trt_tensor(network, index, f"{name}_index")

    layer = network.add_gather_v2(input_val, index, trt.GatherMode.ELEMENT)
    layer.axis = dim
    set_layer_name(layer, target, name)

    return layer.get_output(0)


@tensorrt_converter("lanegcn_att")
def acc_ops_lanegcn_att(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    inputs = list(args[:4])
    layer_name_prefix = name.replace("lanegcn_att", "LanegcnAtt")
    inputs.append(
        get_trt_tensor(
            network, np.array([args[4]], dtype=np.float32), f"{layer_name_prefix}_dist_th"
        )
    )
    for key, val in kwargs.items():
        if not key.startswith("_"):
            if isinstance(val, torch.Tensor):
                inputs.append(get_trt_tensor(network, val, f"{layer_name_prefix}_{key}"))
            elif isinstance(val, TRTTensor):
                inputs.append(val)
            else:
                raise Exception("unsupported datatype")

    field_collection = trt.PluginFieldCollection()
    plugin = get_trt_plugin("LanegcnAtt", field_collection, "1", "")
    layer = network.add_plugin_v2(inputs, plugin)
    set_layer_name(layer, target, name)
    return layer.get_output(0)


@tensorrt_converter("sparsity_nonzero")
def acc_ops_sparsity_nonzero(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    inputs = list(args[:2])
    layer_name_prefix = name.replace("sparsity_nonzero", "SparsityNonzero")
    inputs.append(
        get_trt_tensor(
            network, np.array([args[2]], dtype=np.float32), f"{layer_name_prefix}_dist_th"
        )
    )

    field_collection = trt.PluginFieldCollection()
    plugin = get_trt_plugin("SparsityNonzero", field_collection, "1", "")
    layer = network.add_plugin_v2(inputs, plugin)
    set_layer_name(layer, target, name)
    return layer.get_output(0), layer.get_output(1), layer.get_output(2)


def get_arg(key, args, kwargs, idx, default=None):
    val = kwargs.get(key, None)
    if val is None:
        if idx < len(args):
            val = args[idx]
        else:
            val = default
    return val


@tensorrt_converter("DCNv2_op")
def acc_ops_lanegcn_att(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    if isinstance(kwargs["weight"], torch.Tensor):
        weight = get_trt_tensor(network, kwargs["weight"], f"{name}weight")
    if isinstance(kwargs["bias"], torch.Tensor):
        bias = get_trt_tensor(network, kwargs["bias"], f"{name}bias")
    inputs = [kwargs["input"], kwargs["offset"], kwargs["mask"], weight, bias]
    mPluginAttributes = list()
    mPluginAttributes.append(
        trt.PluginField(
            "in_channel", np.array(kwargs["in_channel"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "out_channel",
            np.array(kwargs["out_channel"], dtype=np.int32),
            trt.PluginFieldType.INT32,
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "kernel_h", np.array(kwargs["kernel_h"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "kernel_w", np.array(kwargs["kernel_w"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "stride", np.array(kwargs["stride"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "padding", np.array(kwargs["padding"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "dilation", np.array(kwargs["dilation"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "deform_groups",
            np.array(kwargs["deform_groups"], dtype=np.int32),
            trt.PluginFieldType.INT32,
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "groups", np.array(kwargs["groups"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )

    field_collection = trt.PluginFieldCollection(mPluginAttributes)
    plugin = get_trt_plugin("DCNv2", field_collection, "1", "")
    layer = network.add_plugin_v2(inputs, plugin)
    return layer.get_output(0)


@tensorrt_converter("dconv_v2")
def acc_ops_dconv_v2(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    if isinstance(kwargs["weight"], torch.Tensor):
        weight = get_trt_tensor(network, kwargs["weight"], f"{name}weight")
    else:
        weight = None
    if isinstance(kwargs["bias"], torch.Tensor):
        bias = get_trt_tensor(network, kwargs["bias"], f"{name}bias")
    else:
        bias = None
    inputs = [kwargs["input"], kwargs["offset"], kwargs["mask"], weight, bias]

    mPluginAttributes = list()
    mPluginAttributes.append(
        trt.PluginField(
            "stride", np.array(kwargs["stride"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "padding", np.array(kwargs["padding"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "dilation", np.array(kwargs["dilation"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "deform_groups",
            np.array(kwargs["deform_groups"], dtype=np.int32),
            trt.PluginFieldType.INT32,
        )
    )
    mPluginAttributes.append(
        trt.PluginField(
            "groups", np.array(kwargs["groups"], dtype=np.int32), trt.PluginFieldType.INT32
        )
    )

    field_collection = trt.PluginFieldCollection(mPluginAttributes)
    plugin = get_trt_plugin("DConv_V2", field_collection, "1", "")
    layer = network.add_plugin_v2(inputs, plugin)
    return layer.get_output(0)


@tensorrt_converter("insert_checkpoint")
def acc_ops_insert_checkpoint(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    assert len(args) >= 1

    input_val = args[0]
    desc = get_arg("desc", args, kwargs, 1, "linfer checkpoint")
    vis_meta = get_arg("vis_meta", args, kwargs, 2, True)
    vis_data_len = get_arg("vis_data_len", args, kwargs, 3, 32)
    atol = get_arg("atol", args, kwargs, 4, 1e-4)
    rtol = get_arg("rtol", args, kwargs, 5, 1e-4)
    replay = get_arg("replay", args, kwargs, 6, False)

    if isinstance(input_val, torch.Tensor):
        input_val = get_trt_tensor(network, input_val, f"{name}_actual_val")

    desc_array_int8 = np.array([ord(c) for c in desc], dtype=np.int8)
    desc_field = trt.PluginField("desc", desc_array_int8, trt.PluginFieldType.INT8)
    vis_meta_field = trt.PluginField(
        "vis_meta", np.array([vis_meta], dtype=np.int8), trt.PluginFieldType.INT8
    )
    vis_data_len_field = trt.PluginField(
        "vis_data_len", np.array([vis_data_len], dtype=np.int32), trt.PluginFieldType.INT32
    )
    atol_field = trt.PluginField(
        "atol", np.array([atol], dtype=np.float32), trt.PluginFieldType.FLOAT32
    )
    rtol_field = trt.PluginField(
        "rtol", np.array([rtol], dtype=np.float32), trt.PluginFieldType.FLOAT32
    )
    replay_field = trt.PluginField(
        "replay", np.array([replay], dtype=np.int8), trt.PluginFieldType.INT8
    )
    field_collection = trt.PluginFieldCollection(
        [desc_field, vis_meta_field, vis_data_len_field, atol_field, rtol_field, replay_field]
    )

    expect_val = get_trt_tensor(network, kwargs["_linfer.torch_output"], f"{name}_expect_val")
    plugin = get_trt_plugin("LinferCheckpoint", field_collection, "1", "")
    inputs = [input_val, expect_val]
    debug_layer = network.add_plugin_v2(inputs, plugin)
    return debug_layer.get_output(0)


@tensorrt_converter("no_op")
def acc_ops_no_op(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    input_val = args[0]
    field_collection = trt.PluginFieldCollection([])
    plugin = get_trt_plugin("LinferNoOp", field_collection, "1", "")
    inputs = [input_val]
    no_op_layer = network.add_plugin_v2(inputs, plugin)
    return no_op_layer.get_output(0)


@tensorrt_converter("observing_point")
def acc_ops_observing_point(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    assert len(args) >= 1

    input_val = args[0]
    replay = get_arg("replay", args, kwargs, 1)
    scale = get_arg("scale", args, kwargs, 2)

    if isinstance(input_val, torch.Tensor):
        input_val = get_trt_tensor(network, input_val, f"{name}_actual_val")

    filepath_torch_data = kwargs["_linfer.filepath_torch_data"]
    filepath_trt_data = kwargs["_linfer.filepath_trt_data"]

    plugin_fields = list()
    fp_torch_np = np.array([ord(c) for c in filepath_torch_data], dtype=np.int8)
    plugin_fields.append(
        trt.PluginField("filepath_torch_data", fp_torch_np, trt.PluginFieldType.INT8)
    )
    fp_trt_np = np.array([ord(c) for c in filepath_trt_data], dtype=np.int8)
    plugin_fields.append(trt.PluginField("filepath_trt_data", fp_trt_np, trt.PluginFieldType.INT8))
    plugin_fields.append(
        trt.PluginField("replay", np.array([replay], dtype=np.int8), trt.PluginFieldType.INT8)
    )
    plugin_fields.append(
        trt.PluginField("scale", np.array([scale], dtype=np.float32), trt.PluginFieldType.FLOAT32)
    )

    plugin = get_trt_plugin(
        "LinferObservingPoint", trt.PluginFieldCollection(plugin_fields), "1", ""
    )
    inputs = [input_val]
    debug_layer = network.add_plugin_v2(inputs, plugin)
    set_layer_name(debug_layer, target, name)
    return debug_layer.get_output(0)


@tensorrt_converter("multiclass_nms_v2")
def acc_ops_multiclass_nms_v2(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    bboxes = args[0]
    scores = args[1]

    num_classes = np.array([scores.shape[-1]], dtype=np.int32)
    max_output_boxes_per_class = np.array([args[2]], dtype=np.int32)
    iou_threshold = np.array([args[3]], dtype=np.float32)
    score_threshold = np.array([args[4]], dtype=np.float32)
    pre_top_k = np.array([args[5]], dtype=np.int32)
    keep_top_k = np.array([args[6]], dtype=np.int32)
    background_label_id = np.array([args[7]], dtype=np.int32)

    shareLocation_filed = trt.PluginField(
        "shareLocation", np.array([0], dtype=np.int32), trt.PluginFieldType.INT32
    )
    background_label_id_filed = trt.PluginField(
        "backgroundLabelId", background_label_id, trt.PluginFieldType.INT32
    )
    num_classes_field = trt.PluginField("numClasses", num_classes, trt.PluginFieldType.INT32)
    topk_field = trt.PluginField("topK", pre_top_k, trt.PluginFieldType.INT32)
    keep_topk_field = trt.PluginField("keepTopK", keep_top_k, trt.PluginFieldType.INT32)
    score_threshold_field = trt.PluginField(
        "scoreThreshold", score_threshold, trt.PluginFieldType.FLOAT32
    )
    iou_threshold_field = trt.PluginField(
        "iouThreshold", iou_threshold, trt.PluginFieldType.FLOAT32
    )
    is_normalized_field = trt.PluginField(
        "isNormalized", np.array([0], dtype=np.int32), trt.PluginFieldType.INT32
    )
    clip_boxes_field = trt.PluginField(
        "clipBoxes", np.array([0], dtype=np.int32), trt.PluginFieldType.INT32
    )
    scoreBits_field = trt.PluginField(
        "scoreBits", np.array([16], dtype=np.int32), trt.PluginFieldType.INT32
    )
    caffeSemantics_field = trt.PluginField(
        "caffeSemantics", np.array([0], dtype=np.int32), trt.PluginFieldType.INT32
    )
    field_collection = trt.PluginFieldCollection(
        [
            shareLocation_filed,
            background_label_id_filed,
            num_classes_field,
            topk_field,
            keep_topk_field,
            score_threshold_field,
            iou_threshold_field,
            is_normalized_field,
            clip_boxes_field,
            scoreBits_field,
            caffeSemantics_field,
        ]
    )

    plugin = get_trt_plugin("TRTBatchedNMSv2", field_collection, "1", "")
    inputs = [bboxes, scores]
    nms_layer = network.add_plugin_v2(inputs, plugin)
    return [nms_layer.get_output(idx) for idx in range(nms_layer.num_outputs)]


@tensorrt_converter("multiclass_nms_supported_natively")
def acc_ops_multiclass_nms_supported_natively(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    bboxes = args[0]
    scores = args[1]
    max_output_boxes_per_class = args[2]
    if isinstance(max_output_boxes_per_class, torch.Tensor):
        max_output_boxes_per_class = get_trt_tensor(
            network, max_output_boxes_per_class, f"{name}_max_output_boxes_per_class"
        )
    IoU_threshold = args[3]
    if isinstance(IoU_threshold, torch.Tensor):
        IoU_threshold = get_trt_tensor(network, IoU_threshold, f"{name}_IoU_threshold")
    score_threshold = args[4]
    if isinstance(score_threshold, torch.Tensor):
        score_threshold = get_trt_tensor(network, score_threshold, f"{name}_score_threshold")
    if len(args) == 6 and np.array([args[5]], dtype=np.int32) == 1:
        bounding_box_format = trt.BoundingBoxFormat.CENTER_SIZES
    else:
        bounding_box_format = trt.BoundingBoxFormat.CORNER_PAIRS

    layer = network.add_nms(bboxes, scores, max_output_boxes_per_class)
    layer.set_input(3, IoU_threshold)
    layer.set_input(4, score_threshold)
    layer.bounding_box_format = bounding_box_format

    set_layer_name(layer, target, name)
    return [layer.get_output(idx) for idx in range(layer.num_outputs)]
    # return layer.get_output(0)


@tensorrt_converter("multiclass_nms")
def acc_ops_multiclass_nms(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    bboxes = args[0]
    scores = args[1]

    num_classes = np.array([scores.shape[-1]], dtype=np.int32)
    max_output_boxes_per_class = np.array([args[2]], dtype=np.int32)
    iou_threshold = np.array([args[3]], dtype=np.float32)
    score_threshold = np.array([args[4]], dtype=np.float32)
    pre_top_k = np.array([args[5]], dtype=np.int32)
    keep_top_k = np.array([args[6]], dtype=np.int32)
    background_label_id = np.array([args[7]], dtype=np.int32)

    background_label_id_filed = trt.PluginField(
        "background_label_id", background_label_id, trt.PluginFieldType.INT32
    )
    num_classes_field = trt.PluginField("num_classes", num_classes, trt.PluginFieldType.INT32)
    topk_field = trt.PluginField("topk", pre_top_k, trt.PluginFieldType.INT32)
    keep_topk_field = trt.PluginField("keep_topk", keep_top_k, trt.PluginFieldType.INT32)
    score_threshold_field = trt.PluginField(
        "score_threshold", score_threshold, trt.PluginFieldType.FLOAT32
    )
    iou_threshold_field = trt.PluginField(
        "iou_threshold", iou_threshold, trt.PluginFieldType.FLOAT32
    )
    is_normalized_field = trt.PluginField(
        "is_normalized", np.array([0], dtype=np.int32), trt.PluginFieldType.INT32
    )
    clip_boxes_field = trt.PluginField(
        "clip_boxes", np.array([0], dtype=np.int32), trt.PluginFieldType.INT32
    )
    field_collection = trt.PluginFieldCollection(
        [
            background_label_id_filed,
            num_classes_field,
            topk_field,
            keep_topk_field,
            score_threshold_field,
            iou_threshold_field,
            is_normalized_field,
            clip_boxes_field,
        ]
    )

    plugin = get_trt_plugin("BatchedNMS", field_collection, "1", "")
    inputs = [bboxes, scores]
    nms_layer = network.add_plugin_v2(inputs, plugin)
    return [nms_layer.get_output(idx) for idx in range(nms_layer.num_outputs)]


@tensorrt_converter("batch_bev_nms")
def acc_ops_batch_bev_nms(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    bboxes = args[0]
    scores = args[1]
    num_classes = np.array(kwargs["num_classes"], dtype=np.int32)
    pre_topk = np.array([kwargs["pre_topk"]], dtype=np.int32)
    keep_top_k = np.array([kwargs["after_topk"]], dtype=np.int32)
    iou_threshold = np.array([kwargs["iou_threshold"]], dtype=np.float32)
    score_threshold = np.array([kwargs["score_threshold"]], dtype=np.float32)
    background_label_id = np.array([kwargs["background_label_id"]], dtype=np.int32)
    is_normalized = np.array([kwargs["is_normalized"]], dtype=np.int32)
    clip_boxes = np.array([kwargs["clip_boxes"]], dtype=np.int32)
    return_index = np.array([kwargs["return_index"]], dtype=np.int32)

    background_label_id_filed = trt.PluginField(
        "background_label_id", background_label_id, trt.PluginFieldType.INT32
    )
    num_classes_field = trt.PluginField("num_classes", num_classes, trt.PluginFieldType.INT32)
    topk_field = trt.PluginField("topk", pre_topk, trt.PluginFieldType.INT32)
    keep_topk_field = trt.PluginField("keep_topk", keep_top_k, trt.PluginFieldType.INT32)
    score_threshold_field = trt.PluginField(
        "score_threshold", score_threshold, trt.PluginFieldType.FLOAT32
    )
    iou_threshold_field = trt.PluginField(
        "iou_threshold", iou_threshold, trt.PluginFieldType.FLOAT32
    )
    is_normalized_field = trt.PluginField("is_normalized", is_normalized, trt.PluginFieldType.INT32)
    clip_boxes_field = trt.PluginField("clip_boxes", clip_boxes, trt.PluginFieldType.INT32)
    return_index = trt.PluginField("return_index", return_index, trt.PluginFieldType.INT32)
    field_collection = trt.PluginFieldCollection(
        [
            background_label_id_filed,
            num_classes_field,
            topk_field,
            keep_topk_field,
            score_threshold_field,
            iou_threshold_field,
            is_normalized_field,
            clip_boxes_field,
            return_index,
        ]
    )

    plugin = get_trt_plugin("TRTBatchedBEVNMS", field_collection, "1", "")
    inputs = [bboxes, scores]
    nms_layer = network.add_plugin_v2(inputs, plugin)
    return [nms_layer.get_output(idx) for idx in range(nms_layer.num_outputs)]


@tensorrt_converter("bevdet_bev_pool_v2")
def acc_ops_bev_pool_v2(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:
    depth = args[0]
    feat = args[1]
    ranks_depth = args[2]
    ranks_feat = args[3]
    ranks_bev = args[4]
    interval_starts = args[6]
    interval_lenths = args[5]

    outWidth = 128
    outHeight = 128
    outWidth = np.array([outWidth], dtype=np.int32)
    outHeight = np.array([outHeight], dtype=np.int32)

    outWidth_filed = trt.PluginField("outWidth", outWidth, trt.PluginFieldType.INT32)
    outHeight_field = trt.PluginField("outHeight", outHeight, trt.PluginFieldType.INT32)
    field_collection = trt.PluginFieldCollection([outWidth_filed, outHeight_field])

    plugin = get_trt_plugin("bev_pool_v2", field_collection, "1", "")
    inputs = [depth, feat, ranks_depth, ranks_feat, ranks_bev, interval_starts, interval_lenths]
    nms_layer = network.add_plugin_v2(inputs, plugin)
    return [nms_layer.get_output(idx) for idx in range(nms_layer.num_outputs)]


@tensorrt_converter("preprocess")
def preprocess(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    x = args[0]
    print(kwargs["_itensor_to_tensor_meta"][x])
    QScalse = 1 / kwargs["_itensor_to_tensor_meta"][x].qparams["scale"]
    if os.environ.get("USE_INT8_QUANT").upper() == "TRUE":
        Int8Input = 1
    else:
        Int8Input = 0
    OutputDatatype = kwargs["datatype"]
    Mean = kwargs["mean"]
    Var = kwargs["var"]
    BGR2RGB = kwargs["BGR2RGB"]

    QScalse = np.array([QScalse], dtype=np.float32)
    Int8Input = np.array([Int8Input], dtype=np.int32)
    OutputDatatype = np.array([OutputDatatype], dtype=np.int32)
    Mean = np.array([Mean], dtype=np.float32)
    Var = np.array([Var], dtype=np.float32)
    BGR2RGB = np.array([BGR2RGB], dtype=np.int32)

    QScalse = trt.PluginField("QScalse", QScalse, trt.PluginFieldType.FLOAT32)
    Int8Input = trt.PluginField("Int8Input", Int8Input, trt.PluginFieldType.INT32)
    OutputDatatype = trt.PluginField("OutputDatatype", OutputDatatype, trt.PluginFieldType.INT32)
    Mean = trt.PluginField("Mean", Mean, trt.PluginFieldType.FLOAT32)
    Var = trt.PluginField("Var", Var, trt.PluginFieldType.FLOAT32)
    BGR2RGB = trt.PluginField("BGR2RGB", BGR2RGB, trt.PluginFieldType.INT32)
    field_collection = trt.PluginFieldCollection(
        [QScalse, Int8Input, OutputDatatype, Mean, Var, BGR2RGB]
    )

    plugin = get_trt_plugin("ImgPreprocess", field_collection, "1", "")
    inputs = [x]
    preprocess_layer = network.add_plugin_v2(inputs, plugin)
    return preprocess_layer.get_output(0)


@tensorrt_converter("nonzero")
def nonzero(
    network: TRTNetwork,
    target: Target,
    args: Tuple[Argument, ...],
    kwargs: Dict[str, Argument],
    name: str,
) -> Union[TRTTensor, Sequence[TRTTensor]]:

    x = args[0]

    layer = network.add_non_zero(input=x)
    set_layer_name(layer, target, name)
    return [layer.get_output(idx) for idx in range(layer.num_outputs)]
