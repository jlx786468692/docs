from packaging.version import Version
import torch
from torch.fx.graph_module import GraphModule
from torch.fx.subgraph_rewriter import Match
from torch.fx._symbolic_trace import symbolic_trace
from torch.fx.node import Node, map_arg
from torch.fx.graph import Graph, Argument
import copy
from typing import Callable, Dict, List, Optional, Set


@torch.fx.wrap
def preprocess(x, scale=50.0, datatype=2, mean=[0.406, 0.456, 0.485], var=[0.225, 0.224, 0.229]):
    # 1. totensor NHWC -> NCHW
    img = x.permute(2, 0, 1).contiguous().float().unsqueeze(0)

    # 2. 处理 torch int8输入数据问题
    img = img.type(torch.float)
    nega_val_index = img < 0
    nega_val_index = nega_val_index.type(torch.int32)
    # img += (nega_val_index * 256).type(torch.float32)
    # nega_val_index = nega_val_index.float()
    img += (nega_val_index * 256).float()
    img = img / 255

    # 3. resize
    workimg_h_, workimg_w_ = img.shape[1], img.shape[2]

    # 4. normalize
    img = torch.nn.functional.interpolate(img, (workimg_h_, workimg_w_), mode="bilinear")
    from torchvision import transforms as T

    img = T.Normalize(mean, var)(img)
    return img


if Version(torch.__version__) < Version("2.0"):
    from torch.fx.subgraph_rewriter import _SubgraphMatcher, _replace_submodules

    class SubgraphMatcher(_SubgraphMatcher):
        def __init__(self, pattern: Graph) -> None:
            super(SubgraphMatcher, self).__init__(pattern)

        # Compare the pattern node `pn` against the graph node `gn`
        def _match_nodes(self, pn: Node, gn: Node) -> bool:

            # Check if we've already matched these nodes in the current
            # traversal
            if pn in self.nodes_map:
                return self.nodes_map[pn] == gn

            def attributes_are_equal(pn: Node, gn: Node) -> bool:
                # Use placeholder and output nodes as wildcards. The
                # only exception is that an output node can't match
                # a placeholder
                if pn.op == "placeholder" or (pn.op == "output" and gn.op != "placeholder"):
                    return True
                # return pn.op == gn.op and pn.target == gn.target
                return pn.op == gn.op and pn.target.__name__ == gn.target.__name__

            # Terminate early if the node attributes are not equal
            if not attributes_are_equal(pn, gn):
                return False

            # Optimistically mark `pn` as a match for `gn`
            self.nodes_map[pn] = gn

            # Traverse the use-def relationships to ensure that `pn` is a true
            # match for `gn`
            if pn.op == "placeholder":
                return True
            if pn.op != "output" and len(pn.all_input_nodes) != len(gn.all_input_nodes):
                return False
            if pn.op == "output":
                match_found = any(
                    self._match_nodes(pn.all_input_nodes[0], gn_) for gn_ in gn.all_input_nodes
                )
            else:
                match_found = len(pn.all_input_nodes) == len(gn.all_input_nodes) and all(
                    self._match_nodes(pn_, gn_)
                    for pn_, gn_ in zip(pn.all_input_nodes, gn.all_input_nodes)
                )
            if not match_found:
                self.nodes_map.pop(pn)
                return False

            return True

    def graph_copy(
        graph,
        g: "Graph",
        val_map: Dict[Node, Node],
        placeholder_map: Dict[Node, Node],
        match_nodes_map: Dict[Node, Node],
        return_output_node=False,
    ) -> "Optional[Argument]":
        for node in g.nodes:
            if node in val_map:
                continue
            if node.op == "output":
                rv = map_arg(node.args[0], lambda n: val_map[n])
                return rv if not return_output_node else (rv, node)
            for pn, gn in match_nodes_map.items():
                if pn.op == node.op and pn.target.__name__ == node.target.__name__:
                    # original: gn.kwargs['scale'] = gn._next.meta['tensor_meta'][6]['scale']
                    # 'immutable_dict' object does not support mutation
                    # node or gn is proprecess，gn._next is q, gn._next.meta include scale
                    node.kwargs = gn.kwargs
                    node.meta = gn._next.meta

            val_map[node] = graph.node_copy(node, lambda n: val_map[n])
            # val_map[node] = self.node_copy(gn, lambda n : val_map[n])
        return None

    def replace_pattern_preprocess(
        gm: GraphModule, pattern: Callable, replacement: Callable
    ) -> List[Match]:
        # Get the graphs for `gm`, `pattern`, `replacement`
        original_graph = gm.graph
        pattern_graph = symbolic_trace(pattern).graph
        replacement_graph = symbolic_trace(replacement).graph

        # Find all possible pattern matches in original_graph. Note that
        # pattern matches may overlap with each other.
        matcher = SubgraphMatcher(pattern_graph)
        matches: List[Match] = []

        # Consider each node as an "anchor" (deepest matching graph node)
        for anchor in original_graph.nodes:

            if matcher.matches_subgraph_from_anchor(anchor):

                def pattern_is_contained(nodes_map: Dict[Node, Node]) -> bool:
                    # `lookup` represents all the nodes in `original_graph`
                    # that are part of `pattern`
                    lookup: Dict[Node, Node] = {v: k for k, v in nodes_map.items()}
                    for n in lookup.keys():

                        # Nodes that can "leak"...

                        # Placeholders (by definition)
                        if n.op == "placeholder":
                            continue
                        # Pattern output (acts as a container)
                        if lookup[n].op == "output":
                            continue
                        # Result contained by pattern output (what we'll
                        # hook in to the new Graph, thus what we'll
                        # potentially use in other areas of the Graph as
                        # an input Node)
                        if (
                            len(lookup[n].users) == 1
                            and list(lookup[n].users.keys())[0].op == "output"
                        ):
                            continue

                        for user in n.users:
                            # If this node has users that were not in
                            # `lookup`, then it must leak out of the
                            # pattern subgraph
                            if user not in lookup:
                                return False
                    return True

                # It's not a match if the pattern leaks out into the rest
                # of the graph
                if pattern_is_contained(matcher.nodes_map):
                    # Shallow copy nodes_map
                    matches.append(
                        Match(
                            anchor=anchor,
                            nodes_map=copy.copy(
                                {key: value for key, value in matcher.nodes_map.items()}
                            ),
                        )
                    )

        # The set of all nodes in `original_graph` that we've seen thus far
        # as part of a pattern match
        replaced_nodes: Set[Node] = set()
        # As we progressively replace nodes, we'll need to keep track of how the match results should change
        match_changed_node: Dict[Node, Node] = dict()

        # Return True if one of the nodes in the current match has already
        # been used as part of another match
        def overlaps_with_prev_match(match: Match) -> bool:
            for pn, gn in match.nodes_map.items():
                if pn.op in ["placeholder", "output"]:
                    continue
                if gn in replaced_nodes and gn.op != "placeholder":
                    return True
            return False

        for match in matches:
            # Skip overlapping matches
            if overlaps_with_prev_match(match):
                continue

            # Map replacement graph nodes to their copy in `original_graph`
            val_map: Dict[Node, Node] = {}

            pattern_placeholders = [n for n in pattern_graph.nodes if n.op == "placeholder"]
            assert len(pattern_placeholders) > 0
            replacement_placeholders = [n for n in replacement_graph.nodes if n.op == "placeholder"]
            assert len(pattern_placeholders) == len(replacement_placeholders)
            placeholder_map = {r: p for r, p in zip(replacement_placeholders, pattern_placeholders)}

            # node from `original_graph` that matched with the output node
            # in `pattern`
            subgraph_output: Node = match.anchor

            def mark_node_as_replaced(n: Node) -> None:
                if n not in match.nodes_map.values():
                    return
                for n_ in n.all_input_nodes:
                    mark_node_as_replaced(n_)
                replaced_nodes.add(n)

            for input_node in subgraph_output.all_input_nodes:
                mark_node_as_replaced(input_node)

            # Initialize `val_map` with mappings from placeholder nodes in
            # `replacement` to their corresponding node in `original_graph`
            for replacement_node in replacement_placeholders:
                # Get the `original_graph` placeholder node
                # corresponding to the current `replacement_node`
                pattern_node = placeholder_map[replacement_node]
                original_graph_node = match_changed_node.get(
                    match.nodes_map[pattern_node], match.nodes_map[pattern_node]
                )

                # Populate `val_map`
                val_map[replacement_node] = original_graph_node

            # Copy the replacement graph over
            with original_graph.inserting_before(subgraph_output):
                # copied_output = original_graph.graph_copy(replacement_graph,
                #                                           val_map)
                # copied_output = original_graph.graph_copy(replacement_graph,
                #                                           val_map, placeholder_map, match.nodes_map)
                copied_output = graph_copy(
                    original_graph, replacement_graph, val_map, placeholder_map, match.nodes_map
                )

            # Hook the output Node of the replacement subgraph in to the
            # original Graph at the correct location

            # CASE 1: We need to hook the replacement subgraph in somewhere
            # in the middle of the graph. We replace the Node in the
            # original graph that corresponds to the end of the pattern
            # subgraph

            for rn, gn in val_map.items():
                # replace preprocess
                if gn.op == "placeholder":
                    # gn is img node, transfer meta from q to img
                    gn.meta["tensor_meta"].qparams["scale"] = gn._next._next.meta[
                        "tensor_meta"
                    ].qparams["scale"]
                    gn.meta["tensor_meta"].qparams["zero_point"] = gn._next._next.meta[
                        "tensor_meta"
                    ].qparams["zero_point"]
                    gn.meta["tensor_meta"].qparams["qscheme"] = gn._next._next.meta[
                        "tensor_meta"
                    ].qparams["qscheme"]

            if subgraph_output.op != "output":
                pattern_outputs = [n for n in pattern_graph.nodes if n.op == "output"]
                assert len(pattern_outputs) > 0
                replacement_outputs = [n for n in replacement_graph.nodes if n.op == "output"]
                assert len(replacement_outputs) == len(pattern_outputs)
                outputs_map = {p: r for r, p in zip(replacement_outputs, pattern_outputs)}

                for pn, gn in match.nodes_map.items():
                    if gn.op == "placeholder":
                        continue

                    # Search for the node corresponding to the output of the pattern
                    if pn.op != "output":
                        continue
                    assert subgraph_output == gn

                    # Update all anchor inputs to the new nodes
                    rn = outputs_map[pn]
                    for pn_input, rn_input in zip(pn.all_input_nodes, rn.all_input_nodes):
                        gn_input = match.nodes_map[pn_input]
                        rn_input_in_original_graph = val_map[rn_input]
                        gn_input.replace_all_uses_with(rn_input_in_original_graph)
                        # We store the updated node point in case other nodes want to use it
                        match_changed_node[gn_input] = rn_input_in_original_graph

                assert subgraph_output.op != "output"
            # CASE 2: The pattern subgraph match extends to the end of the
            # original graph, so we need to change the current graph's
            # output Node to reflect the insertion of the replacement graph.
            # We'll keep the current output Node, but update its args and
            # `_input_nodes` as necessary
            else:
                subgraph_output.args = (copied_output,)
                if isinstance(copied_output, Node):
                    subgraph_output._input_nodes = {copied_output: None}

            assert isinstance(copied_output, Node)
            # Erase the `pattern` nodes
            for node in reversed(original_graph.nodes):
                if len(node.users) == 0 and node.op != "output":
                    original_graph.erase_node(node)

        # Update the passed-in GraphModule to reflect the new state of
        # `original_graph`
        gm.recompile()

        # If `replacement` was an nn.Module, we'll need to make sure that
        # all the submodules have been copied over correctly
        if isinstance(replacement, torch.nn.Module):
            _replace_submodules(gm, replacement)

        return matches

else:

    class SubgraphMatcher:
        def __init__(self):
            raise NotImplementedError("not implemented for SubgraphMatcher")

    def replace_pattern_preprocess(
        gm: GraphModule, pattern: Callable, replacement: Callable
    ) -> List[Match]:
        raise NotImplementedError("not implemented for SubgraphMatcher")
