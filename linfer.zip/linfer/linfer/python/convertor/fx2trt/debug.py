import torch
from typing import Optional


def insert_checkpoint(
    x: torch.Tensor,
    desc: Optional[str] = "LinferCheckpointLayer",
    vis_meta: bool = False,
    vis_data_len: int = 0,
    atol=1e-5,
    rtol=1e-5,
    replay=False,
    filepath: Optional[str] = None,
) -> torch.Tensor:
    # assert isinstance(x, torch.Tensor)
    return x


def observing_point(x: torch.Tensor, replay=True, scale: float = 1.0) -> torch.Tensor:
    # assert isinstance(x, torch.Tensor)
    return x
