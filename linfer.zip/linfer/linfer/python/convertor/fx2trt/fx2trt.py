import warnings
from datetime import datetime
import enum
import os
import json
from typing import Any, Callable, Dict, List, NamedTuple, Optional, Sequence, Tuple, Union
import pathlib
from collections import OrderedDict
import statistics
import shutil
from dataclasses import dataclass
import logging

import tensorrt as trt
import torch
import torch.fx
from torch.fx.node import _get_qualified_name
from torch.fx.passes.shape_prop import TensorMetadata

from convertor.rewriter import RewriterContext, patch_model
from .debug import observing_point
from .tools.replace_pattern import replace_pattern_preprocess, preprocess
from .converter_registry import CONVERTERS
from .input_tensor_spec import InputTensorSpec
from .observer import Observer
from .utils import get_dynamic_dims, torch_dtype_to_trt
from .tracer.acc_tracer import acc_tracer
from .trt_module import TRTModule

from lutility import TRTLogger, logger
from lutility.fxtracer import FxTracer

TRT_INTERPRETER_CALL_PRE_OBSERVER: Observer[Callable[[torch.fx.GraphModule], None]] = Observer(
    "TRT_INTERPRETER_CALL_PRE_OBSERVER"
)


class PrecisionConstraint(enum.Enum):
    NoneConstaint = 0
    ObeyConstraint = 1
    PreferConstaint = 2


class TRTInterpreterResult(NamedTuple):
    engine: Any
    engine_filepath: str
    input_names: Sequence[str]
    output_names: Sequence[str]
    serialized_cache: bytearray


class TRTProfiler(trt.IProfiler):
    def __init__(self, warmup: int):
        super().__init__()
        self._warmup = warmup
        self.layers_profile: Dict[str, List] = OrderedDict()

    def report_layer_time(self, layer_name: str, ms: float) -> None:
        if layer_name not in self.layers_profile:
            self.layers_profile[layer_name] = list()
        self.layers_profile[layer_name].append(ms)

    def get_layer_total_time(self, layer_profile_data) -> float:
        return sum(layer_profile_data[self._warmup :])

    def get_layer_average_time(self, layer_profile_data) -> float:
        return statistics.fmean(layer_profile_data[self._warmup :])

    def get_layer_median_time(self, layer_profile_data) -> float:
        return statistics.median(layer_profile_data[self._warmup :])

    def get_total_time(self) -> float:
        total_time = 0.0
        for _, layer_profile_data in self.layers_profile.items():
            total_time += self.get_layer_total_time(layer_profile_data)
        return total_time

    def export_json(self, filepath: str) -> None:
        profile = list()
        profile.append(OrderedDict(count=len(self.layers_profile.keys())))
        total_time = self.get_total_time()
        for name, layer_profile_data in self.layers_profile.items():
            layer_prof = OrderedDict()
            layer_prof["name"] = name
            layer_prof["timeMs"] = self.get_layer_total_time(layer_profile_data)
            layer_prof["averageMs"] = self.get_layer_average_time(layer_profile_data)
            layer_prof["medianMs"] = self.get_layer_median_time(layer_profile_data)
            layer_prof["percentage"] = 100.0 * layer_prof["timeMs"] / total_time
            profile.append(layer_prof)

        with open(filepath, "w") as f:
            json.dump(profile, f)


def get_output_path_prefix(
    output_path,
    no_tf32: bool,
    fp16: bool,
    int8: bool,
    int8_implict_quant: bool,
    sparse: bool,
    use_dla_core: int = -1,
) -> str:
    workdir = pathlib.Path(output_path)
    quant_method = ""
    precision = ""

    if use_dla_core >= 0:
        device = "DLA"
    else:
        device = "GPU"

    if no_tf32:
        precision = "FP32"
    else:
        precision = "TF32"

    if fp16:
        precision += "+FP16"

    if int8:
        precision += "+INT8"
        if int8_implict_quant:
            quant_method = "ImplictQuant"
        else:
            quant_method = "ExplictQuant"

    filename_prefix = f"{workdir.name}.{device}.{precision}"
    if sparse:
        filename_prefix += "+SPARSE"

    if quant_method != "":
        filename_prefix = f"{filename_prefix}.{quant_method}"
    filename_prefix += f".TRT{trt.__version__}"
    return (workdir / filename_prefix).as_posix()


class TRTInterpreter(torch.fx.Interpreter):
    def __init__(
        self,
        module: torch.fx.GraphModule,
        input_specs: List[InputTensorSpec],
        explicit_batch_dimension: bool = False,
        explicit_precision: bool = False,
        logger_level=None,
    ):
        super().__init__(module)

        # self.logger = trt.Logger(logger_level or trt.Logger.INFO)
        self.logger = TRTLogger(logger_level)
        self.builder = trt.Builder(self.logger)

        flag = 0
        if explicit_batch_dimension:
            EXPLICIT_BATCH = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
            flag |= EXPLICIT_BATCH

        if explicit_precision:
            EXPLICIT_PRECISION = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_PRECISION)
            flag |= EXPLICIT_PRECISION
        self.network = self.builder.create_network(flag)

        missing_ops = self.validate_conversion()
        if missing_ops:
            warnings.warn(
                "Interpretation will fail due to missing operations \n"
                + "\n".join(f"{i}" for i in missing_ops)
            )

        self.optimization_profiles: Optional[List] = None
        self.input_specs = input_specs
        self.input_specs_iter = 0
        self.validate_input_specs()
        self._cur_node_name: Optional[str] = None
        self._input_names: List[str] = []
        self._output_names: List[str] = []
        self._itensor_to_tensor_meta: Dict[trt.tensorrt.ITensor, TensorMetadata] = dict()

    def validate_input_specs(self):
        for shape, _, _, shape_ranges, has_batch_dim in self.input_specs:
            if not self.network.has_implicit_batch_dimension:
                assert (
                    has_batch_dim
                ), "It's required to specify batch dimension when it's explicit in TensorRT network."

            dynamic_dims = get_dynamic_dims(shape)
            if len(dynamic_dims):
                assert not self.network.has_implicit_batch_dimension, (
                    "Can't have dynamic dim when " f"batch dim is implicit, got {shape}."
                )
                assert len(shape_ranges) == 1, "shape_ranges is more than 1."

                if self.optimization_profiles:
                    assert len(shape_ranges) == len(self.optimization_profiles), (
                        "Number of optimization "
                        f"profiles {len(self.optimization_profiles)} doesn't match with the number of shape_range"
                        f" {len(shape_ranges)} provided."
                    )
                else:
                    self.optimization_profiles = [self.builder.create_optimization_profile()]

                for shape_range in shape_ranges:
                    assert (
                        len(shape_range) == 3
                    ), f"Expect three elements in shape_range, got {len(shape_range)}"
                    assert all(len(s) == len(shape) for s in shape_range), (
                        "Expect elements in shape_range"
                        f" {shape_range} have the same number of dimension as the provided shape {len(shape)}"
                    )

                    for i in range(len(shape)):
                        if i in dynamic_dims:
                            assert all(
                                shape_range[j][i] <= shape_range[j + 1][i] for j in range(2)
                            ), (
                                "Expect dynamic dim"
                                f" {i} to have incremental value for shapes in shape_range {shape_range}."
                            )
                        else:
                            assert all(s[i] == shape[i] for s in shape_range), (
                                f"Expect non dynamic dim {i} to be the same"
                                f" for all shapes in shape_range {shape_range}."
                            )
            else:
                assert (
                    len(shape_ranges) == 0
                ), "shape_ranges are provided for input that doesn't have dynamic dim."

    def validate_output_specs(self):
        if not self.optimization_profiles:
            for i in range(self.network.num_outputs):
                output_shape = self.network.get_output(i).shape
                dynamic_dims = any([j == -1 for j in output_shape])
                if dynamic_dims:
                    if not self.optimization_profiles:
                        self.optimization_profiles = [self.builder.create_optimization_profile()]

    def validate_conversion(self):
        missing_converter = set()

        for node in self.module.graph.nodes:
            if node.op == "call_function" and not CONVERTERS.get(node.target):
                missing_converter.add(f"{node.op} {_get_qualified_name(node.target)}")
            elif node.op == "call_method" and not CONVERTERS.get(node.target):
                missing_converter.add(f"{node.op} torch.Tensor.{node.target}")
            elif node.op == "call_module":
                submod = self.fetch_attr(node.target)
                submod_type = getattr(submod, "_base_class_origin", type(submod))
                if not CONVERTERS.get(submod_type):
                    missing_converter.add(f"{node.op} {torch.typename(submod_type)}")

        return missing_converter

    def set_layer_precision(self, fp16_layers, fp32_layers):
        fp16_layers = set(fp16_layers) if fp16_layers else set()
        fp32_layers = set(fp32_layers) if fp32_layers else set()

        for idx in range(self.network.num_layers):
            layer = self.network.get_layer(idx)
            assert not (
                layer.name in fp16_layers and layer.name in fp32_layers
            ), f"{layer.name} should NOT both in fp16_layers and fp32_layers"

            if layer.name in fp32_layers:
                layer.precision = trt.DataType.FLOAT
                layer.set_output_type(0, trt.DataType.FLOAT)
            elif layer.name in fp16_layers:
                layer.precision = trt.DataType.HALF
                layer.set_output_type(0, trt.DataType.HALF)

    def dump_layer_info(self, engine, output_file):
        layers_per_profile = engine.num_layers // engine.num_optimization_profiles
        inspector = engine.create_engine_inspector()
        layer_info = list()
        for profile_idx in range(engine.num_optimization_profiles):
            profile_layer_info = list()
            offset = profile_idx * layers_per_profile
            for index in range(layers_per_profile):
                profile_layer_info.append(
                    json.loads(
                        inspector.get_layer_information(
                            offset + index, trt.LayerInformationFormat.JSON
                        )
                    )
                )
            layer_info.append(profile_layer_info)
        with open(output_file, "w") as f:
            engine_info = json.loads(
                inspector.get_engine_information(trt.LayerInformationFormat.JSON)
            )
            json.dump(engine_info, f)
            logger.info(f"save layer info to: {output_file}")

    def set_tensor_dynamic_range(self, in_range=2.0, out_range=4.0):
        for idx in range(self.network.num_layers):
            layer = self.network.get_layer(idx)

            if layer.type == trt.LayerType.CONCATENATION:
                dyn_range = out_range
            else:
                dyn_range = in_range

            for i in range(layer.num_inputs):
                in_t = layer.get_input(i)
                if in_t:
                    assert in_t.set_dynamic_range(-dyn_range, dyn_range)

            if layer.type == trt.LayerType.POOLING:
                dyn_range = in_range
            else:
                dyn_range = out_range

            for o in range(layer.num_outputs):
                out_t = layer.get_output(o)
                if out_t:
                    assert out_t.set_dynamic_range(-dyn_range, dyn_range)

    def enable_dla(self, builder_config, use_dla_core, allowGPUFallback):
        if use_dla_core >= 0:
            logger.info(f"use DLA Core: {use_dla_core}")
            assert self.builder.num_DLA_cores >= 1, "must have DLA device"
            if allowGPUFallback:
                builder_config.set_flag(trt.BuilderFlag.GPU_FALLBACK)

            builder_config.default_device_type = trt.DeviceType.DLA
            builder_config.DLA_core = use_dla_core

    def has_qdq(self) -> bool:
        for node in self.module.graph.nodes:
            if node.target == torch.fake_quantize_per_tensor_affine:
                return True
        return False

    def set_precision(
        self,
        builder_config,
        precision_constraint,
        no_tf32=False,
        fp16=False,
        int8=False,
        int8_calibrator=None,
        int8_implict_quant=False,
    ):
        if precision_constraint == PrecisionConstraint.ObeyConstraint:
            builder_config.set_flag(trt.BuilderFlag.OBEY_PRECISION_CONSTRAINTS)
        elif precision_constraint == PrecisionConstraint.PreferConstaint:
            builder_config.set_flag(trt.BuilderFlag.PREFER_PRECISION_CONSTRAINTS)
        else:
            builder_config.clear_flag(trt.BuilderFlag.OBEY_PRECISION_CONSTRAINTS)
            builder_config.clear_flag(trt.BuilderFlag.PREFER_PRECISION_CONSTRAINTS)

        if no_tf32:
            builder_config.clear_flag(trt.BuilderFlag.TF32)
            precision_info = "FP32"
        else:
            precision_info = "TF32"

        if fp16:
            if not self.builder.platform_has_fast_fp16:
                warnings.warn("Current platform doesn't support fast native fp16!")
            builder_config.set_flag(trt.BuilderFlag.FP16)
            precision_info += "+FP16"

        if int8:
            os.environ["USE_INT8_QUANT"] = "TRUE"
            if not self.builder.platform_has_fast_int8:
                raise RuntimeError("Current platform doesn't support fast native int8!")
            builder_config.set_flag(trt.BuilderFlag.INT8)
            precision_info += "+INT8"
            has_qdq = self.has_qdq()
            if int8_calibrator is not None:
                assert has_qdq is False, "if use TRT calibrator, must have not Q/DQ"
                builder_config.int8_calibrator = int8_calibrator
                logger.info("QuantType: implict with TRT calibrator")
            elif int8_implict_quant:
                if has_qdq:
                    os.environ["USE_IMPlICT_QUANT"] = "TRUE"
                    logger.info("QuantType: implict with QAT calibrator result")
                else:
                    if os.environ.get("USE_IMPlICT_QUANT", None):
                        del os.environ["USE_IMPlICT_QUANT"]
                    self.set_tensor_dynamic_range()
                    logger.info("QuantType: implict with default dynamic range")
            else:
                logger.info("QuantType: Explict")

        logger.info(f"use precision: {precision_info}")

    def inference(
        self,
        engine,
        input_names,
        output_names,
        infer_warmup,
        infer_iterations,
        profile_filepath,
        inputs=None,
    ):
        trt_mod = TRTModule(engine, input_names, output_names)
        if profile_filepath:
            trt_mod.enable_profiling(TRTProfiler(infer_warmup))

        inputs_cuda = list()
        type_mapping = {
            "DataType.HALF": torch.half,
            "DataType.FLOAT": torch.float32,
            "DataType.INT32": torch.int32,
            "DataType.INT8": torch.int8,
        }
        for i in range(engine.num_bindings):
            if not engine.binding_is_input(i):
                continue

            dims = list(engine.get_binding_shape(i))
            dtype_trt = str(engine.get_binding_dtype(i))
            dtype_torch = type_mapping[dtype_trt]

            if inputs:
                inputs_cuda.append(
                    inputs[i].to(torch.cuda.current_device(), dtype_torch, copy=True)
                )
            else:  # generate input
                if dtype_trt in ["DataType.HALF", "DataType.FLOAT"]:
                    inputs_cuda.append(
                        torch.randn(dims, dtype=dtype_torch, device=torch.cuda.current_device())
                    )
                else:
                    inputs_cuda.append(
                        torch.randint(
                            -128, 127, dims, dtype=dtype_torch, device=torch.cuda.current_device()
                        )
                    )

        for _ in range(infer_warmup + infer_iterations):
            trt_mod(*inputs_cuda)

        if profile_filepath:
            trt_mod.context.profiler.export_json(profile_filepath)
        trt_mod.disable_profiling()

    def run(
        self,
        max_batch_size=64,
        sparse_weights=False,
        strict_type_constraints=False,
        algorithm_selector=None,
        profiling_verbosity=None,
        input_names=None,
        output_names=None,
        force_fp32_output=False,  # TODO
        max_workspace_size=128 * 1024 * 1024,
        no_tf32=False,
        fp16=False,
        int8=False,
        int8_calibrator=None,
        int8_implict_quant=False,
        fp16_layers=None,
        fp32_layers=None,
        precision_constraint=PrecisionConstraint.NoneConstaint,
        enable_cudnn_tactic=True,
        enable_cublas_tactic=True,
        enable_cublaslt_tactic=True,
        use_dla_core: int = -1,
        allow_gpu_fallback=False,
        output_path: str = "workdir/fxtrt",
        export_network: bool = True,
        export_layer_info: bool = True,
        use_timing_cache: bool = True,
        infer_warmup: int = 10,
        infer_iterations: int = 20,
        inputs: Sequence[torch.Tensor] = None,
    ) -> TRTInterpreterResult:
        """
        Build TensorRT engine with some configs.
        Args:
            max_batch_size: set accordingly for maximum batch size you will use.
            max_workspace_size: set to the maximum size we can afford for temporary buffer
            lower_precision: the precision model layers are running on (TensorRT will choose the best perforamnce precision).
            sparse_weights: allow the builder to examine weights and use optimized functions when weights have suitable sparsity
            force_fp32_output: force output to be fp32
            strict_type_constraints: Usually we should set it to False unless we want to control the precision of certain layer for numeric reasons.
            algorithm_selector: set up algorithm selection for certain layer
            timing_cache: enable timing cache for TensorRT
            profiling_verbosity: TensorRT logging level
        Return:
            TRTInterpreterResult
        """
        if use_dla_core >= 0:
            logger.info("Force to use TRT Implict Quant because enable DLA")
            int8_implict_quant = True
        output_prefix = get_output_path_prefix(
            output_path, no_tf32, fp16, int8, int8_implict_quant, sparse_weights, use_dla_core
        )
        trt_engine_filepath = output_prefix + ".trt"
        network_onnx_filepath = output_prefix + ".onnx" if export_network else None
        layer_info_filepath = output_prefix + ".layer.json" if export_layer_info else None
        profile_filepath = output_prefix + ".profile.json" if export_layer_info else None
        timing_cache_filepath = output_prefix + ".timing.cache" if use_timing_cache else None

        self.input_names = input_names
        self.output_names = output_names
        TRT_INTERPRETER_CALL_PRE_OBSERVER.observe(self.module)

        # For float outputs, we set their dtype to fp16 only if lower_precision == LowerPrecision.FP16 and
        # force_fp32_output=False.
        # self.output_fp16 = (not force_fp32_output) and lower_precision == LowerPrecision.FP16
        self.output_fp16 = False
        self.input_specs_iter = 0

        builder_config = self.builder.create_builder_config()
        builder_config.max_workspace_size = max_workspace_size

        tactic_source = builder_config.get_tactic_sources()
        if not enable_cudnn_tactic:
            logger.info("disable cudnn tactic")
            tactic_source &= ~(1 << int(trt.TacticSource.CUDNN))

        if not enable_cublas_tactic:
            logger.info("disable cublas tactic")
            tactic_source &= ~(1 << int(trt.TacticSource.CUBLAS))

        if not enable_cublaslt_tactic:
            logger.info("disable cublaslt tactic")
            tactic_source &= ~(1 << int(trt.TacticSource.CUBLAS_LT))

        builder_config.set_tactic_sources(tactic_source)

        # tf32 = True
        # fp16 = False
        # int8 = False
        # if lower_precision == LowerPrecision.FP16:
        #     fp16 = True
        # if lower_precision == LowerPrecision.INT8:
        #     int8 = True
        # trt_config = CreateConfig(
        #     max_workspace_size=1 << 30,
        #     tf32=tf32,
        #     fp16=fp16,
        #     int8=int8,
        #     profiles=None,
        #     calibrator=int8_calibrator,
        #     obey_precision_constraints=None,
        #     # precision_constraints=None,
        #     strict_types=None,
        #     load_timing_cache=None,
        #     algorithm_selector=None,
        #     sparse_weights=None,
        #     tactic_sources=None,
        #     restricted=None,
        #     use_dla=False,
        #     allow_gpu_fallback=False,
        #     profiling_verbosity=None,
        #     memory_pool_limits=None,
        # )
        # builder_config = trt_config(self.builder, self.network)

        if timing_cache_filepath is not None:
            if os.path.exists(timing_cache_filepath):
                logger.info(f"use the timing cache: {timing_cache_filepath}")
                with open(timing_cache_filepath, "rb") as f:
                    cache = builder_config.create_timing_cache(f.read())
                    builder_config.set_timing_cache(cache, ignore_mismatch=False)
            else:
                logger.info(f"create new timing cache: {timing_cache_filepath}")
                cache = builder_config.create_timing_cache(b"")
                builder_config.set_timing_cache(cache, ignore_mismatch=False)

        if trt.__version__ >= "8.2":
            builder_config.profiling_verbosity = (
                profiling_verbosity
                if profiling_verbosity
                else trt.ProfilingVerbosity.LAYER_NAMES_ONLY
            )

        self.enable_dla(builder_config, use_dla_core, allow_gpu_fallback)

        self.set_precision(
            builder_config,
            precision_constraint,
            no_tf32,
            fp16,
            int8,
            int8_calibrator,
            int8_implict_quant,
        )
        self.set_layer_precision(fp16_layers, fp32_layers)

        if sparse_weights:
            logger.info("use sparse")
            builder_config.set_flag(trt.BuilderFlag.SPARSE_WEIGHTS)

        trt_version_list = trt.__version__.split(".")
        if trt_version_list[0] == "8" and trt_version_list[1] == "6":
            self.validate_output_specs()

        if strict_type_constraints:
            builder_config.set_flag(trt.BuilderFlag.STRICT_TYPES)

        if self.optimization_profiles:
            for optimization_profile in self.optimization_profiles:
                builder_config.add_optimization_profile(optimization_profile)

        if layer_info_filepath:
            builder_config.profiling_verbosity = trt.ProfilingVerbosity.DETAILED

        if algorithm_selector:
            logger.info("use algorithm_selector, so disable timing cache")
            builder_config.set_flag(trt.BuilderFlag.DISABLE_TIMING_CACHE)
            builder_config.algorithm_selector = algorithm_selector

        run_module_start_time = datetime.now()
        logger.info("convert torch model to tensorrt network.")
        super().run()
        logger.info(f"elapsed time: {datetime.now() - run_module_start_time}")
        build_engine_start_time = datetime.now()

        if network_onnx_filepath is not None:
            from polygraphy import mod

            onnx_backend = mod.lazy_import("polygraphy.backend.onnx")
            trt_backend = mod.lazy_import("polygraphy.backend.trt")

            onnx_like = trt_backend.onnx_like_from_network((self.builder, self.network))
            onnx_backend.save_onnx(onnx_like, network_onnx_filepath)
            logger.info(f"save trt onnx to: {network_onnx_filepath}")

        self._engine = self.builder.build_engine(self.network, builder_config)
        assert self._engine

        if timing_cache_filepath is not None:
            cache = builder_config.get_timing_cache()
            with cache.serialize() as buffer, open(timing_cache_filepath, "wb") as f:
                f.write(buffer)
                f.flush()
                os.fsync(f)

        if layer_info_filepath:
            self.dump_layer_info(self._engine, layer_info_filepath)

        with open(trt_engine_filepath, "wb") as f:
            f.write(self._engine.serialize())
            logger.info(f"save trt engine: {trt_engine_filepath}")

        logger.info(f"Build TRT engine elapsed time: {datetime.now() - build_engine_start_time}")
        logger.info("infer...")
        self.inference(
            self._engine,
            self._input_names,
            self._output_names,
            infer_warmup,
            infer_iterations,
            profile_filepath,
            inputs=inputs,
        )

        serialized_cache = (
            bytearray(cache.serialize()) if builder_config.get_timing_cache() else bytearray()
        )
        return TRTInterpreterResult(
            self._engine,
            trt_engine_filepath,
            self._input_names,
            self._output_names,
            serialized_cache,
        )

    def run_node(self, n):
        self._cur_node_name = str(n)
        # add "_itensor_to_tensor_meta"
        kwargs = dict(n.kwargs)
        kwargs["_itensor_to_tensor_meta"] = self._itensor_to_tensor_meta
        n.kwargs = kwargs

        # run the node
        logger.debug(f"run the node, op: {n.op}, name: {n.name}")
        # FIXME why some op have NOT "_linfer.torch_output" key.
        if "_linfer.torch_output" in n.meta.keys():
            logger.debug("copy _linfer.torch_output")
            n.update_kwarg("_linfer.torch_output", n.meta["_linfer.torch_output"])

        # if "_call_stack" in n.meta.keys():
        #     n.update_kwarg("_linfer.call_stack", n.meta["_call_stack"])
        # else:
        #     n.update_kwarg("_linfer.call_stack", "UNKNOWN")

        # if "_fxcode_linenum" in n.meta.keys():
        #     n.update_kwarg("_linfer._fxcode_linenum", n.meta["_fxcode_linenum"])

        if "_linfer.filepath_torch_data" in n.meta.keys():
            n.update_kwarg("_linfer.filepath_torch_data", n.meta["_linfer.filepath_torch_data"])

        if "_linfer.filepath_trt_data" in n.meta.keys():
            n.update_kwarg("_linfer.filepath_trt_data", n.meta["_linfer.filepath_trt_data"])

        if "_linfer.ingore_fq" in n.meta.keys():
            n.update_kwarg("_linfer.ingore_fq", n.meta["_linfer.ingore_fq"])

        # n.update_kwarg("linfer.stack", n.meta["linfer.stack"])
        trt_node = super().run_node(n)

        # remove "_itensor_to_tensor_meta"
        kwargs = dict(n.kwargs)
        del kwargs["_itensor_to_tensor_meta"]
        n.kwargs = kwargs

        if isinstance(trt_node, trt.tensorrt.ITensor):
            self._itensor_to_tensor_meta[trt_node] = n.meta.get("tensor_meta")

        return trt_node

    def placeholder(self, target, args, kwargs):
        if len(args) > 0:  # this input is concrete_args, so ignore it.
            return

        if self.input_names and self.input_specs_iter < len(self.input_names):
            name = self.input_names[self.input_specs_iter]
        else:
            name = target
        self._input_names.append(name)

        shape, dtype, _, shape_ranges, has_batch_dim = self.input_specs[self.input_specs_iter]
        self.input_specs_iter += 1

        if self.network.has_implicit_batch_dimension:
            if has_batch_dim:
                shape = shape[1:]
        else:
            for i, shape_range in enumerate(shape_ranges):
                assert self.optimization_profiles
                self.optimization_profiles[i].set_shape(name, *shape_range)

        input = self.network.add_input(
            name=name, shape=tuple(shape), dtype=torch_dtype_to_trt(dtype)
        )
        if dtype is torch.int8:
            calibScale = 1
            input.set_dynamic_range(-127 * calibScale, 127 * calibScale)

        return input

    def call_module(self, target, args, kwargs):
        assert isinstance(target, str)
        submod = self.fetch_attr(target)
        submod_type = getattr(submod, "_base_class_origin", type(submod))
        converter = CONVERTERS.get(submod_type)

        if not converter:
            raise RuntimeError(
                f"Conversion of module of type {submod_type} not currently supported!"
            )

        assert self._cur_node_name is not None
        return converter(self.network, submod, args, kwargs, self._cur_node_name)

    def call_function(self, target, args, kwargs):
        converter = CONVERTERS.get(target)
        if not converter:
            converter = CONVERTERS.get(target.__name__)
            if not converter:
                raise RuntimeError(
                    f"Conversion of function {torch.typename(target)} not currently supported!"
                )

        assert self._cur_node_name is not None
        return converter(self.network, target, args, kwargs, self._cur_node_name)

    def call_method(self, target, args, kwargs):
        assert isinstance(target, str)
        converter = CONVERTERS.get(target)

        if not converter:
            raise RuntimeError(f"Conversion of method {target} not currently supported!")

        assert self._cur_node_name is not None
        return converter(self.network, target, args, kwargs, self._cur_node_name)

    def output(self, target, args, kwargs):
        assert len(args) == 1
        outputs = args[0] if isinstance(args[0], tuple) else (args[0],)

        outputs_flat = []
        for outs in outputs:
            if isinstance(outs, list):
                [outputs_flat.append(out) for out in outs]
            else:
                outputs_flat.append(outs)

        if not all(isinstance(output, trt.tensorrt.ITensor) for output in outputs_flat):
            raise RuntimeError("TensorRT requires all outputs to be Tensor!")

        for i, output in enumerate(outputs_flat):
            if any(
                op_name in output.name.split("_")
                for op_name in (
                    "eq",
                    "gt",
                    "lt",
                    "or",
                    "xor",
                    "and",
                    "not",
                    "ne",
                    "isinf",
                    "any",
                )
            ):
                output_bool = True
            else:
                output_bool = False

            output.name = self.output_names[i] if self.output_names else f"output{i}"
            self.network.mark_output(output)
            if output_bool:
                output.dtype = trt.bool
            elif self.output_fp16 and output.dtype == trt.float32:
                output.dtype = trt.float16
            self._output_names.append(output.name)


def lower_to_trt(
    model: torch.nn.Module,
    inputs: Union[torch.Tensor, Tuple, Dict],
    input_metas: Optional[Dict] = None,
    input_specs: Optional[InputTensorSpec] = None,
    input_names: Optional[Sequence[str]] = None,
    output_names: Optional[Sequence[str]] = None,
    verbose: bool = False,
    max_workspace_size_MB: int = 128,
    no_tf32: bool = False,
    fp16: bool = False,
    int8: bool = False,
    sparse: bool = False,
    int8_implict_quant: bool = False,
    int8_calibrator=None,
    fp16_layers=None,
    fp32_layers=None,
    precision_constraint: PrecisionConstraint = PrecisionConstraint.NoneConstaint,
    enable_cudnn_tactic=True,
    enable_cublas_tactic=True,
    enable_cublaslt_tactic=True,
    use_dla_core=-1,
    allow_gpu_fallback=False,
    output_path: str = "workdir/fxtrt",
    export_network: bool = True,
    export_layer_info: bool = True,
    use_timing_cache: bool = True,
    infer_warmup: int = 20,
    infer_iterations: int = 100,
    transform_func: Callable[[torch.fx.GraphModule, str], torch.fx.GraphModule] = None,
    export_ir: bool = False,
    export_onnx: bool = True,
    replace_pre: bool = False,
    algorithm_selector=None,
):
    pathlib.Path(output_path).mkdir(exist_ok=True)

    model = patch_model(model, cfg=dict())
    with RewriterContext(), torch.no_grad():
        model(*inputs)

        if export_onnx:
            onnx_path = output_path + "/fx.onnx"
            torch.onnx.export(model, inputs, onnx_path, opset_version=16, verbose=False)
            logger.info(f"export onnx to: {onnx_path}")

        traced = acc_tracer.trace(model, inputs, transform_func=transform_func)
        if export_ir:
            fxir_path = output_path + "/fxir"
            logger.info(f"export fxir to: {fxir_path}")
            model = export_fxir(traced, fxir_path)

        if replace_pre:

            def pattern(img):
                img = preprocess(img)
                # b = fake_per_tensor()
                # output = b(img)
                # return output
                return torch.quantize_per_tensor(img, 1.0, 0, dtype=torch.qint8)

            def replacement(img):
                return preprocess(img)

            replace_pattern_preprocess(traced, pattern, replacement)
        logger_level = logging.DEBUG if verbose else logging.INFO
        interp = TRTInterpreter(
            traced, input_specs, explicit_batch_dimension=True, logger_level=logger_level
        )
        interp.run(
            output_names=output_names,
            input_names=input_names,
            max_workspace_size=max_workspace_size_MB * 1024 * 1024,
            no_tf32=no_tf32,
            fp16=fp16,
            int8=int8,
            sparse_weights=sparse,
            int8_implict_quant=int8_implict_quant,
            int8_calibrator=int8_calibrator,
            fp16_layers=fp16_layers,
            fp32_layers=fp32_layers,
            precision_constraint=precision_constraint,
            enable_cudnn_tactic=enable_cudnn_tactic,
            enable_cublas_tactic=enable_cublas_tactic,
            enable_cublaslt_tactic=enable_cublaslt_tactic,
            use_dla_core=use_dla_core,
            allow_gpu_fallback=allow_gpu_fallback,
            output_path=output_path,
            export_network=export_network,
            export_layer_info=export_layer_info,
            use_timing_cache=use_timing_cache,
            infer_warmup=infer_warmup,
            infer_iterations=infer_iterations,
            inputs=inputs,
            algorithm_selector=algorithm_selector,
        )


def _fix_succ_recursivly(args, target_node, inserted_node):
    # List / Tuple
    if isinstance(args, (list, tuple)):
        _tmp = list(args)
        for _i, _arg in enumerate(args):
            if _arg == target_node:
                _tmp[_i] = inserted_node
            elif isinstance(_arg, tuple):
                _tmp[_i] = _fix_succ_recursivly(_arg, target_node, inserted_node)
            elif isinstance(_arg, list):
                _tmp[_i] = list(_fix_succ_recursivly(_arg, target_node, inserted_node))
            elif isinstance(_arg, dict):
                _tmp[_i] = _fix_succ_recursivly(_arg, target_node, inserted_node)
        return tuple(_tmp)
    # Dict
    elif isinstance(args, dict):
        _tmp = {}
        for k, v in args.items():
            if v == target_node:
                _tmp[k] = inserted_node
            elif not isinstance(v, torch.fx.node.Node):
                _tmp[k] = _fix_succ_recursivly(v, target_node, inserted_node)
            else:
                _tmp[k] = v
        return _tmp
    else:
        return args
        # raise NotImplementedError('{} can not be handled now.'.format(type(args)))


def get_scale(model: torch.fx.GraphModule, node: torch.fx.node.Node) -> Union[float, List[float]]:
    if isinstance(node.args[1], torch.fx.node.Node):
        assert node.args[1].op == "get_attr"
        scale = getattr(getattr(model, node.name), "scale").cpu().tolist()
        return scale
    else:
        scale = node.args[1]
        if isinstance(node.args[1], list):
            return [
                scale,
            ]
        else:
            return scale


def auto_insert_observing_point(traced, save_dir="/dev/shm/linfer/fx2trt/"):
    torch_data_save_dir = save_dir + "/torch"
    trt_data_save_dir = save_dir + "/trt"

    shutil.rmtree(save_dir, ignore_errors=True)
    os.makedirs(torch_data_save_dir, exist_ok=True)
    os.makedirs(trt_data_save_dir, exist_ok=True)

    index = list()
    scales = dict()
    observing_point_idx = 1
    for node in traced.graph.nodes:
        if node.name.endswith("_fake_quant"):
            scale = get_scale(traced, node)
            # TODO add observing_point node for onnx model
            for pnode in node._input_nodes:
                if pnode.op in ["call_module", "call_function", "call_method"]:
                    with traced.graph.inserting_before(node):
                        new_node = traced.graph.call_function(
                            observing_point, args=(pnode, True, scale)
                        )
                        new_node.name = f"observing_point_{observing_point_idx}_{node.name}"
                        filename = f"op_{observing_point_idx}_{node.name}.npy"
                        filepaht_torch_data = f"{torch_data_save_dir}/{filename}"
                        filepaht_trt_data = f"{trt_data_save_dir}/{filename}"
                        new_node.meta["_linfer.filepath_torch_data"] = filepaht_torch_data
                        new_node.meta["_linfer.filepath_trt_data"] = filepaht_trt_data
                        # node.replace_all_uses_with(new_node)  # TODO why failed?

                        node.args = _fix_succ_recursivly(node.args, pnode, new_node)
                        node.kwargs = _fix_succ_recursivly(node.kwargs, pnode, new_node)

                        observing_point_idx += 1
                        index.append(filename)
                        scales[filename] = scale

    with open(save_dir + "/index.txt", "w") as f:
        f.write("\n".join(index))

    with open(save_dir + "/scales.json", "w") as f:
        json.dump(scales, f)

    traced.recompile()
    return traced


default_insert_code = """
import torch
import torch.fx
from convertor.fx2trt import insert_checkpoint as convertor_fx2trt_debug_insert_checkpoint
torch.fx.wrap("convertor_fx2trt_debug_insert_checkpoint")

@torch.fx.wrap
def bevdet_bev_pool_v2(
    depth,
    feat,
    ranks_depth,
    ranks_feat,
    ranks_bev,
    interval_lengths,
    interval_starts,
    outWidth,
    outHeight):
    return [torch.randn((1, outHeight, outWidth, feat.shape[-1])).to(depth.device)]
    
@torch.fx.wrap
def quantize_per_tensor(input: Tensor, scale: _float, zero_point: _int, dtype: _dtype, quant_min=-128, quant_max=127, name=None) -> Tensor:
    x = torch.clip(input / scale, quant_min, quant_max)
    # torch.round will cause x.grad = 0
    x = torch.round(x) - x.detach() + x
    return x

@torch.fx.wrap
def dequantize(input: Tensor, scale: _float,  zero_point: _int, dtype: _dtype, quant_min=-128, quant_max=127) -> Tensor:
    return input * scale

"""


@dataclass(frozen=True)
class ReplPattern:
    old: str
    new: str


def refine_fxcode(
    folder_path,
    insert_codes: Optional[str] = None,
    replace_patterns: Optional[List[ReplPattern]] = None,
):
    folder_path = pathlib.Path(
        folder_path
    ).as_posix()  # normarlize path, e.g. ./workdir/debug/ -> workdir/debug

    default_replace_patterns = [
        ReplPattern("__init__(self):", "__init__(self, path):"),
        ReplPattern(f"r'{folder_path}", "path + '"),
        ReplPattern(
            'torch.fx._symbolic_trace.wrap("convertor_fx2trt_debug_insert_checkpoint")', ""
        ),
        ReplPattern('torch.fx._symbolic_trace.wrap("__main___bevdet_bev_pool_v2")', ""),
        ReplPattern("bevdet_bev_pool_v2", "bevdet_bev_pool_v2__"),
        ReplPattern("__main___bevdet_bev_pool_v2__", "bevdet_bev_pool_v2"),
        ReplPattern(
            'torch.fx._symbolic_trace.wrap("quantization_fake_quantize_fixed_quantize_per_tensor")',
            "",
        ),
        ReplPattern(
            'torch.fx._symbolic_trace.wrap("quantization_fake_quantize_fixed_dequantize")', ""
        ),
        ReplPattern("quantization_fake_quantize_fixed_quantize_per_tensor", "quantize_per_tensor"),
        ReplPattern("quantization_fake_quantize_fixed_dequantize", "dequantize"),
    ]

    if insert_codes is None:
        insert_codes = default_insert_code
    else:
        insert_codes = default_insert_code + insert_codes

    if replace_patterns:
        replace_patterns.extend(default_replace_patterns)
    else:
        replace_patterns = default_replace_patterns

    with open(folder_path + "/module.py", "r+") as f:
        fxcode = f.read()

        for pattern in replace_patterns:
            fxcode = fxcode.replace(pattern.old, pattern.new)

        fxcode = "\n{}\n{}".format(insert_codes, fxcode)

        f.seek(0)
        f.truncate()
        f.write(fxcode)


def export_fxir(
    model: torch.nn.Module,
    save_dir: str,
    insert_codes: Optional[str] = None,
    replace_patterns: Optional[List[ReplPattern]] = None,
    leaf_modules: Optional[List[torch.nn.Module]] = None,
) -> torch.fx.GraphModule:
    traced = FxTracer(leaf_modules=leaf_modules).trace(model)
    model: torch.nn.Module = torch.fx.GraphModule(model, traced)
    for module_name, module in model.named_modules():
        if hasattr(module, "qconfig"):
            logger.debug(f"delete {module_name} qconfig")
            delattr(module, "qconfig")

    pathlib.Path(save_dir).mkdir(exist_ok=True)
    model.to_folder(save_dir)
    refine_fxcode(save_dir, insert_codes, replace_patterns)
    return model
