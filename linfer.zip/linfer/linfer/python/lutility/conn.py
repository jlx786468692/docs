import pickle
import safetensors
import struct
import socket
from typing import Union


def send_all(sock, data: bytes):
    if not isinstance(data, bytes):
        raise TypeError(f"send_all only supports bytes, got {type(data)}")

    sock.sendall(struct.pack("!I", len(data)))
    sock.sendall(data)


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("socket closed before receiving enough data")
        buf += chunk
    return buf


def recv_all(sock):
    raw_len = recv_exact(sock, 4)
    msg_len = struct.unpack("!I", raw_len)[0]
    print(f"[Server] Expecting {msg_len/1024/1024:.2f} MB of data...")

    data = recv_exact(sock, msg_len)
    print("Successfully got all data!")

    return data


def request(sock: socket.socket, request_data: Union[bytes, dict]):
    """
    Send a request over a socket and receive the response.

    - If `request_data` is a `dict`, it will be serialized to safetensors bytes before sending.
    - If `request_data` is already `safetensors bytes`, it will be sent directly.
    - The response type matches the request type:
        * If the request was a dict, the response is automatically deserialized into a dict[str, torch.Tensor].
        * If the request was bytes, the response is returned as safetensors bytes.
    """

    if not isinstance(request_data, (bytes, dict)):
        raise TypeError(
            f"request only supports safetensors bytes or dict, got {type(request_data)}"
        )

    is_dict_request = isinstance(request_data, dict)

    if is_dict_request:
        request_data = safetensors.torch.save(request_data)

    send_all(sock, request_data)

    response_st_bytes = recv_all(sock)
    if is_dict_request:
        return safetensors.torch.load(response_st_bytes)

    return response_st_bytes
