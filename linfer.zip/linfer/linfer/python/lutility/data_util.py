from typing import List, OrderedDict, Dict
import os
from pathlib import Path
import collections
import json

import numpy as np
from numpy.typing import NDArray
import torch


def parse_numpy_data(input_path: str, input_names: List[str]) -> OrderedDict[str, NDArray]:
    input_tensors = collections.OrderedDict()

    input_path: Path = Path(input_path)
    if input_path.is_file():
        name = input_names[0]
        assert len(input_names) == 1, "only one data file, so must have only one input name"
        # assert name == input_path.stem, f"input data file name must match model input name: {name} vs {input_path.stem}"
        input_tensors[name] = np.load(input_path)
    elif input_path.is_dir():
        for iname in input_names:
            npy_path = input_path / (iname + ".npy")
            assert npy_path.exists(), f"no data file input: {iname}"
            input_tensors[iname] = np.load(npy_path)
    else:
        assert False, f"{input_path} must be file or dir"

    return input_tensors


def parse_safetensors_data(input_path: str) -> bytes:
    with open(input_path, "rb") as f:
        return f.read()


def np2tensor(data: OrderedDict[str, NDArray]) -> OrderedDict[str, torch.Tensor]:
    new_data = collections.OrderedDict()
    for k, v in data.items():
        new_data[k] = torch.from_numpy(v).cuda()

    return new_data


def parse_json_data(input_path) -> Dict[str, NDArray]:
    with open(input_path, "r") as f:
        json_data: Dict = json.load(f)

    input: Dict = dict()
    for k, v in json_data["input"].items():
        datatype = v["datatype"]
        if datatype == "int32":
            dtype = np.int32
        elif datatype == "fp32":
            dtype = np.float32
        elif datatype == "int8":
            dtype = np.int8
        else:
            raise Exception(f"{datatype} is unsupported.")

        data = np.array(v["data"], dtype=dtype)
        input[k] = np.ascontiguousarray(np.reshape(data, v["dims"]))

    return input


def generate_random_data(input_names: List[str], trt_engine) -> Dict[str, NDArray]:
    input: Dict = dict()
    for input_name in input_names:
        datatype = trt_engine.get_binding_datatype(input_name)
        datadims = trt_engine.get_binding_dims(input_name)
        datadims_prod = np.prod(datadims)
        if datatype == "FLOAT":
            print("the input " + input_name + " type is float32")
            dtype = np.float32
            value = np.random.randint(-100, 100, datadims_prod) / 100
        elif datatype == "INT32":
            print("the input " + input_name + " type is int32")
            dtype = np.int32
            value = np.random.randint(-100, 100, datadims_prod)
        elif datatype == "INT8":
            print("the input " + input_name + " type is int8")
            dtype = np.int8
            value = np.random.randint(-100, 100, datadims_prod)
        else:
            raise Exception(f"{datatype} is unsupported.")
        data = np.array(value, dtype=dtype)
        input[input_name] = np.ascontiguousarray(np.reshape(data, datadims))

    return input


def save_npy_dict(save_dir: str, data_dict: Dict):
    assert isinstance(data_dict, dict)
    os.makedirs(save_dir, exist_ok=True)
    for name, data_npy in data_dict.items():
        filepath = f"{save_dir}/{name}.npy"
        np.save(filepath, data_npy, allow_pickle=False)


def save_pt_tensor_to_npy(save_dir: str, data_dict: Dict):
    npy_dict = dict()
    for name, tensor in data_dict.items():
        data = np.ascontiguousarray(tensor.cpu().detach().numpy())
        npy_dict[name] = data

    save_npy_dict(save_dir, npy_dict)


def load_npy_dict(load_dir: str):
    npy_dict = dict()

    files = os.listdir(load_dir)
    for filename in files:
        if not filename.endswith(".npy"):
            continue
        path = os.path.join(load_dir, filename)
        basename = filename[:-4]  # remove .npy
        npy_dict[basename] = np.load(path, allow_pickle=False)
    return npy_dict


def load_npy_to_pt_tensor(load_dir: str, device: str = "cpu"):
    npy_dict = load_npy_dict(load_dir)

    tensor_dict = dict()
    for key, value in npy_dict.items():
        tensor_dict[key] = torch.from_numpy(value).to(device)

    return tensor_dict
