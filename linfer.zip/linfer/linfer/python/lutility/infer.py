from time import time
from pathlib import Path
import socket
from typing import Optional, List

from lutility import (
    parse_numpy_data,
    parse_json_data,
    parse_safetensors_data,
    generate_random_data,
    logger,
    request,
)
from .data_util import save_npy_dict


def do_infer(
    trt_engine: str,
    data_file: str,
    save_dir: Optional[str] = None,
    silent: bool = False,
    warmup: int = 10,
    runs_time: int = 100,
    profile: str = "null",
    use_cuda_graph: bool = False,
):
    logger.info(f"trt_engine: {trt_engine}")
    logger.info(f"data_file: {data_file}")
    logger.info(f"silent: {silent}")
    logger.info(f"warmup: {warmup}")
    logger.info(f"runs_time: {runs_time}")
    logger.info(f"use_cuda_graph: {use_cuda_graph}")

    params = dict()
    params["use_cuda_graph"] = str(use_cuda_graph)
    params["profile"] = profile

    if save_dir:
        save_dir = Path(save_dir)
        save_dir.mkdir(exist_ok=True)

    import pylinfer

    trt_engine = pylinfer.TrtModelInferEngine(trt_engine, params)
    input_names = trt_engine.get_input_names()

    use_safetensors = False
    if data_file == "random":
        input = generate_random_data(input_names, trt_engine)
    elif Path(data_file).suffix == ".json":
        input = parse_json_data(data_file)
    elif Path(data_file).suffix in [".st", ".safetensors"]:
        input = parse_safetensors_data(data_file)
        use_safetensors = True
    else:  # numpy
        input = parse_numpy_data(data_file, input_names)

    if warmup > 0:
        logger.info("warmup starting...")
        for _ in range(warmup):
            trt_engine.infer_dict(input)
        logger.info("warmup done, do testing...")

    total_time_cost = 0.0
    for _ in range(runs_time):
        t = time()
        if use_safetensors:
            result = trt_engine.infer_st(input)
        else:
            result = trt_engine.infer_dict(input)

        total_time_cost += time() - t
        if not silent:
            if use_safetensors:
                from safetensors.torch import load

                print(load(result))
            else:
                print(result)

    if save_dir:
        logger.info(f"save result to {save_dir}")
        if use_safetensors:
            with open(save_dir / "input.safetensors", "wb") as f:
                f.write(input)

            with open(save_dir / "output.safetensors", "wb") as f:
                f.write(result)
        else:
            save_npy_dict(f"{save_dir}/input", input)
            save_npy_dict(f"{save_dir}/output", result)

    logger.info("finish test")
    logger.info(f"average time cost: {1000 * total_time_cost / runs_time:.3f} ms")


def datatype_to_torch_dtype(datatype: str):
    import torch

    dtype_map = {
        "FLOAT": torch.float32,
        "HALF": torch.float16,
        "BF16": torch.bfloat16,
        "FP8": torch.float8_e4m3fn,
        "INT64": torch.int64,
        "INT32": torch.int32,
        "UINT32": torch.uint32,
        "INT8": torch.int8,
    }
    return dtype_map[datatype]


def do_infer_vlm(
    prefill_engine: str,
    decode_engine: str,
    input: str,
    save_dir: Optional[str] = None,
    silent: bool = False,
    warmup: int = 10,
    runs_time: int = 100,
    use_cuda_graph: bool = False,
    max_output_token_num: int = -1,
    eos_token_id: List[int] = [151645],
    enable_nvtx: bool = False,
):
    logger.info(f"prefill_engine: {prefill_engine}")
    logger.info(f"decode_engine: {decode_engine}")
    logger.info(f"data_file: {input}")
    logger.info(f"silent: {silent}")
    logger.info(f"warmup: {warmup}")
    logger.info(f"runs_time: {runs_time}")
    logger.info(f"use_cuda_graph: {use_cuda_graph}")
    logger.info(f"max_output_token_num: {max_output_token_num}")
    logger.info(f"eos_token_id: {eos_token_id}")
    logger.info(f"nvtx: {enable_nvtx}")
    logger.info(f"save_dir: {save_dir}")

    if save_dir:
        save_dir = Path(save_dir)
        save_dir.mkdir(exist_ok=True)

    import pylinfer

    vlm_engine = pylinfer.VLMInferEngine(
        prefill_engine,
        decode_engine,
        max_output_token_num,
        eos_token_id,
        use_cuda_graph,
        enable_nvtx,
    )

    if input == "random":
        from torch.testing import make_tensor
        from safetensors.torch import save

        input_data_dict = dict()
        for name in vlm_engine.get_input_names():
            datatype = vlm_engine.get_binding_datatype(name)
            dims = vlm_engine.get_binding_dims(name)
            t = make_tensor(
                dims,
                dtype=datatype_to_torch_dtype(datatype),
                device="cpu",
                low=-1,
                high=1,
            )
            input_data_dict[name] = t

        input_data = save(input_data_dict)

    elif Path(input).suffix in [".st", ".safetensors"]:
        input_data = parse_safetensors_data(input)
    else:
        raise NotImplementedError("unsupported")

    if warmup > 0:
        logger.info("warmup starting...")
        for _ in range(warmup):
            vlm_engine.infer(input_data)
        logger.info("warmup done, do testing...")

    total_time_cost = 0.0
    for _ in range(runs_time):
        t = time()
        ouput_token: List = vlm_engine.infer(input_data)

        total_time_cost += time() - t
        if not silent:
            print(ouput_token)

    if save_dir:
        import torch
        from safetensors.torch import save_file

        logger.info(f"save result to {save_dir}")
        with open(save_dir / "input.safetensors", "wb") as f:
            f.write(input_data)

        result_st = dict(output_token=torch.tensor(ouput_token))
        save_file(result_st, save_dir / "output.safetensors")

    logger.info("finish test")
    logger.info(f"average time cost: {1000 * total_time_cost / runs_time:.3f} ms")


class TrtInferClient(object):

    def __init__(
        self, engine_path, remote_host: Optional[str] = None, remote_port: int = 0
    ) -> None:
        if remote_host:
            self.remote = True
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((remote_host, remote_port))
        else:
            self.remote = False
            import pylinfer

            self.model = pylinfer.TrtModelInferEngine(engine_path, {})

    def infer(self, data_dict):
        if self.remote:
            return request(self.sock, data_dict)
        else:
            return self.model.infer_dict(data_dict)
