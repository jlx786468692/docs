from typing import Any, Dict, Optional, Tuple, Union, List
import ast
import inspect
import pathlib
import os

import torch
from torch.fx import Tracer
from torch.fx.node import Argument, Node, Target


class FxTracer(Tracer):

    def __init__(self, leaf_modules=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.leaf_modules = tuple(leaf_modules) if leaf_modules else None
        self.name_idx = dict()

    def is_leaf_module(self, m: torch.nn.Module, module_qualified_name: str) -> bool:
        if self.leaf_modules and isinstance(m, self.leaf_modules):
            return True
        return m.__module__.startswith("torch.nn")

    def get_node_name_from_fxgraph(self, stack_frame: inspect.FrameInfo):
        code_line = stack_frame.code_context[0]
        code_line = code_line.strip(" ")
        root_node = ast.parse(code_line)
        return root_node.body[0].targets[0].id

    def get_node_name_from_stack(self, stack, kind, target, name, exclude_paths):
        assert isinstance(exclude_paths, (str, list))
        if isinstance(exclude_paths, str):
            exclude_paths = [exclude_paths]

        if name is None:
            if kind == "call_function":
                name = target.__name__  # for python op, e.g. t1 + t2
            elif kind == "call_method":  # for pytorch tensor.method, e.g. t.size()
                name = target
            else:
                name = str(kind)

        idx = self.name_idx.get(name, 0)
        self.name_idx[name] = idx + 1
        name = f"{name}_{idx}"

        # cwd = os.getcwd()
        # for frame in stack[::-1]:
        #     filepath = cwd + "/" + frame.filename
        #     if any([epath in filepath for epath in exclude_paths]):
        #         continue

        #     path = pathlib.Path(frame.filename)
        #     name += f"__{path.stem}_{frame.lineno}"

        return name

    def get_node_name(
        self,
        kind,
        target,
        name,
        exclude_paths: Union[str, List[str]] = [
            "linfer/python",
            "/usr/",
            "/.local/",
            "/.vscode-server/",
        ],
    ) -> str:
        if kind not in ["call_function", "call_method"]:
            return name

        stack = inspect.stack()
        for frame in stack:
            if "eval_with_key" in frame.filename:
                return self.get_node_name_from_fxgraph(frame)

        return self.get_node_name_from_stack(stack, kind, target, name, exclude_paths)

    # override TraceBase's method
    def create_node(
        self,
        kind: str,
        target: Target,
        args: Tuple[Argument, ...],
        kwargs: Dict[str, Argument],
        name: Optional[str] = None,
        type_expr: Optional[Any] = None,
    ) -> Node:
        """
        Inserts a graph node given target, args, kwargs, and name.

        This method can be overridden to do extra checking, validation, or
        modification of values used in node creation. For example, one might
        want to disallow in-place operations from being recorded.
        """

        ## Hacky way to decide inplace ops
        if type(target) != str:
            name_target = target.__name__
        else:
            name_target = target

        allow_list = ["and_", "or_"]  # python  operator.and_,  operator.or_
        if (
            name_target[-1] == "_"
            and name_target[0] != "_"
            and not (name_target in allow_list)
            and kind != "placeholder"
        ):
            raise RuntimeError(
                f"Tried to trace mutable operation {name_target}. FX only supports functional code"
            )

        name = self.get_node_name(kind, target, name)
        node = self.graph.create_node(kind, target, args, kwargs, name, type_expr)
        return node
