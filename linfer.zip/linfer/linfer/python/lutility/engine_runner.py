from typing import Union, List, Optional
import os
from dataclasses import dataclass, asdict

from abc import ABCMeta, abstractmethod

import tensorrt as trt

import torch
import torch.nn as nn

from .trt_util import build_engine
from convertor.fx2trt.utils import torch_dtype_from_trt


class BackendConfig:
    @abstractmethod
    def get_all(self):
        return asdict(self)


@dataclass
class TRTBackendConfig(BackendConfig):
    max_workspace_size: int = 4096 * 1024 * 1024
    tf32: bool = True
    fp16: bool = False
    bf16: bool = False
    int8: bool = False
    fp8: bool = False
    sparse: bool = False
    timing_cache: str = None
    verbose: bool = False


class Backend(metaclass=ABCMeta):
    def __init__(
        self,
        testdir: str,
        model: nn.Module,
        input_data: Union[torch.Tensor, List[torch.Tensor]],
        backend_cfg: BackendConfig,
        input_names: Optional[List] = None,
        output_names: Optional[List] = None,
    ):
        self.testdir = testdir
        self.input_names = input_names
        self.output_names = output_names
        self.backend_cfg: BackendConfig = backend_cfg
        if isinstance(input_data, torch.Tensor):
            input_data = [input_data]

        assert isinstance(model, torch.nn.Module), "model must be a pytorch module"
        assert isinstance(input_data, list), "input_data must be a list"
        assert all(
            isinstance(t, torch.Tensor) for t in input_data
        ), "input_data must be a list of tensors"
        assert all(
            t.device.type == "cuda" for t in input_data
        ), "input_data must be a list of cuda tensors"
        self.input_data = [t.cuda().contiguous() for t in input_data]
        # copy input data for trt, because some pytorch operations are inplace
        self.input_data_for_trt = [t.detach().clone().contiguous() for t in self.input_data]

        model = model.cuda().eval()
        with torch.no_grad():
            self.expect_result = model(*self.input_data)
            if not isinstance(self.expect_result, (list, tuple)):
                self.expect_result = [self.expect_result]

        self.onnx_file = self.export_onnx(model, self.input_data_for_trt)

    def get_inputs_for_torch(self):
        return self.input_data

    def get_inputs_for_trt(self):
        return self.input_data_for_trt

    def get_test_workdir(self) -> str:
        # tmpdir = os.getenv("TMPDIR", "/tmp")
        # workdir = f"{tmpdir}/linfer_test"
        return self.testdir

    def export_onnx(self, model, input_data) -> None:
        workdir = self.get_test_workdir()
        os.makedirs(workdir, exist_ok=True)
        onnx_file = self.get_onnx_filepath()

        model_input = tuple(input_data)
        with torch.no_grad():
            torch.onnx.export(
                model,
                model_input,
                onnx_file,
                input_names=self.input_names,
                output_names=self.output_names,
                opset_version=12,
            )
        return onnx_file

    def get_onnx_filepath(self):
        workdir = self.get_test_workdir()
        os.makedirs(workdir, exist_ok=True)
        return f"{workdir}/test.onnx"

    def get_backend_config(self):
        return self.backend_cfg.get_all()

    @abstractmethod
    def run(self):
        pass


class TRTBackendRunner(Backend):
    def __init__(
        self,
        testdir: str,
        model: Union[nn.Module, str],
        input_data: Union[torch.Tensor, List[torch.Tensor]],
        backend_cfg: BackendConfig = TRTBackendConfig(),
        input_names: Optional[List] = None,
        output_names: Optional[List] = None,
    ):
        super().__init__(testdir, model, input_data, backend_cfg, input_names, output_names)

    def get_trt_engine_filepath(self):
        workdir = self.get_test_workdir()
        os.makedirs(workdir, exist_ok=True)
        return f"{workdir}/test.engine"

    # TODO dataclass
    def build_engine(self):
        _, engine = build_engine(
            self.onnx_file,
            max_ws=self.backend_cfg.max_workspace_size,
            tf32=self.backend_cfg.tf32,
            fp16=self.backend_cfg.fp16,
            bf16=self.backend_cfg.bf16,
            int8=self.backend_cfg.int8,
            fp8=self.backend_cfg.fp8,
            sparse=self.backend_cfg.sparse,
            timing_cache=self.backend_cfg.timing_cache,
            verbose=self.backend_cfg.verbose,
            input_in_order=self.input_data_for_trt,
            output_in_order=self.expect_result,
            save_engine_file=self.get_trt_engine_filepath(),
        )

        if self.backend_cfg.verbose:
            TRT_LOGGER = trt.Logger(trt.Logger.VERBOSE)
        else:
            TRT_LOGGER = trt.Logger(trt.Logger.WARNING)

        runtime = trt.Runtime(TRT_LOGGER)
        engine = runtime.deserialize_cuda_engine(engine)
        return engine

    def run_engine(self, engine, input_in_order, output_in_order):
        context = engine.create_execution_context()
        if hasattr(engine, "num_io_tensors"):
            bindings = [None] * engine.num_io_tensors
            input_idx = 0
            output_idx = 0
            for idx in range(engine.num_io_tensors):
                binding_name = engine.get_tensor_name(idx)
                if engine.get_tensor_mode(binding_name) == trt.TensorIOMode.INPUT:
                    bindings[idx] = input_in_order[input_idx].data_ptr()
                    input_idx += 1
                else:
                    bindings[idx] = output_in_order[output_idx].data_ptr()
                    output_idx += 1
            context.execute_v2(bindings=bindings)
        else:
            bindings = [None] * engine.num_bindings
            input_idx = 0
            output_idx = 0
            for idx in range(engine.num_bindings):
                binding_name = engine.get_binding_name(idx)
                if engine.binding_is_input(idx):
                    bindings[idx] = input_in_order[input_idx].data_ptr()
                    input_idx += 1
                else:
                    bindings[idx] = output_in_order[output_idx].data_ptr()
                    output_idx += 1
            context.execute_v2(bindings=bindings)

    def gen_tensors_for_outputs(self, trt_engine):
        outputs = []
        if hasattr(trt_engine, "num_io_tensors"):
            for idx in range(trt_engine.num_io_tensors):
                binding_name = trt_engine.get_tensor_name(idx)
                if trt_engine.get_tensor_mode(binding_name) == trt.TensorIOMode.OUTPUT:
                    shape = tuple(trt_engine.get_tensor_shape(binding_name))
                    dtype = torch_dtype_from_trt(trt_engine.get_tensor_dtype(binding_name))
                    output = torch.empty(
                        size=shape, dtype=dtype, device=torch.cuda.current_device()
                    )
                    outputs.append(output)
        else:
            for idx in range(trt_engine.num_bindings):
                if not trt_engine.binding_is_input(idx):
                    shape = tuple(trt_engine.get_binding_shape(idx))
                    dtype = torch_dtype_from_trt(trt_engine.get_binding_dtype(idx))
                    output = torch.empty(
                        size=shape, dtype=dtype, device=torch.cuda.current_device()
                    )
                    outputs.append(output)
        return outputs

    def run(self):
        # convert onnx to tensorrt engine
        trt_engine = self.build_engine()

        # gen output tensor
        actual_result = self.gen_tensors_for_outputs(trt_engine)

        # run the tensorrt engine and get result.
        self.run_engine(trt_engine, self.input_data_for_trt, actual_result)
        if len(actual_result) > 1:
            return self.expect_result, actual_result
        else:
            return self.expect_result[0], actual_result[0]
