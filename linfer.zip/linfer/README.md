## 拉取源码
* 以git submodule方式集成了几个依赖库，因此：
    * 从零拉源码：git clone --recursive ${repo_url}
    * 已有代码库：git submodule update --recursive

## 编译、上传与环境配置
### CMake编译
```已切换成conan编译，不再支持cmake编译。```

### 基于lmake的编译及conan包上传
```bash
# 进入编译环境
make [devcar|x86|orin|thor]

# 编译，打包（注：目前本地已不支持上传conna 包）
make && make package

### 环境配置
编译完成之后，在bashrc或zshrc中添加环境变量
export LINFER_ROOT_DIR=${path/to/linfer/root_dir}
export PYTHONPATH=${PYTHONPATH}:${LINFER_ROOT_DIR}:${LINFER_ROOT_DIR}/linfer/python:${LINFER_ROOT_DIR}/build/devcar/lib
```
或者使用whl包安装模式，[参考文档](https://lotuscars.feishu.cn/wiki/LbpVwmmlViCUJ4khudcc3piqnLh)
### 编译whl包
[编译whl包参考文档](https://lotuscars.feishu.cn/wiki/LbpVwmmlViCUJ4khudcc3piqnLh)

### 默认编译配置

| 平台      |  TRT版本    | Python Binding版本| 编译onnx算子 | TRT Plugin版本 |
| -------- | ----------- | ---------------- | ----------- | ------------- |
| Devcar  | 8.5.3.1      | Python 3.8       | 否          | V2            |
| X86     | 10.8.0.43    | Python 3.12      | 是          | V2 + V3       |
| ORIN    | 编译镜像内提供 | 不开启            | 否          | V2            |
| THOR    | 编译镜像内提供 | 不开启            | 否          | V2 + V3       |

* 配置TRT版本
```bash
# 在makefile中找到变量 LMAKE_TRT_VERSION
LMAKE_TRT_VERSION=OFF      # 关闭指定TRT版本，使用镜像内默认版本

# 指定编译时所使用的TRT版本，支持[8.5.3.1, 8.6.16, 10.8.0.43]
# 当选用8.5.3.1、8.6.16，默认使用编译镜像内的CUDA 11.3、CUDNN 8.6
# 当选用10.x，默认使用CUDA 12.8、CUDNN 9.10（在connafile中指定）
# 当选用10.x，开启PluginV3编译
# TODO 如果需要更灵活的配置，可以考虑将CUDA、CUDNN版本也作为变量传入
LMAKE_TRT_VERSION=8.5.3.1
```

* 配置Python Binding
```bash
# 在makefile中找到变量 LMAKE_PYTHON_VERSION
LMAKE_PYTHON_VERSION=OFF  # 关闭编译python binding
LMAKE_PYTHON_VERSION=3.8  # 开启编译python binding，并指定python版本
```

* 开启/关闭编译onnx算子
```bash
# 在makefile中找到变量 LMAKE_BUILD_WITH_ONNXRUNTIME_OP
LMAKE_BUILD_WITH_ONNXRUNTIME_OP=ON   # 开启编译 onnxruntime 算子
LMAKE_BUILD_WITH_ONNXRUNTIME_OP=OFF  # 关闭编译 onnxruntime 算子
```

* 开启/关闭链接 libtorch
```bash
# 在makefile中找到变量 LMAKE_BUILD_WITH_LIBTORCH
LMAKE_BUILD_WITH_LIBTORCH=ON   # 开启链接 libtorch
LMAKE_BUILD_WITH_LIBTORCH=OFF  # 关闭链接 libtorch
```

* 开启/关闭编译cupti_trace， 目前只支持x86和thor(要求cuda12)
```bash
# 在makefile中找到变量ENABLE_CUPTI 
ENABLE_CUPTI=ON   # 开启cupti_trace
ENABLE_CUPTI=OFF  # 关闭cupti_trace
```

## format python file
在python3.12下安装black、clang-format
```bash
#pip install black ==25.12.0
#pip install clang-format==21.1.8
sh code_format.sh
```

## 算子测试
### 安装依赖
```bash
pip install pytest==8.3.4
pip install pytest-xdist==3.6.1
```

### 执行CUDA算子测试
```
pytest -n 4 linfer/test/ops/cuda/ 
```

### 执行TensorRT插件测试
```
pytest -n 4 linfer/test/ops/trt
```

## 万能模型推理工具
### C++版本
对应代码：tools/linfer.cc
```bash
./bin/linfer_model --trt_engine   ${trt引擎文件路径}
                   --data_file   ${数据文件路径}  # 指定到输入文件或目录，支持numpy、safetensors、json格式
                   --warmup      # 预热次数；默认为0，即不开启预热
                   --runs_time   # 运行次数
                   --duration    # 持续时间（秒）
                   --save_dir    ${存储输出的路径}
                   # 指定输入输出的存储格式，支持numpy, safetensors.
                   # 当前这里用仅指定模型输入输出的存储格式
                   # 对于模型所加载的输入(即由data_file指定的输入)，仍可以是numpy、safetensors、json
                   --tensor_storage_format  # [npy, numpy, st, safetensors]
                   --silent     # 是否打印输出
```

* 样例:
```bash
# 输入数据
├── bevformer_construct
│   ├── lidar2img.npy
│   ├── mlvl_feats.npy


./bin/linfer_model --trt_engine  ./bevformer_construct.trt \
                   --data_file   ./bevformer_construct/ \
                   --silent      1 \
                   --warmup      10 \
                   --runs_time   10 \
                   --save_dir    ./bevformer_construct_save_dir
```

```bash
# 输入数据
├── bevformer_construct_inputs.safetensors


./bin/linfer_model --trt_engine  ./bevformer_construct.trt \
                   --data_file   ./bevformer_construct_inputs.safetensors \
                   --silent      1 \
                   --warmup      10 \
                   --runs_time   10 \
                   --save_dir    ./bevformer_construct_save_dir \
                   --tensor_storage_format safetensors
```


```bash
# 多engine测试，每个engine分配一个thread运行
../bin/linfer_model --trt_engine './../resnet50-v2-13.engine ./../limitation_speed.engine' \
                    --use_cuda_graph \
                    --memory_type managed \
                    --silent 1
```

### python(依赖numpy及pylinfer)
```bash
tools/linfer.py --trt_engine    ${trt引擎文件路径}
                --data_file     ${数据文件路径}
                --silent        # 关闭打印输出，默认打印输出
                --warmup        # 预热次数；默认为0，即不开启预热
                --runs_time     # 运行次数
                # 输入输出数据的存储路径
                # 当输入数据为json/numpy时，存储为numpy
                # 当输入数据为safetensors时，存储为safetensors
                --save_dir

# 样例
tools/linfer.py --trt_engine    ./lanegcn_replace_att.onnx.trt  \
                --data_file     ./data.json                     \
                --silent                                        \
                --warmup        10                              \
                --runs_time     1                               \
                --save_dir      ./lanegcn_inout_save_dir
```
### 使用cupti_trace
#### 设置环境变量
x86:
```
export CUDA_INJECTION64_PATH=/xxx/linfer/build/x86/lib/libcupti_trace_injection.so
export LD_LIBRARY_PATH=/usr/local/cuda/extras/CUPTI/lib64:$LD_LIBRARY_PATH

```

thor:
```
export CUDA_INJECTION64_PATH=/xxx/linfer/build/thor/lib/libcupti_trace_injection.so
```
#### 执行cuda程序
比如执行trt，执行完成后，在当前目录，生成trace.log文件。

