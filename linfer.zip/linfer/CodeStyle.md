# Git commit style
* use template: ${type} [${space}]: brief msg
* type:
    * feat: add new feature
    * refactor: refactor code
    * refine: small change for more robust, clean, simple, etc.
    * fix: fix bug
    * format: format code
    * perf: update code for performace
    * pub: publish version
    * update: update something
    * add: add something
* space:
    * util
    * ops
        * cpu
        * cuda
        * trt
    * lutility
    * convertor
        * fx2trt
        * rewriter
    * quantization
    * sparse
    * test
    * build
    * tools
        * onnx
        * example
        * deploy
        * quant
    * docs
    * config
* msg: use English
* example:
    * feat model.cuda: add new ops
    * format model.prediction: follow google style
    * fix ops.trt: seg-fault
    * update build: use C++14 instead of C++17
