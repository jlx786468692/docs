#!/bin/bash
# 文件路径: /home/peanut/Desktop/linfer/format_code.sh

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== 开始代码格式化 ===${NC}"

# 格式化 C++ 和 CUDA 文件
echo -e "${BLUE}格式化 C++/CUDA 文件...${NC}"
find ./linfer ./tools \
    -type f \( -name "*.cu" -o -name "*.cuh" -o -name "*.cpp" -o -name "*.cc" -o -name "*.c" -o -name "*.h" -o -name "*.hpp" \) -print \
| xargs -I {} clang-format -i "{}"
if [ $? -eq 0 ]; then
    echo -e "${GREEN}C++/CUDA 文件格式化成功!${NC}"
else
    echo -e "${RED}C++/CUDA 文件格式化失败!${NC}"
    exit 1
fi

# 格式化 Python 文件
echo -e "${BLUE}格式化 Python 文件...${NC}"
find ./ \
    -path ./tools/quant/third_party/perception_one_model -prune -o \
    -path ./build -prune -o \
    -type f -name "*.py" -print \
| xargs -I {} black -l 100 "{}"
if [ $? -eq 0 ]; then
    echo -e "${GREEN}Python 文件格式化成功!${NC}"
else
    echo -e "${RED}Python 文件格式化失败!${NC}"
    exit 1
fi

echo -e "${GREEN}=== 所有代码格式化完成 ===${NC}"
