import subprocess
import shutil
import json
import os

package_path = "linfer/python"
trt_plugin_name = "liblinfer.so"
extension_posix = "pylinfer"


def copy_lib(platform_machine):
    platform_lib_path = os.path.join("build", platform_machine, "package/lib")
    if os.path.exists(platform_lib_path):
        dst_path = os.path.join(package_path, "lib")
        os.makedirs(dst_path, exist_ok=True)
        shutil.copy(
            os.path.join(platform_lib_path, trt_plugin_name),
            os.path.join(dst_path, trt_plugin_name),
        )
        pylinfer_name = [i for i in os.listdir(platform_lib_path) if extension_posix in i]
        for i in pylinfer_name:
            shutil.copy(os.path.join(platform_lib_path, i), os.path.join(dst_path, i))
        print("copy lib from %s to %s" % (platform_lib_path, dst_path))
    else:
        raise RuntimeError("Not found so file, please make first")


def clean_lib():
    dst_path = os.path.join(package_path, "lib")
    setup_path = "build/lib"
    if os.path.exists(dst_path):
        shutil.rmtree(dst_path)

    if os.path.exists(setup_path):
        shutil.rmtree(setup_path)


def build(platform):
    arch = "linux_aarch64" if platform == "orin" else "linux_x86_64"
    copy_lib(platform)
    subprocess.run("python3 setup.py bdist_wheel --plat-name=%s" % arch, shell=True)
    clean_lib()


if __name__ == "__main__":
    build("orin")
    build("devcar")
