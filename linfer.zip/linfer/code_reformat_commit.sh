#!/bin/bash
# 文件路径: /home/peanut/Desktop/linfer/format_code.sh
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
echo -e "${BLUE}=== 开始代码格式化（仅 Git 修改文件） ===${NC}"
# 获取 git 修改或新增的文件（暂存 + 工作区）
modified_files=$( (git diff --cached --name-only; git diff --name-only) | sort -u )
# 过滤 C++/CUDA 文件
cpp_files=$(echo "$modified_files" | grep -E '\.(cu|cuh|cpp|cc|c|h|hpp)$')
if [ -n "$cpp_files" ]; then
    echo -e "${BLUE}以下 C++/CUDA 文件将被格式化：${NC}"
    echo "$cpp_files" | sed 's/^/  - /'
    echo -e "${BLUE}格式化 C++/CUDA 文件...${NC}"
    echo "$cpp_files" | xargs -r clang-format -i
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}C++/CUDA 文件格式化成功!${NC}"
    else
        echo -e "${RED}C++/CUDA 文件格式化失败!${NC}"
        exit 1
    fi
else
    echo -e "${BLUE}没有需要格式化的 C++/CUDA 文件。${NC}"
fi
# 过滤 Python 文件
py_files=$(echo "$modified_files" | grep -E '\.py$')
if [ -n "$py_files" ]; then
    echo -e "${BLUE}以下 Python 文件将被格式化：${NC}"
    echo "$py_files" | sed 's/^/  - /'
    echo -e "${BLUE}格式化 Python 文件...${NC}"
    echo "$py_files" | xargs -r black -l 100
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Python 文件格式化成功!${NC}"
    else
        echo -e "${RED}Python 文件格式化失败!${NC}"
        exit 1
    fi
else
    echo -e "${BLUE}没有需要格式化的 Python 文件。${NC}"
fi
echo -e "${GREEN}=== Git 修改文件格式化完成 ===${NC}"
