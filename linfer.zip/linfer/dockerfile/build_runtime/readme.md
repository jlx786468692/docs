# Dockfile 说明文档
- 提供了2种生成docker image的方法，该image主要用在自动化测试系统的环境构建上。
## 方法1 (以这个为主)
1. 在nvidia/cuda:11.4.3-runtime-ubuntu20.04基础上，构建含有ubuntu、cuda、python和基础库的镜像。
- docker file 目录下，cp Dockerfile_step1 Dockerfile；执行：docker build -t myenv_ub20.04_cu11.4.3_py3.8:latest . 
2. 在myenv_ub20.04_cu11.4.3_py3.8:latest基础上，构建python第三方包
- docker file 目录下，cp Dockerfile_step2 Dockerfile；执行：docker build -t myenv_ub20.04_cu11.4.3_py3.8_torch_trt:latest . 
## 方法2 （后续未更新）
1. 在nvidia/cuda:11.4.3-runtime-ubuntu20.04基础上，构建含有ubuntu、cuda、python和基础库和python第三方包基础库。
- docker file 目录下，cp Dockerfile_zerostep Dockerfile；执行：docker build -t myenv_ub20.04_cu11.4.3_py3.8_torch_trt:latest . 