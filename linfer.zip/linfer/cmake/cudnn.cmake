
if (DEFINED NVIDIA_CUDNN_LIB_DIR AND DEFINED NVIDIA_CUDNN_INCLUDE_DIR)
    set(LIB_DIRS ${NVIDIA_CUDNN_LIB_DIR})
    set(INC_DIRS ${NVIDIA_CUDNN_INCLUDE_DIR})
elseif (DEFINED ENV{CUDNN_ROOT_DIR})
    message(WARNING "not set NVIDIA_CUDNN_LIB_DIR or NVIDIA_CUDNN_INCLUDE_DIR, try to use ENV{CUDNN_ROOT_DIR}")
    set(DNN_ROOT_DIR $ENV{CUDNN_ROOT_DIR})
    set(LIB_DIRS ${DNN_ROOT_DIR}/lib64)
    set(INC_DIRS ${DNN_ROOT_DIR}/include)
else()
    message(FATAL_ERROR "NOT set ENV{CUDNN_ROOT_DIR}")
endif()

message(STATUS LIB_DIRS=${LIB_DIRS})

include_directories(${INC_DIRS})
link_directories(${LIB_DIRS})

message(STATUS "NVIDIA_CUDNN_LIB_DIR: ${LIB_DIRS}")
message(STATUS "NVIDIA_CUDNN_INCLUDE_DIR: ${INC_DIRS}")

assert_file_exist("libcudnn.so" ${LIB_DIRS})
assert_file_exist("cudnn.h" ${INC_DIRS})