
if (DEFINED NVIDIA_CUDA_LIB_DIR AND DEFINED NVIDIA_CUDA_INCLUDE_DIR)
    set(LIB_DIRS ${NVIDIA_CUDA_LIB_DIR})
    set(INC_DIRS ${NVIDIA_CUDA_INCLUDE_DIR})
elseif (DEFINED ENV{CUDA_ROOT_DIR})
    message(WARNING "not set NVIDIA_CUDA_LIB_DIR or NVIDIA_CUDA_INCLUDE_DIR, try to use ENV{CUDA_ROOT_DIR}")
    set(CU_ROOT_DIR $ENV{CUDA_ROOT_DIR})
    set(LIB_DIRS ${CU_ROOT_DIR}/lib64)
    set(INC_DIRS ${CU_ROOT_DIR}/include)
    include_directories(${INC_DIRS})
    link_directories(${LIB_DIRS})
else()
    message(FATAL_ERROR "NOT set ENV{CUDA_ROOT_DIR}")
endif()

message(STATUS "NVIDIA_CUDA_LIB_DIR: ${LIB_DIRS}")
message(STATUS "NVIDIA_CUDA_INCLUDE_DIR: ${INC_DIRS}")

assert_file_exist("libcudart.so" ${LIB_DIRS})
assert_file_exist("cuda.h" ${INC_DIRS})

############################################################################################
set(GPU_ARCHS ${LINFER_GPU_ARCHS} CACHE STRING "GPU ARCH" FORCE)
# set(CMAKE_CUDA_ARCHITECTURES ${GPU_ARCHS})

# Generate SASS for each architecture
foreach(arch ${GPU_ARCHS})
    set(GENCODES "${GENCODES} -gencode arch=compute_${arch},code=sm_${arch}")
endforeach()
# Generate PTX for the last architecture in the list.
list(GET GPU_ARCHS -1 LATEST_SM)
set(GENCODES "${GENCODES} -gencode arch=compute_${LATEST_SM},code=compute_${LATEST_SM}")
set(CMAKE_CUDA_FLAGS "${CMAKE_CUDA_FLAGS} -Xcompiler -Wno-deprecated-declarations")

if(${LINFER_NVCC_LINEINFO} MATCHES "ON")
    set(CMAKE_CUDA_FLAGS "${CMAKE_CUDA_FLAGS} --generate-line-info")
endif()


# only for cmake 3.18+
function(apply_cuda_gencode_flags TARGET)
    set(ARCHS_ENABLED ${LINFER_GPU_ARCHS})

    set(__CMAKE_CUDA_ARCHS)
    foreach(ARCH ${ARCHS_ENABLED})
        set(CODES)
        list(APPEND __CMAKE_CUDA_ARCHS ${ARCH}-real)
        list(APPEND __CMAKE_CUDA_ARCHS ${ARCH}-virtual)

        list(JOIN CODES "," CODES_STR)
    endforeach()

    set_property(TARGET ${TARGET} PROPERTY CUDA_ARCHITECTURES ${__CMAKE_CUDA_ARCHS})
endfunction()