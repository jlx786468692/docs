#
# Copyright (c) 2021, NVIDIA CORPORATION. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
function (set_ifndef variable value)
  if(NOT DEFINED ${variable})
    set(${variable} ${value} PARENT_SCOPE)
  endif()
endfunction()

function(assert_file_exist filename)
    set(FILE_EXIST FALSE)
    list(SUBLIST ARGV 1 -1 DIRS)
    foreach(DIR ${DIRS})
        message("DIR: " ${DIR})
        message("filepath: " "${DIR}/${filename}")
        if (EXISTS "${DIR}/${filename}")
            set(FILE_EXIST TRUE)
            break()
        endif()
    endforeach()

    if (NOT ${FILE_EXIST})
        message(FATAL_ERROR "${filename} NOT EXIST IN DIR: [${DIRS}]")
    endif()
endfunction()
