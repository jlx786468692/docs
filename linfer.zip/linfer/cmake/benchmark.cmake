cmake_minimum_required(VERSION 3.10)

if (NOT EXISTS "${PROJECT_SOURCE_DIR}/thirdparty/benchmark/CMakeLists.txt")
  message(FATAL_ERROR
          "Cannot find thirdparty/benchmark directory that's needed to "
          "build tests. If you use git, make sure you have cloned submodules:\n"
          "  git submodule update --init --recursive\n")
endif()

set(benchmark_source_dir "${PROJECT_SOURCE_DIR}/thirdparty/benchmark")
include_directories(
  ${benchmark_source_dir}/include
)